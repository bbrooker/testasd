package com.daym.clientproxy;

import com.daym.serverproxy.*;
import com.daym.render.*;
import com.daym.registry.*;
import com.daym.handlers.*;
import com.daym.handlers.sound.*;
import java.util.*;
import com.daym.*;
import net.minecraft.client.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import com.daym.config.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;

public class ClientProxy extends CommonProxy
{
    public static RenderSetup daym_baccf3380;
    public static RenderRegistry daym_d8c0b6d10;
    public static ModelRegistry daym_b00293de0;
    public static TextureRegistry daym_a9db75e40;
    public static ServerListHandler daym_6bf6ace50;
    public static boolean daym_72efc9900;
    public static int daym_1227f65d0;
    public static LoopingSound daym_b7fb94700;
    public static HashMap<String, LoopingSound> daym_12f37d010;
    public static boolean daym_4fa0d23c0;
    public static int mouseX;
    public static int mouseY;
    public static byte daym_f4e660b80;
    
    public ClientProxy() {
        ClientProxy.daym_d8c0b6d10 = new RenderRegistry();
        ClientProxy.daym_a9db75e40 = new TextureRegistry();
        ClientProxy.daym_b00293de0 = new ModelRegistry();
        ClientProxy.daym_6bf6ace50 = new ServerListHandler();
        ClientProxy.daym_baccf3380 = new RenderSetup(DayM.getInstance());
    }
    
    @Override
    public boolean isSinglePlayer() {
        return Minecraft.func_71410_x().func_71356_B();
    }
    
    public static EntityPlayer daym_281cc4bf0(final MessageContext ctx) {
        return (EntityPlayer)Minecraft.func_71410_x().field_71439_g;
    }
    
    public static void playerEvent(final int msgID, final Entity entity) {
        if (entity instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)entity;
            final Minecraft mc = Minecraft.func_71410_x();
            if (msgID == 0 && mc.field_71439_g != null && mc.field_71439_g == player) {
                DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerSkin(0, DayMConfig.daym_d836addc0, DayMConfig.daym_8eb8ec9d0, mc.field_71439_g.func_110124_au().toString()));
            }
            if (msgID == 1) {
                DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerSkin(2, DayMConfig.daym_d836addc0, DayMConfig.daym_8eb8ec9d0, mc.field_71439_g.func_110124_au().toString()));
            }
        }
    }
    
    public static int getForcedView(final Minecraft mc) {
        if (ClientProxy.daym_f4e660b80 == 1) {
            return 0;
        }
        if (ClientProxy.daym_f4e660b80 == 2) {
            return Math.max(1, mc.field_71474_y.field_74320_O);
        }
        return mc.field_71474_y.field_74320_O;
    }
    
    static {
        ClientProxy.daym_72efc9900 = false;
        ClientProxy.daym_1227f65d0 = 0;
        ClientProxy.daym_b7fb94700 = null;
        ClientProxy.daym_12f37d010 = new HashMap<String, LoopingSound>();
        ClientProxy.daym_4fa0d23c0 = false;
        ClientProxy.mouseX = 0;
        ClientProxy.mouseY = 0;
        ClientProxy.daym_f4e660b80 = 0;
    }
}
