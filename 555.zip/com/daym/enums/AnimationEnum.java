package com.daym.enums;

import com.daym.render.*;

public enum AnimationEnum
{
    ak47_shoot(new AnimKeyframe[] { new AnimKeyframe(-0.7f, -0.7f, 0.01f, 0.01f, 0.01f, 0.01f, 3.5f, 0.013f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, false, false, false) }), 
    ak47_zoom(new AnimKeyframe[] { new AnimKeyframe(-1.4791667f, -0.3333334f, -1.9383334f, 0.0f, 0.6510376f, -5.208331f, -2.6041687f, 0.001f, false, false, true), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.001f, false, false, false) }), 
    ak47_reload(new AnimKeyframe[] { new AnimKeyframe(0.0f, -1.5f, 0.0f, 0.0f, 0.0f, 30.0f, 25.0f, 4.0E-4f, false, false, false), new AnimKeyframe(1.0f, -1.4f, -3.5f, 0.0f, 0.0f, -25.0f, 15.0f, 5.0E-4f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.003f, false, false, false) }), 
    ak47_reload_lh(new AnimKeyframe[] { new AnimKeyframe(-0.86f, -1.08f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false), new AnimKeyframe(-0.8f, -1.0f, -0.86f, 0.0f, 9.78f, 0.0f, -58.6f, 0.0055f, false, false, false), new AnimKeyframe(-0.86f, -1.08f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 5.5E-4f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false) }), 
    ak47_reload_rh(new AnimKeyframe[] { new AnimKeyframe(1.3f, 0.8f, 0.6f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false), new AnimKeyframe(1.52f, 1.52f, 0.43f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false), new AnimKeyframe(0.65f, 1.08f, 0.43f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0045f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false) }), 
    rem700_shoot(new AnimKeyframe[] { new AnimKeyframe(1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 10.0f, 0.01f, false, false, false) }), 
    rem700_zoom(new AnimKeyframe[] { new AnimKeyframe(-3.05f, -1.04f, -1.832f, 0.0f, 1.2f, -4.0f, 0.0f, 5.0E-4f, false, false, true), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 5.0E-4f, false, false, false) }), 
    rem700_reload_lh(new AnimKeyframe[] { new AnimKeyframe(-0.615f, -0.615f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false), new AnimKeyframe(-0.8f, -1.0f, -0.86f, 0.0f, 9.78f, 0.0f, -58.6f, 0.0055f, false, false, false), new AnimKeyframe(-0.615f, -0.615f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 5.5E-4f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false) }), 
    rem700_reload_rh(new AnimKeyframe[] { new AnimKeyframe(-0.14814815f, 1.0123456f, 0.28728887f, 0.0f, 0.0f, 0.0f, 0.0f, 0.002f, false, false, false), new AnimKeyframe(-0.75f, 0.59350663f, 0.27272725f, 0.0f, 0.0f, 0.0f, 0.0f, 0.002f, false, false, false), new AnimKeyframe(-0.14814815f, 1.0123456f, 0.28728887f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0015f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.002f, false, false, false) }), 
    rem700_bolt(new AnimKeyframe[] { new AnimKeyframe(0.6875f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 5.0E-4f, false, false, true), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.002f, false, false, false) }), 
    makarov_zoom(new AnimKeyframe[] { new AnimKeyframe(-1.6551f, 0.01724f, -1.431034f, 0.0f, 2.1551f, -4.3103f, -2.1551f, 0.001f, false, false, true), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 5.0E-4f, false, false, false) }), 
    makarov_reload(new AnimKeyframe[] { new AnimKeyframe(0.0f, 0.0416666f, 0.25f, 0.0f, 15.625f, 1.953125f, 17.903645f, 0.001f, false, false, true), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.003f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.003f, false, false, false) }), 
    makarov_reload_lh(new AnimKeyframe[] { new AnimKeyframe(-0.86f, -1.08f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false), new AnimKeyframe(-0.8f, -1.0f, -0.86f, 0.0f, 9.78f, 0.0f, -58.6f, 0.0055f, false, false, false), new AnimKeyframe(-0.86f, -1.08f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 5.5E-4f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false) }), 
    makarov_reload_lh2(new AnimKeyframe[] { new AnimKeyframe(-0.2083333f, 0.7395834f, -0.2395833f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false), new AnimKeyframe(-0.7291666f, 0.4479166f, -0.1666667f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false), new AnimKeyframe(-0.2083333f, 0.7395834f, -0.2395833f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0045f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0035f, false, false, false) }), 
    reset(new AnimKeyframe[] { new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.002f, false, true, false) }), 
    global_sprint(new AnimKeyframe[] { new AnimKeyframe(-0.21621615f, -0.4594594f, 1.756757f, 0.0f, -49.831085f, 40.540543f, 18.581076f, 0.001f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0015f, false, false, false) }), 
    global_sprint_handgun(new AnimKeyframe[] { new AnimKeyframe(0.0f, -1.41f, 0.0f, 0.0f, 0.0f, 0.0f, 48.38f, 0.001f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0015f, false, false, false) }), 
    global_viewgun(new AnimKeyframe[] { new AnimKeyframe(-0.42854f, 0.24979f, 0.96458f, 0.0f, -18.9732f, 33.4823f, 5.5803f, 4.5E-4f, false, false, false), new AnimKeyframe(-0.42857f, -1.5f, -0.0714f, 0.0f, -18.973f, 14.508f, 24.553f, 4.5E-4f, false, false, false), new AnimKeyframe(3.2496f, -2.9976f, -1.9996f, 0.0f, 0.0f, -54.688f, 39.062f, 4.5E-4f, false, false, false), new AnimKeyframe(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.003f, false, false, false) });
    
    public AnimKeyframe[] animkey;
    
    private AnimationEnum(final AnimKeyframe[] akf) {
        this.animkey = new AnimKeyframe[16];
        int i = 0;
        for (final AnimKeyframe ak : akf) {
            this.animkey[i] = ak;
            ++i;
        }
    }
}
