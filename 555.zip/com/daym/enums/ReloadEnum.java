package com.daym.enums;

public enum ReloadEnum
{
    ak47(5, 13, 27, 6, 45, 75, 80, 89, 95), 
    rem700(5, 13, 27, 6, 45, 65, 75, 93, 99), 
    makarov(5, 13, 27, 6, 45, 75, 80, 89, 95);
    
    public int target0;
    public int target1;
    public int target2;
    public int target2_delay;
    public int target3;
    public int target4;
    public int target5;
    public int target6;
    public int target7;
    
    private ReloadEnum(final int t0, final int t1, final int t2, final int t2d, final int t3, final int t4, final int t5, final int t6, final int t7) {
        this.target0 = 0;
        this.target1 = 0;
        this.target2 = 0;
        this.target2_delay = 0;
        this.target3 = 0;
        this.target4 = 0;
        this.target5 = 0;
        this.target6 = 0;
        this.target7 = 0;
        this.target0 = t0;
        this.target1 = t1;
        this.target2 = t2;
        this.target2_delay = t2d;
        this.target3 = t3;
        this.target4 = t4;
        this.target5 = t5;
        this.target6 = t6;
        this.target7 = t7;
    }
}
