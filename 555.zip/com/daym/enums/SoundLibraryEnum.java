package com.daym.enums;

public enum SoundLibraryEnum
{
    ak47(new DayMSoundEnum[] { DayMSoundEnum.ak47_shoot, DayMSoundEnum.ak47_chamber, DayMSoundEnum.ak47_dryfire, DayMSoundEnum.ak47_insert_mag, DayMSoundEnum.ak47_remove_mag }), 
    rem700(new DayMSoundEnum[] { DayMSoundEnum.rem700_shoot, DayMSoundEnum.ak47_chamber, DayMSoundEnum.ak47_dryfire, DayMSoundEnum.ak47_insert_mag, DayMSoundEnum.ak47_remove_mag }), 
    makarov(new DayMSoundEnum[] { DayMSoundEnum.makarov_shoot, DayMSoundEnum.makarov_chamber, DayMSoundEnum.makarov_dryfire, DayMSoundEnum.makarov_insert_mag, DayMSoundEnum.ak47_remove_mag });
    
    public DayMSoundEnum[] sounds;
    
    private SoundLibraryEnum(final DayMSoundEnum[] dse) {
        this.sounds = new DayMSoundEnum[8];
        this.sounds = dse;
    }
}
