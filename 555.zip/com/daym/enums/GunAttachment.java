package com.daym.enums;

public enum GunAttachment
{
    ak47_reddot(0, 0.2f, 0.0f, -0.43f, true), 
    rem700_scope(1, 0.0f, 0.0f, 0.0f, true);
    
    public int id;
    public float x;
    public float y;
    public float z;
    public boolean doesOffset;
    
    private GunAttachment(final int i, final float xx, final float yy, final float zz, final boolean dos) {
        this.doesOffset = false;
        this.id = i;
        this.x = xx;
        this.y = yy;
        this.z = zz;
        this.doesOffset = dos;
    }
    
    public static GunAttachment getByID(final int id) {
        if (id == 0) {
            return GunAttachment.ak47_reddot;
        }
        if (id == 1) {
            return GunAttachment.rem700_scope;
        }
        return null;
    }
}
