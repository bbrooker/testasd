package com.daym.enums;

import com.daym.*;

public enum DayMSoundEnum
{
    ak47_shoot(0, "ak47_shoot_echo"), 
    ak47_chamber(1, "ak47_chamber"), 
    ak47_dryfire(2, "ak47_dryfire"), 
    ak47_insert_mag(3, "ak47_insert_mag"), 
    ak47_remove_mag(4, "ak47_remove_mag"), 
    rem700_shoot(5, "rem700_shoot"), 
    makarov_shoot(6, "makarov_shoot"), 
    makarov_chamber(7, "makarov_chamber"), 
    makarov_dryfire(8, "makarov_dryfire"), 
    makarov_insert_mag(9, "makarov_insert_mag");
    
    public int id;
    public String name;
    
    private DayMSoundEnum(final int i, final String n) {
        this.id = i;
        this.name = n;
        DayM.sounds.add(this);
    }
}
