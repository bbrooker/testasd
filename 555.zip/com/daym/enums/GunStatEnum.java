package com.daym.enums;

import net.minecraft.item.*;
import com.daym.registry.*;

public enum GunStatEnum
{
    ak47(0, true, 4, 5.0f, 57, 32, 0.8f, 3.0, new Item[] { ItemRegistry.mag_ak47 }, ReloadEnum.ak47, SoundLibraryEnum.ak47), 
    rem700(1, false, 5, 10.0f, 88, 42, 1.2f, 4.0, new Item[] { ItemRegistry.mag_rem700 }, ReloadEnum.rem700, SoundLibraryEnum.rem700), 
    makarov(2, false, 2, 4.0f, 42, 30, 0.6f, 1.5, new Item[] { ItemRegistry.mag_makarov }, ReloadEnum.makarov, SoundLibraryEnum.makarov);
    
    public int delayFireSpeed;
    public int gunID;
    public boolean isAutomatic;
    public float recoil;
    public int reloadTime;
    public int unloadTime;
    public float bulletSpeed;
    public double bulletDamage;
    public SoundLibraryEnum soundLib;
    public ReloadEnum reloadStat;
    public Item[] magazines;
    
    private GunStatEnum(final int i, final boolean ia, final int dfs, final float rec, final int reltime, final int unltime, final float bspeed, final double bdam, final Item[] mags, final ReloadEnum rle, final SoundLibraryEnum sle) {
        this.delayFireSpeed = 5;
        this.isAutomatic = false;
        this.recoil = 2.0f;
        this.magazines = new Item[8];
        this.gunID = i;
        this.isAutomatic = ia;
        this.delayFireSpeed = dfs;
        this.recoil = rec;
        this.reloadTime = reltime;
        this.soundLib = sle;
        this.magazines = mags;
        this.reloadStat = rle;
        this.unloadTime = unltime;
        this.bulletSpeed = bspeed;
        this.bulletDamage = bdam;
    }
    
    public static boolean isMagazine(final GunStatEnum gse, final Item mag) {
        for (int i = 0; i < gse.magazines.length; ++i) {
            if (gse.magazines[i] == mag) {
                return true;
            }
        }
        return false;
    }
    
    public static GunStatEnum getStatFromGun(final String gun) {
        int n = -1;
        if (gun.toLowerCase().contains("gid_")) {
            final String ids = gun.toLowerCase().replace("gid_", "");
            n = Integer.parseInt(ids);
        }
        if (gun.toLowerCase().contains("ak47") || n == 0) {
            return GunStatEnum.ak47;
        }
        if (gun.toLowerCase().contains("rem700") || n == 1) {
            return GunStatEnum.rem700;
        }
        if (gun.toLowerCase().contains("makarov") || n == 2) {
            return GunStatEnum.makarov;
        }
        return GunStatEnum.ak47;
    }
}
