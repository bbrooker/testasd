package com.daym.ai;

import net.minecraft.entity.ai.*;
import net.minecraft.command.*;
import net.minecraft.entity.*;
import java.util.*;

public class AINearestAttackableTargetDayM extends EntityAITarget
{
    private final Class targetClass;
    private final int targetChance;
    private final Sorter theNearestAttackableTargetSorter;
    private final IEntitySelector targetEntitySelector;
    private EntityLivingBase targetEntity;
    
    public AINearestAttackableTargetDayM(final EntityCreature p_i1663_1_, final Class p_i1663_2_, final int p_i1663_3_, final boolean p_i1663_4_) {
        this(p_i1663_1_, p_i1663_2_, p_i1663_3_, p_i1663_4_, false);
    }
    
    public AINearestAttackableTargetDayM(final EntityCreature p_i1664_1_, final Class p_i1664_2_, final int p_i1664_3_, final boolean p_i1664_4_, final boolean p_i1664_5_) {
        this(p_i1664_1_, p_i1664_2_, p_i1664_3_, p_i1664_4_, p_i1664_5_, null);
    }
    
    public AINearestAttackableTargetDayM(final EntityCreature p_i1665_1_, final Class p_i1665_2_, final int p_i1665_3_, final boolean p_i1665_4_, final boolean p_i1665_5_, final IEntitySelector p_i1665_6_) {
        super(p_i1665_1_, p_i1665_4_, p_i1665_5_);
        this.targetClass = p_i1665_2_;
        this.targetChance = p_i1665_3_;
        this.theNearestAttackableTargetSorter = new Sorter((Entity)p_i1665_1_);
        this.func_75248_a(1);
        this.targetEntitySelector = (IEntitySelector)new IEntitySelector() {
            public boolean func_82704_a(final Entity p_isEntityApplicable_1_) {
                return p_isEntityApplicable_1_ instanceof EntityLivingBase && AINearestAttackableTargetDayM.this.field_75299_d.func_70685_l(p_isEntityApplicable_1_) && (p_i1665_6_ == null || p_i1665_6_.func_82704_a(p_isEntityApplicable_1_)) && AINearestAttackableTargetDayM.access$100(AINearestAttackableTargetDayM.this, (EntityLivingBase)p_isEntityApplicable_1_, false);
            }
        };
    }
    
    public boolean func_75250_a() {
        if (this.targetChance > 0 && this.field_75299_d.func_70681_au().nextInt(this.targetChance) != 0) {
            return false;
        }
        final double d = this.func_111175_f();
        final List localList = this.field_75299_d.field_70170_p.func_82733_a(this.targetClass, this.field_75299_d.field_70121_D.func_72314_b(d, 4.0, d), this.targetEntitySelector);
        Collections.sort((List<Object>)localList, this.theNearestAttackableTargetSorter);
        if (localList.isEmpty()) {
            return false;
        }
        this.targetEntity = localList.get(0);
        return true;
    }
    
    public void func_75249_e() {
        this.field_75299_d.func_70624_b(this.targetEntity);
        super.func_75249_e();
    }
    
    static /* synthetic */ boolean access$100(final AINearestAttackableTargetDayM x0, final EntityLivingBase x1, final boolean x2) {
        return x0.func_75296_a(x1, x2);
    }
    
    public static class Sorter implements Comparator
    {
        private final Entity theEntity;
        
        @Override
        public int compare(final Object p_compare_1_, final Object p_compare_2_) {
            return this.compare((Entity)p_compare_1_, (Entity)p_compare_2_);
        }
        
        public Sorter(final Entity p_i1662_1_) {
            this.theEntity = p_i1662_1_;
        }
        
        public int compare(final Entity p_compare_1_, final Entity p_compare_2_) {
            final double d1 = this.theEntity.func_70068_e(p_compare_1_);
            final double d2 = this.theEntity.func_70068_e(p_compare_2_);
            if (d1 < d2) {
                return -1;
            }
            if (d1 > d2) {
                return 1;
            }
            return 0;
        }
    }
}
