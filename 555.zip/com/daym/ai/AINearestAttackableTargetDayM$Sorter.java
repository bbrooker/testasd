package com.daym.ai;

import java.util.*;
import net.minecraft.entity.*;

public static class Sorter implements Comparator
{
    private final Entity theEntity;
    
    @Override
    public int compare(final Object p_compare_1_, final Object p_compare_2_) {
        return this.compare((Entity)p_compare_1_, (Entity)p_compare_2_);
    }
    
    public Sorter(final Entity p_i1662_1_) {
        this.theEntity = p_i1662_1_;
    }
    
    public int compare(final Entity p_compare_1_, final Entity p_compare_2_) {
        final double d1 = this.theEntity.func_70068_e(p_compare_1_);
        final double d2 = this.theEntity.func_70068_e(p_compare_2_);
        if (d1 < d2) {
            return -1;
        }
        if (d1 > d2) {
            return 1;
        }
        return 0;
    }
}
