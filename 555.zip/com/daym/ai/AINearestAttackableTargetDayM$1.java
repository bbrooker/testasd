package com.daym.ai;

import net.minecraft.command.*;
import net.minecraft.entity.*;

class AINearestAttackableTargetDayM$1 implements IEntitySelector {
    final /* synthetic */ IEntitySelector val$p_i1665_6_;
    
    public boolean func_82704_a(final Entity p_isEntityApplicable_1_) {
        return p_isEntityApplicable_1_ instanceof EntityLivingBase && AINearestAttackableTargetDayM.access$000(AINearestAttackableTargetDayM.this).func_70685_l(p_isEntityApplicable_1_) && (this.val$p_i1665_6_ == null || this.val$p_i1665_6_.func_82704_a(p_isEntityApplicable_1_)) && AINearestAttackableTargetDayM.access$100(AINearestAttackableTargetDayM.this, (EntityLivingBase)p_isEntityApplicable_1_, false);
    }
}