package com.daym.extended;

import net.minecraftforge.common.*;
import net.minecraft.entity.player.*;
import com.daym.inventory.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.*;
import net.minecraft.world.*;
import com.daym.serverproxy.*;
import com.daym.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;

public class ExtendedPlayer implements IExtendedEntityProperties
{
    public static final String EXT_PROP_NAME = "ExtendedPlayer";
    private final EntityPlayer player;
    private int maxMana;
    public PlayerInventoryDayM inventory;
    public static final int MANA_WATCHER = 20;
    
    public ExtendedPlayer(final EntityPlayer player) {
        this.inventory = new PlayerInventoryDayM();
        this.player = player;
        this.player.func_70096_w().func_75682_a(20, (Object)this.maxMana);
    }
    
    public static final void register(final EntityPlayer player) {
        player.registerExtendedProperties("ExtendedPlayer", (IExtendedEntityProperties)new ExtendedPlayer(player));
    }
    
    public static ExtendedPlayer get(final EntityPlayer player) {
        return (ExtendedPlayer)player.getExtendedProperties("ExtendedPlayer");
    }
    
    public void saveNBTData(final NBTTagCompound compound) {
        final NBTTagCompound properties = new NBTTagCompound();
        this.inventory.writeToNBT(properties);
        properties.func_74768_a("CurrentMana", this.player.func_70096_w().func_75679_c(20));
        properties.func_74768_a("MaxMana", this.maxMana);
        compound.func_74782_a("ExtendedPlayer", (NBTBase)properties);
    }
    
    public void loadNBTData(final NBTTagCompound compound) {
        final NBTTagCompound properties = (NBTTagCompound)compound.func_74781_a("ExtendedPlayer");
        this.inventory.readFromNBT(properties);
        this.player.func_70096_w().func_75692_b(20, (Object)properties.func_74762_e("CurrentMana"));
        this.maxMana = properties.func_74762_e("MaxMana");
    }
    
    public void init(final Entity entity, final World world) {
    }
    
    public final boolean consumeMana(final int amount) {
        int mana = this.player.func_70096_w().func_75679_c(20);
        final boolean sufficient = amount <= mana;
        mana -= ((amount < mana) ? amount : mana);
        this.player.func_70096_w().func_75692_b(20, (Object)mana);
        return sufficient;
    }
    
    public final void replenishMana() {
        this.player.func_70096_w().func_75692_b(20, (Object)this.maxMana);
    }
    
    public final int getCurrentMana() {
        return this.player.func_70096_w().func_75679_c(20);
    }
    
    public final void setCurrentMana(final int amount) {
        this.player.func_70096_w().func_75692_b(20, (Object)((amount < this.maxMana) ? amount : this.maxMana));
    }
    
    public static final String getSaveKey(final EntityPlayer player) {
        return player.func_70005_c_() + ":" + "ExtendedPlayer";
    }
    
    public static final void daym_698e99d30(final EntityPlayer player) {
        final ExtendedPlayer playerData = get(player);
        final NBTTagCompound savedData = CommonProxy.getEntityData(getSaveKey(player));
        if (savedData != null) {
            playerData.loadNBTData(savedData);
        }
        DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_SyncPlayerProps(0, player));
    }
    
    public static void daym_2c5f87020(final EntityPlayer player) {
        try {
            final ExtendedPlayer playerData = get(player);
            final NBTTagCompound savedData = new NBTTagCompound();
            playerData.saveNBTData(savedData);
            CommonProxy.storeEntityData(getSaveKey(player), savedData);
        }
        catch (Exception ex) {}
    }
}
