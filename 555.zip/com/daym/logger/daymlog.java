package com.daym.logger;

public class daymlog
{
    public static void out(final Object o) {
        final StackTraceElement[] trace = Thread.currentThread().getStackTrace();
        try {
            System.out.println("[DayM] " + trace[2].getClassName() + "|" + trace[2].getMethodName() + " (" + trace[2].getLineNumber() + ") : " + o);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
