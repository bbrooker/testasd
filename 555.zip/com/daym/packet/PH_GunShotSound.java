package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.client.*;
import com.daym.handlers.*;

public class PH_GunShotSound implements IMessageHandler<MSG_GunShotSound, IMessage>
{
    public IMessage onMessage(final MSG_GunShotSound message, final MessageContext ctx) {
        if (ctx != null && ctx.side.isClient() && Minecraft.func_71410_x().field_71439_g != null) {
            SoundHandlerDayM.playGunShotSound(message.uuid, message.id);
        }
        return null;
    }
}
