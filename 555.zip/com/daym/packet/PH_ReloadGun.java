package com.daym.packet;

import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.enums.*;
import net.minecraft.item.*;
import com.daym.misc.*;
import com.daym.registry.*;
import net.minecraft.nbt.*;
import com.daym.extended.*;
import com.daym.*;
import com.daym.packet.message.*;
import net.minecraft.entity.player.*;
import com.daym.items.*;
import com.daym.inventory.*;

public class PH_ReloadGun implements IMessageHandler<MSG_ReloadGun, IMessage>
{
    public IMessage onMessage(final MSG_ReloadGun message, final MessageContext ctx) {
        if (ctx != null) {
            if (message.msgID == 1 || message.msgID == 2 || message.msgID == 3 || message.msgID == 5) {
                final EntityPlayer player = (EntityPlayer)ctx.getServerHandler().field_147369_b;
                if (player.field_71071_by.func_70448_g() != null) {
                    final ItemStack is = player.field_71071_by.func_70448_g();
                    if (is.func_77973_b() instanceof ItemDayMGun) {
                        if (message.msgID == 2 || message.msgID == 1) {
                            ItemDayMGun.setChambered(is, message.msgID == 1);
                        }
                        if (message.msgID == 5) {
                            final GunStatEnum gstat = GunStatEnum.getStatFromGun(is.func_77977_a());
                            if (ItemDayMGun.isChambered(is)) {
                                final ItemAmmo am = ((ItemMagazine)gstat.magazines[0]).ammoType;
                                ItemDayMGun.setChambered(is, false);
                                if (!PlayerInventoryManager.addItemStackToInventory(new ItemStack((Item)am), player)) {
                                    player.func_146097_a(new ItemStack((Item)am), false, false);
                                }
                                ItemDayMGun.addBullets(is, -1);
                            }
                        }
                        if (message.msgID == 3) {
                            final GunStatEnum gstat = GunStatEnum.getStatFromGun(is.func_77977_a());
                            if (!ItemDayMGun.isChambered(is)) {
                                final ItemAmmo am = ((ItemMagazine)gstat.magazines[0]).ammoType;
                                if (PlayerInventoryManager.hasItem(player, am)) {
                                    ItemDayMGun.setChambered(is, true);
                                    if (!ItemDayMGun.hasMagazine(is)) {
                                        PlayerInventoryManager.consumeInventoryItem(player, am);
                                        ItemDayMGun.addBullets(is, 1);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (message.msgID == 4) {
                final EntityPlayer player = (EntityPlayer)ctx.getServerHandler().field_147369_b;
                if (player.field_71071_by.func_70448_g() != null) {
                    final ItemStack is = player.field_71071_by.func_70448_g();
                    if (is.func_77973_b() instanceof ItemDayMGun) {
                        final boolean bl = ItemDayMGun.hasMagazine(is);
                        int b = ItemDayMGun.getBullets(is);
                        final String daym_511e1e650 = ItemDayMGun.getMagazineUnloc(is);
                        if (bl && b != -1 && daym_511e1e650 != "null") {
                            final ItemStack oldmag = new ItemStack(ItemRegistry.getByUnlocname(daym_511e1e650));
                            final NBTTagCompound tag = new NBTTagCompound();
                            if (ItemDayMGun.isChambered(is)) {
                                if (b > 0) {
                                    --b;
                                    is.field_77990_d.func_74768_a("mag_bullets", 1);
                                }
                            }
                            else {
                                is.field_77990_d.func_74768_a("mag_bullets", 0);
                            }
                            if (b < 0) {
                                b = 0;
                            }
                            tag.func_74768_a("bullets", b);
                            oldmag.field_77990_d = tag;
                            if (!PlayerInventoryManager.addItemStackToInventory(oldmag, player)) {
                                player.func_146097_a(oldmag, false, false);
                            }
                            ItemDayMGun.setMagazine(is, false, null);
                        }
                    }
                }
            }
            if (message.msgID == 0) {
                final EntityPlayer player = (EntityPlayer)ctx.getServerHandler().field_147369_b;
                if (player.field_71071_by.func_70448_g() != null) {
                    final ItemStack is = player.field_71071_by.func_70448_g();
                    if (is.func_77973_b() instanceof ItemDayMGun) {
                        ItemStack ammo = null;
                        int bscan = 0;
                        int prevbScan = 0;
                        int slot = 0;
                        if (!ItemDayMGun.hasMagazine(is)) {
                            prevbScan = -1;
                        }
                        int selectedInv = 0;
                        for (final Item mag : GunStatEnum.getStatFromGun("gid_" + message.gunID).magazines) {
                            for (int a = 0; a < 4; ++a) {
                                final ItemInventory inv = PlayerInventoryManager.getItemInventory(a, ExtendedPlayer.get(player).inventory);
                                if (inv != null) {
                                    int i = 0;
                                    for (final ItemStack items : inv.inventory) {
                                        if (items != null && items.func_77973_b() == mag) {
                                            if (items.field_77990_d != null) {
                                                bscan = items.field_77990_d.func_74762_e("bullets");
                                            }
                                            if (bscan > prevbScan) {
                                                prevbScan = bscan;
                                                ammo = items;
                                                slot = i;
                                                selectedInv = a;
                                            }
                                        }
                                        ++i;
                                    }
                                }
                            }
                        }
                        if (ammo != null) {
                            final int bl2 = ItemDayMGun.loadMagazine(is, ammo);
                            final ItemInventory inv2 = PlayerInventoryManager.getItemInventory(selectedInv, ExtendedPlayer.get(player).inventory);
                            inv2.func_70299_a(slot, null);
                            if (ctx.side.isServer()) {
                                DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_SyncPlayerProps(0, (EntityPlayer)ctx.getServerHandler().field_147369_b));
                            }
                            if (bl2 > -5 && bl2 != -1) {
                                final ItemStack oldmag2 = new ItemStack(ammo.func_77973_b());
                                final NBTTagCompound tag2 = new NBTTagCompound();
                                tag2.func_74768_a("bullets", bl2);
                                oldmag2.field_77990_d = tag2;
                                if (!PlayerInventoryManager.addItemStackToInventory(oldmag2, player)) {
                                    player.func_146097_a(oldmag2, false, false);
                                }
                            }
                            ItemDayMGun.setMagazine(is, true, ammo.func_77973_b());
                        }
                    }
                }
            }
            if (ctx.side.isServer()) {
                DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_SyncPlayerProps(0, (EntityPlayer)ctx.getServerHandler().field_147369_b));
            }
        }
        return null;
    }
}
