package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.handlers.*;

public class PH_SyncWorldHandler implements IMessageHandler<MSG_SyncWorldHandler, IMessage>
{
    public IMessage onMessage(final MSG_SyncWorldHandler message, final MessageContext ctx) {
        if (ctx != null) {
            if (message.msgID == 0) {
                WorldHandler.daym_5635fd3d0 = message.encoded;
                final String[] data = WorldHandler.daym_4524cfb60(WorldHandler.daym_5635fd3d0, null);
                WorldHandler.daym_56da15940(data);
            }
            if (message.msgID == 1) {
                WorldHandler.daym_24d72dcb0 = message.encoded;
                final String[] data = WorldHandler.daym_4524cfb60(WorldHandler.daym_24d72dcb0, null);
                WorldHandler.daym_788aec670(data);
            }
            if (message.msgID == 2) {
                WorldHandler.daym_28d3f01a0 = message.encoded;
                final String[] data = WorldHandler.daym_4524cfb60(WorldHandler.daym_28d3f01a0, null);
                WorldHandler.daym_09520b930(data);
            }
        }
        return null;
    }
}
