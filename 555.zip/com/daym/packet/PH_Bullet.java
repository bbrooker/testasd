package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.items.*;
import com.daym.enums.*;
import com.daym.entity.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraft.world.*;

public class PH_Bullet implements IMessageHandler<MSG_Bullet, IMessage>
{
    public IMessage onMessage(final MSG_Bullet message, final MessageContext ctx) {
        if (ctx != null) {
            final EntityPlayerMP player = ctx.getServerHandler().field_147369_b;
            if (player != null) {
                if (player.field_71071_by.func_70448_g() == null) {
                    return null;
                }
                final ItemStack is = player.field_71071_by.func_70448_g();
                if (!(is.func_77973_b() instanceof ItemDayMGun)) {
                    return null;
                }
                if (!player.field_71075_bZ.field_75098_d) {
                    final GunStatEnum gstat = GunStatEnum.getStatFromGun(is.func_77977_a());
                    if (!ItemDayMGun.isChambered(is)) {
                        return null;
                    }
                    if (!ItemDayMGun.eatBullet(is)) {
                        ItemDayMGun.setChambered(is, false);
                        return null;
                    }
                    if (ItemDayMGun.getBullets(is) <= 0) {
                        ItemDayMGun.setChambered(is, false);
                    }
                }
                final World world = player.field_70170_p;
                final EntityBullet entitybullet = new EntityBullet(world, (EntityPlayer)player, message.speed, message.gunID);
                if (!world.field_72995_K) {
                    world.func_72838_d((Entity)entitybullet);
                }
            }
        }
        return null;
    }
}
