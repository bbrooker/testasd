package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.client.*;
import net.minecraft.entity.*;
import com.daym.clientproxy.*;
import java.util.*;

public class PH_PlayerEvent implements IMessageHandler<MSG_PlayerEvent, IMessage>
{
    public IMessage onMessage(final MSG_PlayerEvent message, final MessageContext ctx) {
        if (ctx != null) {
            final Minecraft mc = Minecraft.func_71410_x();
            if (mc.field_71441_e != null) {
                for (final Object o : mc.field_71441_e.field_73010_i) {
                    if (o instanceof Entity && message.uuid.contains(((Entity)o).func_110124_au().toString())) {
                        ClientProxy.playerEvent(message.msgID, (Entity)o);
                    }
                }
            }
        }
        return null;
    }
}
