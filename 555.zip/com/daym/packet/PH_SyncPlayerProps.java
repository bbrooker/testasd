package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.client.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import com.daym.extended.*;
import net.minecraft.item.*;
import java.util.*;

public class PH_SyncPlayerProps implements IMessageHandler<MSG_SyncPlayerProps, IMessage>
{
    public IMessage onMessage(final MSG_SyncPlayerProps message, final MessageContext ctx) {
        if (ctx != null && ctx.side.isClient() && Minecraft.func_71410_x().field_71441_e != null) {
            Entity chosenone = null;
            for (final Object o : Minecraft.func_71410_x().field_71441_e.field_73010_i) {
                if (o instanceof Entity) {
                    final Entity plobj = (Entity)o;
                    if (!plobj.func_110124_au().toString().contains(message.playeruuid)) {
                        continue;
                    }
                    chosenone = plobj;
                }
            }
            if (chosenone != null && message.msgID == 0) {
                final ExtendedPlayer extplayer = ExtendedPlayer.get((EntityPlayer)chosenone);
                extplayer.inventory.inventory = new ItemStack[extplayer.inventory.func_70302_i_()];
                extplayer.loadNBTData(message.data);
            }
        }
        return null;
    }
}
