package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.handlers.*;
import com.daym.*;
import com.daym.extended.*;
import com.daym.items.*;
import com.daym.registry.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import com.daym.inventory.*;

public class PH_PlayerSkin implements IMessageHandler<MSG_PlayerSkin, IMessage>
{
    public IMessage onMessage(final MSG_PlayerSkin message, final MessageContext ctx) {
        if (ctx != null) {
            if (message.msgID <= 3) {
                int offset = 0;
                if (message.daym_8eb8ec9d0 && message.skinID <= 4) {
                    offset = 5;
                }
                if (message.msgID == 0) {
                    final EntityPlayerMP player = ctx.getServerHandler().field_147369_b;
                    if (player != null) {
                        WorldHandler.daym_3bb3f01c0.put(player.func_110124_au().toString(), message.skinID + offset);
                        DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_PlayerSkin(1, message.skinID, message.daym_8eb8ec9d0, player.func_110124_au().toString()));
                    }
                }
                if (message.msgID == 2) {
                    final EntityPlayerMP player = ctx.getServerHandler().field_147369_b;
                    if (player != null) {
                        WorldHandler.daym_3bb3f01c0.remove(player.func_110124_au().toString());
                        DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_PlayerSkin(3, message.skinID, message.daym_8eb8ec9d0, player.func_110124_au().toString()));
                    }
                }
                if (message.msgID == 1) {
                    WorldHandler.daym_3bb3f01c0.put(message.uuid, message.skinID + offset);
                }
                if (message.msgID == 3) {
                    WorldHandler.daym_3bb3f01c0.remove(message.uuid);
                }
            }
            else if (ctx.side.isServer()) {
                final EntityPlayer player2 = (EntityPlayer)ctx.getServerHandler().field_147369_b;
                final PlayerInventoryDayM inventory = ExtendedPlayer.get(player2).inventory;
                boolean inventoryEmpty = true;
                int amc = 0;
                for (final ItemStack is : player2.field_71071_by.field_70462_a) {
                    if (is != null && !(is.func_77973_b() instanceof ItemClothing)) {
                        inventoryEmpty = false;
                    }
                    if (is != null && is.func_77973_b() instanceof ItemClothing) {
                        ++amc;
                    }
                }
                if (inventoryEmpty && amc <= 2 && !WorldHandler.daym_9619787d0.containsKey(player2.func_110124_au().toString())) {
                    if (message.msgID == 4 && inventory.inventory[1] == null) {
                        try {
                            player2.field_71071_by.func_70441_a(new ItemStack(ItemRegistry.defaultClothingShirt[message.skinID - 2]));
                        }
                        catch (ArrayIndexOutOfBoundsException ex) {}
                    }
                    if (message.msgID == 5 && inventory.inventory[2] == null) {
                        try {
                            player2.field_71071_by.func_70441_a(new ItemStack(ItemRegistry.defaultClothingPants[message.skinID]));
                        }
                        catch (ArrayIndexOutOfBoundsException ex2) {}
                    }
                    if (message.msgID == 6 && inventory.inventory[3] == null) {
                        try {
                            player2.field_71071_by.func_70441_a(new ItemStack(ItemRegistry.item_c_shoes_0));
                        }
                        catch (ArrayIndexOutOfBoundsException ex3) {}
                    }
                }
                if (amc > 2) {
                    WorldHandler.daym_9619787d0.put(player2.func_110124_au().toString(), true);
                }
            }
        }
        return null;
    }
}
