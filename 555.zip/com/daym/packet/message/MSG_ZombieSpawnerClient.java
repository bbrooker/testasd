package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;

public class MSG_ZombieSpawnerClient implements IMessage
{
    public int msgid;
    public int type;
    public int spawnChance;
    public int spawnRadius;
    public int amountSpawn;
    public int randAmount;
    public int x;
    public int y;
    public int z;
    
    public MSG_ZombieSpawnerClient() {
    }
    
    public MSG_ZombieSpawnerClient(final int id, final int a, final int b, final int c, final int d, final int e, final int x1, final int y1, final int z1) {
        this.msgid = id;
        this.type = a;
        this.spawnChance = b;
        this.spawnRadius = c;
        this.amountSpawn = d;
        this.randAmount = e;
        this.x = x1;
        this.y = y1;
        this.z = z1;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgid = buf.readInt();
        this.type = buf.readInt();
        this.spawnChance = buf.readInt();
        this.spawnRadius = buf.readInt();
        this.amountSpawn = buf.readInt();
        this.randAmount = buf.readInt();
        this.x = buf.readInt();
        this.y = buf.readInt();
        this.z = buf.readInt();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeInt(this.msgid);
        buf.writeInt(this.type);
        buf.writeInt(this.spawnChance);
        buf.writeInt(this.spawnRadius);
        buf.writeInt(this.amountSpawn);
        buf.writeInt(this.randAmount);
        buf.writeInt(this.x);
        buf.writeInt(this.y);
        buf.writeInt(this.z);
    }
}
