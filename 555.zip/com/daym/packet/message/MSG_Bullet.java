package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;

public class MSG_Bullet implements IMessage
{
    public int gunID;
    public float speed;
    
    public MSG_Bullet() {
    }
    
    public MSG_Bullet(final int i, final float s) {
        this.gunID = i;
        this.speed = s;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.gunID = buf.readInt();
        this.speed = buf.readFloat();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeInt(this.gunID);
        buf.writeFloat(this.speed);
    }
}
