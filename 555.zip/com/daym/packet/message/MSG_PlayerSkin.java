package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;
import cpw.mods.fml.common.network.*;

public class MSG_PlayerSkin implements IMessage
{
    public int msgID;
    public int skinID;
    public String uuid;
    public boolean daym_8eb8ec9d0;
    
    public MSG_PlayerSkin() {
    }
    
    public MSG_PlayerSkin(final int id, final int c, final boolean g, final String uid) {
        this.msgID = id;
        this.skinID = c;
        this.daym_8eb8ec9d0 = g;
        this.uuid = uid;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgID = buf.readInt();
        this.skinID = buf.readInt();
        this.daym_8eb8ec9d0 = buf.readBoolean();
        this.uuid = ByteBufUtils.readUTF8String(buf);
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeInt(this.msgID);
        buf.writeInt(this.skinID);
        buf.writeBoolean(this.daym_8eb8ec9d0);
        ByteBufUtils.writeUTF8String(buf, this.uuid);
    }
}
