package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;

public class MSG_MouseClick implements IMessage
{
    public boolean clicked;
    
    public MSG_MouseClick() {
    }
    
    public MSG_MouseClick(final boolean c) {
        this.clicked = c;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.clicked = buf.readBoolean();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeBoolean(this.clicked);
    }
}
