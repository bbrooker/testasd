package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;
import cpw.mods.fml.common.network.*;

public class MSG_PlayerAnimation implements IMessage
{
    public String uuid;
    public byte animID;
    
    public MSG_PlayerAnimation() {
    }
    
    public MSG_PlayerAnimation(final String s, final byte c) {
        this.uuid = s;
        this.animID = c;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.uuid = ByteBufUtils.readUTF8String(buf);
        this.animID = buf.readByte();
    }
    
    public void toBytes(final ByteBuf buf) {
        ByteBufUtils.writeUTF8String(buf, this.uuid);
        buf.writeByte((int)this.animID);
    }
}
