package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;
import cpw.mods.fml.common.network.*;

public class MSG_SyncWorldHandler implements IMessage
{
    public byte msgID;
    public int length;
    public String encoded;
    
    public MSG_SyncWorldHandler() {
        this.encoded = "";
    }
    
    public MSG_SyncWorldHandler(final byte c, final String enc) {
        this.encoded = "";
        this.msgID = c;
        this.encoded = enc;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgID = buf.readByte();
        this.length = buf.readInt();
        final String[] enc = new String[this.length];
        for (int i = 0; i < enc.length; ++i) {
            this.encoded += ByteBufUtils.readUTF8String(buf);
        }
    }
    
    public void toBytes(final ByteBuf buf) {
        final String[] enc = this.encoded.split("\\|");
        this.length = enc.length;
        buf.writeByte((int)this.msgID);
        buf.writeInt(this.length);
        for (int i = 0; i < this.length; ++i) {
            ByteBufUtils.writeUTF8String(buf, enc[i] + "|");
        }
    }
}
