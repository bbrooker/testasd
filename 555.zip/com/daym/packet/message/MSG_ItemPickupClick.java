package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;

public class MSG_ItemPickupClick implements IMessage
{
    public byte msgid;
    public int itemID;
    public double x;
    public double y;
    public double z;
    
    public MSG_ItemPickupClick() {
        this.msgid = 0;
        this.itemID = -1;
    }
    
    public MSG_ItemPickupClick(final byte b, final int s, final double xx, final double yy, final double zz) {
        this.msgid = 0;
        this.itemID = -1;
        this.msgid = b;
        this.itemID = s;
        this.x = xx;
        this.y = yy;
        this.z = zz;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgid = buf.readByte();
        this.itemID = buf.readInt();
        this.x = buf.readDouble();
        this.y = buf.readDouble();
        this.z = buf.readDouble();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeByte((int)this.msgid);
        buf.writeInt(this.itemID);
        buf.writeDouble(this.x);
        buf.writeDouble(this.y);
        buf.writeDouble(this.z);
    }
}
