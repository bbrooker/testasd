package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;
import cpw.mods.fml.common.network.*;

public class MSG_GunShotSound implements IMessage
{
    public String uuid;
    public float volume;
    public float pitch;
    public int id;
    
    public MSG_GunShotSound() {
    }
    
    public MSG_GunShotSound(final String id1, final int c, final float v, final float p) {
        this.uuid = id1;
        this.id = c;
        this.volume = v;
        this.pitch = p;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.uuid = ByteBufUtils.readUTF8String(buf);
        this.id = buf.readInt();
        this.volume = buf.readFloat();
        this.pitch = buf.readFloat();
    }
    
    public void toBytes(final ByteBuf buf) {
        ByteBufUtils.writeUTF8String(buf, this.uuid);
        buf.writeInt(this.id);
        buf.writeFloat(this.volume);
        buf.writeFloat(this.pitch);
    }
}
