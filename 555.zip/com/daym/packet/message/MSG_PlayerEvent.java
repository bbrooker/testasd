package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;
import cpw.mods.fml.common.network.*;

public class MSG_PlayerEvent implements IMessage
{
    public int msgID;
    public String uuid;
    
    public MSG_PlayerEvent() {
    }
    
    public MSG_PlayerEvent(final String uid, final int id) {
        this.uuid = uid;
        this.msgID = id;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.uuid = ByteBufUtils.readUTF8String(buf);
        this.msgID = buf.readInt();
    }
    
    public void toBytes(final ByteBuf buf) {
        ByteBufUtils.writeUTF8String(buf, this.uuid);
        buf.writeInt(this.msgID);
    }
}
