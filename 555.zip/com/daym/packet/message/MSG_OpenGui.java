package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;

public class MSG_OpenGui implements IMessage
{
    public int guiID;
    public int msgID;
    
    public MSG_OpenGui() {
    }
    
    public MSG_OpenGui(final int m, final int c) {
        this.msgID = m;
        this.guiID = c;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgID = buf.readInt();
        this.guiID = buf.readInt();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeInt(this.msgID);
        buf.writeInt(this.guiID);
    }
}
