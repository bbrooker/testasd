package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;

public class MSG_Suicide implements IMessage
{
    public byte msgID;
    
    public MSG_Suicide() {
    }
    
    public MSG_Suicide(final byte c) {
        this.msgID = c;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgID = buf.readByte();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeByte((int)this.msgID);
    }
}
