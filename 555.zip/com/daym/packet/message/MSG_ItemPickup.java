package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.item.*;
import io.netty.buffer.*;
import cpw.mods.fml.common.network.*;

public class MSG_ItemPickup implements IMessage
{
    public ItemStack stack;
    
    public MSG_ItemPickup() {
    }
    
    public MSG_ItemPickup(final ItemStack is) {
        this.stack = is;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.stack = ByteBufUtils.readItemStack(buf);
    }
    
    public void toBytes(final ByteBuf buf) {
        ByteBufUtils.writeItemStack(buf, this.stack);
    }
}
