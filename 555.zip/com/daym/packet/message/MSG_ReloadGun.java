package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;

public class MSG_ReloadGun implements IMessage
{
    public int gunID;
    public int msgID;
    
    public MSG_ReloadGun() {
    }
    
    public MSG_ReloadGun(final int id, final int i) {
        this.msgID = id;
        this.gunID = i;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgID = buf.readInt();
        this.gunID = buf.readInt();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeInt(this.msgID);
        buf.writeInt(this.gunID);
    }
}
