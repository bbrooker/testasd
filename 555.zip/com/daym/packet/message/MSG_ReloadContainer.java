package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;

public class MSG_ReloadContainer implements IMessage
{
    public byte msgid;
    
    public MSG_ReloadContainer() {
    }
    
    public MSG_ReloadContainer(final byte c) {
        this.msgid = c;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgid = buf.readByte();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeByte((int)this.msgid);
    }
}
