package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;

public class MSG_PlayerSpawner implements IMessage
{
    public int msgid;
    public int spawnChance;
    public int x;
    public int y;
    public int z;
    
    public MSG_PlayerSpawner() {
    }
    
    public MSG_PlayerSpawner(final int id, final int b, final int x1, final int y1, final int z1) {
        this.msgid = id;
        this.spawnChance = b;
        this.x = x1;
        this.y = y1;
        this.z = z1;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgid = buf.readInt();
        this.spawnChance = buf.readInt();
        this.x = buf.readInt();
        this.y = buf.readInt();
        this.z = buf.readInt();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeInt(this.msgid);
        buf.writeInt(this.spawnChance);
        buf.writeInt(this.x);
        buf.writeInt(this.y);
        buf.writeInt(this.z);
    }
}
