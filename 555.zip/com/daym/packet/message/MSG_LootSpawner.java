package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import java.util.*;
import io.netty.buffer.*;

public class MSG_LootSpawner implements IMessage
{
    public int msgid;
    public int arraySize;
    public int arraySize2;
    public ArrayList<Integer> lootTable;
    public ArrayList<Integer> lootTableChance;
    public int lootId;
    public int radius;
    public int spawnChance;
    public int x;
    public int y;
    public int z;
    
    public MSG_LootSpawner() {
        this.lootTable = new ArrayList<Integer>();
        this.lootTableChance = new ArrayList<Integer>();
    }
    
    public MSG_LootSpawner(final int id, final ArrayList<Integer> al, final ArrayList<Integer> alc, final int size, final int size2, final int lid, final int r, final int b, final int x1, final int y1, final int z1) {
        this.lootTable = new ArrayList<Integer>();
        this.lootTableChance = new ArrayList<Integer>();
        this.msgid = id;
        this.lootTable = al;
        this.lootTableChance = alc;
        this.arraySize = size;
        this.arraySize2 = size2;
        this.lootId = lid;
        this.radius = r;
        this.spawnChance = b;
        this.x = x1;
        this.y = y1;
        this.z = z1;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgid = buf.readInt();
        this.arraySize = buf.readInt();
        this.arraySize2 = buf.readInt();
        if (this.lootTable != null) {
            final int[] t = new int[this.arraySize + 1];
            for (int i = 0; i < this.arraySize; ++i) {
                t[i] = buf.readInt();
                this.lootTable.add(t[i]);
            }
        }
        if (this.lootTableChance != null) {
            final int[] t = new int[this.arraySize2 + 1];
            for (int i = 0; i < this.arraySize2; ++i) {
                t[i] = buf.readInt();
                this.lootTableChance.add(t[i]);
            }
        }
        this.lootId = buf.readInt();
        this.radius = buf.readInt();
        this.spawnChance = buf.readInt();
        this.x = buf.readInt();
        this.y = buf.readInt();
        this.z = buf.readInt();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeInt(this.msgid);
        buf.writeInt(this.arraySize);
        buf.writeInt(this.arraySize2);
        if (this.lootTable != null) {
            for (int i = 0; i < this.arraySize; ++i) {
                final int a = this.lootTable.get(i);
                buf.writeInt(a);
            }
        }
        if (this.lootTableChance != null) {
            for (int i = 0; i < this.arraySize2; ++i) {
                final int a = this.lootTableChance.get(i);
                buf.writeInt(a);
            }
        }
        buf.writeInt(this.lootId);
        buf.writeInt(this.radius);
        buf.writeInt(this.spawnChance);
        buf.writeInt(this.x);
        buf.writeInt(this.y);
        buf.writeInt(this.z);
    }
}
