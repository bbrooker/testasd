package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import io.netty.buffer.*;

public class MSG_ForceView implements IMessage
{
    public byte daym_f4e660b80;
    
    public MSG_ForceView() {
        this.daym_f4e660b80 = 0;
    }
    
    public MSG_ForceView(final byte v) {
        this.daym_f4e660b80 = 0;
        this.daym_f4e660b80 = v;
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.daym_f4e660b80 = buf.readByte();
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeByte((int)this.daym_f4e660b80);
    }
}
