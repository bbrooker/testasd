package com.daym.packet.message;

import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.player.*;
import com.daym.extended.*;
import io.netty.buffer.*;
import cpw.mods.fml.common.network.*;

public class MSG_SyncPlayerProps implements IMessage
{
    public int msgID;
    public NBTTagCompound data;
    public String playeruuid;
    
    public MSG_SyncPlayerProps() {
    }
    
    public MSG_SyncPlayerProps(final int id, final EntityPlayer player) {
        this.msgID = id;
        this.data = new NBTTagCompound();
        ExtendedPlayer.get(player).saveNBTData(this.data);
        this.playeruuid = player.func_110124_au().toString();
    }
    
    public void fromBytes(final ByteBuf buf) {
        this.msgID = buf.readInt();
        this.data = ByteBufUtils.readTag(buf);
        this.playeruuid = ByteBufUtils.readUTF8String(buf);
    }
    
    public void toBytes(final ByteBuf buf) {
        buf.writeInt(this.msgID);
        ByteBufUtils.writeTag(buf, this.data);
        ByteBufUtils.writeUTF8String(buf, this.playeruuid);
    }
}
