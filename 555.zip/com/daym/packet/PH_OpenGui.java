package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.clientproxy.*;
import com.daym.*;
import cpw.mods.fml.common.network.internal.*;
import net.minecraft.entity.player.*;

public class PH_OpenGui implements IMessageHandler<MSG_OpenGui, IMessage>
{
    public IMessage onMessage(final MSG_OpenGui message, final MessageContext ctx) {
        if (ctx != null) {
            EntityPlayer player = null;
            if (ctx.side.isClient()) {
                player = ClientProxy.daym_281cc4bf0(ctx);
            }
            else {
                player = (EntityPlayer)ctx.getServerHandler().field_147369_b;
            }
            if (player != null) {
                if (message.msgID == 0) {
                    FMLNetworkHandler.openGui(player, (Object)DayM.getInstance(), message.guiID, player.field_70170_p, 0, 0, 0);
                    if (ctx.side.isServer()) {}
                }
                if (message.msgID == 1) {
                    player.func_71053_j();
                    if (ctx.side.isServer()) {}
                }
            }
        }
        return null;
    }
}
