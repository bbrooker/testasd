package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.handlers.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import java.util.*;

public class PH_ItemPickup implements IMessageHandler<MSG_ItemPickup, IMessage>
{
    public IMessage onMessage(final MSG_ItemPickup message, final MessageContext ctx) {
        if (ctx != null) {
            final EntityPlayerMP player = ctx.getServerHandler().field_147369_b;
            if (player != null) {
                ArrayList<EntityItem> al = null;
                if (WorldHandler.daym_e3864ff00.containsKey(player.func_110124_au().toString())) {
                    al = WorldHandler.daym_e3864ff00.get(player.func_110124_au().toString());
                }
                final ItemStack is = message.stack;
                if (al != null && is != null) {
                    for (final EntityItem ei : al) {
                        if (ei.func_92059_d() != null && is != null && ei.func_92059_d().func_77973_b() == is.func_77973_b()) {
                            al.remove(ei);
                            ei.func_70106_y();
                            break;
                        }
                    }
                }
            }
        }
        return null;
    }
}
