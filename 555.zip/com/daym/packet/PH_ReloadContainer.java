package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.serverproxy.*;
import com.daym.inventory.*;
import com.daym.*;
import net.minecraft.entity.player.*;

public class PH_ReloadContainer implements IMessageHandler<MSG_ReloadContainer, IMessage>
{
    public IMessage onMessage(final MSG_ReloadContainer message, final MessageContext ctx) {
        if (ctx != null) {
            final EntityPlayer player = CommonProxy.daym_281cc4bf0(ctx);
            if (player != null && player.field_71070_bA instanceof PlayerContainerDayM) {
                if (message.msgid == 0 && player instanceof EntityPlayerMP) {
                    DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_ReloadContainer((byte)1), (EntityPlayerMP)player);
                }
                final PlayerContainerDayM container = (PlayerContainerDayM)player.field_71070_bA;
                container.addInventorySlots(player, true);
                container.daym_a58cb7bc0 = 0;
                container.daym_a58cb7bc0gui = 0;
                container.daym_72bd6ea70 = 0;
                container.daym_1bb3e1050 = 0;
                container.daym_1bb3e10502 = 0;
                if (message.msgid == 1) {}
            }
        }
        return null;
    }
}
