package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.handlers.*;
import net.minecraft.entity.player.*;
import com.daym.*;
import java.util.*;

public class PH_PlayerAnimation implements IMessageHandler<MSG_PlayerAnimation, IMessage>
{
    public IMessage onMessage(final MSG_PlayerAnimation message, final MessageContext ctx) {
        if (ctx != null) {
            PlayerVarHandler.daym_b73359c80.put(message.uuid, message.animID);
            if (ctx.side.isServer()) {
                for (final Object o : ctx.getServerHandler().field_147369_b.field_70170_p.field_73010_i) {
                    if (o instanceof EntityPlayerMP) {
                        DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_PlayerAnimation(message.uuid, message.animID), (EntityPlayerMP)o);
                    }
                }
            }
        }
        return null;
    }
}
