package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.serverproxy.*;
import com.daym.items.*;
import net.minecraft.entity.player.*;
import com.daym.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import java.util.*;

public class PH_Suicide implements IMessageHandler<MSG_Suicide, IMessage>
{
    public IMessage onMessage(final MSG_Suicide message, final MessageContext ctx) {
        if (ctx != null) {
            System.out.println("SIDE SUICIDE: " + ctx.side);
            final EntityPlayer player = CommonProxy.daym_281cc4bf0(ctx);
            if (player != null) {
                if (player.field_71071_by.func_70448_g() != null) {
                    final ItemStack is = player.field_71071_by.func_70448_g();
                    if (is.func_77973_b() instanceof ItemDayMGun) {
                        if (!ItemDayMGun.eatBullet(is)) {
                            ItemDayMGun.setChambered(is, false);
                        }
                        if (ItemDayMGun.getBullets(is) <= 0) {
                            ItemDayMGun.setChambered(is, false);
                        }
                    }
                }
                if (message.msgID == 0) {
                    final IChatComponent test = (IChatComponent)new ChatComponentText(player.getDisplayName() + " ended their own life.");
                    for (final Object o : player.field_70170_p.field_73010_i) {
                        if (o instanceof EntityPlayer) {
                            ((EntityPlayer)o).func_145747_a(test);
                        }
                    }
                }
                player.func_70097_a(DamageSource.field_76377_j, 200.0f);
                if (message.msgID == 0 && player instanceof EntityPlayerMP) {
                    DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_Suicide((byte)1), (EntityPlayerMP)player);
                }
            }
        }
        return null;
    }
}
