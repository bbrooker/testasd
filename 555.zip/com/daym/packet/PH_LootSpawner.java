package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.serverproxy.*;
import com.daym.handlers.*;
import com.daym.*;
import net.minecraft.entity.player.*;
import java.util.*;

public class PH_LootSpawner implements IMessageHandler<MSG_LootSpawner, IMessage>
{
    public IMessage onMessage(final MSG_LootSpawner message, final MessageContext ctx) {
        if (ctx != null) {
            final EntityPlayer player = CommonProxy.daym_281cc4bf0(ctx);
            if (player != null) {
                if (message.msgid == 0 || message.msgid == 2) {
                    final ArrayList<Integer> al = message.lootTable;
                    final ArrayList<Integer> alc = message.lootTableChance;
                    final int lid = message.lootId;
                    final int r = message.radius;
                    final int spawnChance = 100 - message.spawnChance;
                    final int x = message.x;
                    final int y = message.y;
                    final int z = message.z;
                    WorldHandler.daym_5da285b70(al, alc, lid, r, spawnChance, x, y, z);
                    if (message.msgid == 0) {
                        WorldHandler.daym_86fc86bb0(true);
                        DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_LootSpawner(2, al, alc, al.size(), alc.size(), lid, r, message.spawnChance, x, y, z));
                    }
                    else {
                        WorldHandler.daym_86fc86bb0(false);
                    }
                }
                if (message.msgid == 1) {
                    final int lid2 = message.lootId;
                    final int spawnChance2 = 100 - message.spawnChance;
                    final int x2 = message.x;
                    final int y2 = message.y;
                    final int z2 = message.z;
                    final boolean worked = WorldHandler.daym_9bdc5ed90(lid2, spawnChance2, x2, y2, z2);
                    if (worked) {
                        WorldHandler.daym_86fc86bb0(true);
                    }
                }
            }
        }
        return null;
    }
}
