package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.serverproxy.*;
import com.daym.handlers.*;
import net.minecraft.entity.item.*;
import net.minecraft.item.*;
import com.daym.*;
import net.minecraft.entity.player.*;
import java.util.*;

public class PH_ItemPickupClick implements IMessageHandler<MSG_ItemPickupClick, IMessage>
{
    public IMessage onMessage(final MSG_ItemPickupClick message, final MessageContext ctx) {
        if (ctx != null) {
            final EntityPlayer player = CommonProxy.daym_281cc4bf0(ctx);
            if (player != null) {
                final ArrayList<EntityItem> test2 = (ArrayList<EntityItem>)WorldHandler.daym_4ceb36930.clone();
                for (final EntityItem ei : test2) {
                    if (ei != null && ei.func_92059_d() != null && message.itemID != -1) {
                        final double dist = ei.func_70011_f(message.x, message.y, message.z);
                        final double dist2 = 0.0;
                        if (dist >= 1.0 || Item.func_150891_b(ei.func_92059_d().func_77973_b()) != message.itemID || ei.field_70173_aa <= 20 || ei.field_70128_L || !ei.func_70089_S()) {
                            continue;
                        }
                        if (message.msgid == 0) {
                            player.field_71071_by.func_70441_a(ei.func_92059_d());
                        }
                        player.field_71069_bz.func_75142_b();
                        player.field_71071_by.func_70296_d();
                        WorldHandler.daym_4ceb36930.remove(ei);
                        WorldHandler.daym_801545040.remove(ei);
                        ei.func_70106_y();
                        if (message.msgid == 0) {
                            DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_ItemPickupClick((byte)1, message.itemID, message.x, message.y, message.z));
                            break;
                        }
                        break;
                    }
                }
            }
        }
        return null;
    }
}
