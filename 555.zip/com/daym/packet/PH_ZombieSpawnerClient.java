package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.handlers.*;

public class PH_ZombieSpawnerClient implements IMessageHandler<MSG_ZombieSpawnerClient, IMessage>
{
    public IMessage onMessage(final MSG_ZombieSpawnerClient message, final MessageContext ctx) {
        if (ctx != null && ctx.side.isClient()) {
            if (message.msgid == 0) {
                final int type = message.type;
                final int spawnChance = message.spawnChance;
                final int spawnRadius = message.spawnRadius;
                final int amountSpawn = message.amountSpawn;
                final int randAmount = message.randAmount;
                final int x = message.x;
                final int y = message.y;
                final int z = message.z;
                WorldHandler.daym_cf5555f70(type, spawnChance, spawnRadius, amountSpawn, randAmount, x, y, z);
                WorldHandler.daym_2fe7daff0(false);
            }
            if (message.msgid == 1) {
                final int type = message.type;
                final int spawnChance = 100 - message.spawnChance;
                final int spawnRadius = message.spawnRadius;
                final int amountSpawn = message.amountSpawn;
                final int randAmount = message.randAmount;
                final int x = message.x;
                final int y = message.y;
                final int z = message.z;
                final boolean worked = WorldHandler.daym_46f78edb0(type, spawnChance, spawnRadius, amountSpawn, randAmount, x, y, z);
                if (worked) {
                    WorldHandler.daym_2fe7daff0(false);
                }
            }
        }
        return null;
    }
}
