package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.serverproxy.*;
import com.daym.handlers.*;
import com.daym.*;
import net.minecraft.entity.player.*;

public class PH_PlayerSpawner implements IMessageHandler<MSG_PlayerSpawner, IMessage>
{
    public IMessage onMessage(final MSG_PlayerSpawner message, final MessageContext ctx) {
        if (ctx != null) {
            final EntityPlayer player = CommonProxy.daym_281cc4bf0(ctx);
            if (player != null) {
                if (message.msgid == 0 || message.msgid == 2) {
                    final int spawnChance = 100 - message.spawnChance;
                    final int x = message.x;
                    final int y = message.y;
                    final int z = message.z;
                    WorldHandler.daym_6368556e0(spawnChance, x, y, z);
                    if (message.msgid == 0) {
                        WorldHandler.daym_8df4b26c0(true);
                        DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_PlayerSpawner(2, message.spawnChance, x, y, z));
                    }
                    else {
                        WorldHandler.daym_8df4b26c0(false);
                    }
                }
                if (message.msgid == 1) {
                    final int spawnChance = 100 - message.spawnChance;
                    final int x = message.x;
                    final int y = message.y;
                    final int z = message.z;
                    final boolean worked = WorldHandler.daym_dc4d2fc30(spawnChance, x, y, z);
                    if (worked) {
                        WorldHandler.daym_8df4b26c0(true);
                    }
                }
            }
        }
        return null;
    }
}
