package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.clientproxy.*;

public class PH_ForceView implements IMessageHandler<MSG_ForceView, IMessage>
{
    public IMessage onMessage(final MSG_ForceView message, final MessageContext ctx) {
        if (ctx != null) {
            ClientProxy.daym_f4e660b80 = message.daym_f4e660b80;
        }
        return null;
    }
}
