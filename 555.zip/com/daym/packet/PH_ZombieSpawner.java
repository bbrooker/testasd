package com.daym.packet;

import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.handlers.*;
import com.daym.*;
import com.daym.packet.message.*;
import net.minecraft.entity.player.*;

public class PH_ZombieSpawner implements IMessageHandler<MSG_ZombieSpawner, IMessage>
{
    public IMessage onMessage(final MSG_ZombieSpawner message, final MessageContext ctx) {
        if (ctx != null) {
            final EntityPlayerMP player = ctx.getServerHandler().field_147369_b;
            if (player != null) {
                if (message.msgid == 0) {
                    final int type = message.type;
                    final int spawnChance = 100 - message.spawnChance;
                    final int spawnRadius = message.spawnRadius;
                    final int amountSpawn = message.amountSpawn;
                    final int randAmount = message.randAmount;
                    final int x = message.x;
                    final int y = message.y;
                    final int z = message.z;
                    WorldHandler.daym_cf5555f70(type, spawnChance, spawnRadius, amountSpawn, randAmount, x, y, z);
                    WorldHandler.daym_2fe7daff0(true);
                    DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_ZombieSpawnerClient(0, type, spawnChance, spawnRadius, amountSpawn, randAmount, x, y, z));
                }
                if (message.msgid == 1) {
                    final int type = message.type;
                    final int spawnChance = 100 - message.spawnChance;
                    final int spawnRadius = message.spawnRadius;
                    final int amountSpawn = message.amountSpawn;
                    final int randAmount = message.randAmount;
                    final int x = message.x;
                    final int y = message.y;
                    final int z = message.z;
                    final boolean worked = WorldHandler.daym_46f78edb0(type, spawnChance, spawnRadius, amountSpawn, randAmount, x, y, z);
                    if (worked) {
                        WorldHandler.daym_2fe7daff0(true);
                    }
                }
            }
        }
        return null;
    }
}
