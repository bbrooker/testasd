package com.daym.packet;

import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.handlers.*;
import net.minecraft.entity.player.*;

public class PH_MouseClick implements IMessageHandler<MSG_MouseClick, IMessage>
{
    public IMessage onMessage(final MSG_MouseClick message, final MessageContext ctx) {
        if (ctx != null) {
            final EntityPlayerMP player = ctx.getServerHandler().field_147369_b;
            if (player != null) {
                PlayerVarHandler.clickingList.put(player.func_110124_au().toString(), message.clicked);
            }
        }
        return null;
    }
}
