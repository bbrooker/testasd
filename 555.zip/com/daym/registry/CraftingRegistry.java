package com.daym.registry;

public class CraftingRegistry
{
}
