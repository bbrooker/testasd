package com.daym.registry;

import cpw.mods.fml.common.network.simpleimpl.*;
import cpw.mods.fml.relauncher.*;
import com.daym.packet.*;
import com.daym.packet.message.*;

public class PacketRegistry
{
    SimpleNetworkWrapper daym_6cbaa18a0;
    public int currentID;
    
    public PacketRegistry(final SimpleNetworkWrapper n) {
        this.currentID = 0;
        this.daym_6cbaa18a0 = n;
        this.init();
    }
    
    public void init() {
        this.daym_6cbaa18a0.registerMessage((Class)PH_ReloadGun.class, (Class)MSG_ReloadGun.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_MouseClick.class, (Class)MSG_MouseClick.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_GunShotSound.class, (Class)MSG_GunShotSound.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_Bullet.class, (Class)MSG_Bullet.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_ZombieSpawner.class, (Class)MSG_ZombieSpawner.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_ZombieSpawnerClient.class, (Class)MSG_ZombieSpawnerClient.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_PlayerSkin.class, (Class)MSG_PlayerSkin.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_PlayerSkin.class, (Class)MSG_PlayerSkin.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_PlayerEvent.class, (Class)MSG_PlayerEvent.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_OpenGui.class, (Class)MSG_OpenGui.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_OpenGui.class, (Class)MSG_OpenGui.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_SyncPlayerProps.class, (Class)MSG_SyncPlayerProps.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_PlayerSpawner.class, (Class)MSG_PlayerSpawner.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_PlayerSpawner.class, (Class)MSG_PlayerSpawner.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_ItemPickup.class, (Class)MSG_ItemPickup.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_ItemPickupClick.class, (Class)MSG_ItemPickupClick.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_ItemPickupClick.class, (Class)MSG_ItemPickupClick.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_LootSpawner.class, (Class)MSG_LootSpawner.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_LootSpawner.class, (Class)MSG_LootSpawner.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_ForceView.class, (Class)MSG_ForceView.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_SyncWorldHandler.class, (Class)MSG_SyncWorldHandler.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_Suicide.class, (Class)MSG_Suicide.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_Suicide.class, (Class)MSG_Suicide.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_PlayerAnimation.class, (Class)MSG_PlayerAnimation.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_PlayerAnimation.class, (Class)MSG_PlayerAnimation.class, this.getIDNext(), Side.CLIENT);
        this.daym_6cbaa18a0.registerMessage((Class)PH_ReloadContainer.class, (Class)MSG_ReloadContainer.class, this.getIDNext(), Side.SERVER);
        this.daym_6cbaa18a0.registerMessage((Class)PH_ReloadContainer.class, (Class)MSG_ReloadContainer.class, this.getIDNext(), Side.CLIENT);
    }
    
    private int getIDNext() {
        final int ci = this.currentID;
        ++this.currentID;
        return ci;
    }
}
