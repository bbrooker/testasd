package com.daym.registry;

import net.minecraft.util.*;
import java.util.*;
import net.minecraft.client.*;
import net.minecraft.entity.*;
import com.daym.handlers.*;

public class TextureRegistry
{
    public static ResourceLocation mainmenu_backgroundTexture;
    public static ResourceLocation mainmenu_backgroundTextureClouds;
    public static ResourceLocation mainmenu_backgroundTextureOV;
    public static ResourceLocation mainmenu_backgroundTextureUN;
    public static ResourceLocation mainmenu_logoTexture;
    public static ResourceLocation[] player_skin_male;
    public static ResourceLocation[] player_skin_female;
    public static ResourceLocation gui_mcicon;
    public static ResourceLocation gui_shadow;
    public static ResourceLocation gui_crosshair;
    public static ResourceLocation render_scope;
    public static ResourceLocation tex_parachute;
    public static ResourceLocation tex_daym;
    public static ResourceLocation rooftile;
    public static ResourceLocation solid;
    public static ResourceLocation tex_mmbg_terrain;
    public static ResourceLocation[] c_headgear;
    public static ResourceLocation[] c_shirt;
    public static ResourceLocation[] c_pants;
    public static ResourceLocation[] c_shoes;
    public static ResourceLocation[] backpack;
    public static ResourceLocation[] tex_zombies;
    public static ResourceLocation[] tutorial;
    public static ResourceLocation cardboard_box;
    public static ResourceLocation tallgrass;
    public static ResourceLocation[] gunAttachments;
    public static ResourceLocation[] gui_playerinv_slots;
    public static ResourceLocation[] c_vest;
    public static ResourceLocation[] c_headwear;
    public static ResourceLocation[] c_gloves;
    public static ResourceLocation muzzleflash;
    public static ResourceLocation front_muzzleflash;
    public static ResourceLocation flashlight_ov;
    public static ResourceLocation[] camos;
    Random random;
    
    public TextureRegistry() {
        this.random = new Random();
        try {
            this.loadArray(TextureRegistry.player_skin_male, "textures/players/male");
            this.loadArray(TextureRegistry.player_skin_female, "textures/players/female");
            this.loadArray(TextureRegistry.c_headgear, "textures/players/clothing/headgear_");
            this.loadArray(TextureRegistry.c_shirt, "textures/players/clothing/shirt_");
            this.loadArray(TextureRegistry.c_pants, "textures/players/clothing/pants_");
            this.loadArray(TextureRegistry.c_shoes, "textures/players/clothing/shoes_");
            this.loadArray(TextureRegistry.c_vest, "textures/players/clothing/vest_");
            this.loadArray(TextureRegistry.c_headwear, "textures/players/clothing/headwear_");
            this.loadArray(TextureRegistry.c_gloves, "textures/players/clothing/gloves_");
            this.loadArray(TextureRegistry.backpack, "textures/players/backpack/backpack_");
            this.loadArray(TextureRegistry.camos, "textures/guns/camo_");
            this.loadArray(TextureRegistry.tutorial, "textures/gui/tutorial/tutorial_");
            TextureRegistry.tex_parachute = setupTextures("textures/players/backpack/parachute_tex.png");
            TextureRegistry.flashlight_ov = setupTextures("textures/gui/overlay/flashlight.png");
            TextureRegistry.mainmenu_backgroundTexture = setupTextures("textures/gui/background_01.png");
            TextureRegistry.mainmenu_backgroundTextureOV = setupTextures("textures/gui/background_01_ov.png");
            TextureRegistry.mainmenu_backgroundTextureUN = setupTextures("textures/gui/background_01_un.png");
            TextureRegistry.mainmenu_backgroundTextureClouds = setupTextures("textures/gui/background_01_clouds.png");
            TextureRegistry.mainmenu_logoTexture = setupTextures("textures/gui/logo.png");
            TextureRegistry.rooftile = setupTextures("textures/blocks/rooftile.png");
            TextureRegistry.tallgrass = new ResourceLocation("minecraft:textures/blocks/tallgrass.png");
            TextureRegistry.gui_mcicon = setupTextures("textures/gui/mc_icon.png");
            TextureRegistry.gui_shadow = setupTextures("textures/gui/shadow.png");
            TextureRegistry.render_scope = setupTextures("textures/gui/shadow.png");
            TextureRegistry.gui_crosshair = setupTextures("textures/gui/crosshair.png");
            TextureRegistry.tex_daym = setupTextures("textures/misc/DayM_LogoSmall.png");
            TextureRegistry.solid = setupTextures("textures/misc/solid.png");
            TextureRegistry.tex_mmbg_terrain = setupTextures("textures/gui/background/grass_top.png");
            TextureRegistry.tex_zombies[0] = new ResourceLocation("daym:textures/zombies/basic_0.png");
            TextureRegistry.tex_zombies[1] = new ResourceLocation("daym:textures/zombies/basic_1.png");
            TextureRegistry.tex_zombies[2] = new ResourceLocation("daym:textures/zombies/basic_2.png");
            TextureRegistry.gunAttachments[0] = new ResourceLocation("daym:textures/attachments/reddot.png");
            TextureRegistry.cardboard_box = new ResourceLocation("daym:textures/blocks/misc/cardboardbox.png");
            TextureRegistry.muzzleflash = new ResourceLocation("daym:textures/misc/muzzleflash.png");
            TextureRegistry.front_muzzleflash = new ResourceLocation("daym:textures/misc/front_muzzleflash.png");
            TextureRegistry.gui_playerinv_slots[0] = setupTextures("textures/gui/inventory/slot_headgear.png");
            TextureRegistry.gui_playerinv_slots[1] = setupTextures("textures/gui/inventory/slot_shirt.png");
            TextureRegistry.gui_playerinv_slots[2] = setupTextures("textures/gui/inventory/slot_pants.png");
            TextureRegistry.gui_playerinv_slots[3] = setupTextures("textures/gui/inventory/slot_shoes.png");
            TextureRegistry.gui_playerinv_slots[4] = setupTextures("textures/gui/inventory/slot_headwear.png");
            TextureRegistry.gui_playerinv_slots[5] = setupTextures("textures/gui/inventory/slot_backpack.png");
            TextureRegistry.gui_playerinv_slots[6] = setupTextures("textures/gui/inventory/slot_vest.png");
            TextureRegistry.gui_playerinv_slots[7] = setupTextures("textures/gui/inventory/slot_gloves.png");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void loadArray(final ResourceLocation[] arr, final String tex) {
        for (int i = 0; i < arr.length; ++i) {
            arr[i] = setupTextures(tex + i + ".png");
        }
    }
    
    public static ResourceLocation getZombieTexture(final int zt) {
        return TextureRegistry.tex_zombies[zt];
    }
    
    public static ResourceLocation setupTextures(final String res) {
        final ResourceLocation loc = new ResourceLocation("daym:" + res);
        return loc;
    }
    
    public static void bindResource(final ResourceLocation res) {
        Minecraft.func_71410_x().field_71446_o.func_110577_a(res);
    }
    
    public static ResourceLocation handleSkin(final Entity par1Entity) {
        if (!WorldHandler.daym_3bb3f01c0.containsKey(par1Entity.func_110124_au().toString())) {
            return TextureRegistry.player_skin_male[1];
        }
        final int test = WorldHandler.daym_3bb3f01c0.get(par1Entity.func_110124_au().toString());
        ResourceLocation[] skins = TextureRegistry.player_skin_male;
        if (test > 4) {
            skins = TextureRegistry.player_skin_female;
            final int int1 = test - 5;
            return skins[int1];
        }
        return skins[test];
    }
    
    public static ResourceLocation handleSkin(final int id, final boolean isf) {
        ResourceLocation[] skins = TextureRegistry.player_skin_male;
        if (isf) {
            skins = TextureRegistry.player_skin_female;
            return skins[id];
        }
        return skins[id];
    }
    
    static {
        TextureRegistry.player_skin_male = new ResourceLocation[5];
        TextureRegistry.player_skin_female = new ResourceLocation[5];
        TextureRegistry.c_headgear = new ResourceLocation[3];
        TextureRegistry.c_shirt = new ResourceLocation[15];
        TextureRegistry.c_pants = new ResourceLocation[6];
        TextureRegistry.c_shoes = new ResourceLocation[4];
        TextureRegistry.backpack = new ResourceLocation[6];
        TextureRegistry.tex_zombies = new ResourceLocation[3];
        TextureRegistry.tutorial = new ResourceLocation[11];
        TextureRegistry.gunAttachments = new ResourceLocation[1];
        TextureRegistry.gui_playerinv_slots = new ResourceLocation[8];
        TextureRegistry.c_vest = new ResourceLocation[1];
        TextureRegistry.c_headwear = new ResourceLocation[1];
        TextureRegistry.c_gloves = new ResourceLocation[3];
        TextureRegistry.camos = new ResourceLocation[2];
    }
}
