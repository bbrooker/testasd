package com.daym.registry;

import net.minecraft.block.*;
import com.daym.*;
import com.daym.misc.*;
import net.minecraft.block.material.*;
import net.minecraft.creativetab.*;
import com.daym.blocks.tileentity.*;
import cpw.mods.fml.common.*;
import net.minecraft.client.resources.*;
import com.daym.logger.*;
import cpw.mods.fml.common.registry.*;
import com.daym.blocks.tile.*;
import com.daym.blocks.*;
import com.daym.models.*;

public class BlockRegistry
{
    public static Block[] tileFloor;
    public static Block[] tileFloorStairs;
    public static Block[] tileFloorSlabs;
    public static Block[] tileFloorSlopes;
    public static String[] tileFloorTypes;
    public static Block.SoundType[] tileFloorSounds;
    public static Block[] woodPlank;
    public static Block[] woodPlankStairs;
    public static Block[] woodPlankSlabs;
    public static Block[] woodPlankSlopes;
    public static String[] woodPlankTypes;
    public static Block.SoundType[] woodPlankSounds;
    public static Block[] concreteBlock;
    public static Block[] concreteBlockStairs;
    public static Block[] concreteBlockSlabs;
    public static Block[] concreteBlockSlopes;
    public static String[] concreteBlockTypes;
    public static Block.SoundType[] concreteBlockSounds;
    public static Block[] plasterBlock;
    public static Block[] plasterBlockStairs;
    public static Block[] plasterBlockSlabs;
    public static Block[] plasterBlockSlopes;
    public static String[] plasterBlockTypes;
    public static Block.SoundType[] plasterBlockSounds;
    public static Block crate;
    public static Block asphaltBlock;
    public static Block asphaltBlock_1;
    public static Block asphaltBlock_2;
    public static Block asphaltBlock_3;
    public static Block asphaltBlock_slabfull;
    public static Block asphaltBlock_slab;
    public static Block bookshelf;
    public static Block bookshelf_slab;
    public static Block bookshelf_empty;
    public static Block bookshelf_emptyslab;
    public static Block[] roofTile;
    public static Block[] roofTileStairs;
    public static Block[] roofTileSlabs;
    public static Block[] roofTileSlopes;
    public static String[] roofTileTypes;
    public static Block.SoundType[] roofTileSounds;
    public static Block[] glassPane;
    public static String[] glassPaneTypes;
    public static Block.SoundType[] glassPaneSounds;
    static DayMBoundingBox dbb;
    public static Block trafficCone;
    static DayMBoundingBox dbb2;
    public static Block invisibleLight;
    static DayMBoundingBox dbb3;
    public static Block woodenChair1;
    static DayMBoundingBox dbb4;
    public static Block woodenChair2;
    static DayMBoundingBox dbb5;
    public static Block woodenTable1;
    static DayMBoundingBox dbb6;
    public static Block woodenTable2;
    static DayMBoundingBox dbb7;
    public static Block metalShelf1;
    static DayMBoundingBox dbb8;
    public static Block woodenBench1;
    public static Block asphaltBlock_1_45;
    public static Block asphaltBlock_2_45;
    
    public BlockRegistry() {
        final Block[] tileFloor = BlockRegistry.tileFloor;
        final int id = 2;
        final String type = "slabF";
        final DayMTabHandler daym_d4179bfe0 = DayM.daym_d4179bfe0;
        this.constructBlockArray(tileFloor, id, type, DayMTabHandler.tabDayMBlocks, "blockTileFloor", "daym:tilefloor/tile_floor_", "daym_tilefloor");
        final Block[] tileFloorStairs = BlockRegistry.tileFloorStairs;
        final int id2 = 2;
        final String type2 = "stair";
        final DayMTabHandler daym_d4179bfe2 = DayM.daym_d4179bfe0;
        this.constructBlockArray(tileFloorStairs, id2, type2, DayMTabHandler.tabDayMStairs, "stairsTileFloor", "daym:tilefloor/tile_floor_", "daym_tilefloor_stairs");
        final Block[] tileFloorSlabs = BlockRegistry.tileFloorSlabs;
        final int id3 = 2;
        final String type3 = "slab";
        final DayMTabHandler daym_d4179bfe3 = DayM.daym_d4179bfe0;
        this.constructBlockArray(tileFloorSlabs, id3, type3, DayMTabHandler.tabDayMSlabs, "slabTileFloor", "daym:tilefloor/tile_floor_", "daym_tilefloor_slab");
        final Block[] tileFloorSlopes = BlockRegistry.tileFloorSlopes;
        final int id4 = 2;
        final String type4 = "slope";
        final DayMTabHandler daym_d4179bfe4 = DayM.daym_d4179bfe0;
        this.constructBlockArray(tileFloorSlopes, id4, type4, DayMTabHandler.tabDayMSlopes, "slopeTileFloor", "daym:tilefloor/tile_floor_", "daym_tilefloor_slope");
        final Block[] woodPlank = BlockRegistry.woodPlank;
        final int id5 = 3;
        final String type5 = "slabF";
        final DayMTabHandler daym_d4179bfe5 = DayM.daym_d4179bfe0;
        this.constructBlockArray(woodPlank, id5, type5, DayMTabHandler.tabDayMBlocks, "blockWoodPlank", "daym:woodplanks/wood_planks_", "daym_woodplanks");
        final Block[] woodPlankStairs = BlockRegistry.woodPlankStairs;
        final int id6 = 3;
        final String type6 = "stair";
        final DayMTabHandler daym_d4179bfe6 = DayM.daym_d4179bfe0;
        this.constructBlockArray(woodPlankStairs, id6, type6, DayMTabHandler.tabDayMStairs, "stairsWoodPlank", "daym:woodplanks/wood_planks_", "daym_woodplanks_stairs");
        final Block[] woodPlankSlabs = BlockRegistry.woodPlankSlabs;
        final int id7 = 3;
        final String type7 = "slab";
        final DayMTabHandler daym_d4179bfe7 = DayM.daym_d4179bfe0;
        this.constructBlockArray(woodPlankSlabs, id7, type7, DayMTabHandler.tabDayMSlabs, "slabWoodPlank", "daym:woodplanks/wood_planks_", "daym_woodplanks_slab");
        final Block[] woodPlankSlopes = BlockRegistry.woodPlankSlopes;
        final int id8 = 3;
        final String type8 = "slope";
        final DayMTabHandler daym_d4179bfe8 = DayM.daym_d4179bfe0;
        this.constructBlockArray(woodPlankSlopes, id8, type8, DayMTabHandler.tabDayMSlopes, "slopeWoodPlank", "daym:woodplanks/wood_planks_", "daym_woodplanks_slope");
        final Block[] concreteBlock = BlockRegistry.concreteBlock;
        final int id9 = 4;
        final String type9 = "slabF";
        final DayMTabHandler daym_d4179bfe9 = DayM.daym_d4179bfe0;
        this.constructBlockArray(concreteBlock, id9, type9, DayMTabHandler.tabDayMBlocks, "blockConcrete", "daym:concrete/concrete_", "daym_concrete");
        final Block[] concreteBlockStairs = BlockRegistry.concreteBlockStairs;
        final int id10 = 4;
        final String type10 = "stair";
        final DayMTabHandler daym_d4179bfe10 = DayM.daym_d4179bfe0;
        this.constructBlockArray(concreteBlockStairs, id10, type10, DayMTabHandler.tabDayMStairs, "stairsConcrete", "daym:concrete/concrete_", "daym_concrete_stairs");
        final Block[] concreteBlockSlabs = BlockRegistry.concreteBlockSlabs;
        final int id11 = 4;
        final String type11 = "slab";
        final DayMTabHandler daym_d4179bfe11 = DayM.daym_d4179bfe0;
        this.constructBlockArray(concreteBlockSlabs, id11, type11, DayMTabHandler.tabDayMSlabs, "slabConcrete", "daym:concrete/concrete_", "daym_concrete_slab");
        final Block[] concreteBlockSlopes = BlockRegistry.concreteBlockSlopes;
        final int id12 = 4;
        final String type12 = "slope";
        final DayMTabHandler daym_d4179bfe12 = DayM.daym_d4179bfe0;
        this.constructBlockArray(concreteBlockSlopes, id12, type12, DayMTabHandler.tabDayMSlopes, "slopeConcrete", "daym:concrete/concrete_", "daym_concrete_slope");
        final Block[] plasterBlock = BlockRegistry.plasterBlock;
        final int id13 = 5;
        final String type13 = "slabF";
        final DayMTabHandler daym_d4179bfe13 = DayM.daym_d4179bfe0;
        this.constructBlockArray(plasterBlock, id13, type13, DayMTabHandler.tabDayMBlocks, "blockPlaster", "daym:plaster/plaster_", "daym_plaster");
        final Block[] plasterBlockStairs = BlockRegistry.plasterBlockStairs;
        final int id14 = 5;
        final String type14 = "stair";
        final DayMTabHandler daym_d4179bfe14 = DayM.daym_d4179bfe0;
        this.constructBlockArray(plasterBlockStairs, id14, type14, DayMTabHandler.tabDayMStairs, "stairsPlaster", "daym:plaster/plaster_", "daym_plaster_stairs");
        final Block[] plasterBlockSlabs = BlockRegistry.plasterBlockSlabs;
        final int id15 = 5;
        final String type15 = "slab";
        final DayMTabHandler daym_d4179bfe15 = DayM.daym_d4179bfe0;
        this.constructBlockArray(plasterBlockSlabs, id15, type15, DayMTabHandler.tabDayMSlabs, "slabPlaster", "daym:plaster/plaster_", "daym_plaster_slab");
        final Block[] plasterBlockSlopes = BlockRegistry.plasterBlockSlopes;
        final int id16 = 5;
        final String type16 = "slope";
        final DayMTabHandler daym_d4179bfe16 = DayM.daym_d4179bfe0;
        this.constructBlockArray(plasterBlockSlopes, id16, type16, DayMTabHandler.tabDayMSlopes, "slopePlaster", "daym:plaster/plaster_", "daym_plaster_slope");
        this.addBlock(BlockRegistry.crate, "crateBlock", "daym:misc/crate", "daym_crate", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.asphaltBlock, "asphaltBlock", "daym:asphalt/asphalt_clean", "daym_asphalt", Block.field_149769_e, 0);
        this.addBlock(BlockRegistry.asphaltBlock_1, "asphaltBlock1", "daym:asphalt/asphalt_clean", "daym_asphalt1", Block.field_149769_e, 0);
        this.addBlock(BlockRegistry.asphaltBlock_2, "asphaltBlock2", "daym:asphalt/asphalt_clean", "daym_asphalt2", Block.field_149769_e, 0);
        this.addBlock(BlockRegistry.asphaltBlock_3, "asphaltBlock3", "daym:asphalt/asphalt_clean", "daym_asphalt3", Block.field_149769_e, 0);
        this.addBlock(BlockRegistry.asphaltBlock_slabfull, "asphaltBlockslabfull", "daym:asphalt/asphalt_clean", "daym_asphaltslabf", Block.field_149769_e, 0);
        this.addBlock(BlockRegistry.asphaltBlock_slab, "asphaltBlockslab", "daym:asphalt/asphalt_clean", "daym_asphaltslab", Block.field_149769_e, 0);
        this.addBlock(BlockRegistry.bookshelf, "blockBookShelf", "minecraft:bookshelf", "daym_bookshelf", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.bookshelf_slab, "slabBookShelf", "minecraft:bookshelf", "daym_bookshelfslab", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.bookshelf_empty, "blockBookShelfEmpty", "daym:misc/book_shelf_empty", "daym_bookshelfempty", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.bookshelf_emptyslab, "slabBookShelfEmpty", "daym:misc/book_shelf_empty", "daym_bookshelfemptyslab", Block.field_149766_f, 0);
        final Block[] roofTile = BlockRegistry.roofTile;
        final int id17 = 6;
        final String type17 = "slabF";
        final DayMTabHandler daym_d4179bfe17 = DayM.daym_d4179bfe0;
        this.constructBlockArray(roofTile, id17, type17, DayMTabHandler.tabDayMBlocks, "blockRoofTile", "daym:rooftile/rooftile_", "daym_rooftile");
        final Block[] roofTileStairs = BlockRegistry.roofTileStairs;
        final int id18 = 6;
        final String type18 = "stair";
        final DayMTabHandler daym_d4179bfe18 = DayM.daym_d4179bfe0;
        this.constructBlockArray(roofTileStairs, id18, type18, DayMTabHandler.tabDayMStairs, "stairsRoofTile", "daym:rooftile/rooftile_", "daym_rooftile_stairs");
        final Block[] roofTileSlabs = BlockRegistry.roofTileSlabs;
        final int id19 = 6;
        final String type19 = "slab";
        final DayMTabHandler daym_d4179bfe19 = DayM.daym_d4179bfe0;
        this.constructBlockArray(roofTileSlabs, id19, type19, DayMTabHandler.tabDayMSlabs, "slabRoofTile", "daym:rooftile/rooftile_", "daym_rooftile_slab");
        final Block[] roofTileSlopes = BlockRegistry.roofTileSlopes;
        final int id20 = 6;
        final String type20 = "slope";
        final DayMTabHandler daym_d4179bfe20 = DayM.daym_d4179bfe0;
        this.constructBlockArray(roofTileSlopes, id20, type20, DayMTabHandler.tabDayMSlopes, "slopeRoofTile", "daym:rooftile/rooftile_", "daym_rooftile_slope");
        this.addBlockArray(0, BlockRegistry.glassPane, BlockRegistry.glassPaneTypes, BlockRegistry.glassPaneSounds, "glassPaneDayM", "daym:glass/glass_", "daym_glasspane", "daym:glass/glass_top_");
        this.addBlock(BlockRegistry.trafficCone, "blockTrafficCone", "daym:icons/trafficcone", "daym_traffic_cone", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.invisibleLight, "blockInvisibleLight", "daym:misc/invisible", "daym_light_invs", Block.field_149775_l, 0);
        this.addBlock(BlockRegistry.woodenChair1, "blockWoodenChair", "daym:icons/chair", "daym_wooden_chair_1", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.woodenChair2, "blockChair2", "daym:icons/chair2", "daym_wooden_chair_2", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.woodenTable1, "blockWoodenTable", "daym:icons/table", "daym_wooden_table_1", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.woodenTable2, "blockWoodenTable2", "daym:icons/table2", "daym_wooden_table_2", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.metalShelf1, "blockMetalShelf1", "daym:icons/metalshelf1", "daym_metal_shelf_1", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.woodenBench1, "blockWoodenBench1", "daym:icons/bench1", "daym_wooden_bench_1", Block.field_149766_f, 0);
        this.addBlock(BlockRegistry.asphaltBlock_1_45, "asphaltBlock1_45", "daym:asphalt/asphalt_clean", "daym_asphalt1_45", Block.field_149769_e, 0);
        this.addBlock(BlockRegistry.asphaltBlock_2_45, "asphaltBlock2_45", "daym:asphalt/asphalt_clean", "daym_asphalt2_45", Block.field_149769_e, 0);
    }
    
    private void addBlock(final int i, final Block block, final String[] types, final Block.SoundType[] sounds, final String name, final String tex, final String unlocName) {
        if (block != null) {
            this.addBlock(block, name + types[i], tex + types[i].toLowerCase(), unlocName + types[i].toLowerCase(), sounds[i], i);
        }
    }
    
    private void addBlockArray(final int id, final Block[] blocks, final String[] types, final Block.SoundType[] sounds, final String name, final String tex, final String unlocName, final String extra) {
        int i = 0;
        for (Block block : blocks) {
            if (id == 0) {
                final Block func_149711_c = new BlockDayMGlassPane(tex + types[i].toLowerCase(), extra + types[i].toLowerCase(), Material.field_151592_s, false).func_149711_c(0.5f);
                final DayMTabHandler daym_d4179bfe0 = DayM.daym_d4179bfe0;
                block = func_149711_c.func_149647_a(DayMTabHandler.tabDayMBlocks);
            }
            this.addBlock(block, name + types[i], tex + types[i].toLowerCase(), unlocName + types[i].toLowerCase(), sounds[i], i);
            ++i;
        }
    }
    
    private void constructBlockArray(final Block[] blocks, final int id, final String type, final CreativeTabs tab, final String name, final String tex, final String unlocName) {
        int i = 0;
        for (Block block : blocks) {
            if (type == "decorative") {
                block = new BlockDecorative(Material.field_151578_c).func_149711_c(0.5f).func_149647_a(tab);
                blocks[i] = block;
            }
            if (id == 0) {
                this.addBlock(i, block, BlockRegistry.tileFloorTypes, BlockRegistry.tileFloorSounds, name, tex, unlocName);
            }
            if (id == 1) {
                this.addBlock(i, block, BlockRegistry.woodPlankTypes, BlockRegistry.woodPlankSounds, name, tex, unlocName);
            }
            final boolean isStair = type == "stair";
            if (type == "stair" || type == "slope") {
                if (id == 2) {
                    if (BlockRegistry.tileFloor[i] != null) {
                        if (isStair) {
                            block = new BlockDayMStairs(BlockRegistry.tileFloor[i], 0).func_149711_c(0.5f).func_149647_a(tab);
                        }
                        else {
                            block = new BlockCustomTileStair(Material.field_151578_c, TileCustomRender.class, tex, BlockRegistry.tileFloor[i], 0).func_149711_c(0.5f).func_149647_a(tab);
                        }
                        blocks[i] = block;
                    }
                    this.addBlock(i, block, BlockRegistry.tileFloorTypes, BlockRegistry.tileFloorSounds, name, tex, unlocName);
                }
                if (id == 3) {
                    if (BlockRegistry.woodPlank[i] != null) {
                        if (isStair) {
                            block = new BlockDayMStairs(BlockRegistry.woodPlank[i], 0).func_149711_c(0.5f).func_149647_a(tab);
                        }
                        else {
                            block = new BlockCustomTileStair(Material.field_151578_c, TileCustomRender.class, tex, BlockRegistry.woodPlank[i], 0).func_149711_c(0.5f).func_149647_a(tab);
                        }
                        blocks[i] = block;
                    }
                    this.addBlock(i, block, BlockRegistry.woodPlankTypes, BlockRegistry.woodPlankSounds, name, tex, unlocName);
                }
                if (id == 4) {
                    if (BlockRegistry.concreteBlock[i] != null) {
                        if (isStair) {
                            block = new BlockDayMStairs(BlockRegistry.concreteBlock[i], 0).func_149711_c(0.5f).func_149647_a(tab);
                        }
                        else {
                            block = new BlockCustomTileStair(Material.field_151578_c, TileCustomRender.class, tex, BlockRegistry.concreteBlock[i], 0).func_149711_c(0.5f).func_149647_a(tab);
                        }
                        blocks[i] = block;
                    }
                    this.addBlock(i, block, BlockRegistry.concreteBlockTypes, BlockRegistry.concreteBlockSounds, name, tex, unlocName);
                }
                if (id == 5) {
                    if (BlockRegistry.plasterBlock[i] != null) {
                        if (isStair) {
                            block = new BlockDayMStairs(BlockRegistry.plasterBlock[i], 0).func_149711_c(0.5f).func_149647_a(tab);
                        }
                        else {
                            block = new BlockCustomTileStair(Material.field_151578_c, TileCustomRender.class, tex, BlockRegistry.plasterBlock[i], 0).func_149711_c(0.5f).func_149647_a(tab);
                        }
                        blocks[i] = block;
                    }
                    this.addBlock(i, block, BlockRegistry.plasterBlockTypes, BlockRegistry.plasterBlockSounds, name, tex, unlocName);
                }
                if (id == 6) {
                    if (BlockRegistry.roofTile[i] != null) {
                        if (isStair) {
                            block = new BlockDayMStairs(BlockRegistry.roofTile[i], 0).func_149711_c(0.5f).func_149647_a(tab);
                        }
                        else {
                            block = new BlockCustomTileStair(Material.field_151578_c, TileCustomRender.class, tex, BlockRegistry.roofTile[i], 0).func_149711_c(0.5f).func_149647_a(tab);
                        }
                        blocks[i] = block;
                    }
                    this.addBlock(i, block, BlockRegistry.roofTileTypes, BlockRegistry.roofTileSounds, name, tex, unlocName);
                }
            }
            if (type == "slab" || type == "slabF") {
                boolean full = false;
                Block fullB = null;
                if (id == 2) {
                    if (type == "slabF") {
                        full = true;
                    }
                    else {
                        fullB = BlockRegistry.tileFloor[i];
                    }
                    block = new BlockDayMSlab(full, Material.field_151578_c, fullB, name).func_149711_c(0.5f).func_149647_a(tab);
                    this.addBlock(i, blocks[i] = block, BlockRegistry.tileFloorTypes, BlockRegistry.tileFloorSounds, name, tex, unlocName);
                }
                if (id == 3) {
                    if (type == "slabF") {
                        full = true;
                    }
                    else {
                        fullB = BlockRegistry.woodPlank[i];
                    }
                    block = new BlockDayMSlab(full, Material.field_151578_c, fullB, name).func_149711_c(0.5f).func_149647_a(tab);
                    this.addBlock(i, blocks[i] = block, BlockRegistry.woodPlankTypes, BlockRegistry.woodPlankSounds, name, tex, unlocName);
                }
                if (id == 4) {
                    if (type == "slabF") {
                        full = true;
                    }
                    else {
                        fullB = BlockRegistry.concreteBlock[i];
                    }
                    block = new BlockDayMSlab(full, Material.field_151578_c, fullB, name).func_149711_c(0.5f).func_149647_a(tab);
                    this.addBlock(i, blocks[i] = block, BlockRegistry.concreteBlockTypes, BlockRegistry.concreteBlockSounds, name, tex, unlocName);
                }
                if (id == 5) {
                    if (type == "slabF") {
                        full = true;
                    }
                    else {
                        fullB = BlockRegistry.plasterBlock[i];
                    }
                    block = new BlockDayMSlab(full, Material.field_151578_c, fullB, name).func_149711_c(0.5f).func_149647_a(tab);
                    this.addBlock(i, blocks[i] = block, BlockRegistry.plasterBlockTypes, BlockRegistry.plasterBlockSounds, name, tex, unlocName);
                }
                if (id == 6) {
                    if (type == "slabF") {
                        full = true;
                    }
                    else {
                        fullB = BlockRegistry.roofTile[i];
                    }
                    block = new BlockDayMSlab(full, Material.field_151578_c, fullB, name).func_149711_c(0.5f).func_149647_a(tab);
                    this.addBlock(i, blocks[i] = block, BlockRegistry.roofTileTypes, BlockRegistry.roofTileSounds, name, tex, unlocName);
                }
            }
            ++i;
        }
    }
    
    private void addBlock(final Block block, final String s1, final String s2, final String s3, final Block.SoundType s4, final int i) {
        block.func_149663_c(s1);
        if (s2 != "") {
            block.func_149658_d(s2);
        }
        block.func_149672_a(s4);
        if (s1.toLowerCase().contains("stair")) {
            block.func_149713_g(0);
        }
        if (FMLCommonHandler.instance().getEffectiveSide().isClient()) {
            final String test = "tile." + s1 + ".name";
            if (I18n.func_135052_a(test, new Object[0]).contains(test)) {
                daymlog.out("Block missing LANG mapping: " + test);
            }
        }
        if (s1.toLowerCase().contains("slope")) {
            if (block instanceof BlockCustomTileStair) {
                final BlockCustomTileStair bcts = (BlockCustomTileStair)block;
                bcts.texture = s2;
            }
            block.func_149713_g(0);
        }
        if (!s1.toLowerCase().contains("slab")) {
            GameRegistry.registerBlock(block, s3);
        }
        else {
            block.func_149713_g(0);
            GameRegistry.registerBlock(block, (Class)ItemDayMSlab.class, s3);
        }
    }
    
    static {
        BlockRegistry.tileFloor = new Block[12];
        BlockRegistry.tileFloorStairs = new Block[12];
        BlockRegistry.tileFloorSlabs = new Block[12];
        BlockRegistry.tileFloorSlopes = new Block[12];
        BlockRegistry.tileFloorTypes = new String[] { "Wood", "Black", "Blue", "Green", "Purple", "Orange", "Red", "Teal", "Yellow", "Brown", "Gray", "LightBlue" };
        BlockRegistry.tileFloorSounds = new Block.SoundType[] { Block.field_149766_f, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e };
        BlockRegistry.woodPlank = new Block[10];
        BlockRegistry.woodPlankStairs = new Block[10];
        BlockRegistry.woodPlankSlabs = new Block[10];
        BlockRegistry.woodPlankSlopes = new Block[10];
        BlockRegistry.woodPlankTypes = new String[] { "Black", "Blue", "Dark", "Green", "Light", "Oak", "Red", "White", "Yellow", "Blue_Striped" };
        BlockRegistry.woodPlankSounds = new Block.SoundType[] { Block.field_149766_f, Block.field_149766_f, Block.field_149766_f, Block.field_149766_f, Block.field_149766_f, Block.field_149766_f, Block.field_149766_f, Block.field_149766_f, Block.field_149766_f, Block.field_149766_f };
        BlockRegistry.concreteBlock = new Block[5];
        BlockRegistry.concreteBlockStairs = new Block[5];
        BlockRegistry.concreteBlockSlabs = new Block[5];
        BlockRegistry.concreteBlockSlopes = new Block[5];
        BlockRegistry.concreteBlockTypes = new String[] { "RoughDark", "Dark", "Rough", "Smooth", "Tile" };
        BlockRegistry.concreteBlockSounds = new Block.SoundType[] { Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e };
        BlockRegistry.plasterBlock = new Block[18];
        BlockRegistry.plasterBlockStairs = new Block[18];
        BlockRegistry.plasterBlockSlabs = new Block[18];
        BlockRegistry.plasterBlockSlopes = new Block[18];
        BlockRegistry.plasterBlockTypes = new String[] { "Black", "Blue", "Gray", "Green", "Orange", "Pink", "Purple", "White", "Yellow", "Red", "BlueDark", "GrayDark", "GreenDark", "OrangeDark", "PinkDark", "PurpleDark", "YellowDark", "RedDark" };
        BlockRegistry.plasterBlockSounds = new Block.SoundType[] { Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e };
        final Block func_149711_c = new BlockDecorative(Material.field_151578_c).func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe0 = DayM.daym_d4179bfe0;
        BlockRegistry.crate = func_149711_c.func_149647_a(DayMTabHandler.tabDayMBlocks);
        final Block func_149711_c2 = new BlockDecorativeDir(Material.field_151578_c, "daym:asphalt/asphalt_clean", "daym:asphalt/asphalt_clean", "daym:asphalt/asphalt_clean").func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe2 = DayM.daym_d4179bfe0;
        BlockRegistry.asphaltBlock = func_149711_c2.func_149647_a(DayMTabHandler.tabDayMBlocks);
        final Block func_149711_c3 = new BlockDecorativeDir(Material.field_151578_c, "daym:asphalt/asphalt_clean", "daym:asphalt/asphalt_middlestripe", "daym:asphalt/asphalt_middlestripehor").func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe3 = DayM.daym_d4179bfe0;
        BlockRegistry.asphaltBlock_1 = func_149711_c3.func_149647_a(DayMTabHandler.tabDayMBlocks);
        final Block func_149711_c4 = new BlockDecorativeDir(Material.field_151578_c, "daym:asphalt/asphalt_clean", "daym:asphalt/asphalt_doublestripe", "daym:asphalt/asphalt_doublestripehor").func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe4 = DayM.daym_d4179bfe0;
        BlockRegistry.asphaltBlock_2 = func_149711_c4.func_149647_a(DayMTabHandler.tabDayMBlocks);
        final Block func_149711_c5 = new BlockDecorativeDir(Material.field_151578_c, "daym:asphalt/asphalt_clean", "daym:asphalt/asphalt_stripes", "daym:asphalt/asphalt_stripeshor").func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe5 = DayM.daym_d4179bfe0;
        BlockRegistry.asphaltBlock_3 = func_149711_c5.func_149647_a(DayMTabHandler.tabDayMBlocks);
        BlockRegistry.asphaltBlock_slabfull = new BlockDayMSlabMT(true, Material.field_151578_c, null, "daym_asphaltslabf", "daym:asphalt/asphalt_clean", "daym:asphalt/asphalt_clean").func_149711_c(0.5f).func_149647_a((CreativeTabs)null);
        final Block func_149711_c6 = new BlockDayMSlabMT(false, Material.field_151578_c, BlockRegistry.asphaltBlock_slabfull, "daym_asphaltslab", "daym:asphalt/asphalt_clean", "daym:asphalt/asphalt_clean").func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe6 = DayM.daym_d4179bfe0;
        BlockRegistry.asphaltBlock_slab = func_149711_c6.func_149647_a(DayMTabHandler.tabDayMSlabs);
        BlockRegistry.bookshelf = new BlockDayMSlabMT(true, Material.field_151578_c, null, "daym_bookshelf", "minecraft:planks_oak", "minecraft:bookshelf").func_149711_c(0.5f).func_149647_a((CreativeTabs)null);
        final Block func_149711_c7 = new BlockDayMSlabMT(false, Material.field_151578_c, BlockRegistry.bookshelf, "daym_bookshelfslab", "minecraft:planks_oak", "minecraft:bookshelf").func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe7 = DayM.daym_d4179bfe0;
        BlockRegistry.bookshelf_slab = func_149711_c7.func_149647_a(DayMTabHandler.tabDayMSlabs);
        final Block func_149711_c8 = new BlockDayMSlabMT(true, Material.field_151578_c, null, "daym_bookshelfempty", "minecraft:planks_oak", "daym:misc/book_shelf_empty").func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe8 = DayM.daym_d4179bfe0;
        BlockRegistry.bookshelf_empty = func_149711_c8.func_149647_a(DayMTabHandler.tabDayMBlocks);
        final Block func_149711_c9 = new BlockDayMSlabMT(false, Material.field_151578_c, BlockRegistry.bookshelf_empty, "daym_bookshelfemptyslab", "minecraft:planks_oak", "daym:misc/book_shelf_empty").func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe9 = DayM.daym_d4179bfe0;
        BlockRegistry.bookshelf_emptyslab = func_149711_c9.func_149647_a(DayMTabHandler.tabDayMSlabs);
        BlockRegistry.roofTile = new Block[4];
        BlockRegistry.roofTileStairs = new Block[4];
        BlockRegistry.roofTileSlabs = new Block[4];
        BlockRegistry.roofTileSlopes = new Block[4];
        BlockRegistry.roofTileTypes = new String[] { "Black", "Brown", "Orange", "Sand" };
        BlockRegistry.roofTileSounds = new Block.SoundType[] { Block.field_149769_e, Block.field_149769_e, Block.field_149769_e, Block.field_149769_e };
        BlockRegistry.glassPane = new Block[2];
        BlockRegistry.glassPaneTypes = new String[] { "Black", "White" };
        BlockRegistry.glassPaneSounds = new Block.SoundType[] { Block.field_149778_k, Block.field_149778_k };
        BlockRegistry.dbb = new DayMBoundingBox(0.25f, 0.0f, 0.25f, 0.75f, 1.0f, 0.75f);
        final Block func_149711_c10 = new BlockCustomTile(Material.field_151578_c, TileCustomRender.class, "daym:misc/traffic_cone", 1, 0, null, BlockRegistry.dbb, false).func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe10 = DayM.daym_d4179bfe0;
        BlockRegistry.trafficCone = func_149711_c10.func_149647_a(DayMTabHandler.tabDayMDecoration);
        BlockRegistry.dbb2 = new DayMBoundingBox(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
        BlockRegistry.invisibleLight = new BlockLightFlash(Material.field_151594_q, BlockRegistry.dbb2).func_149711_c(0.5f).func_149715_a(0.6f).func_149647_a((CreativeTabs)null);
        BlockRegistry.dbb3 = new DayMBoundingBox(0.15f, 0.0f, 0.15f, 0.85f, 0.55f, 0.85f);
        final Block func_149711_c11 = new BlockCustomTile(Material.field_151578_c, TileCustomRender.class, "minecraft:planks_oak", 3, 0, ModelChair1.class, BlockRegistry.dbb3, false).func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe11 = DayM.daym_d4179bfe0;
        BlockRegistry.woodenChair1 = func_149711_c11.func_149647_a(DayMTabHandler.tabDayMDecoration);
        BlockRegistry.dbb4 = new DayMBoundingBox(0.2f, 0.0f, 0.2f, 0.8f, 0.885f, 0.8f);
        final Block func_149711_c12 = new BlockCustomTile(Material.field_151578_c, TileCustomRender.class, "minecraft:planks_oak", 3, 0, ModelChair2.class, BlockRegistry.dbb4, false).func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe12 = DayM.daym_d4179bfe0;
        BlockRegistry.woodenChair2 = func_149711_c12.func_149647_a(DayMTabHandler.tabDayMDecoration);
        BlockRegistry.dbb5 = new DayMBoundingBox(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        final Block func_149711_c13 = new BlockCustomTile(Material.field_151578_c, TileCustomRender.class, "minecraft:planks_oak", 3, 0, ModelTable1.class, BlockRegistry.dbb5, false).func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe13 = DayM.daym_d4179bfe0;
        BlockRegistry.woodenTable1 = func_149711_c13.func_149647_a(DayMTabHandler.tabDayMDecoration);
        BlockRegistry.dbb6 = new DayMBoundingBox(0.0f, 0.0f, 0.0f, 1.0f, 0.4f, 1.0f);
        final Block func_149711_c14 = new BlockCustomTile(Material.field_151578_c, TileCustomRender.class, "minecraft:planks_oak", 3, 0, ModelTable2.class, BlockRegistry.dbb6, false).func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe14 = DayM.daym_d4179bfe0;
        BlockRegistry.woodenTable2 = func_149711_c14.func_149647_a(DayMTabHandler.tabDayMDecoration);
        BlockRegistry.dbb7 = new DayMBoundingBox(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        final Block func_149711_c15 = new BlockCustomTile(Material.field_151578_c, TileCustomRender.class, "daym:plaster/plaster_gray", 3, 0, ModelShelf1.class, BlockRegistry.dbb7, true).func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe15 = DayM.daym_d4179bfe0;
        BlockRegistry.metalShelf1 = func_149711_c15.func_149647_a(DayMTabHandler.tabDayMDecoration);
        BlockRegistry.dbb8 = new DayMBoundingBox(0.0f, 0.0f, 0.0f, 1.0f, 0.5f, 1.0f);
        final Block func_149711_c16 = new BlockCustomTile(Material.field_151578_c, TileCustomRender.class, "minecraft:planks_oak", 3, 0, ModelBench1.class, BlockRegistry.dbb8, false).func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe16 = DayM.daym_d4179bfe0;
        BlockRegistry.woodenBench1 = func_149711_c16.func_149647_a(DayMTabHandler.tabDayMDecoration);
        final Block func_149711_c17 = new BlockDecorativeDir(Material.field_151578_c, "daym:asphalt/asphalt_clean", "daym:asphalt/asphalt_middlestripe_45", "daym:asphalt/asphalt_middlestripehor_45").func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe17 = DayM.daym_d4179bfe0;
        BlockRegistry.asphaltBlock_1_45 = func_149711_c17.func_149647_a(DayMTabHandler.tabDayMBlocks);
        final Block func_149711_c18 = new BlockDecorativeDir(Material.field_151578_c, "daym:asphalt/asphalt_clean", "daym:asphalt/asphalt_doublestripe_45", "daym:asphalt/asphalt_doublestripehor_45").func_149711_c(0.5f);
        final DayMTabHandler daym_d4179bfe18 = DayM.daym_d4179bfe0;
        BlockRegistry.asphaltBlock_2_45 = func_149711_c18.func_149647_a(DayMTabHandler.tabDayMBlocks);
    }
}
