package com.daym.registry;

import net.minecraft.entity.player.*;
import net.minecraft.client.renderer.entity.*;
import com.daym.entity.*;
import com.daym.render.entity.*;
import com.daym.entity.zombie.*;
import com.daym.render.entity.zombie.*;
import com.daym.blocks.tileentity.*;
import com.daym.render.tile.*;
import cpw.mods.fml.client.registry.*;
import net.minecraft.client.renderer.tileentity.*;

public class RenderRegistry
{
    public RenderRegistry() {
        RenderingRegistry.registerEntityRenderingHandler((Class)EntityPlayer.class, (Render)new RenderPlayerDayM());
        RenderingRegistry.registerEntityRenderingHandler((Class)EntityBullet.class, (Render)new RenderBullet());
        RenderingRegistry.registerEntityRenderingHandler((Class)EntityChair.class, (Render)new RenderChair());
        RenderingRegistry.registerEntityRenderingHandler((Class)EntityZombieBase.class, (Render)new RenderZombieBase());
        ClientRegistry.bindTileEntitySpecialRenderer((Class)TileCustomRender.class, (TileEntitySpecialRenderer)new RenderCustomBlock());
    }
}
