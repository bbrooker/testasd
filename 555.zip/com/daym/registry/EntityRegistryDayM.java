package com.daym.registry;

import com.daym.entity.*;
import com.daym.entity.zombie.*;
import java.awt.*;
import com.daym.blocks.tileentity.*;
import cpw.mods.fml.common.registry.*;
import com.daym.*;

public class EntityRegistryDayM
{
    public EntityRegistryDayM() {
        registerEntity(EntityBullet.class, "daym_entity_bullet");
        registerEntity(EntityChair.class, "daym_entity_chair");
        registerEntityLiving(EntityZombieBase.class, "daym_zombie_base", Color.black, Color.red);
        GameRegistry.registerTileEntity((Class)TileCustomRender.class, "tileCustomRender");
    }
    
    public static void registerEntity(final Class entityClass, final String name) {
        final int entityID = EntityRegistry.findGlobalUniqueEntityId();
        EntityRegistry.registerGlobalEntityID(entityClass, name, entityID);
        EntityRegistry.registerModEntity(entityClass, name, entityID, (Object)DayM.getInstance(), 64, 1, true);
    }
    
    public static void registerEntityLiving(final Class entityClass, final String name, final Color myColor, final Color myColor2) {
        final int entityID = EntityRegistry.findGlobalUniqueEntityId();
        final int color1 = (myColor.getRed() << 16) + (myColor.getGreen() << 8) + myColor.getBlue();
        final int color2 = (myColor2.getRed() << 16) + (myColor2.getGreen() << 8) + myColor2.getBlue();
        EntityRegistry.registerGlobalEntityID(entityClass, name, entityID, color1, color2);
        EntityRegistry.registerModEntity(entityClass, name, entityID, (Object)DayM.getInstance(), 80, 1, true);
    }
}
