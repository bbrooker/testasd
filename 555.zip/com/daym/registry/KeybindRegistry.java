package com.daym.registry;

import net.minecraft.client.settings.*;
import net.minecraft.client.*;
import com.daym.logger.*;
import cpw.mods.fml.client.registry.*;
import cpw.mods.fml.common.gameevent.*;
import com.daym.render.*;
import com.daym.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import com.daym.gui.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.gui.*;
import java.util.*;
import cpw.mods.fml.common.eventhandler.*;

public class KeybindRegistry
{
    public static Boolean[] keypressed;
    public static ArrayList<KeyBinding> keyList;
    Minecraft mc;
    public static boolean isKeyDown;
    
    public KeybindRegistry() {
        this.mc = Minecraft.func_71410_x();
        for (int i = 0; i < KeybindRegistry.keypressed.length; ++i) {
            daymlog.out("Mapping keybind: " + i);
            KeybindRegistry.keypressed[i] = false;
        }
        KeybindRegistry.keyList.add(register("key.reload", 19, "key.categories.daym"));
        KeybindRegistry.keyList.add(register("key.unload", 22, "key.categories.daym"));
        KeybindRegistry.keyList.add(register("key.viewgun", 33, "key.categories.daym"));
        KeybindRegistry.keyList.add(this.mc.field_71474_y.field_151445_Q);
        KeybindRegistry.keyList.add(register("key.handsup", 79, "key.categories.daym"));
        KeybindRegistry.keyList.add(register("key.wave", 80, "key.categories.daym"));
        KeybindRegistry.keyList.add(register("key.middlefinger", 81, "key.categories.daym"));
        KeybindRegistry.keyList.add(register("key.point", 75, "key.categories.daym"));
    }
    
    public static KeyBinding register(final String str1, final int key, final String str2) {
        final KeyBinding keyb = new KeyBinding(str1, key, str2);
        ClientRegistry.registerKeyBinding(keyb);
        return keyb;
    }
    
    @SubscribeEvent
    public void onKeyInput(final InputEvent.KeyInputEvent event) {
        int i = 0;
        for (final KeyBinding kb : KeybindRegistry.keyList) {
            KeybindRegistry.keypressed[i] = kb.func_151468_f();
            ++i;
        }
        if (KeybindRegistry.keypressed[3] && this.mc.field_71415_G && this.mc.field_71439_g != null && RenderSetup.daym_8a1531e40 == -1) {
            if (!KeybindRegistry.isKeyDown) {
                if (!this.mc.field_71439_g.field_71075_bZ.field_75098_d) {
                    DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_OpenGui(0, DayM.GUI_CUSTOM_INV));
                }
                else {
                    this.mc.func_147114_u().func_147297_a((Packet)new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
                    this.mc.func_147108_a((GuiScreen)new GuiInventoryMC((EntityPlayer)this.mc.field_71439_g));
                }
                KeybindRegistry.isKeyDown = true;
                return;
            }
            if (!this.mc.field_71439_g.field_71075_bZ.field_75098_d) {
                DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_OpenGui(1, DayM.GUI_CUSTOM_INV));
            }
            else {
                this.mc.func_147108_a((GuiScreen)null);
            }
            KeybindRegistry.isKeyDown = false;
        }
    }
    
    static {
        KeybindRegistry.keypressed = new Boolean[32];
        KeybindRegistry.keyList = new ArrayList<KeyBinding>();
        KeybindRegistry.isKeyDown = false;
    }
}
