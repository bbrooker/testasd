package com.daym.registry;

import com.daym.render.models.*;
import com.daym.daymobjloader.*;
import net.minecraft.client.model.*;
import java.util.*;
import com.daym.render.*;

public class ModelRegistry
{
    private static ModelBipedDayM lm;
    private static ArrayList<Object> boxlist;
    private static ArrayList<Object> boxlist2;
    private static float rotationYawPR;
    public static DayM_Model[] letterModels;
    public static DayM_Model[] blockSlanted;
    public static DayM_Model traffic_cone;
    public static DayM_Model mainmenu_terrain;
    public static DayM_Model tallgrass;
    public static DayM_Model box;
    public static DayM_Model[] gunAttachments;
    public static DayM_Model[] playerVests;
    public static DayM_Model[] playerHats;
    public static DayM_Model muzzleflash;
    public static DayM_Model front_muzzleflash;
    
    public ModelRegistry() {
        ModelRegistry.blockSlanted[0] = new DayM_Model("/com/daym/models/blocks/slanted.obj");
        ModelRegistry.blockSlanted[1] = new DayM_Model("/com/daym/models/blocks/slanted_corner1.obj");
        ModelRegistry.blockSlanted[2] = new DayM_Model("/com/daym/models/blocks/slanted_corner2.obj");
        ModelRegistry.traffic_cone = new DayM_Model("/com/daym/models/misc/traffic_cone1.obj");
        ModelRegistry.mainmenu_terrain = new DayM_Model("/com/daym/models/misc/daym_bg.obj");
        ModelRegistry.tallgrass = new DayM_Model("/com/daym/models/misc/tall_grass.obj");
        ModelRegistry.box = new DayM_Model("/com/daym/models/misc/box.obj");
        for (int i = 0; i < ModelRegistry.letterModels.length; ++i) {
            ModelRegistry.letterModels[i] = new DayM_Model("/com/daym/models/misc/letters/letter_d.obj");
        }
        ModelRegistry.gunAttachments[0] = new DayM_Model("/com/daym/models/attachments/ga_reddot.obj");
        ModelRegistry.playerVests[0] = new DayM_Model("/com/daym/models/player/vest_0.obj");
        ModelRegistry.playerHats[0] = new DayM_Model("/com/daym/models/player/headwear_0.obj");
        ModelRegistry.muzzleflash = new DayM_Model("/com/daym/models/misc/muzzle_flash.obj");
        ModelRegistry.front_muzzleflash = new DayM_Model("/com/daym/models/misc/front_muzzleflash.obj");
    }
    
    public static void renderTechne(final ModelBase mainModel) {
        for (final Object models : mainModel.field_78092_r) {
            if (models instanceof ModelRenderer) {
                final ModelRenderer box = (ModelRenderer)models;
                if (box.field_78807_k) {
                    continue;
                }
                box.func_78785_a(0.0625f);
            }
        }
    }
    
    static {
        ModelRegistry.lm = RenderSetup.daym_52058ee50;
        ModelRegistry.boxlist = new ArrayList<Object>();
        ModelRegistry.boxlist2 = new ArrayList<Object>();
        ModelRegistry.rotationYawPR = 0.0f;
        ModelRegistry.letterModels = new DayM_Model[30];
        ModelRegistry.blockSlanted = new DayM_Model[3];
        ModelRegistry.gunAttachments = new DayM_Model[3];
        ModelRegistry.playerVests = new DayM_Model[1];
        ModelRegistry.playerHats = new DayM_Model[1];
    }
}
