package com.daym.handlers;

import com.daym.tools.*;
import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.passive.*;
import com.daym.config.*;
import net.minecraft.entity.player.*;
import com.daym.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.server.*;
import java.util.*;
import cpw.mods.fml.common.*;
import java.io.*;

public class WorldHandler
{
    public static final Properties daym_2e14bae20;
    public static final Properties daym_3c31c2bc0;
    public static String daym_0b5a7f8a0;
    public static String daym_5635fd3d0;
    public static String daym_24d72dcb0;
    public static String daym_28d3f01a0;
    public static String daym_a5956ee00;
    public static ArrayList<ZombieSpawn> daym_9fe0fd250;
    public static ArrayList<PlayerSpawn> daym_d9470e610;
    public static ArrayList<LootSpawn> daym_d5981e440;
    public static ArrayList<Entity> daym_54c1b80c0;
    public static ArrayList<EntityItem> daym_4ceb36930;
    public static ArrayList<EntityItem> daym_801545040;
    public static HashMap<String, Integer> daym_3bb3f01c0;
    public static HashMap<Integer, IInventory> daym_8c6969130;
    public static HashMap<String, Boolean> daym_9619787d0;
    public static HashMap<String, ArrayList> daym_e3864ff00;
    public static ArrayList<String> daym_e94bfd790;
    public static int daym_f4e660b80;
    public static ArrayList<EntityChicken> daym_e0d55c940;
    public static int daym_095996cc0;
    public static boolean canGrief;
    public static String worldBorder;
    
    public static void setDirectoryAndLoad(final String s) {
        if (WorldHandler.daym_0b5a7f8a0 == "null" && s != "null") {
            WorldHandler.daym_0b5a7f8a0 = s;
        }
        daym_df85ad1e0();
        WorldHandler.daym_5635fd3d0 = (String)DayMConfig.loadProp(WorldHandler.daym_2e14bae20, WorldHandler.daym_5635fd3d0, "null", "zombieSpawnLocations");
        final String[] data = daym_4524cfb60(WorldHandler.daym_5635fd3d0, null);
        daym_56da15940(data);
        WorldHandler.daym_24d72dcb0 = (String)DayMConfig.loadProp(WorldHandler.daym_2e14bae20, WorldHandler.daym_24d72dcb0, "null", "playerSpawnLocations");
        final String[] data2 = daym_4524cfb60(WorldHandler.daym_24d72dcb0, null);
        daym_788aec670(data2);
        WorldHandler.daym_28d3f01a0 = (String)DayMConfig.loadProp(WorldHandler.daym_2e14bae20, WorldHandler.daym_28d3f01a0, "null", "lootLocations");
        final String[] data3 = daym_4524cfb60(WorldHandler.daym_28d3f01a0, null);
        daym_09520b930(data3);
        WorldHandler.daym_a5956ee00 = (String)DayMConfig.loadProp(WorldHandler.daym_2e14bae20, WorldHandler.daym_a5956ee00, "IgnoreNull,EntityBlaze,EntityCaveSpider,EntityCreeper,EntityEnderman,EntityGhast,EntityGiantZombie,EntityGolem,EntityIronGolem,EntityMagmaCube,EntityPigZombie,EntitySilverfish,EntitySkeleton,EntitySlime,EntitySnowman,EntitySpider,EntityWitch,EntityZombie", "disabledEntities");
        final String[] data4 = daym_4524cfb60(WorldHandler.daym_a5956ee00, ",");
        daym_1d4880d50(data4);
        WorldHandler.daym_f4e660b80 = Math.min(2, (int)DayMConfig.loadProp(WorldHandler.daym_2e14bae20, WorldHandler.daym_f4e660b80, 0, "forcePlayerCamera"));
        daym_3b7cb0b60();
        WorldHandler.canGrief = (boolean)DayMConfig.loadProp(WorldHandler.daym_2e14bae20, WorldHandler.canGrief, false, "canGrief");
        WorldHandler.worldBorder = (String)DayMConfig.loadProp(WorldHandler.daym_2e14bae20, WorldHandler.worldBorder, "0,0,0,0", "worldBorder");
        daym_c651688a0();
    }
    
    public static void daym_3b7cb0b60() {
        final MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        for (final Object o : server.field_71305_c[0].field_73010_i) {
            if (o instanceof EntityPlayerMP) {
                if (WorldHandler.daym_f4e660b80 > 16) {
                    WorldHandler.daym_f4e660b80 = 16;
                }
                if (WorldHandler.daym_f4e660b80 < 0) {
                    WorldHandler.daym_f4e660b80 = 0;
                }
                DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_ForceView((byte)WorldHandler.daym_f4e660b80), (EntityPlayerMP)o);
            }
        }
    }
    
    private static void daym_1d4880d50(final String[] data) {
        WorldHandler.daym_e94bfd790.clear();
        if (data != null) {
            for (final String d : data) {
                WorldHandler.daym_e94bfd790.add(d);
            }
        }
    }
    
    public static void daym_56da15940(final String[] data) {
        WorldHandler.daym_9fe0fd250.clear();
        if (data != null) {
            for (final String d : data) {
                try {
                    final String[] sd = d.split("\\.");
                    final int type = Integer.parseInt(sd[0]);
                    final int chance = Integer.parseInt(sd[1]);
                    final int radius = Integer.parseInt(sd[2]);
                    final int amount = Integer.parseInt(sd[3]);
                    final int randomize = Integer.parseInt(sd[4]);
                    daym_cf5555f70(type, chance, radius, amount, randomize, Integer.parseInt(sd[5]), Integer.parseInt(sd[6]), Integer.parseInt(sd[7]));
                    String fin = "";
                    for (final ZombieSpawn zs : WorldHandler.daym_9fe0fd250) {
                        fin += zs.location;
                    }
                    WorldHandler.daym_5635fd3d0 = fin;
                }
                catch (Exception ex) {}
            }
        }
    }
    
    public static void daym_788aec670(final String[] data) {
        WorldHandler.daym_d9470e610.clear();
        if (data != null) {
            for (final String d : data) {
                try {
                    final String[] sd = d.split("\\.");
                    final int chance = Integer.parseInt(sd[0]);
                    daym_6368556e0(chance, Integer.parseInt(sd[1]), Integer.parseInt(sd[2]), Integer.parseInt(sd[3]));
                    String fin = "";
                    for (final PlayerSpawn ps : WorldHandler.daym_d9470e610) {
                        fin += ps.location;
                    }
                    WorldHandler.daym_24d72dcb0 = fin;
                }
                catch (Exception ex) {}
            }
        }
    }
    
    public static void daym_09520b930(final String[] data) {
        WorldHandler.daym_d5981e440.clear();
        if (data != null) {
            for (final String d : data) {
                try {
                    final String[] sd = d.split("\\.");
                    final String t = sd[0];
                    final ArrayList<String> loots = LootSpawn.decodeLootTable(t);
                    final int lootid = Integer.parseInt(sd[1]);
                    final int rad = Integer.parseInt(sd[2]);
                    final int chance = Integer.parseInt(sd[3]);
                    final ArrayList<Integer> loot1 = new ArrayList<Integer>();
                    final ArrayList<Integer> loot2 = new ArrayList<Integer>();
                    for (final String ll : loots) {
                        final String[] ss = ll.split("\\?");
                        loot1.add(Integer.parseInt(ss[0]));
                        loot2.add(Integer.parseInt(ss[1]));
                    }
                    daym_5da285b70(loot1, loot2, lootid, rad, chance, Integer.parseInt(sd[4]), Integer.parseInt(sd[5]), Integer.parseInt(sd[6]));
                    String fin = "";
                    for (final LootSpawn ls : WorldHandler.daym_d5981e440) {
                        fin += ls.location;
                    }
                    WorldHandler.daym_28d3f01a0 = fin;
                }
                catch (Exception ex) {}
            }
        }
    }
    
    private static void daym_df85ad1e0() {
        if (WorldHandler.daym_0b5a7f8a0 == "null") {
            return;
        }
        final String basedir = Loader.instance().getConfigDir().getPath().replace("config", "") + "/";
        String var = "";
        if (DayM.serverProxy.isSinglePlayer()) {
            var = "saves/";
        }
        final File f = new File(basedir, var + WorldHandler.daym_0b5a7f8a0 + "/");
        File f2 = new File(f, "daym.cfg");
        DayMConfig.daym_df85ad1e0(f, f2, WorldHandler.daym_2e14bae20);
        f2 = new File(f, "daym_playerdata.cfg");
        DayMConfig.daym_df85ad1e0(f, f2, WorldHandler.daym_3c31c2bc0);
    }
    
    public static void daym_c651688a0() {
        if (WorldHandler.daym_0b5a7f8a0 == "null") {
            return;
        }
        final String basedir = Loader.instance().getConfigDir().getPath().replace("config", "") + "/";
        String var = "";
        if (DayM.serverProxy.isSinglePlayer()) {
            var = "saves/";
        }
        final File f = new File(basedir, var + WorldHandler.daym_0b5a7f8a0 + "/");
        File f2 = new File(f, "daym.cfg");
        DayMConfig.daym_c651688a0(f, f2, WorldHandler.daym_2e14bae20);
        f2 = new File(f, "daym_playerdata.cfg");
        DayMConfig.daym_c651688a0(f, f2, WorldHandler.daym_3c31c2bc0);
    }
    
    public static String[] daym_4524cfb60(final String loc, final String splitby) {
        if (loc == "null") {
            return null;
        }
        String[] data = loc.split("\\" + splitby);
        if (splitby == null) {
            data = loc.split("\\|");
            return data;
        }
        data = loc.split("\\" + splitby);
        if (!loc.contains(splitby)) {
            data = new String[] { loc };
        }
        return data;
    }
    
    public static void daym_cf5555f70(final int type, final int chance, final int radius, final int amount, final int randomize, final int x, final int y, final int z) {
        final ZombieSpawn zs = new ZombieSpawn(type, chance, radius, amount, randomize, x, y, z);
        WorldHandler.daym_9fe0fd250.add(zs);
    }
    
    public static void daym_2fe7daff0(final boolean saveconfig) {
        String fin = "";
        for (final ZombieSpawn zs : WorldHandler.daym_9fe0fd250) {
            fin += zs.location;
        }
        WorldHandler.daym_5635fd3d0 = fin;
        if (saveconfig) {
            DayMConfig.saveProp(WorldHandler.daym_2e14bae20, WorldHandler.daym_5635fd3d0, "zombieSpawnLocations");
            daym_c651688a0();
        }
    }
    
    public static boolean daym_46f78edb0(final int type, final int chance, final int radius, final int amount, final int randomize, final int x, final int y, final int z) {
        final String en = "." + x + "." + y + "." + z + "|";
        int i = 0;
        try {
            for (final ZombieSpawn zs : WorldHandler.daym_9fe0fd250) {
                if (WorldHandler.daym_9fe0fd250.get(i).location.contains(en)) {
                    WorldHandler.daym_9fe0fd250.remove(i);
                    return true;
                }
                ++i;
            }
        }
        catch (Exception ex) {}
        return false;
    }
    
    public static void daym_6368556e0(final int chance, final int x, final int y, final int z) {
        final PlayerSpawn ps = new PlayerSpawn(chance, x, y, z);
        WorldHandler.daym_d9470e610.add(ps);
    }
    
    public static void daym_8df4b26c0(final boolean saveconfig) {
        String fin = "";
        for (final PlayerSpawn ps : WorldHandler.daym_d9470e610) {
            fin += ps.location;
        }
        WorldHandler.daym_24d72dcb0 = fin;
        if (saveconfig) {
            DayMConfig.saveProp(WorldHandler.daym_2e14bae20, WorldHandler.daym_24d72dcb0, "playerSpawnLocations");
            daym_c651688a0();
        }
    }
    
    public static boolean daym_dc4d2fc30(final int chance, final int x, final int y, final int z) {
        final String en = "." + x + "." + y + "." + z + "|";
        int i = 0;
        try {
            for (final PlayerSpawn ps : WorldHandler.daym_d9470e610) {
                if (WorldHandler.daym_d9470e610.get(i).location.contains(en)) {
                    WorldHandler.daym_d9470e610.remove(i);
                    return true;
                }
                ++i;
            }
        }
        catch (Exception ex) {}
        return false;
    }
    
    public static void daym_5da285b70(final ArrayList<Integer> al, final ArrayList<Integer> alc, final int tableid, final int rad, final int chance, final int x, final int y, final int z) {
        final LootSpawn ps = new LootSpawn(al, alc, tableid, rad, chance, x, y, z);
        WorldHandler.daym_d5981e440.add(ps);
    }
    
    public static void daym_86fc86bb0(final boolean saveconfig) {
        String fin = "";
        for (final LootSpawn ps : WorldHandler.daym_d5981e440) {
            fin += ps.location;
        }
        WorldHandler.daym_28d3f01a0 = fin;
        if (saveconfig) {
            DayMConfig.saveProp(WorldHandler.daym_2e14bae20, WorldHandler.daym_28d3f01a0, "lootLocations");
            daym_c651688a0();
        }
    }
    
    public static boolean daym_9bdc5ed90(final int lid, final int chance, final int x, final int y, final int z) {
        final String en = "." + x + "." + y + "." + z + "|";
        int i = 0;
        try {
            for (final LootSpawn ps : WorldHandler.daym_d5981e440) {
                if (WorldHandler.daym_d5981e440.get(i).location.contains(en)) {
                    WorldHandler.daym_d5981e440.remove(i);
                    return true;
                }
                ++i;
            }
        }
        catch (Exception ex) {}
        return false;
    }
    
    public static int daym_3c94c7b50(final int hashCode) {
        boolean hasID = WorldHandler.daym_8c6969130.containsKey(hashCode);
        int newID = hashCode;
        int i = 0;
        while (hasID) {
            ++i;
            newID = hashCode + i;
            hasID = WorldHandler.daym_8c6969130.containsKey(newID);
        }
        return newID;
    }
    
    static {
        daym_2e14bae20 = new Properties();
        daym_3c31c2bc0 = new Properties();
        WorldHandler.daym_0b5a7f8a0 = "null";
        WorldHandler.daym_5635fd3d0 = "null";
        WorldHandler.daym_24d72dcb0 = "null";
        WorldHandler.daym_28d3f01a0 = "null";
        WorldHandler.daym_a5956ee00 = "null";
        WorldHandler.daym_9fe0fd250 = new ArrayList<ZombieSpawn>();
        WorldHandler.daym_d9470e610 = new ArrayList<PlayerSpawn>();
        WorldHandler.daym_d5981e440 = new ArrayList<LootSpawn>();
        WorldHandler.daym_54c1b80c0 = new ArrayList<Entity>();
        WorldHandler.daym_4ceb36930 = new ArrayList<EntityItem>();
        WorldHandler.daym_801545040 = new ArrayList<EntityItem>();
        WorldHandler.daym_3bb3f01c0 = new HashMap<String, Integer>();
        WorldHandler.daym_8c6969130 = new HashMap<Integer, IInventory>();
        WorldHandler.daym_9619787d0 = new HashMap<String, Boolean>();
        WorldHandler.daym_e3864ff00 = new HashMap<String, ArrayList>();
        WorldHandler.daym_e94bfd790 = new ArrayList<String>();
        WorldHandler.daym_f4e660b80 = 0;
        WorldHandler.daym_e0d55c940 = new ArrayList<EntityChicken>();
        WorldHandler.daym_095996cc0 = 5;
        WorldHandler.canGrief = false;
        WorldHandler.worldBorder = "0,0,0,0";
    }
}
