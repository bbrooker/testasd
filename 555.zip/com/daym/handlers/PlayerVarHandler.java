package com.daym.handlers;

import java.util.*;

public class PlayerVarHandler
{
    public static HashMap<String, Boolean> clickingList;
    public static HashMap<String, Boolean> canUnclickList;
    public static HashMap<String, Byte> daym_b73359c80;
    
    static {
        PlayerVarHandler.clickingList = new HashMap<String, Boolean>();
        PlayerVarHandler.canUnclickList = new HashMap<String, Boolean>();
        PlayerVarHandler.daym_b73359c80 = new HashMap<String, Byte>();
    }
}
