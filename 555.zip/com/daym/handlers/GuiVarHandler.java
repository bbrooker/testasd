package com.daym.handlers;

public class GuiVarHandler
{
    public float mtcm_posX;
    
    public GuiVarHandler() {
        this.mtcm_posX = 0.0f;
    }
}
