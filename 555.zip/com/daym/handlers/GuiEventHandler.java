package com.daym.handlers;

import cpw.mods.fml.common.network.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.inventory.*;
import cpw.mods.fml.common.eventhandler.*;
import net.minecraftforge.client.event.*;
import com.daym.clientproxy.*;
import org.lwjgl.opengl.*;
import com.daym.render.*;
import com.daym.*;
import com.daym.config.*;
import java.awt.*;
import com.daym.extended.*;
import com.daym.registry.*;
import net.minecraft.client.renderer.*;
import com.daym.items.*;
import net.minecraft.util.*;
import org.lwjgl.input.*;
import com.daym.gui.*;
import net.minecraft.client.gui.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraft.world.*;
import cpw.mods.fml.common.*;
import com.daym.gui.inventory.*;
import com.daym.inventory.*;

@SideOnly(Side.CLIENT)
public class GuiEventHandler implements IGuiHandler
{
    protected static final RenderItem itemRenderer;
    Minecraft mc;
    public static GuiScreen currentScreen;
    public static GuiScreen lastScreen;
    
    public GuiEventHandler() {
        this.mc = Minecraft.func_71410_x();
    }
    
    @SubscribeEvent
    public void onOpenGui(final GuiScreenEvent e) {
        GuiScreen scr = this.mc.field_71462_r;
        if (e.gui instanceof GuiMainMenu) {
            this.mc.func_147108_a((GuiScreen)new GuiDaymMainMenu());
            if (GuiEventHandler.currentScreen != scr) {
                GuiEventHandler.lastScreen = GuiEventHandler.currentScreen;
                GuiEventHandler.currentScreen = scr;
            }
        }
        if (e.gui instanceof GuiInventory && !(e.gui instanceof GuiPlayerInventoryDayM)) {
            this.mc.func_147108_a((GuiScreen)null);
        }
        if (e.gui instanceof GuiMultiplayer && !(e.gui instanceof GuiMultiplayerMC)) {
            scr = (GuiScreen)new GuiMainMenu();
            this.mc.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, 0));
        }
        if (e.gui instanceof GuiIngameMenu && !(e.gui instanceof GuiIngameMenuDayM)) {
            this.mc.func_147108_a((GuiScreen)new GuiIngameMenuDayM());
            if (GuiEventHandler.currentScreen != scr) {
                GuiEventHandler.lastScreen = GuiEventHandler.currentScreen;
                GuiEventHandler.currentScreen = scr;
            }
        }
        if (e.gui instanceof GuiOptions && !(e.gui instanceof GuiOptionsDayM) && GuiEventHandler.lastScreen != null) {
            this.mc.func_147108_a((GuiScreen)new GuiOptionsDayM(GuiEventHandler.lastScreen, this.mc.field_71474_y));
        }
    }
    
    @SubscribeEvent
    public void onGuiIngame(final RenderGameOverlayEvent e) {
        if (ClientProxy.daym_b7fb94700 != null) {
            ClientProxy.daym_b7fb94700.donePlaying = true;
            ClientProxy.daym_b7fb94700 = null;
        }
        final int scalew = e.resolution.func_78326_a();
        final int scaleh = e.resolution.func_78328_b();
        final int k = scalew;
        final int l = scaleh;
        final FontRenderer fontrenderer = this.mc.field_71466_p;
        if (e.type == RenderGameOverlayEvent.ElementType.CROSSHAIRS) {
            final float var = Math.min(this.mc.field_71439_g.field_70173_aa / 100.0f, 1.0f);
            if (var != 1.0f) {
                GL11.glPushMatrix();
                GL11.glDisable(2929);
                GL11.glDepthMask(false);
                GL11.glBlendFunc(770, 771);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                GL11.glDisable(3008);
                GL11.glEnable(3042);
                TextureRegistry.bindResource(TextureRegistry.solid);
                final Tessellator var2 = Tessellator.field_78398_a;
                var2.func_78382_b();
                var2.func_78369_a(0.0f, 0.0f, 0.0f, 1.0f - var);
                final double x = 0.0;
                final double y = 0.0;
                final double w = k;
                final double h = l;
                var2.func_78374_a(x, y + h, -90.0, 0.0, 1.0);
                var2.func_78374_a(x + w, y + h, -90.0, 1.0, 1.0);
                var2.func_78374_a(x + w, y, -90.0, 1.0, 0.0);
                var2.func_78374_a(x, y, -90.0, 0.0, 0.0);
                var2.func_78381_a();
                GL11.glDepthMask(true);
                GL11.glEnable(2929);
                GL11.glEnable(3008);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                GL11.glPopMatrix();
            }
            Label_0659: {
                if (RenderSetup.daym_2b3b426c0) {
                    final DayMConfig daym_748d583f0 = DayM.daym_748d583f0;
                    if (DayMConfig.daym_8fd972390) {
                        break Label_0659;
                    }
                }
                if (this.mc.field_71474_y.field_74320_O == 0) {
                    GL11.glPushMatrix();
                    GL11.glDisable(2929);
                    GL11.glDepthMask(false);
                    GL11.glBlendFunc(770, 771);
                    GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                    GL11.glDisable(3008);
                    GL11.glEnable(3042);
                    TextureRegistry.bindResource(TextureRegistry.gui_crosshair);
                    final Tessellator var2 = Tessellator.field_78398_a;
                    var2.func_78382_b();
                    final double x = k / 2;
                    final double y = l / 2;
                    final double w = 8.0;
                    final double h = 8.0;
                    var2.func_78374_a(x - w, y + h, -90.0, 0.0, 1.0);
                    var2.func_78374_a(x + w, y + h, -90.0, 1.0, 1.0);
                    var2.func_78374_a(x + w, y - h, -90.0, 1.0, 0.0);
                    var2.func_78374_a(x - w, y - h, -90.0, 0.0, 0.0);
                    var2.func_78381_a();
                    GL11.glDepthMask(true);
                    GL11.glEnable(2929);
                    GL11.glEnable(3008);
                    GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                    GL11.glPopMatrix();
                    if (TickHandler.daym_6f4591d50 != null) {
                        int amStack = TickHandler.daym_6f4591d50.field_77994_a;
                        String text = TickHandler.daym_6f4591d50.func_82833_r();
                        boolean sc = false;
                        if (TickHandler.daym_6f4591d50.func_77973_b() instanceof ItemMagazine && TickHandler.daym_6f4591d50.field_77990_d != null) {
                            amStack = TickHandler.daym_6f4591d50.field_77990_d.func_74762_e("bullets");
                            sc = true;
                        }
                        if (amStack > 1 || sc) {
                            text = TickHandler.daym_6f4591d50.func_82833_r() + " (" + amStack + ")";
                        }
                        this.mc.field_71466_p.func_78261_a(text, e.resolution.func_78326_a() / 2 - this.mc.field_71466_p.func_78256_a(text) / 2, e.resolution.func_78328_b() / 2 + 10, Color.white.getRGB());
                    }
                }
            }
            e.setCanceled(true);
            return;
        }
        if (e.type == RenderGameOverlayEvent.ElementType.ALL) {
            DayM.forceUnicode();
        }
        if (e.type == RenderGameOverlayEvent.ElementType.EXPERIENCE) {
            e.setCanceled(true);
            return;
        }
        if (e.type == RenderGameOverlayEvent.ElementType.HOTBAR) {
            final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get((EntityPlayer)this.mc.field_71439_g).inventory;
            if (inventorydaym.inventory[0] != null && this.mc.field_71474_y.field_74320_O == 0) {
                Color col1 = Color.black;
                Color col2 = Color.white;
                float alpha = -0.75f;
                boolean render = false;
                if (inventorydaym.inventory[0].func_77973_b() == ItemRegistry.item_c_head_1) {
                    col1 = Color.yellow;
                    col2 = Color.red;
                    alpha = -0.9f;
                    render = true;
                }
                if (inventorydaym.inventory[0].func_77973_b() == ItemRegistry.item_c_head_2) {
                    col1 = Color.red;
                    col2 = Color.blue;
                    alpha = -0.8f;
                    render = true;
                }
                if (render) {
                    GL11.glPushMatrix();
                    RenderSetup.drawGradientRect(0, 0, e.resolution.func_78326_a(), e.resolution.func_78328_b(), col1.getRGB(), col2.getRGB(), alpha);
                    GL11.glPopMatrix();
                }
            }
            if (this.mc.field_71462_r == null || this.mc.field_71462_r instanceof GuiChat) {
                RenderSetup.deltaValue = RenderSetup.setDelta();
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                final InventoryPlayer inv = this.mc.field_71439_g.field_71071_by;
                int varw = 60;
                int am = 5;
                if (this.mc.field_71439_g.field_71075_bZ.field_75098_d) {
                    varw = 113;
                    am = 9;
                }
                for (int i = 0; i < am; ++i) {
                    Gui.func_73734_a(scalew / 2 - (varw + 2) + 25 * i, scaleh - 24, scalew / 2 - varw + 22 + 25 * i, scaleh, Integer.MIN_VALUE);
                }
                Gui.func_73734_a(scalew / 2 - varw - 1 + inv.field_70461_c * 25, scaleh - 22 - 1, scalew / 2 - varw - 1 + inv.field_70461_c * 25 + 22, scaleh, Integer.MIN_VALUE);
                GL11.glDisable(3042);
                GL11.glEnable(32826);
                RenderHelper.func_74520_c();
                for (int i = 0; i < 9; ++i) {
                    final int x2 = scalew / 2 - (varw - 1) + i * 25 + 1;
                    final int z = scaleh - 16 - 3;
                    this.renderInventorySlot(i, x2, z, e.partialTicks);
                }
                RenderHelper.func_74518_a();
                GL11.glDisable(32826);
                int xoff = 0;
                int yoff = 0;
                if (this.mc.field_71474_y.field_74330_P) {
                    xoff = 0;
                    yoff = 120;
                }
                String textDaym = EnumChatFormatting.BOLD.toString() + "DayM" + " (" + "2.1.4_beta" + ")";
                int len = this.mc.field_71466_p.func_78256_a(textDaym);
                if (this.mc.field_71439_g.field_71075_bZ.field_75098_d) {
                    textDaym = textDaym + EnumChatFormatting.RED + " (Guns + Most Items don't work properly in creative mode!)";
                    len = this.mc.field_71466_p.func_78256_a(textDaym);
                    len -= 44;
                }
                else if (!DayMConfig.didTutorial) {
                    textDaym = textDaym + EnumChatFormatting.GOLD + " (You have not checked out the tutorial, please do! [Pause -> Open Tutorial])";
                    len = this.mc.field_71466_p.func_78256_a(textDaym);
                    len -= 72;
                }
                else {
                    textDaym = textDaym + EnumChatFormatting.RED + " (Note: This is an early beta release)";
                    len = this.mc.field_71466_p.func_78256_a(textDaym);
                    len -= 36;
                }
                Gui.func_73734_a(1 + xoff, 1 + yoff, len + 5 + xoff, 12 + yoff, Integer.MIN_VALUE);
                this.mc.field_71466_p.func_78261_a(textDaym, 3 + xoff, 2 + yoff, Color.white.getRGB());
                if (this.mc.field_71439_g != null && this.mc.field_71439_g.field_71071_by.func_70448_g() != null) {
                    int xOffs = 0;
                    int yOffs = 0;
                    if (this.mc.field_71474_y.field_74330_P) {
                        xOffs = 0;
                        yOffs = 70;
                    }
                    final ItemStack gun = this.mc.field_71439_g.field_71071_by.func_70448_g();
                    if (gun.func_77973_b() instanceof ItemZombieSpawner && this.mc.field_71462_r == null) {
                        String strvar1 = "NULL :(";
                        if (WorldVarHandler.daym_6e949c730 == 0) {
                            strvar1 = "Zombie Spawner Tool";
                        }
                        if (WorldVarHandler.daym_6e949c730 == 1) {
                            strvar1 = "Loot Spawner Tool";
                        }
                        if (WorldVarHandler.daym_6e949c730 == 2) {
                            strvar1 = "Player Spawn Tool";
                        }
                        this.mc.field_71466_p.func_78261_a(strvar1, 4, e.resolution.func_78328_b() - 12, Color.red.getRGB());
                    }
                    if (gun.func_77973_b() instanceof ItemDayMGun) {
                        final ItemDayMGun dgun = (ItemDayMGun)gun.func_77973_b();
                        int maxam = dgun.daym_511e1e650.maxAmmo;
                        final boolean cham = ItemDayMGun.isChambered(gun);
                        final boolean mag = ItemDayMGun.hasMagazine(gun);
                        boolean empty = false;
                        final int bu = ItemDayMGun.getBullets(gun);
                        if (bu <= 0) {
                            empty = true;
                        }
                        if (!mag) {
                            if (!cham) {
                                maxam = 0;
                            }
                            else {
                                maxam = 1;
                            }
                        }
                        final String ammo = StatCollector.func_74838_a(dgun.daym_511e1e650.ammoType.func_77658_a() + ".name") + "(s) : " + bu + " / " + maxam;
                        Gui.func_73734_a(k - (fontrenderer.func_78256_a(ammo) + 5) + xOffs, 1 + yOffs, k - 2 + xOffs, 12 + yOffs, Integer.MIN_VALUE);
                        fontrenderer.func_78261_a(ammo, k - 3 - fontrenderer.func_78256_a(ammo) + xOffs, 2 + yOffs, Color.white.getRGB());
                        if (!mag) {
                            if (cham) {
                                if (!empty) {
                                    final String amc = StatCollector.func_74838_a("daym.gui.ingame.chambered");
                                    fontrenderer.func_78261_a(amc, k - 3 - fontrenderer.func_78256_a(amc) + xOffs, 12 + yOffs, Color.white.getRGB());
                                }
                                else {
                                    final String amc = StatCollector.func_74838_a("daym.gui.ingame.chambered") + " " + StatCollector.func_74838_a("daym.gui.ingame.but") + " " + StatCollector.func_74838_a("daym.gui.ingame.empty");
                                    fontrenderer.func_78261_a(amc, k - 3 - fontrenderer.func_78256_a(amc) + xOffs, 12 + yOffs, Color.white.getRGB());
                                }
                            }
                            else {
                                final String amc = StatCollector.func_74838_a("daym.gui.ingame.empty");
                                fontrenderer.func_78261_a(amc, k - 3 - fontrenderer.func_78256_a(amc) + xOffs, 12 + yOffs, Color.white.getRGB());
                            }
                        }
                        else if (cham) {
                            final String amc = StatCollector.func_74838_a("daym.gui.ingame.loaded");
                            fontrenderer.func_78261_a(amc, k - 3 - fontrenderer.func_78256_a(amc) + xOffs, 12 + yOffs, Color.white.getRGB());
                        }
                        else if (!empty) {
                            final String amc = StatCollector.func_74838_a("daym.gui.ingame.loaded") + " " + StatCollector.func_74838_a("daym.gui.ingame.but") + " " + StatCollector.func_74838_a("daym.gui.ingame.not") + " " + StatCollector.func_74838_a("daym.gui.ingame.chambered");
                            fontrenderer.func_78261_a(amc, k - 3 - fontrenderer.func_78256_a(amc) + xOffs, 12 + yOffs, Color.white.getRGB());
                        }
                        else {
                            final String amc = StatCollector.func_74838_a("daym.gui.ingame.loaded") + " " + StatCollector.func_74838_a("daym.gui.ingame.but") + " " + StatCollector.func_74838_a("daym.gui.ingame.empty");
                            fontrenderer.func_78261_a(amc, k - 3 - fontrenderer.func_78256_a(amc) + xOffs, 12 + yOffs, Color.white.getRGB());
                        }
                    }
                }
                if (!Keyboard.isKeyDown(50) || this.mc.field_71462_r instanceof GuiAnimationCreator || this.mc.field_71462_r == null) {}
            }
            e.setCanceled(true);
        }
    }
    
    protected void renderInventorySlot(final int p_73832_1_, final int p_73832_2_, final int p_73832_3_, final float p_73832_4_) {
        final ItemStack itemstack = this.mc.field_71439_g.field_71071_by.field_70462_a[p_73832_1_];
        if (itemstack != null) {
            final float f1 = itemstack.field_77992_b - p_73832_4_;
            if (f1 > 0.0f) {
                GL11.glPushMatrix();
                final float f2 = 1.0f + f1 / 5.0f;
                GL11.glTranslatef((float)(p_73832_2_ + 8), (float)(p_73832_3_ + 12), 0.0f);
                GL11.glScalef(1.0f / f2, (f2 + 1.0f) / 2.0f, 1.0f);
                GL11.glTranslatef((float)(-(p_73832_2_ + 8)), (float)(-(p_73832_3_ + 12)), 0.0f);
            }
            GuiEventHandler.itemRenderer.func_82406_b(this.mc.field_71466_p, this.mc.func_110434_K(), itemstack, p_73832_2_, p_73832_3_);
            if (f1 > 0.0f) {
                GL11.glPopMatrix();
            }
            GuiEventHandler.itemRenderer.func_77021_b(this.mc.field_71466_p, this.mc.func_110434_K(), itemstack, p_73832_2_, p_73832_3_);
        }
    }
    
    public Object getClientGuiElement(final int arg0, final EntityPlayer player, final World arg2, final int arg3, final int arg4, final int arg5) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (arg0 == DayM.GUI_CUSTOM_INV) {
            return new GuiPlayerInventoryDayM(player, player.field_71071_by, ExtendedPlayer.get(player).inventory, true);
        }
        if (player.field_71071_by.func_70448_g() == null) {
            return null;
        }
        if (arg0 == DayM.GUIID_ITEM) {
            return new GuiItemInventory(new ContainerItem(player, player.field_71071_by, new ItemInventory(player.func_70694_bm())));
        }
        return null;
    }
    
    public Object getServerGuiElement(final int arg0, final EntityPlayer player, final World arg2, final int arg3, final int arg4, final int arg5) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (arg0 == DayM.GUI_CUSTOM_INV) {
            return new PlayerContainerDayM(player, player.field_71071_by, ExtendedPlayer.get(player).inventory);
        }
        if (player.field_71071_by.func_70448_g() == null) {
            return null;
        }
        if (arg0 == DayM.GUIID_ITEM) {
            return new ContainerItem(player, player.field_71071_by, new ItemInventory(player.func_70694_bm()));
        }
        return null;
    }
    
    static {
        itemRenderer = new RenderItem();
        GuiEventHandler.currentScreen = null;
        GuiEventHandler.lastScreen = null;
    }
}
