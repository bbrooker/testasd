package com.daym.handlers;

import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.client.*;
import cpw.mods.fml.relauncher.*;
import com.daym.handlers.sound.*;
import net.minecraft.client.audio.*;
import com.google.common.collect.*;
import java.lang.reflect.*;
import net.minecraft.entity.player.*;
import com.daym.enums.*;
import com.daym.*;
import java.util.*;

public class SoundHandlerDayM
{
    public static void playSoundEntity(final World world, final Entity ent, final String sound, final float volume, final float pitch, final boolean checkIfPlaying) {
        if (checkIfPlaying) {
            if (!isSoundPlaying(new ResourceLocation("daym:" + sound))) {
                world.func_72956_a(ent, "daym:" + sound, volume, pitch);
            }
        }
        else {
            world.func_72956_a(ent, "daym:" + sound, volume, pitch);
        }
    }
    
    @SideOnly(Side.CLIENT)
    public static void playSound(final String sound, final float volume, final float pitch) {
        final Minecraft mc = Minecraft.func_71410_x();
        final SoundHandler sh = mc.func_147118_V();
        if (sh != null) {
            if (mc.field_71439_g != null) {
                sh.func_147682_a((ISound)SoundRecExt.createSound(new ResourceLocation("daym:" + sound), volume, pitch, (float)(mc.field_71439_g.field_70165_t + mc.field_71439_g.field_70159_w * 10.0), (float)(mc.field_71439_g.field_70163_u + mc.field_71439_g.field_70181_x * 10.0), (float)(mc.field_71439_g.field_70161_v + mc.field_71439_g.field_70179_y * 10.0)));
            }
            else {
                sh.func_147682_a((ISound)SoundRecExt.createSound(new ResourceLocation("daym:" + sound), volume, pitch));
            }
        }
    }
    
    @SideOnly(Side.CLIENT)
    public static LoopingSound playSoundLoop(final String sound, final float volume, final float pitch, final String biome, final boolean isNight) {
        final Minecraft mc = Minecraft.func_71410_x();
        final SoundHandler sh = mc.func_147118_V();
        if (sh == null) {
            return null;
        }
        if (mc.field_71439_g != null) {
            final LoopingSound sound2 = LoopingSound.createSound(new ResourceLocation("daym:" + sound), volume, pitch, (float)(mc.field_71439_g.field_70165_t + mc.field_71439_g.field_70159_w * 10.0), (float)(mc.field_71439_g.field_70163_u + mc.field_71439_g.field_70181_x * 10.0), (float)(mc.field_71439_g.field_70161_v + mc.field_71439_g.field_70179_y * 10.0), (Entity)mc.field_71439_g, biome, isNight);
            sh.func_147682_a((ISound)sound2);
            return sound2;
        }
        final LoopingSound sound2 = LoopingSound.createSound(new ResourceLocation("daym:" + sound), volume, pitch, biome, isNight);
        sh.func_147682_a((ISound)sound2);
        return sound2;
    }
    
    @SideOnly(Side.CLIENT)
    public static boolean isSoundPlaying(final ResourceLocation res) {
        HashBiMap<String, ISound> playing = null;
        SoundManager manager = null;
        try {
            final Field field_handler = Minecraft.class.getDeclaredField("mcSoundHandler");
            field_handler.setAccessible(true);
            final SoundHandler handler = (SoundHandler)field_handler.get(Minecraft.func_71410_x());
            final Field field_manager = SoundHandler.class.getDeclaredField("sndManager");
            field_manager.setAccessible(true);
            manager = (SoundManager)field_manager.get(handler);
            final Field field_playing = SoundManager.class.getDeclaredField("playingSounds");
            field_playing.setAccessible(true);
            playing = (HashBiMap<String, ISound>)field_playing.get(manager);
        }
        catch (Exception ex) {}
        if (playing != null) {
            final ISound[] array_playing = playing.values().toArray(new ISound[playing.values().size()]);
            for (int i = 0; i < array_playing.length; ++i) {
                if (array_playing[i].func_147650_b().equals((Object)res)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    @SideOnly(Side.CLIENT)
    public static void playGunShotSound(final String uuid, final int soundID) {
        EntityPlayer target = null;
        final EntityPlayer playersp = (EntityPlayer)Minecraft.func_71410_x().field_71439_g;
        for (final Object play : playersp.field_70170_p.field_73010_i) {
            if (play instanceof EntityPlayer) {
                final EntityPlayer temp = (EntityPlayer)play;
                if (!temp.func_110124_au().toString().contains(uuid)) {
                    continue;
                }
                target = temp;
            }
        }
        if (target != null && playersp != target) {
            final float soundMax = 128.0f;
            final float dist = playersp.func_70032_d((Entity)target);
            float soundVol = 1.0f - dist / soundMax;
            soundVol = -(soundVol * ((dist - soundMax) / soundMax));
            if (soundVol < 0.0f) {
                soundVol = 0.0f;
            }
            if (soundVol > 1.0f) {
                soundVol = 1.0f;
            }
            playSound(DayM.sounds.get(soundID).name, soundVol, 1.0f + (0.1f - soundVol / 3.0f));
        }
    }
    
    public static String getBiomeSound(final String biomen, final boolean isNight) {
        if (biomen.contains("plains") || biomen.contains("desert")) {
            return "ambient_plains";
        }
        if (biomen.contains("forest") || biomen.contains("taiga")) {
            if (isNight) {
                return "ambient_plains";
            }
            return "ambient_forest";
        }
        else {
            if (biomen.contains("river")) {
                return "ambient_river";
            }
            if (biomen.contains("ocean") || biomen.contains("beach")) {
                return "ambient_ocean";
            }
            return "null";
        }
    }
}
