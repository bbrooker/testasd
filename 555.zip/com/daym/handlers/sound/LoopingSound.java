package com.daym.handlers.sound;

import cpw.mods.fml.relauncher.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.client.audio.*;
import net.minecraft.client.*;
import net.minecraft.entity.player.*;

@SideOnly(Side.CLIENT)
public class LoopingSound extends PositionedSound implements ITickableSound
{
    private static Entity field_147670_k;
    private float field_147669_l;
    public boolean donePlaying;
    public boolean isFading;
    public boolean canBeDestroyed;
    public String biome;
    public float lastVolume;
    public boolean isNight;
    
    public static LoopingSound createSound(final ResourceLocation p_147674_0_, final float vol, final float pitch, final String par10, final boolean in) {
        return new LoopingSound(p_147674_0_, vol, pitch, true, 0, ISound.AttenuationType.NONE, 0.0f, 0.0f, 0.0f, null, par10, in);
    }
    
    public static LoopingSound createSound(final ResourceLocation p_147674_0_, final float vol, final float pitch, final float x, final float y, final float z, final Entity entity, final String par10, final boolean in) {
        return new LoopingSound(p_147674_0_, vol, pitch, true, 0, ISound.AttenuationType.NONE, x, y, z, entity, par10, in);
    }
    
    public static LoopingSound createSound(final ResourceLocation p_147674_0_, final float vol, final float pitch, final Entity entity, final String par10, final boolean in) {
        LoopingSound.field_147670_k = entity;
        return new LoopingSound(p_147674_0_, vol, pitch, true, 0, ISound.AttenuationType.NONE, (float)entity.field_70165_t, (float)entity.field_70163_u, (float)entity.field_70161_v, entity, par10, in);
    }
    
    protected LoopingSound(final ResourceLocation par1, final float par2, final float par3, final boolean par4, final int par5, final ISound.AttenuationType par6, final float par7, final float par8, final float par9, final Entity entity, final String par10, final boolean in) {
        super(par1);
        this.field_147669_l = 0.0f;
        this.donePlaying = false;
        this.isFading = false;
        this.canBeDestroyed = false;
        this.biome = "";
        this.lastVolume = 1.0f;
        this.isNight = false;
        this.field_147662_b = par2;
        this.field_147663_c = par3;
        this.field_147660_d = par7;
        this.field_147661_e = par8;
        this.field_147658_f = par9;
        this.field_147659_g = par4;
        this.field_147665_h = par5;
        this.field_147666_i = par6;
        this.biome = par10;
        this.isNight = in;
    }
    
    public boolean func_147667_k() {
        return this.donePlaying;
    }
    
    public void updatePosition(final Entity ent) {
        this.field_147660_d = (float)ent.field_70165_t;
        this.field_147661_e = (float)ent.field_70163_u;
        this.field_147658_f = (float)ent.field_70161_v;
    }
    
    public void func_73660_a() {
        final Minecraft mc = Minecraft.func_71410_x();
        final EntityPlayer player = (EntityPlayer)mc.field_71439_g;
        if (LoopingSound.field_147670_k == null) {
            if (player == null) {
                return;
            }
            LoopingSound.field_147670_k = (Entity)player;
        }
        if (LoopingSound.field_147670_k.field_70128_L) {
            this.donePlaying = true;
            return;
        }
        this.updatePosition(LoopingSound.field_147670_k);
        if (this.isFading) {
            if (this.field_147662_b > 0.0f) {
                this.field_147662_b -= 0.005f;
            }
            else {
                this.field_147662_b = 0.0f;
                this.canBeDestroyed = true;
            }
        }
        if (mc.field_71462_r == null) {
            if (this.field_147662_b != 0.0f) {
                this.lastVolume = this.field_147662_b;
            }
            if (this.field_147662_b != this.lastVolume) {
                this.field_147662_b = this.lastVolume;
            }
        }
        else {
            this.field_147662_b = 0.0f;
        }
    }
}
