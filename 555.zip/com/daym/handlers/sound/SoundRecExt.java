package com.daym.handlers.sound;

import cpw.mods.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.audio.*;

@SideOnly(Side.CLIENT)
public class SoundRecExt extends PositionedSound
{
    public static SoundRecExt createSound(final ResourceLocation p_147674_0_, final float vol, final float pitch) {
        return new SoundRecExt(p_147674_0_, vol, pitch, false, 0, ISound.AttenuationType.NONE, 0.0f, 0.0f, 0.0f);
    }
    
    public static SoundRecExt createSound(final ResourceLocation p_147674_0_, final float vol, final float pitch, final float x, final float y, final float z) {
        return new SoundRecExt(p_147674_0_, vol, pitch, false, 0, ISound.AttenuationType.LINEAR, x, y, z);
    }
    
    public static SoundRecExt func_147673_a(final ResourceLocation p_147673_0_) {
        return new SoundRecExt(p_147673_0_, 1.0f, 1.0f, false, 0, ISound.AttenuationType.NONE, 0.0f, 0.0f, 0.0f);
    }
    
    public static SoundRecExt func_147675_a(final ResourceLocation p_147675_0_, final float p_147675_1_, final float p_147675_2_, final float p_147675_3_) {
        return new SoundRecExt(p_147675_0_, 4.0f, 1.0f, false, 0, ISound.AttenuationType.LINEAR, p_147675_1_, p_147675_2_, p_147675_3_);
    }
    
    public SoundRecExt(final ResourceLocation p_i45107_1_, final float p_i45107_2_, final float p_i45107_3_, final float p_i45107_4_, final float p_i45107_5_, final float p_i45107_6_) {
        this(p_i45107_1_, p_i45107_2_, p_i45107_3_, false, 0, ISound.AttenuationType.LINEAR, p_i45107_4_, p_i45107_5_, p_i45107_6_);
    }
    
    protected SoundRecExt(final ResourceLocation p_i45108_1_, final float p_i45108_2_, final float p_i45108_3_, final boolean p_i45108_4_, final int p_i45108_5_, final ISound.AttenuationType p_i45108_6_, final float p_i45108_7_, final float p_i45108_8_, final float p_i45108_9_) {
        super(p_i45108_1_);
        this.field_147662_b = p_i45108_2_;
        this.field_147663_c = p_i45108_3_;
        this.field_147660_d = p_i45108_7_;
        this.field_147661_e = p_i45108_8_;
        this.field_147658_f = p_i45108_9_;
        this.field_147659_g = p_i45108_4_;
        this.field_147665_h = p_i45108_5_;
        this.field_147666_i = p_i45108_6_;
    }
}
