package com.daym.handlers;

import java.util.*;
import com.daym.gui.*;
import com.daym.threads.*;
import com.daym.*;
import com.daym.serverproxy.*;
import com.daym.logger.*;
import java.io.*;

public class ServerListHandler
{
    public static ArrayList<String[]> serverList;
    public static ArrayList<String[]> oServerList;
    public static ArrayList<String[]> fServerList;
    public static ArrayList<String[]> hServerList;
    public static ArrayList<GuiDayMButton> serverButtonList;
    public static ArrayList<GuiDayMButton> oServerButtonList;
    public static ArrayList<GuiDayMButton> fServerButtonList;
    public static ArrayList<GuiDayMButton> hServerButtonList;
    public static OfficialSLThread oslt;
    public static int serverAmount;
    
    public static void refreshServerAmount() {
        (ServerListHandler.oslt = new OfficialSLThread("http://daymmod.com/data/servers.daym", "serverAmount")).start();
    }
    
    public static void refreshServers() {
        (ServerListHandler.oslt = new OfficialSLThread("http://daymmod.com/data/serverlist.daym", "public")).start();
    }
    
    public static void refreshOfficialServers() {
        (ServerListHandler.oslt = new OfficialSLThread("http://daymmod.com/data/officialserverlist.daym", "official")).start();
    }
    
    public static void refreshFavoriteServers() {
        try {
            ServerListHandler.fServerList.clear();
            final String str = DayM.readFile(DayM.daym_697207960.getPath() + "/sl_favorites.daym");
            if (str != null) {
                final String[] servers = CommonProxy.decodeServers(str);
                ServerListHandler.fServerList.add(servers);
            }
        }
        catch (IOException e) {
            daymlog.out("Failed to load server list: Favorites (File probably missing.)");
        }
    }
    
    public static void refreshHistoryServers() {
        try {
            ServerListHandler.hServerList.clear();
            final String str = DayM.readFile(DayM.daym_697207960.getPath() + "/sl_history.daym");
            if (str != null) {
                final String[] servers = CommonProxy.decodeServers(str);
                ServerListHandler.hServerList.add(servers);
            }
        }
        catch (IOException e) {
            daymlog.out("Failed to load server list: History (File probably missing.)");
        }
    }
    
    static {
        ServerListHandler.serverList = new ArrayList<String[]>();
        ServerListHandler.oServerList = new ArrayList<String[]>();
        ServerListHandler.fServerList = new ArrayList<String[]>();
        ServerListHandler.hServerList = new ArrayList<String[]>();
        ServerListHandler.serverButtonList = new ArrayList<GuiDayMButton>();
        ServerListHandler.oServerButtonList = new ArrayList<GuiDayMButton>();
        ServerListHandler.fServerButtonList = new ArrayList<GuiDayMButton>();
        ServerListHandler.hServerButtonList = new ArrayList<GuiDayMButton>();
    }
}
