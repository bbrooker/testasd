package com.daym.handlers.event;

import net.minecraftforge.event.*;
import cpw.mods.fml.common.eventhandler.*;
import com.daym.extended.*;
import net.minecraftforge.common.*;
import cpw.mods.fml.common.*;
import com.daym.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.entity.zombie.*;
import com.daym.inventory.*;
import net.minecraftforge.event.entity.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.monster.*;
import net.minecraft.entity.passive.*;
import net.minecraft.item.*;
import net.minecraft.entity.item.*;
import com.daym.registry.*;
import java.util.*;
import net.minecraftforge.event.world.*;
import net.minecraft.util.*;
import net.minecraftforge.client.event.*;
import com.daym.render.*;
import cpw.mods.fml.relauncher.*;
import com.daym.handlers.*;
import com.daym.packet.message.*;
import net.minecraftforge.event.entity.player.*;
import net.minecraftforge.event.entity.living.*;

public class EventHandlerDayM
{
    @SubscribeEvent
    public void onCommand(final CommandEvent event) {
    }
    
    @SubscribeEvent
    public void onEntityConstructing(final EntityEvent.EntityConstructing event) {
        if (event.entity instanceof EntityPlayer && ExtendedPlayer.get((EntityPlayer)event.entity) == null) {
            ExtendedPlayer.register((EntityPlayer)event.entity);
        }
        if (event.entity instanceof EntityPlayer && event.entity.getExtendedProperties("ExtendedPlayer") == null) {
            event.entity.registerExtendedProperties("ExtendedPlayer", (IExtendedEntityProperties)new ExtendedPlayer((EntityPlayer)event.entity));
        }
    }
    
    @SubscribeEvent
    public void onLivingDeathEvent(final LivingDeathEvent event) {
        if (event.entity instanceof EntityPlayer) {
            final String uuid = event.entity.func_110124_au().toString();
            WorldHandler.daym_9619787d0.remove(uuid);
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            if (side.isServer()) {
                ((EntityPlayer)event.entity).field_71071_by.func_70436_m();
                final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get((EntityPlayer)event.entity).inventory;
                inventorydaym.dropAllItems((EntityPlayer)event.entity);
                DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_SyncPlayerProps(0, (EntityPlayer)event.entity));
            }
        }
        if (event.entity instanceof EntityZombieBase) {
            WorldHandler.daym_54c1b80c0.remove(event.entity);
        }
    }
    
    @SubscribeEvent
    public void onEntityJoinWorld(final EntityJoinWorldEvent event) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (!event.entity.field_70170_p.field_72995_K) {
            if (event.entity instanceof EntityPlayer) {
                ExtendedPlayer.daym_698e99d30((EntityPlayer)event.entity);
                final String uuid = event.entity.func_110124_au().toString();
                final EntityPlayer entityPlayer = (EntityPlayer)event.entity;
                entityPlayer.field_70155_l *= 3.0;
                if (side.isServer()) {
                    DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_SyncPlayerProps(0, (EntityPlayer)event.entity));
                }
            }
            if (event.entity instanceof EntityPlayerMP && side.isServer()) {
                for (final Object o : event.world.field_73010_i) {
                    if (o instanceof EntityPlayer) {
                        DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_SyncPlayerProps(0, (EntityPlayer)o), (EntityPlayerMP)event.entity);
                    }
                }
            }
            if (event.entity instanceof EntityItem) {
                final EntityItem ei = (EntityItem)event.entity;
            }
        }
        if (WorldHandler.daym_a5956ee00.contains("EntityZombie")) {
            final String spawned = event.entity.getClass().getSimpleName();
            if (spawned.contains("EntityZombie") && !spawned.contains("EntityZombieBase") && event.isCancelable()) {
                ((EntityZombie)event.entity).func_82227_f(false);
                event.entity.func_70012_b(0.0, -2.0, 0.0, 0.0f, 0.0f);
                event.setCanceled(true);
                return;
            }
        }
        if (!(event.entity instanceof EntityPlayer) && !WorldHandler.daym_e94bfd790.isEmpty()) {
            for (final String d : WorldHandler.daym_e94bfd790) {
                final String spawned2 = event.entity.getClass().getSimpleName();
                if (spawned2.equalsIgnoreCase(d) && event.isCancelable()) {
                    event.setCanceled(true);
                }
            }
        }
        if (event.entity instanceof EntityChicken) {
            WorldHandler.daym_e0d55c940.add((EntityChicken)event.entity);
        }
        if (event.entity instanceof EntityItem) {
            if (!WorldHandler.daym_4ceb36930.contains(event.entity)) {
                WorldHandler.daym_4ceb36930.add((EntityItem)event.entity);
            }
            final ArrayList<EntityItem> test2 = (ArrayList<EntityItem>)WorldHandler.daym_4ceb36930.clone();
            for (final EntityItem ei2 : test2) {
                if (ei2 != null) {
                    if (ei2.func_70089_S()) {
                        continue;
                    }
                    WorldHandler.daym_4ceb36930.remove(ei2);
                }
                else {
                    WorldHandler.daym_4ceb36930.remove(ei2);
                }
            }
        }
    }
    
    @SubscribeEvent
    public void itemPickupEvent(final EntityItemPickupEvent event) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (event.isCancelable() && event.entityPlayer != null) {
            ArrayList<EntityItem> al = null;
            if (WorldHandler.daym_e3864ff00.containsKey(event.entityPlayer.func_110124_au().toString())) {
                al = WorldHandler.daym_e3864ff00.get(event.entityPlayer.func_110124_au().toString());
            }
            else {
                al = new ArrayList<EntityItem>();
            }
            if (al != null) {
                if (!al.contains(event.item)) {
                    al.add(event.item);
                }
                WorldHandler.daym_e3864ff00.put(event.entityPlayer.func_110124_au().toString(), al);
            }
            if (!event.entityPlayer.field_71075_bZ.field_75098_d) {
                event.setCanceled(true);
            }
            else {
                int i = 0;
                boolean hasEmpty = true;
                for (final ItemStack is : event.entityPlayer.field_71071_by.field_70462_a) {
                    final int var = 8;
                    if (is == null) {
                        hasEmpty = false;
                    }
                    if (++i > var) {
                        break;
                    }
                }
                if (hasEmpty) {
                    event.setCanceled(true);
                }
            }
        }
    }
    
    @SubscribeEvent
    public void attackEvent(final AttackEntityEvent event) {
        if ((event.target instanceof EntityPainting || event.target instanceof EntityItemFrame) && !WorldHandler.canGrief && !event.entityPlayer.field_71075_bZ.field_75098_d && event.isCancelable()) {
            event.setCanceled(true);
        }
        if (event.target instanceof EntityPlayer && PlayerVarHandler.daym_b73359c80.get(event.entityPlayer.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(event.entityPlayer.func_70005_c_()) != -1 && event.isCancelable()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void entityAttackEvent(final LivingAttackEvent event) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (event.source != null && event.source.func_76364_f() instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)event.source.func_76364_f();
            if (player.field_71071_by.func_70448_g() != null && ItemRegistry.gunList.contains(player.field_71071_by.func_70448_g().func_77973_b()) && event.isCancelable()) {
                event.setCanceled(true);
            }
            if (PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) != -1 && event.isCancelable()) {
                event.setCanceled(true);
            }
        }
    }
    
    @SubscribeEvent
    public void itemInteractEvent(final EntityInteractEvent event) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (event.entityPlayer != null && event.entityPlayer.field_71071_by.func_70448_g() != null) {
            if (ItemRegistry.gunList.contains(event.entityPlayer.field_71071_by.func_70448_g().func_77973_b()) && event.isCancelable()) {
                event.setCanceled(true);
            }
            try {
                if (event.target instanceof EntityPlayer && event.entityPlayer.field_71071_by.func_70448_g().func_77973_b() == ItemRegistry.item_handcuffs && !((EntityPlayer)event.target).field_71075_bZ.field_75098_d) {
                    final Random random = new Random();
                    if (PlayerVarHandler.daym_b73359c80.get(event.target.func_70005_c_()) == null && event.entityPlayer.field_71071_by.func_146026_a(ItemRegistry.item_handcuffs)) {
                        if (side.isClient()) {
                            final IChatComponent test = (IChatComponent)new ChatComponentText(((EntityPlayer)event.entity).getDisplayName() + " hand cuffed you.");
                            ((EntityPlayer)event.target).func_145747_a(test);
                            final IChatComponent test2 = (IChatComponent)new ChatComponentText("You handcuffed " + ((EntityPlayer)event.target).getDisplayName());
                            ((EntityPlayer)event.entity).func_145747_a(test2);
                            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerAnimation(event.target.func_70005_c_(), (byte)3));
                        }
                        PlayerVarHandler.daym_b73359c80.put(event.target.func_70005_c_(), (byte)3);
                        event.entityPlayer.field_70170_p.func_72956_a(event.target, "daym:lock_click", 0.4f, 1.5f - random.nextFloat() / 2.0f);
                        return;
                    }
                    if (PlayerVarHandler.daym_b73359c80.get(event.target.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(event.target.func_70005_c_()) != 3 && event.entityPlayer.field_71071_by.func_146026_a(ItemRegistry.item_handcuffs)) {
                        if (side.isClient()) {
                            final IChatComponent test = (IChatComponent)new ChatComponentText(((EntityPlayer)event.entity).getDisplayName() + " unlocked your handcuffs");
                            ((EntityPlayer)event.target).func_145747_a(test);
                            final IChatComponent test2 = (IChatComponent)new ChatComponentText("You unlocked " + ((EntityPlayer)event.target).getDisplayName());
                            ((EntityPlayer)event.entity).func_145747_a(test2);
                            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerAnimation(event.target.func_70005_c_(), (byte)3));
                        }
                        PlayerVarHandler.daym_b73359c80.put(event.target.func_70005_c_(), (byte)3);
                        event.entityPlayer.field_70170_p.func_72956_a(event.target, "daym:lock_click", 0.4f, 1.5f - random.nextFloat() / 2.0f);
                        return;
                    }
                }
                if (event.target instanceof EntityPlayer && event.entityPlayer.field_71071_by.func_70448_g().func_77973_b() == ItemRegistry.item_key && !((EntityPlayer)event.target).field_71075_bZ.field_75098_d && PlayerVarHandler.daym_b73359c80.get(event.target.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(event.target.func_70005_c_()) == 3) {
                    final Random random = new Random();
                    if (event.entityPlayer.field_71071_by.func_146026_a(ItemRegistry.item_key)) {
                        event.entityPlayer.field_70170_p.func_72956_a(event.target, "daym:lock_click", 0.2f, 1.5f - random.nextFloat() / 2.0f);
                        if (side.isClient()) {
                            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerAnimation(event.target.func_70005_c_(), (byte)(-1)));
                        }
                        PlayerVarHandler.daym_b73359c80.put(event.target.func_70005_c_(), (byte)(-1));
                        return;
                    }
                }
            }
            catch (Exception ex) {}
        }
        if ((event.target instanceof EntityPainting || event.target instanceof EntityItemFrame) && !WorldHandler.canGrief && !event.entityPlayer.field_71075_bZ.field_75098_d && event.isCancelable()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void placeBlock(final BlockEvent.PlaceEvent e) {
        if (e.player.field_70173_aa < 60) {
            e.setCanceled(true);
        }
        if (!WorldHandler.canGrief && !e.player.field_71075_bZ.field_75098_d && e.isCancelable()) {
            final IChatComponent test = (IChatComponent)new ChatComponentText(EnumChatFormatting.RED.toString() + "[DayM] Can't place block.");
            e.player.func_145747_a(test);
            e.setCanceled(true);
        }
    }
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void renderHandEvent(final RenderHandEvent event) {
        RenderSetup.daym_fb4863ec0(event);
    }
    
    @SubscribeEvent
    public void blockBreak(final BlockEvent.BreakEvent e) {
        final EntityPlayer player = e.getPlayer();
        if (player.field_70173_aa < 60) {
            e.setCanceled(true);
        }
        if (player != null) {
            if (player.field_71071_by.func_70448_g() != null) {
                if (ItemRegistry.gunList.contains(player.field_71071_by.func_70448_g().func_77973_b())) {
                    e.setCanceled(true);
                }
                if (ItemRegistry.debugGlobalTools == player.field_71071_by.func_70448_g().func_77973_b()) {
                    final Side side = FMLCommonHandler.instance().getEffectiveSide();
                    if (side.isServer()) {
                        final int type = WorldVarHandler.daym_91c21be00;
                        final int spawnChance = 100 - WorldVarHandler.daym_7b9f69410;
                        final int spawnRadius = WorldVarHandler.daym_82c209f00;
                        final int amountSpawn = WorldVarHandler.daym_47241d9f0;
                        final int randAmount = WorldVarHandler.daym_fc4e31e70;
                        final boolean worked = WorldHandler.daym_46f78edb0(type, spawnChance, spawnRadius, amountSpawn, randAmount, e.x, e.y, e.z);
                        if (worked) {
                            DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_ZombieSpawnerClient(1, type, spawnChance, spawnRadius, amountSpawn, randAmount, e.x, e.y, e.z));
                            WorldHandler.daym_2fe7daff0(true);
                        }
                        final boolean worked2 = WorldHandler.daym_dc4d2fc30(0, e.x, e.y, e.z);
                        if (worked2) {
                            DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_PlayerSpawner(1, 0, e.x, e.y, e.z));
                            WorldHandler.daym_8df4b26c0(true);
                        }
                        final boolean worked3 = WorldHandler.daym_9bdc5ed90(0, 0, e.x, e.y, e.z);
                        if (worked3) {
                            DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_LootSpawner(1, null, null, 0, 0, 0, 0, 0, e.x, e.y, e.z));
                            WorldHandler.daym_86fc86bb0(true);
                        }
                        if (worked || worked2 || worked3) {
                            final IChatComponent test = (IChatComponent)new ChatComponentText("Removed Tool Data from: " + e.x + ", " + e.y + ", " + e.z);
                            player.func_145747_a(test);
                        }
                    }
                    e.setCanceled(true);
                }
            }
            if (!WorldHandler.canGrief && !player.field_71075_bZ.field_75098_d && e.isCancelable()) {
                final IChatComponent test2 = (IChatComponent)new ChatComponentText(EnumChatFormatting.RED.toString() + "[DayM] Can't destroy this block.");
                player.func_145747_a(test2);
                e.setCanceled(true);
            }
        }
    }
    
    @SubscribeEvent
    public void onClick(final PlayerInteractEvent event) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
    }
    
    @SubscribeEvent
    public void livingEntityTick(final LivingEvent.LivingUpdateEvent event) {
        if (!(event.entity instanceof EntityPlayer) && !WorldHandler.daym_e94bfd790.isEmpty()) {
            for (final String d : WorldHandler.daym_e94bfd790) {
                final String spawned = event.entity.getClass().getSimpleName();
                if (spawned.equalsIgnoreCase(d) && !event.entity.field_70128_L) {
                    event.entity.func_70106_y();
                }
            }
        }
    }
    
    @SubscribeEvent
    public void playerFallEvent(final LivingFallEvent e) {
        if (!(e.entity instanceof EntityPlayer)) {
            return;
        }
        final EntityPlayer player = (EntityPlayer)e.entity;
        if (player != null) {
            final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get(player).inventory;
            if (inventorydaym.inventory[5] != null && inventorydaym.inventory[5].func_77973_b() == ItemRegistry.item_parachute && player.field_70143_R > 3.1f) {
                e.setCanceled(true);
                player.field_70143_R = 0.0f;
                inventorydaym.inventory[5] = null;
            }
        }
    }
}
