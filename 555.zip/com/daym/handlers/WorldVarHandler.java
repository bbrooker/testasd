package com.daym.handlers;

import java.util.*;

public class WorldVarHandler
{
    public static int daym_91c21be00;
    public static int daym_7b9f69410;
    public static int daym_82c209f00;
    public static int daym_47241d9f0;
    public static int daym_fc4e31e70;
    public static int daym_d968810a0;
    public static int daym_fbd202650;
    public static int daym_b8e432020;
    public static int daym_6e949c730;
    public static int daym_fda9862f0;
    public static int daym_6176e9ba0id;
    public static int daym_55512bc80;
    public static int daym_fd6bdaa50;
    public static ArrayList<Integer> daym_6176e9ba0;
    public static ArrayList<Integer> daym_4f999ab20;
    
    static {
        WorldVarHandler.daym_91c21be00 = 0;
        WorldVarHandler.daym_7b9f69410 = 5;
        WorldVarHandler.daym_82c209f00 = 8;
        WorldVarHandler.daym_47241d9f0 = 5;
        WorldVarHandler.daym_fc4e31e70 = 1;
        WorldVarHandler.daym_d968810a0 = 0;
        WorldVarHandler.daym_fbd202650 = 0;
        WorldVarHandler.daym_b8e432020 = 0;
        WorldVarHandler.daym_6e949c730 = 0;
        WorldVarHandler.daym_fda9862f0 = 5;
        WorldVarHandler.daym_6176e9ba0id = 0;
        WorldVarHandler.daym_55512bc80 = 5;
        WorldVarHandler.daym_fd6bdaa50 = 6;
        WorldVarHandler.daym_6176e9ba0 = new ArrayList<Integer>();
        WorldVarHandler.daym_4f999ab20 = new ArrayList<Integer>();
    }
}
