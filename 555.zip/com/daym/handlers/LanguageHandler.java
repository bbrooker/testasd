package com.daym.handlers;

import cpw.mods.fml.common.registry.*;

public class LanguageHandler
{
    public static String translate(final String key) {
        return LanguageRegistry.instance().getStringLocalization(key);
    }
}
