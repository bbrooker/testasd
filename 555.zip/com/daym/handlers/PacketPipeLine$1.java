package com.daym.handlers;

import java.util.*;

class PacketPipeLine$1 implements Comparator<Class<? extends AbstractPacket>> {
    @Override
    public int compare(final Class<? extends AbstractPacket> clazz1, final Class<? extends AbstractPacket> clazz2) {
        int com = String.CASE_INSENSITIVE_ORDER.compare(clazz1.getCanonicalName(), clazz2.getCanonicalName());
        if (com == 0) {
            com = clazz1.getCanonicalName().compareTo(clazz2.getCanonicalName());
        }
        return com;
    }
}