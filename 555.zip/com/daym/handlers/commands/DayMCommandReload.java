package com.daym.handlers.commands;

import net.minecraft.command.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.*;
import com.daym.handlers.*;
import net.minecraft.entity.*;
import net.minecraft.server.*;
import net.minecraft.util.*;
import java.util.*;

public class DayMCommandReload implements ICommand
{
    public int compareTo(final Object arg0) {
        return 0;
    }
    
    public String func_71517_b() {
        return "daym";
    }
    
    public String func_71518_a(final ICommandSender icommandsender) {
        return "/daym - Displays sub-commands for DayM";
    }
    
    public List func_71514_a() {
        return null;
    }
    
    public void func_71515_b(final ICommandSender icommandsender, final String[] params) {
        if (icommandsender instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)icommandsender;
            if (player.field_70170_p.field_72995_K) {
                return;
            }
            final MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
            if (server.func_71203_ab().func_152596_g(player.func_146103_bH())) {
                if (params.length > 0) {
                    if (params[0].equalsIgnoreCase("reloadconfig")) {
                        WorldHandler.setDirectoryAndLoad(null);
                        final IChatComponent arg0 = (IChatComponent)new ChatComponentText("Reloaded DayM World Config");
                        icommandsender.func_145747_a(arg0);
                    }
                    if (params[0].equalsIgnoreCase("reload")) {
                        for (final Entity ent : WorldHandler.daym_54c1b80c0) {
                            ent.func_70106_y();
                        }
                        WorldHandler.daym_54c1b80c0.clear();
                        final IChatComponent arg0 = (IChatComponent)new ChatComponentText("Reloading Entities, Server may lag for 5 seconds.");
                        for (final Object o : player.field_70170_p.field_73010_i) {
                            if (o instanceof EntityPlayer) {
                                ((EntityPlayer)o).func_145747_a(arg0);
                            }
                        }
                    }
                }
                else {
                    final IChatComponent arg0 = (IChatComponent)new ChatComponentText("Missing parameters! List: /daym reloadconfig (reloads world config) | /daym reload (reloads entities)");
                    icommandsender.func_145747_a(arg0);
                }
            }
            else {
                final IChatComponent arg0 = (IChatComponent)new ChatComponentText("You need to be an OP to run this command.");
                icommandsender.func_145747_a(arg0);
            }
        }
    }
    
    public boolean func_71519_b(final ICommandSender icommandsender) {
        return true;
    }
    
    public List func_71516_a(final ICommandSender icommandsender, final String[] astring) {
        return null;
    }
    
    public boolean func_82358_a(final String[] astring, final int i) {
        return false;
    }
}
