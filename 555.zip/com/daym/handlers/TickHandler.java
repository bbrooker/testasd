package com.daym.handlers;

import net.minecraft.client.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.world.*;
import cpw.mods.fml.common.*;
import cpw.mods.fml.client.*;
import com.daym.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import cpw.mods.fml.common.eventhandler.*;
import com.daym.extended.*;
import com.daym.config.*;
import com.daym.inventory.*;
import cpw.mods.fml.common.gameevent.*;
import com.daym.clientproxy.*;
import net.minecraft.entity.item.*;
import org.lwjgl.input.*;
import net.minecraft.item.*;
import com.daym.handlers.sound.*;
import net.minecraft.entity.*;
import com.daym.registry.*;
import com.daym.packet.message.*;
import com.daym.render.*;
import net.minecraft.world.chunk.*;
import net.minecraft.entity.passive.*;
import com.daym.logger.*;
import com.daym.entity.zombie.*;
import net.minecraft.init.*;
import com.daym.tools.*;
import com.daym.blocks.*;
import net.minecraft.nbt.*;
import com.daym.items.*;
import net.minecraft.server.*;
import net.minecraft.block.*;
import net.minecraft.entity.player.*;
import java.util.*;
import net.minecraft.util.*;

public class TickHandler
{
    @SideOnly(Side.CLIENT)
    Minecraft mc;
    static Random rand;
    private boolean leftClicked;
    private boolean daym_f8f4c47d0;
    public int daym_1fef99d20;
    public int daym_c14f56470;
    public int daym_c14f564702;
    public int daym_9d9bbdf70;
    public World world;
    private boolean daym_5239c32e0;
    private double daym_cf2c741a0;
    public static ItemStack daym_6f4591d50;
    public static int daym_154aa7680;
    private boolean daym_2cc9623d0;
    private boolean daym_77618ddd0;
    private boolean daym_e9d55ce20;
    private boolean daym_a78a97af0;
    public boolean needsInventoryReload;
    
    public TickHandler() {
        this.leftClicked = false;
        this.daym_f8f4c47d0 = false;
        this.daym_1fef99d20 = 0;
        this.daym_c14f56470 = 0;
        this.daym_c14f564702 = 0;
        this.daym_9d9bbdf70 = 0;
        this.world = null;
        this.daym_2cc9623d0 = false;
        this.daym_77618ddd0 = false;
        this.daym_e9d55ce20 = false;
        this.daym_a78a97af0 = false;
        this.needsInventoryReload = false;
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            this.mc = FMLClientHandler.instance().getClient();
        }
    }
    
    @SubscribeEvent
    public void playerJoinEvent(final PlayerEvent.PlayerLoggedInEvent event) {
        DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_PlayerEvent(event.player.func_110124_au().toString(), 0));
        DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_SyncWorldHandler((byte)0, WorldHandler.daym_5635fd3d0), (EntityPlayerMP)event.player);
        DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_SyncWorldHandler((byte)1, WorldHandler.daym_24d72dcb0), (EntityPlayerMP)event.player);
        DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_SyncWorldHandler((byte)2, WorldHandler.daym_28d3f01a0), (EntityPlayerMP)event.player);
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isServer()) {
            this.needsInventoryReload = true;
        }
        if (event.player instanceof EntityPlayer) {
            DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_SyncPlayerProps(0, event.player));
            for (final Object o : event.player.field_70170_p.field_73010_i) {
                if (o instanceof EntityPlayer) {
                    final EntityPlayer player = (EntityPlayer)o;
                    final String uuid = player.func_110124_au().toString();
                    if (WorldHandler.daym_3bb3f01c0.containsKey(uuid)) {
                        final int skin = WorldHandler.daym_3bb3f01c0.get(uuid);
                        DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_PlayerSkin(1, skin, skin > 4, uuid), (EntityPlayerMP)event.player);
                    }
                    if (PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) != null) {
                        DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_PlayerAnimation(player.func_70005_c_(), PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_())), (EntityPlayerMP)event.player);
                    }
                }
                if (o instanceof EntityPlayerMP && side.isServer()) {
                    DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_SyncPlayerProps(0, (EntityPlayer)o), (EntityPlayerMP)event.player);
                }
            }
        }
        if (event.player instanceof EntityPlayerMP) {
            boolean bl = false;
            final EntityPlayerMP player2 = (EntityPlayerMP)event.player;
            if (DayM.daym_c93febc30 != null && DayM.daym_c93febc30.daym_28f500420 && DayM.daym_f06245270.contains(player2.func_110124_au().toString().replace("-", ""))) {
                bl = true;
            }
            if (bl) {
                player2.field_71135_a.func_147360_c("You have been blacklisted from DayM.");
                if (event.isCancelable()) {
                    event.setCanceled(true);
                }
            }
        }
    }
    
    @SubscribeEvent
    public void onPlayerRepawn(final PlayerEvent.PlayerRespawnEvent event) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isServer()) {
            if (event.player != null) {
                teleportPlayerSpawn(event.player);
                DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_PlayerAnimation(event.player.func_70005_c_(), (byte)(-1)));
                PlayerVarHandler.daym_b73359c80.put(event.player.func_70005_c_(), (byte)(-1));
            }
        }
        else {
            if (event.player == this.mc.field_71439_g) {
                DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerAnimation(this.mc.field_71439_g.func_70005_c_(), (byte)(-1)));
                PlayerVarHandler.daym_b73359c80.put(this.mc.field_71439_g.func_70005_c_(), (byte)(-1));
            }
            if (event.player == this.mc.field_71439_g) {
                final EntityPlayer player = event.player;
                if (WorldHandler.daym_9619787d0.get(event.player.func_110124_au().toString()) == null || (WorldHandler.daym_9619787d0.get(event.player.func_110124_au().toString()) != null && !WorldHandler.daym_9619787d0.get(event.player.func_110124_au().toString()))) {
                    final PlayerInventoryDayM inventory = ExtendedPlayer.get(player).inventory;
                    DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerSkin(4, DayMConfig.daym_bed00c4b0, false, event.player.func_110124_au().toString()));
                    DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerSkin(5, DayMConfig.daym_94a3461e0, false, event.player.func_110124_au().toString()));
                    DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerSkin(6, 0, false, event.player.func_110124_au().toString()));
                    WorldHandler.daym_9619787d0.put(event.player.func_110124_au().toString(), true);
                }
            }
        }
    }
    
    public static void teleportPlayerSpawn(final EntityPlayer player) {
        final String[] data = WorldHandler.daym_4524cfb60(WorldHandler.daym_24d72dcb0, null);
        if (data != null) {
            final ArrayList<String[]> chancelist = new ArrayList<String[]>();
            final ArrayList<String[]> fulllist = new ArrayList<String[]>();
            for (final String d : data) {
                try {
                    if (!d.contains(".")) {
                        return;
                    }
                    final String[] sd = d.split("\\.");
                    if (sd == null) {
                        return;
                    }
                    fulllist.add(sd);
                    final int random = TickHandler.rand.nextInt(100);
                    final int chance = Integer.parseInt(sd[0]);
                    if (random > chance) {
                        chancelist.add(sd);
                    }
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            String[] sd2 = null;
            if (!chancelist.isEmpty()) {
                final int randomn = TickHandler.rand.nextInt(chancelist.size());
                sd2 = chancelist.get(randomn);
            }
            else {
                final int randomn = TickHandler.rand.nextInt(fulllist.size());
                sd2 = fulllist.get(randomn);
            }
            if (sd2 != null) {
                try {
                    player.func_70634_a(Integer.parseInt(sd2[1]) + 0.5, (double)(Integer.parseInt(sd2[2]) + 1), Integer.parseInt(sd2[3]) + 0.5);
                    player.func_70012_b(Integer.parseInt(sd2[1]) + 0.5, (double)(Integer.parseInt(sd2[2]) + 1), Integer.parseInt(sd2[3]) + 0.5, (float)TickHandler.rand.nextInt(359), 0.0f);
                    player.field_70165_t = Integer.parseInt(sd2[1]) + 0.5;
                    player.field_70163_u = Integer.parseInt(sd2[2]) + 1;
                    player.field_70161_v = Integer.parseInt(sd2[3]) + 0.5;
                }
                catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
    }
    
    @SubscribeEvent
    public void playerLeaveEvent(final PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.player instanceof EntityPlayer) {
            for (final Object o : event.player.field_70170_p.field_73010_i) {
                if (o instanceof EntityPlayerMP) {
                    final EntityPlayerMP player = (EntityPlayerMP)o;
                    final String uuid = event.player.func_110124_au().toString();
                    if (!WorldHandler.daym_3bb3f01c0.containsKey(uuid)) {
                        continue;
                    }
                    final int skin = WorldHandler.daym_3bb3f01c0.get(uuid);
                    DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_PlayerSkin(3, skin, skin > 4, uuid), player);
                }
            }
        }
        final String uuid2 = event.player.func_110124_au().toString();
        if (WorldHandler.daym_3bb3f01c0.containsKey(uuid2)) {
            WorldHandler.daym_3bb3f01c0.remove(uuid2);
        }
    }
    
    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public void clientTick(final TickEvent.ClientTickEvent event) {
        if (this.mc.field_71441_e != null && this.mc.field_71439_g != null) {
            this.mc.field_71474_y.field_74320_O = ClientProxy.getForcedView(this.mc);
            boolean canDoAnim = true;
            if (KeybindRegistry.keypressed[4] && !this.daym_2cc9623d0) {
                byte byt = 0;
                if (PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) == 0) {
                    byt = -1;
                }
                if (PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) == 3) {
                    canDoAnim = false;
                }
                if (canDoAnim) {
                    DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerAnimation(this.mc.field_71439_g.func_70005_c_(), byt));
                    PlayerVarHandler.daym_b73359c80.put(this.mc.field_71439_g.func_70005_c_(), byt);
                    this.daym_2cc9623d0 = true;
                }
            }
            if (KeybindRegistry.keypressed[5] && !this.daym_77618ddd0) {
                byte byt = 1;
                if (PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) == 1) {
                    byt = -1;
                }
                if (PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) == 3) {
                    canDoAnim = false;
                }
                if (canDoAnim) {
                    DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerAnimation(this.mc.field_71439_g.func_70005_c_(), byt));
                    PlayerVarHandler.daym_b73359c80.put(this.mc.field_71439_g.func_70005_c_(), byt);
                    this.daym_77618ddd0 = true;
                }
            }
            if (KeybindRegistry.keypressed[6] && !this.daym_e9d55ce20) {
                byte byt = 2;
                if (PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) == 2) {
                    byt = -1;
                }
                if (PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) == 3) {
                    canDoAnim = false;
                }
                if (canDoAnim) {
                    DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerAnimation(this.mc.field_71439_g.func_70005_c_(), byt));
                    PlayerVarHandler.daym_b73359c80.put(this.mc.field_71439_g.func_70005_c_(), byt);
                    this.daym_e9d55ce20 = true;
                }
            }
            if (KeybindRegistry.keypressed[7] && !this.daym_a78a97af0) {
                byte byt = 4;
                if (PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) == 4) {
                    byt = -1;
                }
                if (PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(this.mc.field_71439_g.func_70005_c_()) == 3) {
                    canDoAnim = false;
                }
                if (canDoAnim) {
                    DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_PlayerAnimation(this.mc.field_71439_g.func_70005_c_(), byt));
                    PlayerVarHandler.daym_b73359c80.put(this.mc.field_71439_g.func_70005_c_(), byt);
                    this.daym_a78a97af0 = true;
                }
            }
        }
        if (!KeybindRegistry.keypressed[4] && this.daym_2cc9623d0) {
            this.daym_2cc9623d0 = false;
        }
        if (!KeybindRegistry.keypressed[5] && this.daym_77618ddd0) {
            this.daym_77618ddd0 = false;
        }
        if (!KeybindRegistry.keypressed[6] && this.daym_e9d55ce20) {
            this.daym_e9d55ce20 = false;
        }
        if (!KeybindRegistry.keypressed[7] && this.daym_a78a97af0) {
            this.daym_a78a97af0 = false;
        }
        if (this.mc.field_71441_e != null && this.mc.field_71439_g != null && this.mc.field_71462_r == null) {
            final MovingObjectPosition test = this.mc.field_71476_x;
            TickHandler.daym_6f4591d50 = null;
            if (test != null && test.field_72313_a == MovingObjectPosition.MovingObjectType.BLOCK) {
                this.daym_cf2c741a0 = 0.0;
                final ArrayList<EntityItem> test2 = (ArrayList<EntityItem>)WorldHandler.daym_4ceb36930.clone();
                for (final EntityItem ei : test2) {
                    if (ei != null && !ei.field_70128_L) {
                        final Vec3 hit = test.field_72307_f;
                        if (hit == null) {
                            continue;
                        }
                        final double dist = ei.func_70011_f(hit.field_72450_a + 0.1, hit.field_72448_b + 0.1, hit.field_72449_c + 0.1);
                        if (dist >= 1.0) {
                            continue;
                        }
                        if (this.daym_cf2c741a0 == 0.0) {
                            this.daym_cf2c741a0 = 1.0;
                        }
                        if (dist < this.daym_cf2c741a0 && !ei.field_70128_L) {
                            TickHandler.daym_6f4591d50 = ei.func_92059_d();
                        }
                        this.daym_cf2c741a0 = dist;
                        if (Mouse.isButtonDown(1) && !this.daym_5239c32e0 && TickHandler.daym_6f4591d50 != null && ei.field_70173_aa > 20) {
                            this.daym_5239c32e0 = true;
                            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_ItemPickupClick((byte)0, Item.func_150891_b(TickHandler.daym_6f4591d50.func_77973_b()), hit.field_72450_a + 0.1, hit.field_72448_b + 0.1, hit.field_72449_c + 0.1));
                            this.mc.field_71439_g.field_71071_by.func_70296_d();
                            TickHandler.daym_6f4591d50 = null;
                            break;
                        }
                        continue;
                    }
                }
            }
        }
        if (!Mouse.isButtonDown(1) && this.daym_5239c32e0) {
            this.daym_5239c32e0 = false;
            TickHandler.daym_6f4591d50 = null;
        }
        if (this.daym_c14f564702 < 10) {
            ++this.daym_c14f564702;
        }
        else {
            if (this.daym_9d9bbdf70 < 2) {
                ++this.daym_9d9bbdf70;
            }
            else {
                this.daym_9d9bbdf70 = 0;
                if (this.mc.field_71441_e != null && this.mc.field_71439_g != null) {
                    final EntityPlayer player = (EntityPlayer)this.mc.field_71439_g;
                    final String uuid = player.func_110124_au().toString();
                    final int j3 = (int)player.field_70165_t;
                    final int k3 = (int)player.field_70163_u;
                    final int l3 = (int)player.field_70161_v;
                    String biomen = "plains";
                    if (this.mc.field_71441_e.func_72899_e(j3, k3, l3)) {
                        final Chunk chunk = this.mc.field_71441_e.func_72938_d(j3, l3);
                        biomen = chunk.func_76591_a(j3 & 0xF, l3 & 0xF, this.mc.field_71441_e.func_72959_q()).field_76791_y.toLowerCase();
                    }
                    final boolean isNight = this.mc.field_71441_e.func_72820_D() > 13000L && this.mc.field_71441_e.func_72820_D() < 22500L;
                    if (!ClientProxy.daym_12f37d010.containsKey(uuid)) {
                        final String bsn = SoundHandlerDayM.getBiomeSound(biomen, isNight);
                        if (bsn != "null") {
                            final LoopingSound ls = SoundHandlerDayM.playSoundLoop(bsn, 0.75f, 1.0f, biomen, isNight);
                            ls.biome = biomen;
                            ClientProxy.daym_12f37d010.put(uuid, ls);
                        }
                    }
                    else {
                        LoopingSound ls2 = ClientProxy.daym_12f37d010.get(uuid);
                        if (!ls2.biome.contains(biomen) || ls2.isNight != isNight) {
                            ls2.isFading = true;
                            ls2.func_73660_a();
                            if (ls2.canBeDestroyed) {
                                ls2.donePlaying = true;
                                ls2 = null;
                                ClientProxy.daym_12f37d010.remove(uuid);
                            }
                        }
                        else {
                            ls2.func_73660_a();
                        }
                    }
                }
            }
            if (this.mc.field_71441_e != null && this.mc.field_71439_g != null) {
                final EntityPlayer player = (EntityPlayer)this.mc.field_71439_g;
                final String uuid = player.func_110124_au().toString();
                if (ClientProxy.daym_12f37d010.containsKey(uuid)) {
                    final LoopingSound ls3 = ClientProxy.daym_12f37d010.get(uuid);
                    ls3.func_73660_a();
                }
            }
            this.daym_c14f564702 = 0;
        }
        if (this.mc.field_71439_g != null) {
            final EntityPlayer player = (EntityPlayer)this.mc.field_71439_g;
            final String uuid = player.func_110124_au().toString();
            if (ClientProxy.daym_12f37d010.containsKey(uuid)) {
                final LoopingSound ls3 = ClientProxy.daym_12f37d010.get(uuid);
                ls3.updatePosition((Entity)player);
            }
        }
        if (Mouse.isButtonDown(0)) {
            if (this.mc.field_71462_r == null && this.mc.field_71439_g != null) {
                PlayerVarHandler.clickingList.put(this.mc.field_71439_g.func_110124_au().toString(), true);
            }
            if (!this.leftClicked) {
                this.leftClicked = true;
            }
        }
        else {
            this.leftClicked = false;
            if (this.mc.field_71439_g != null && PlayerVarHandler.clickingList.containsKey(this.mc.field_71439_g.func_110124_au().toString()) && PlayerVarHandler.clickingList.get(this.mc.field_71439_g.func_110124_au().toString())) {
                PlayerVarHandler.clickingList.put(this.mc.field_71439_g.func_110124_au().toString(), false);
            }
        }
        if (this.daym_f8f4c47d0 != this.leftClicked) {
            this.daym_f8f4c47d0 = this.leftClicked;
            if (this.mc.field_71439_g == null) {
                return;
            }
            if (this.mc.field_71439_g.field_71071_by.func_70448_g() == null) {
                return;
            }
            if (Minecraft.func_71410_x().field_71462_r == null && ItemRegistry.gunList.contains(this.mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b())) {
                DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_MouseClick(this.leftClicked));
            }
        }
        if (RenderSetup.daym_2b3b426c0) {
            if (this.mc.field_71439_g == null) {
                RenderSetup.daym_2b3b426c0 = false;
                return;
            }
            if (this.mc.field_71439_g.field_71071_by.func_70448_g() == null) {
                RenderSetup.daym_2b3b426c0 = false;
                return;
            }
            if (!ItemRegistry.gunList.contains(this.mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b())) {
                RenderSetup.daym_2b3b426c0 = false;
            }
        }
    }
    
    @SubscribeEvent
    public void serverTick(final TickEvent.ServerTickEvent event) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            return;
        }
        if (WorldHandler.daym_a5956ee00.contains("EntityZombie")) {
            final ArrayList<EntityChicken> chlist = (ArrayList<EntityChicken>)WorldHandler.daym_e0d55c940.clone();
            for (final EntityChicken ec : chlist) {
                if (ec.field_70153_n != null) {
                    ec.field_70153_n.func_70106_y();
                    ec.func_70106_y();
                    WorldHandler.daym_e0d55c940.remove(ec);
                }
            }
        }
        if (WorldHandler.daym_0b5a7f8a0 == "null") {
            final MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
            if (DayM.daym_2bb53b850) {
                WorldHandler.setDirectoryAndLoad(FMLCommonHandler.instance().getSavesDirectory() + "/" + server.func_71270_I() + "/");
            }
            else {
                WorldHandler.setDirectoryAndLoad("/" + server.func_71270_I() + "/");
            }
            daymlog.out("World Directory(DayM Debug): " + WorldHandler.daym_0b5a7f8a0);
        }
        if (this.world == null) {
            this.world = (World)FMLCommonHandler.instance().getMinecraftServerInstance().field_71305_c[0];
        }
        if (this.daym_c14f564702 < 10) {
            ++this.daym_c14f564702;
        }
        else if (this.daym_9d9bbdf70 < 1) {
            ++this.daym_9d9bbdf70;
        }
        else {
            this.daym_9d9bbdf70 = 0;
        }
        if (this.daym_c14f56470 < 240) {
            ++this.daym_c14f56470;
        }
        else {
            if (this.daym_1fef99d20 < 10) {
                if (this.daym_1fef99d20 % 5 == 0 && this.world != null && this.needsInventoryReload && TickHandler.rand.nextBoolean()) {
                    for (final Object o : this.world.field_73010_i) {
                        if (o instanceof EntityPlayer) {
                            DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_SyncPlayerProps(0, (EntityPlayer)o));
                        }
                    }
                    this.needsInventoryReload = false;
                }
                if (this.daym_1fef99d20 % 2 == 0) {
                    final ArrayList<EntityItem> clone = (ArrayList<EntityItem>)WorldHandler.daym_801545040.clone();
                    for (final EntityItem ei : clone) {
                        if (ei == null) {
                            WorldHandler.daym_801545040.remove(ei);
                        }
                        else {
                            if (!ei.field_70128_L) {
                                continue;
                            }
                            WorldHandler.daym_801545040.remove(ei);
                        }
                    }
                    if (WorldHandler.daym_801545040.size() > WorldHandler.daym_095996cc0 * TickHandler.daym_154aa7680) {
                        for (int r = 0; r < TickHandler.rand.nextInt(10) + 10; ++r) {
                            int var = WorldHandler.daym_801545040.size() - 16;
                            if (var <= 0) {
                                var = 2;
                            }
                            final int rr = TickHandler.rand.nextInt(var);
                            try {
                                WorldHandler.daym_801545040.remove(rr);
                                WorldHandler.daym_4ceb36930.remove(rr);
                            }
                            catch (Exception ex) {}
                        }
                    }
                }
                if (this.daym_1fef99d20 % 5 == 0 && TickHandler.rand.nextBoolean()) {
                    final String[] data = WorldHandler.daym_4524cfb60(WorldHandler.daym_5635fd3d0, null);
                    if (data != null) {
                        for (final String d : data) {
                            try {
                                final String[] sd = d.split("\\.");
                                if (this.world != null && this.world.func_72863_F() != null) {
                                    final boolean chunkLoaded = this.world.func_72863_F().func_73149_a(Integer.parseInt(sd[5]) >> 4, Integer.parseInt(sd[7]) >> 4);
                                    if (chunkLoaded) {
                                        final int type = Integer.parseInt(sd[0]);
                                        final int chance = Integer.parseInt(sd[1]);
                                        final int randint = TickHandler.rand.nextInt(100);
                                        if (randint > chance) {
                                            final int radius = Integer.parseInt(sd[2]);
                                            int amount = Integer.parseInt(sd[3]);
                                            final int randomize = Integer.parseInt(sd[4]);
                                            if (randomize == 1) {
                                                amount = TickHandler.rand.nextInt(amount) + 1;
                                            }
                                            for (int i = 0; i < amount; ++i) {
                                                final EntityZombieBase zom = new EntityZombieBase(this.world, radius, amount);
                                                if (!this.world.field_72995_K) {
                                                    final double x = Integer.parseInt(sd[5]) + 0.5 - radius / 2 + TickHandler.rand.nextInt(radius);
                                                    final double y = Integer.parseInt(sd[6]) + 1;
                                                    final double z = Integer.parseInt(sd[7]) + 0.5 - radius / 2 + TickHandler.rand.nextInt(radius);
                                                    zom.func_70012_b(x, y, z, (float)TickHandler.rand.nextInt(360), 0.0f);
                                                    if (this.world.func_147439_a((int)x, (int)y, (int)z) == Blocks.field_150350_a && this.world.func_147439_a((int)x, (int)y + 1, (int)z) == Blocks.field_150350_a) {
                                                        boolean playernear = false;
                                                        for (final Object o2 : this.world.field_73010_i) {
                                                            if (o2 instanceof EntityPlayer) {
                                                                final EntityPlayer opla = (EntityPlayer)o2;
                                                                if (opla.func_70011_f(x, y, z) < 13.0) {
                                                                    playernear = true;
                                                                    break;
                                                                }
                                                                continue;
                                                            }
                                                        }
                                                        if (!playernear) {
                                                            this.world.func_72838_d((Entity)zom);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception ex2) {}
                        }
                    }
                }
                final int var2 = (this.world.field_73010_i.size() + 1) / 10 + 2;
                if (this.daym_1fef99d20 % 4 == 0) {
                    for (int r = 0; r < var2; ++r) {
                        final String[] data2 = WorldHandler.daym_4524cfb60(WorldHandler.daym_28d3f01a0, null);
                        if (data2 != null) {
                            TickHandler.daym_154aa7680 = data2.length;
                            for (final String d2 : data2) {
                                boolean chunkChecked = false;
                                try {
                                    final String[] sd2 = d2.split("\\.");
                                    final ArrayList<String> loots = LootSpawn.decodeLootTable(sd2[0]);
                                    final ArrayList<Integer> loot1 = new ArrayList<Integer>();
                                    final ArrayList<Integer> loot2 = new ArrayList<Integer>();
                                    for (final String ll : loots) {
                                        final String[] ss = ll.split("\\?");
                                        if (ss.length > 1) {
                                            if (ss[0] != null) {
                                                loot1.add(Integer.parseInt(ss[0]));
                                            }
                                            if (ss[1] == null) {
                                                continue;
                                            }
                                            loot2.add(Integer.parseInt(ss[1]));
                                        }
                                    }
                                    if (this.world != null && this.world.func_72863_F() != null) {
                                        final boolean chunkLoaded2 = this.world.func_72863_F().func_73149_a(Integer.parseInt(sd2[4]) >> 4, Integer.parseInt(sd2[6]) >> 4);
                                        if (chunkLoaded2) {
                                            chunkChecked = true;
                                        }
                                    }
                                    if (chunkChecked) {
                                        for (int randAm = TickHandler.rand.nextInt(6), i = 0; i < randAm; ++i) {
                                            if (loot1.size() > 0) {
                                                final int lid = Integer.parseInt(sd2[1]);
                                                final int radius2 = Integer.parseInt(sd2[2]);
                                                final int chance2 = Integer.parseInt(sd2[3]);
                                                final int randint2 = TickHandler.rand.nextInt(100);
                                                if (randint2 > chance2) {
                                                    for (int bh = 0; bh < 1; ++bh) {
                                                        final double x2 = Integer.parseInt(sd2[4]) + TickHandler.rand.nextDouble() - radius2 / 2 + TickHandler.rand.nextInt(radius2);
                                                        final double y2 = Integer.parseInt(sd2[5]) + 1;
                                                        final double z2 = Integer.parseInt(sd2[6]) + TickHandler.rand.nextDouble() - radius2 / 2 + TickHandler.rand.nextInt(radius2);
                                                        final Block blck = this.world.func_147439_a((int)x2, (int)y2, (int)z2);
                                                        if (blck == Blocks.field_150350_a || blck instanceof BlockSlab || blck instanceof BlockDayMSlab) {
                                                            boolean playernear2 = false;
                                                            for (final Object o3 : this.world.field_73010_i) {
                                                                if (o3 instanceof EntityPlayer) {
                                                                    final EntityPlayer opla2 = (EntityPlayer)o3;
                                                                    if (opla2.func_70011_f(x2, y2, z2) < 33.0) {
                                                                        playernear2 = true;
                                                                        break;
                                                                    }
                                                                    continue;
                                                                }
                                                            }
                                                            double offsetY = 0.0;
                                                            if (blck instanceof BlockSlab || blck instanceof BlockDayMSlab) {
                                                                offsetY = 1.0;
                                                            }
                                                            for (final EntityItem loopei : WorldHandler.daym_801545040) {
                                                                if (loopei.func_70011_f(x2, y2 + offsetY, z2) < 1.5) {
                                                                    playernear2 = true;
                                                                    break;
                                                                }
                                                            }
                                                            for (final EntityItem loopei : WorldHandler.daym_4ceb36930) {
                                                                if (loopei.func_70011_f(x2, y2 + offsetY, z2) < 1.5) {
                                                                    playernear2 = true;
                                                                    break;
                                                                }
                                                            }
                                                            if (!playernear2) {
                                                                final int randn = TickHandler.rand.nextInt(loot1.size());
                                                                Item item = null;
                                                                final int randint3 = TickHandler.rand.nextInt(100);
                                                                item = ItemRegistry.lootTable.get(loot1.get(randn));
                                                                if (item != null && randint3 > 100 - loot2.get(randn)) {
                                                                    ItemStack itemstackSpawn = new ItemStack(item);
                                                                    itemstackSpawn.field_77994_a = 1;
                                                                    if (item instanceof ItemMagazine) {
                                                                        final ItemMagazine mag = (ItemMagazine)item;
                                                                        final int bul = TickHandler.rand.nextInt(mag.maxAmmo);
                                                                        if (bul > 0) {
                                                                            if (itemstackSpawn.field_77990_d == null) {
                                                                                itemstackSpawn.field_77990_d = new NBTTagCompound();
                                                                            }
                                                                            final NBTTagCompound tag = itemstackSpawn.field_77990_d;
                                                                            tag.func_74768_a("bullets", bul);
                                                                        }
                                                                    }
                                                                    if (item instanceof ItemAmmo) {
                                                                        int randstacksize = TickHandler.rand.nextInt(itemstackSpawn.func_77976_d());
                                                                        if (randstacksize == 0) {
                                                                            randstacksize = 1;
                                                                        }
                                                                        itemstackSpawn.field_77994_a = randstacksize;
                                                                    }
                                                                    EntityItem ei2 = new EntityItem(this.world, x2, y2 + offsetY, z2, itemstackSpawn);
                                                                    ei2.field_70159_w = 0.0;
                                                                    ei2.field_70181_x = 0.0;
                                                                    ei2.field_70179_y = 0.0;
                                                                    ei2.func_70012_b(x2, y2 + offsetY, z2, 0.0f, 0.0f);
                                                                    this.world.func_72838_d((Entity)ei2);
                                                                    ei2.lifespan *= 2;
                                                                    WorldHandler.daym_801545040.add(ei2);
                                                                    WorldHandler.daym_4ceb36930.add(ei2);
                                                                    if (itemstackSpawn.func_77973_b() instanceof ItemDayMGun) {
                                                                        final ItemDayMGun gun = (ItemDayMGun)itemstackSpawn.func_77973_b();
                                                                        if (TickHandler.rand.nextBoolean()) {
                                                                            itemstackSpawn = new ItemStack((Item)gun.daym_511e1e650);
                                                                            final int bul2 = TickHandler.rand.nextInt(gun.daym_511e1e650.maxAmmo);
                                                                            if (bul2 > 0) {
                                                                                if (itemstackSpawn.field_77990_d == null) {
                                                                                    itemstackSpawn.field_77990_d = new NBTTagCompound();
                                                                                }
                                                                                final NBTTagCompound tag2 = itemstackSpawn.field_77990_d;
                                                                                tag2.func_74768_a("bullets", bul2);
                                                                            }
                                                                            ei2 = new EntityItem(this.world, x2 - 1.0 + TickHandler.rand.nextInt(2), y2 + offsetY, z2 - 1.0 + TickHandler.rand.nextInt(2), itemstackSpawn);
                                                                            ei2.field_70159_w = 0.0;
                                                                            ei2.field_70181_x = 0.0;
                                                                            ei2.field_70179_y = 0.0;
                                                                            ei2.func_70012_b(x2 - 1.0 + TickHandler.rand.nextInt(2), y2 + offsetY, z2 - 1.0 + TickHandler.rand.nextInt(2), 0.0f, 0.0f);
                                                                            this.world.func_72838_d((Entity)ei2);
                                                                            ei2.lifespan *= 2;
                                                                            WorldHandler.daym_801545040.add(ei2);
                                                                            WorldHandler.daym_4ceb36930.add(ei2);
                                                                        }
                                                                        break;
                                                                    }
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                catch (Exception ex3) {}
                            }
                        }
                    }
                }
                ++this.daym_1fef99d20;
            }
            else {
                this.daym_1fef99d20 = 0;
            }
            this.daym_c14f56470 = 0;
        }
    }
    
    @SubscribeEvent
    public void playerTick(final TickEvent.PlayerTickEvent event) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        final EntityPlayer player = event.player;
        if (player != null) {
            this.worldBorderCheck(player, side);
            this.parachuteStuff(player, side);
            this.scanCheckInventory(player, side);
            this.vicinityCheckReload(player, side);
            if (!player.field_71075_bZ.field_75098_d) {
                final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get(player).inventory;
                if (inventorydaym.inventory[3] == null) {
                    final EntityPlayer entityPlayer = player;
                    entityPlayer.field_70159_w *= 0.8500000238418579 + Math.min(0.20000000298023224, Math.abs(player.field_70181_x));
                    final EntityPlayer entityPlayer2 = player;
                    entityPlayer2.field_70179_y *= 0.8500000238418579 + Math.min(0.20000000298023224, Math.abs(player.field_70181_x));
                }
            }
            if (PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) != null) {
                if (PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) == 0) {
                    final EntityPlayer entityPlayer3 = player;
                    entityPlayer3.field_70159_w *= 0.6000000238418579;
                    final EntityPlayer entityPlayer4 = player;
                    entityPlayer4.field_70179_y *= 0.6000000238418579;
                    player.func_70031_b(false);
                }
                if (PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) == 1) {
                    final EntityPlayer entityPlayer5 = player;
                    entityPlayer5.field_70159_w *= 0.8999999761581421;
                    final EntityPlayer entityPlayer6 = player;
                    entityPlayer6.field_70179_y *= 0.8999999761581421;
                    player.func_70031_b(false);
                }
                if (PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) == 3) {
                    final EntityPlayer entityPlayer7 = player;
                    entityPlayer7.field_70159_w *= 0.30000001192092896;
                    final EntityPlayer entityPlayer8 = player;
                    entityPlayer8.field_70179_y *= 0.30000001192092896;
                    player.func_70031_b(false);
                }
            }
            if ((player.func_70115_ae() || (PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) != -1)) && player.field_71071_by.func_70448_g() != null && ItemRegistry.gunList.contains(player.field_71071_by.func_70448_g().func_77973_b())) {
                final InventoryPlayer field_71071_by = player.field_71071_by;
                ++field_71071_by.field_70461_c;
                if (player.field_71071_by.field_70461_c < 0) {
                    player.field_71071_by.field_70461_c = 0;
                }
                if (player.field_71071_by.field_70461_c > 4) {
                    player.field_71071_by.field_70461_c = 0;
                }
            }
            if (player.field_71075_bZ.field_75098_d) {
                return;
            }
            if (player.field_71071_by.field_70461_c > 7) {
                player.field_71071_by.field_70461_c = 4;
            }
            if (player.field_71071_by.field_70461_c > 4) {
                player.field_71071_by.field_70461_c = 0;
            }
        }
    }
    
    private void vicinityCheckReload(final EntityPlayer player, final Side side) {
        ArrayList<EntityItem> al = null;
        ArrayList<EntityItem> alr = null;
        if (WorldHandler.daym_e3864ff00.containsKey(player.func_110124_au().toString())) {
            al = WorldHandler.daym_e3864ff00.get(player.func_110124_au().toString());
            alr = new ArrayList<EntityItem>();
        }
        if (al != null && alr != null) {
            try {
                for (final EntityItem ei : al) {
                    if (ei != null) {
                        final float dist = player.func_70032_d((Entity)ei);
                        if (dist <= 2.5f) {
                            continue;
                        }
                        if (side.isClient()) {
                            ClientProxy.daym_4fa0d23c0 = true;
                        }
                        alr.add(ei);
                    }
                    else {
                        if (side.isClient()) {
                            ClientProxy.daym_4fa0d23c0 = true;
                        }
                        alr.add(ei);
                    }
                }
                al.removeAll(alr);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            alr.clear();
        }
    }
    
    private void worldBorderCheck(final EntityPlayer player, final Side side) {
        final String[] locs = WorldHandler.worldBorder.split("\\,");
        int x = 0;
        int y = 0;
        int x2 = 0;
        int y2 = 0;
        try {
            x = Integer.parseInt(locs[0]);
            y = Integer.parseInt(locs[1]);
            x2 = Integer.parseInt(locs[2]);
            y2 = Integer.parseInt(locs[3]);
        }
        catch (Exception ex) {}
        if (x != 0 || y != 0 || x2 != 0 || (y2 != 0 && !player.field_71075_bZ.field_75098_d)) {
            if (player.field_70165_t < x) {
                player.func_70024_g(Math.abs(player.field_70159_w * 1.5) + 0.05, 0.0, 0.0);
            }
            if (player.field_70161_v < y) {
                player.func_70024_g(0.0, 0.0, Math.abs(player.field_70179_y * 1.5) + 0.05);
            }
            if (player.field_70165_t > x2) {
                player.func_70024_g(-Math.abs(player.field_70159_w * 1.5) - 0.05, 0.0, 0.0);
            }
            if (player.field_70161_v > y2) {
                player.func_70024_g(0.0, 0.0, -Math.abs(player.field_70179_y * 1.5) - 0.05);
            }
        }
    }
    
    private void scanCheckInventory(final EntityPlayer player, final Side side) {
        int i = 0;
        int amgr = 0;
        int amgo = 0;
        int lastgun = 0;
        ItemStack lastgunis = null;
        for (final ItemStack is : player.field_71071_by.field_70462_a) {
            int var = 4;
            if (player.field_71075_bZ.field_75098_d) {
                var = 8;
            }
            else if (i < var + 1 && is != null && is.func_77973_b() instanceof ItemDayMGun) {
                final ItemDayMGun gun = (ItemDayMGun)is.func_77973_b();
                if (!gun.daym_c46b8fa90) {
                    ++amgr;
                }
                else {
                    ++amgo;
                }
                lastgun = i;
                lastgunis = is;
            }
            if ((i > var || ((amgr > 1 || amgo > 2) && lastgunis != null)) && is != null) {
                if (side.isClient()) {
                    IChatComponent test = (IChatComponent)new ChatComponentText("Inventory full.");
                    if ((amgr > 1 || amgo > 2) && lastgunis != null) {
                        if (amgr > 1) {
                            test = (IChatComponent)new ChatComponentText("You can't carry more than 1 large weapon.");
                        }
                        else {
                            test = (IChatComponent)new ChatComponentText("You can't carry more than 2 small weapons.");
                        }
                    }
                }
                else {
                    if ((amgr > 1 || amgo > 2) && lastgunis != null) {
                        player.field_71071_by.func_70299_a(lastgun, (ItemStack)null);
                        player.field_71071_by.field_70462_a[lastgun] = null;
                        player.func_146097_a(lastgunis, false, false);
                    }
                    else {
                        player.field_71071_by.func_70299_a(i, (ItemStack)null);
                        player.field_71071_by.field_70462_a[i] = null;
                        player.func_146097_a(is, false, false);
                    }
                    player.field_71071_by.func_70296_d();
                }
            }
            ++i;
        }
    }
    
    public void parachuteStuff(final EntityPlayer player, final Side side) {
        if (player.field_70143_R > 3.1f) {
            final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get(player).inventory;
            if (inventorydaym.inventory[5] != null && inventorydaym.inventory[5].func_77973_b() == ItemRegistry.item_parachute && player.field_70181_x < -0.2) {
                player.func_70024_g(0.0, 0.05, 0.0);
            }
        }
    }
    
    static {
        TickHandler.rand = new Random();
        TickHandler.daym_154aa7680 = 0;
    }
}
