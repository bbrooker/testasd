package com.daym.handlers.packets;

import com.daym.handlers.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.player.*;
import com.daym.extended.*;
import io.netty.channel.*;
import io.netty.buffer.*;
import cpw.mods.fml.common.network.*;

public class SyncPlayerPropsPacketDEPRECATED extends AbstractPacket
{
    private NBTTagCompound data;
    
    public SyncPlayerPropsPacketDEPRECATED() {
    }
    
    public SyncPlayerPropsPacketDEPRECATED(final EntityPlayer player) {
        this.data = new NBTTagCompound();
        ExtendedPlayer.get(player).saveNBTData(this.data);
    }
    
    @Override
    public void encodeInto(final ChannelHandlerContext ctx, final ByteBuf buffer) {
        ByteBufUtils.writeTag(buffer, this.data);
    }
    
    @Override
    public void decodeInto(final ChannelHandlerContext ctx, final ByteBuf buffer) {
        this.data = ByteBufUtils.readTag(buffer);
    }
    
    @Override
    public void handleClientSide(final EntityPlayer player) {
        ExtendedPlayer.get(player).loadNBTData(this.data);
    }
    
    @Override
    public void handleServerSide(final EntityPlayer player) {
    }
}
