package com.daym.handlers.packets;

import com.daym.handlers.*;
import io.netty.channel.*;
import io.netty.buffer.*;
import net.minecraft.entity.player.*;
import com.daym.*;

public class OpenGuiPacket extends AbstractPacket
{
    private int id;
    
    public OpenGuiPacket() {
    }
    
    public OpenGuiPacket(final int id) {
        this.id = id;
    }
    
    @Override
    public void encodeInto(final ChannelHandlerContext ctx, final ByteBuf buffer) {
        buffer.writeInt(this.id);
    }
    
    @Override
    public void decodeInto(final ChannelHandlerContext ctx, final ByteBuf buffer) {
        this.id = buffer.readInt();
    }
    
    @Override
    public void handleClientSide(final EntityPlayer player) {
    }
    
    @Override
    public void handleServerSide(final EntityPlayer player) {
        player.openGui((Object)DayM.getInstance(), this.id, player.field_70170_p, (int)player.field_70165_t, (int)player.field_70163_u, (int)player.field_70161_v);
    }
}
