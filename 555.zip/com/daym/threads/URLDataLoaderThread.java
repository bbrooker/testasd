package com.daym.threads;

import com.daym.logger.*;
import java.net.*;
import java.io.*;

public class URLDataLoaderThread extends Thread
{
    public String output;
    public String urlString;
    
    public URLDataLoaderThread(final String u) {
        this.output = "$$ERROR";
        this.urlString = "$$ERROR";
        this.urlString = u;
    }
    
    @Override
    public void run() {
        this.output = this.getData(this.urlString);
    }
    
    public String getData(final String url) {
        daymlog.out("Checking url data.");
        InputStream is = null;
        String ret = "$$ERROR";
        try {
            final URL u = new URL(this.urlString);
            is = u.openStream();
            final DataInputStream dis = new DataInputStream(new BufferedInputStream(is));
            String s;
            while ((s = dis.readLine()) != null) {
                ret = s;
            }
        }
        catch (MalformedURLException mue) {
            daymlog.out("DayM - a MalformedURLException (readOnlineData:52)");
            return "$$ERROR";
        }
        catch (IOException ioe) {
            daymlog.out("DayM - an IOException happened. (readOnlineData:60)");
            return "$$ERROR";
        }
        finally {
            return ret;
        }
    }
    
    public String getOutput() {
        return this.output;
    }
}
