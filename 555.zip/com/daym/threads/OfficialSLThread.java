package com.daym.threads;

import com.daym.handlers.*;
import com.daym.serverproxy.*;
import com.daym.*;
import com.daym.logger.*;
import java.net.*;
import java.io.*;

public class OfficialSLThread extends Thread
{
    public boolean daym_28f500420;
    public String url;
    public String type;
    
    public OfficialSLThread(final String u, final String t) {
        this.daym_28f500420 = false;
        this.url = "";
        this.type = "";
        this.url = u;
        this.type = t;
    }
    
    @Override
    public void run() {
        if (this.type == "official") {
            ServerListHandler.oServerList.clear();
        }
        if (this.type == "public") {
            ServerListHandler.serverList.clear();
        }
        String output = this.getData(this.url);
        int i = 0;
        final int a = 0;
        boolean shouldLoop = output == "$$ERROR";
        while (shouldLoop) {
            if (i > 15000) {
                shouldLoop = false;
                output = "$ERROR";
                break;
            }
            ++i;
        }
        final String[] servers = CommonProxy.decodeServers(output);
        if (this.type == "official") {
            ServerListHandler.oServerList.add(servers);
        }
        if (this.type == "public") {
            ServerListHandler.serverList.add(servers);
        }
        if (this.type == "serverAmount" && output != "$$ERROR" && output != "$ERROR") {
            try {
                ServerListHandler.serverAmount = Integer.parseInt(output);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (this.type == "bl" && output != "$$ERROR" && output != "$ERROR") {
            try {
                DayM.daym_f06245270 = output;
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (this.type == "version" && output != "$$ERROR" && output != "$ERROR") {
            try {
                DayM.daym_8907e7060 = output;
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        this.daym_28f500420 = true;
    }
    
    public String getData(final String url) {
        InputStream is = null;
        String ret = "$$ERROR";
        try {
            final URL u = new URL(url);
            is = u.openStream();
            final DataInputStream dis = new DataInputStream(new BufferedInputStream(is));
            String s;
            while ((s = dis.readLine()) != null) {
                ret = s;
            }
        }
        catch (MalformedURLException mue) {
            daymlog.out("DayM - a MalformedURLException (readOnlineData:52)");
            return "$$ERROR";
        }
        catch (IOException ioe) {
            daymlog.out("DayM - an IOException happened. (readOnlineData:60)");
            return "$$ERROR";
        }
        finally {
            return ret;
        }
    }
}
