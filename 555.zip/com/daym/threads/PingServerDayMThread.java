package com.daym.threads;

import net.minecraft.client.multiplayer.*;
import com.daym.gui.*;
import java.io.*;

public class PingServerDayMThread extends Thread
{
    public int daym_28f500420;
    public boolean hasStarted;
    public boolean shouldWait;
    public ServerData server;
    private GuiMultiplayerDayM guiMultiplayer;
    
    public PingServerDayMThread(final GuiMultiplayerDayM gui, final ServerData s) {
        this.daym_28f500420 = 0;
        this.hasStarted = false;
        this.shouldWait = true;
        this.guiMultiplayer = gui;
        this.server = s;
        this.daym_28f500420 = 0;
    }
    
    @Override
    public void run() {
        this.hasStarted = true;
        this.daym_28f500420 = 0;
        this.getData();
    }
    
    public void getData() {
        try {
            this.guiMultiplayer.olderServerPinger.func_147224_a(this.server);
        }
        catch (IOException e) {
            e.printStackTrace();
            this.daym_28f500420 = 1;
        }
        this.daym_28f500420 = 2;
    }
}
