package com.daym.render;

import net.minecraft.client.renderer.entity.*;

public class RenderItemDayM extends RenderItem
{
    public boolean shouldBob() {
        return false;
    }
    
    public boolean shouldSpreadItems() {
        return false;
    }
}
