package com.daym.render;

public class AnimKeyframe
{
    public float lx;
    public float ly;
    public float lz;
    public float r0;
    public float rx;
    public float ry;
    public float rz;
    public float speed;
    public boolean repeat;
    public boolean singleRotation;
    public boolean daym_e3c338e00;
    
    public AnimKeyframe(final float x, final float y, final float z, final float rx0, final float rx1, final float ry1, final float rz1, final float sp, final boolean b, final boolean r, final boolean i) {
        this.lx = 0.0f;
        this.ly = 0.0f;
        this.lz = 0.0f;
        this.r0 = 0.0f;
        this.rx = 0.0f;
        this.ry = 0.0f;
        this.rz = 0.0f;
        this.speed = 0.0f;
        this.repeat = false;
        this.singleRotation = false;
        this.daym_e3c338e00 = false;
        this.lx = x;
        this.ly = y;
        this.lz = z;
        this.r0 = rx0;
        this.rx = rx1;
        this.ry = ry1;
        this.rz = rz1;
        this.speed = sp;
        this.repeat = b;
        this.singleRotation = r;
        this.daym_e3c338e00 = i;
    }
    
    public String stringify() {
        return "lx: " + this.lx + ",ly: " + this.ly + ",lz: " + this.lz + ",r0: " + this.r0 + ",rx: " + this.rx + ",ry: " + this.ry + ",rz: " + this.rz + ",speed: " + this.speed + ",repeat: " + this.repeat + ",singleRotation: " + this.singleRotation + ",daym_e3c338e00: " + this.daym_e3c338e00;
    }
}
