package com.daym.render;

import com.daym.registry.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.particle.*;
import java.util.*;

public class DynamicSmoke
{
    Vec3[] vec3;
    
    public DynamicSmoke(final double xx, final double yy, final double zz) {
        this.vec3 = new Vec3[4];
        this.addVector(xx, yy, zz);
    }
    
    public void addVector(final double xx, final double yy, final double zz) {
        int a = 0;
        boolean clear = false;
        for (int i = 0; i < this.vec3.length; ++i) {
            if (this.vec3[i] == null) {
                this.vec3[i] = Vec3.func_72443_a(xx, yy, zz);
                break;
            }
            if (++a == this.vec3.length) {
                clear = true;
            }
        }
        if (clear) {
            RenderSetup.daym_a169211b0 = null;
        }
    }
    
    public void render() {
        TextureRegistry.bindResource(TextureRegistry.cardboard_box);
        GL11.glPushMatrix();
        final Minecraft mc = Minecraft.func_71410_x();
        final float motionX = -MathHelper.func_76126_a(mc.field_71439_g.field_70177_z / 180.0f * 3.141593f) * MathHelper.func_76134_b(mc.field_71439_g.field_70125_A / 180.0f * 3.141593f);
        final float motionZ = MathHelper.func_76134_b(mc.field_71439_g.field_70177_z / 180.0f * 3.141593f) * MathHelper.func_76134_b(mc.field_71439_g.field_70125_A / 180.0f * 3.141593f);
        final float motionY = -MathHelper.func_76126_a(mc.field_71439_g.field_70125_A / 180.0f * 3.141593f);
        GL11.glTranslatef(motionX, motionY, motionZ);
        final RenderManager renderManager = RenderManager.field_78727_a;
        GL11.glRotatef(-renderManager.field_78735_i, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(renderManager.field_78732_j, 1.0f, 0.0f, 0.0f);
        GL11.glScalef(0.15f, 0.15f, 0.15f);
        final Tessellator localTessellator = Tessellator.field_78398_a;
        final double i = 0.5;
        final double j = 2.0;
        final double k = 2.0;
        final double l = 2.0;
        int a = 0;
        final double addx = 0.0;
        double addy = 0.0;
        double addz = 0.0;
        boolean addnew = true;
        final double interpPosX = EntityFX.field_70556_an;
        final double interpPosZ = EntityFX.field_70555_ap;
        for (final Vec3 vec : this.vec3) {
            if (vec != null) {
                addnew = false;
                final double xofs = (vec.field_72450_a - interpPosX - addx) * motionX;
                final double yofs = a * 2.02;
                final double zofs = (vec.field_72449_c - interpPosZ - addz) * -motionZ - xofs;
                final double max = 0.1;
                if (zofs * (a + 1) > max || xofs * (a + 1) > max) {
                    addnew = true;
                }
                if (zofs * (a + 1) < -max || xofs * (a + 1) < -max) {
                    addnew = true;
                }
                localTessellator.func_78382_b();
                localTessellator.func_78369_a(0.0f, 0.0f, 0.5f, 0.25f);
                localTessellator.func_78377_a(-(j + addx), yofs + (i - l / 2.0), addz);
                localTessellator.func_78377_a(-(j + addx), yofs + (i + l / 2.0), -zofs);
                localTessellator.func_78377_a(-(j + addx) + k * 1.0, yofs + (i + l / 2.0), -zofs);
                localTessellator.func_78377_a(-(j + addx) + k * 1.0, yofs + (i - l / 2.0), addz);
                localTessellator.func_78381_a();
                addz = -zofs;
                addy = yofs;
                ++a;
            }
        }
        if (addnew) {
            final Random random = new Random();
            if (random.nextInt(25) == random.nextInt(25)) {
                this.addVector(mc.field_71439_g.field_70165_t + motionX, mc.field_71439_g.field_70163_u + motionY, mc.field_71439_g.field_70161_v + motionZ);
            }
        }
        GL11.glPopMatrix();
    }
}
