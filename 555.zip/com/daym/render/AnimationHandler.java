package com.daym.render;

import cpw.mods.fml.relauncher.*;
import com.daym.enums.*;
import com.daym.logger.*;
import java.util.*;
import org.lwjgl.opengl.*;

@SideOnly(Side.CLIENT)
public class AnimationHandler
{
    private AnimationEnum[] anim;
    private AnimationEnum animation;
    private float lx;
    private float ly;
    private float lz;
    private float r0;
    private float rx;
    private float ry;
    private float rz;
    private float timer;
    private boolean daym_959c15c70;
    private int daym_fc1a1a780;
    private int daym_a1ec475f0;
    private float daym_94fcc54c0;
    private boolean adding;
    private boolean daym_479545bf0;
    private boolean daym_e3c338e00;
    public boolean daym_0667df810;
    public boolean daym_e037c16b0;
    private boolean daym_70a7d6d00Anim;
    public AnimKeyframe[] animKeysDebug;
    public boolean isPlaying;
    
    public AnimationHandler(final AnimationEnum[] ae, final boolean mfs) {
        this.lx = 0.0f;
        this.ly = 0.0f;
        this.lz = 0.0f;
        this.r0 = 0.0f;
        this.rx = 0.0f;
        this.ry = 0.0f;
        this.rz = 0.0f;
        this.timer = 0.0f;
        this.daym_959c15c70 = false;
        this.daym_fc1a1a780 = 0;
        this.daym_a1ec475f0 = 0;
        this.daym_94fcc54c0 = 0.0f;
        this.adding = false;
        this.daym_479545bf0 = false;
        this.daym_e3c338e00 = false;
        this.daym_0667df810 = true;
        this.daym_e037c16b0 = true;
        this.daym_70a7d6d00Anim = false;
        this.isPlaying = false;
        this.anim = ae;
        this.daym_e037c16b0 = mfs;
    }
    
    public AnimationHandler(final String string) {
        this.lx = 0.0f;
        this.ly = 0.0f;
        this.lz = 0.0f;
        this.r0 = 0.0f;
        this.rx = 0.0f;
        this.ry = 0.0f;
        this.rz = 0.0f;
        this.timer = 0.0f;
        this.daym_959c15c70 = false;
        this.daym_fc1a1a780 = 0;
        this.daym_a1ec475f0 = 0;
        this.daym_94fcc54c0 = 0.0f;
        this.adding = false;
        this.daym_479545bf0 = false;
        this.daym_e3c338e00 = false;
        this.daym_0667df810 = true;
        this.daym_e037c16b0 = true;
        this.daym_70a7d6d00Anim = false;
        this.isPlaying = false;
        this.daym_70a7d6d00Anim = true;
        this.daym_e037c16b0 = false;
    }
    
    public void setupAnims() {
        this.animKeysDebug = new AnimKeyframe[RenderSetup.daym_b73359c80.size() + 1];
        int a = 0;
        for (final String anim : RenderSetup.daym_b73359c80) {
            final String[] anims = anim.split("\\|");
            final float lxT = Float.parseFloat(anims[0]);
            final float lyT = Float.parseFloat(anims[1]);
            final float lzT = Float.parseFloat(anims[2]);
            final float rxT = Float.parseFloat(anims[3]);
            final float ryT = Float.parseFloat(anims[4]);
            final float rzT = Float.parseFloat(anims[5]);
            final float speed = Float.parseFloat(anims[6]);
            this.animKeysDebug[a] = new AnimKeyframe(lxT, lyT, lzT, 0.0f, rxT, ryT, rzT, speed, false, false, false);
            daymlog.out("Setting up debug anim keys: " + this.animKeysDebug[a].stringify());
            ++a;
        }
    }
    
    public void setAnimation(final int a) {
        if (this.anim.length >= a) {
            if (a > -1) {
                this.animation = this.anim[a];
            }
            else {
                this.animation = null;
            }
        }
        if (a < 0) {
            this.animation = null;
        }
    }
    
    public boolean isUsingAnimation(final int a) {
        return a >= 0 && this.animation == this.anim[a];
    }
    
    public void setAnimationFrame(final int f) {
        this.daym_fc1a1a780 = f;
    }
    
    public int getAnimationFrame() {
        return this.daym_fc1a1a780;
    }
    
    public void doAnimation(final String rt) {
        float tar = 0.0f;
        if (this.animation == null && !this.daym_70a7d6d00Anim) {
            this.isPlaying = false;
            return;
        }
        if (rt == "") {
            AnimKeyframe akf = null;
            if (this.daym_70a7d6d00Anim) {
                if (this.animKeysDebug != null) {
                    try {
                        akf = this.animKeysDebug[this.daym_fc1a1a780];
                    }
                    catch (Exception e) {}
                }
            }
            else {
                akf = this.animation.animkey[this.daym_fc1a1a780];
            }
            if (akf != null) {
                if (this.lx != akf.lx || this.ly != akf.ly || this.lz != akf.lz || this.rx != akf.rx || this.ry != akf.ry || this.rz != akf.rz) {
                    tar = 10.0f;
                }
                this.daym_959c15c70 = akf.singleRotation;
                this.daym_e3c338e00 = akf.daym_e3c338e00;
                final float speed = akf.speed * 3.0f;
                final float delta = RenderSetup.deltaValue;
                ++this.daym_a1ec475f0;
                AnimKeyframe akf2 = null;
                if (this.daym_fc1a1a780 > 0) {
                    if (this.daym_70a7d6d00Anim) {
                        if (this.animKeysDebug != null) {
                            akf2 = this.animKeysDebug[this.daym_fc1a1a780 - 1];
                        }
                    }
                    else {
                        akf2 = this.animation.animkey[this.daym_fc1a1a780 - 1];
                    }
                }
                this.lx = this.doAxis("lx", this.lx, akf.lx, akf2, 0.0f, speed, delta);
                this.ly = this.doAxis("ly", this.ly, akf.ly, akf2, 0.0f, speed, delta);
                this.lz = this.doAxis("lz", this.lz, akf.lz, akf2, 0.0f, speed, delta);
                this.timer = this.doAxis("timer", this.timer, tar, null, tar, speed, delta);
                if (this.timer == tar) {
                    if (!akf.repeat && this.daym_0667df810) {
                        if (!this.daym_e037c16b0) {
                            ++this.daym_fc1a1a780;
                        }
                        this.timer = 0.0f;
                    }
                    this.isPlaying = false;
                }
                if (!this.daym_959c15c70) {
                    this.r0 = akf.r0;
                    this.rx = this.doAxis("rx", this.rx, akf.rx, akf2, 0.0f, speed, delta);
                    this.ry = this.doAxis("ry", this.ry, akf.ry, akf2, 0.0f, speed, delta);
                    this.rz = this.doAxis("rz", this.rz, akf.rz, akf2, 0.0f, speed, delta);
                }
                else {
                    this.r0 = this.doAxis("r0", this.r0, akf.r0, akf2, 0.0f, speed, delta);
                }
            }
            else if (this.daym_e037c16b0) {
                this.daym_fc1a1a780 = 0;
                this.timer = 0.0f;
                this.isPlaying = false;
            }
        }
        if (rt == "reset") {
            this.lx = 0.0f;
            this.ly = 0.0f;
            this.lz = 0.0f;
            this.rx = 0.0f;
            this.ry = 0.0f;
            this.rz = 0.0f;
            this.r0 = 0.0f;
            this.isPlaying = false;
        }
        GL11.glTranslatef(this.lx, this.ly, this.lz);
        if (!this.daym_959c15c70) {
            if (this.daym_e3c338e00) {
                GL11.glRotatef(this.rz, 0.0f, 0.0f, 1.0f);
                GL11.glRotatef(this.ry, 0.0f, 1.0f, 0.0f);
                GL11.glRotatef(this.rx, 1.0f, 0.0f, 0.0f);
            }
            else {
                GL11.glRotatef(this.rx, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(this.ry, 0.0f, 1.0f, 0.0f);
                GL11.glRotatef(this.rz, 0.0f, 0.0f, 1.0f);
            }
        }
        else {
            GL11.glRotatef(this.r0, this.rx, this.ry, this.rz);
        }
    }
    
    public float doAxis(final String axStr, final float axis, final float target, final AnimKeyframe akf, final float target3, final float speed, final float delta) {
        boolean sub = false;
        boolean add = false;
        float axis2 = axis;
        float target4 = target;
        if (akf != null) {
            target4 = this.getAxis(axStr, akf);
        }
        if (target4 == 0.0f) {
            target4 += 5.0f;
        }
        if (target3 != 0.0f) {
            target4 = target3;
        }
        if (axis2 > target) {
            if (!add) {
                if (axis2 - this.getPositive(target4) * speed * delta < target) {
                    return target;
                }
                axis2 -= this.getPositive(target4) * speed * delta;
                this.isPlaying = true;
                sub = true;
            }
            else {
                add = false;
            }
        }
        if (axis2 < target) {
            if (!sub) {
                if (axis2 + this.getPositive(target4) * speed * delta > target) {
                    return target;
                }
                axis2 += this.getPositive(target4) * speed * delta;
                this.isPlaying = true;
                add = true;
            }
            else {
                sub = false;
            }
        }
        return axis2;
    }
    
    private float getAxis(final String axStr, final AnimKeyframe akf) {
        float temp = 0.0f;
        if (axStr == "lx") {
            temp = akf.lx;
        }
        if (axStr == "ly") {
            temp = akf.ly;
        }
        if (axStr == "lz") {
            temp = akf.lz;
        }
        if (axStr == "rx") {
            temp = akf.rx;
        }
        if (axStr == "ry") {
            temp = akf.ry;
        }
        if (axStr == "rz") {
            temp = akf.rz;
        }
        if (axStr == "r0") {
            temp = akf.r0;
        }
        return temp;
    }
    
    public float getPositive(final float var) {
        if (var < 0.0f) {
            return -var;
        }
        return var;
    }
}
