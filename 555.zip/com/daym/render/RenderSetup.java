package com.daym.render;

import com.daym.daymobjloader.*;
import com.daym.render.models.*;
import com.daym.*;
import net.minecraft.client.*;
import org.lwjgl.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraftforge.client.event.*;
import com.daym.config.*;
import org.lwjgl.opengl.*;
import com.daym.handlers.*;
import net.minecraft.entity.player.*;
import com.daym.render.entity.*;
import com.daym.gui.inventory.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import com.daym.enums.*;
import net.minecraft.client.renderer.entity.*;
import com.daym.registry.*;
import com.daym.clientproxy.*;
import com.daym.extended.*;
import com.daym.items.*;
import com.daym.inventory.*;
import net.minecraft.client.model.*;
import org.lwjgl.util.glu.*;
import java.util.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.*;
import net.minecraft.client.particle.*;
import net.minecraft.client.gui.*;
import com.daym.tools.*;
import net.minecraft.client.resources.*;

public class RenderSetup
{
    public static DayMGunRender daym_3c8b8d790;
    public DayM_Model daym_32733c920;
    public static DayMGunRender daym_09732d150;
    public static DayMGunRender daym_7636fa700;
    public static DayMGunRender daym_4e230c440;
    public static DayMGunRender daym_7ac4aa4e0;
    public static DayMGunRender daym_86ce1c790;
    public static DayM_Model daym_7636fa700_render;
    public static ModelBiped modelbiped;
    public static ModelBipedDayM daym_52058ee50;
    public static DayM_Model daym_736d8e4e0;
    private AnimationHandler daym_2da23e540;
    private AnimationHandler daym_90be45d10;
    private AnimationHandler daym_36b44b4d0;
    private AnimationHandler daym_843ef91a0;
    private AnimationHandler daym_681d4bc70;
    private AnimationHandler daym_dd45bd2d0;
    private AnimationHandler daym_3abbb09d0;
    private AnimationHandler daym_e69239f30;
    public static AnimationHandler daym_8ff2912f0;
    AnimationHandler[] anims;
    public static String daym_fdec667d0;
    DayM daym;
    static long daym_f54ccc6f0;
    public String daym_b43bb7930;
    private int daym_eed696130;
    private float prevRotationYaw;
    private boolean daym_0c2ff39f0;
    public ArrayList<GunAttachment> daym_1d1fc56a0;
    private float daym_240c5bb60;
    private Minecraft mc;
    public static int daym_658294230;
    public static int daym_150173cf0;
    private static int daym_6b1c3e8e0;
    public static boolean daym_2b3b426c0;
    public static int daym_8a1531e40;
    public static int daym_a5d853260;
    public static boolean daym_a13965e60;
    public static float delta;
    public static float deltaValue;
    public static float mcFov;
    public static float[] lx;
    public static float[] ly;
    public static float[] lz;
    public static float[] r0;
    public static float[] rx;
    public static float[] ry;
    public static float[] rz;
    public static float[] speed;
    public static float[] animSensitivity;
    public static int daym_6b1c3e8e0Debug;
    public static float daym_76fabd190;
    public static ArrayList<Integer> daym_3ce7ac6c0;
    public static ArrayList<String> daym_b73359c80;
    public static boolean daym_1bcc50820;
    public static float partialTicks;
    public static boolean daym_c46b8fa90;
    static RenderBlocks daym_8bad1f340;
    private static float daym_3af4fa140;
    public static DynamicSmoke daym_a169211b0;
    public static int daym_839b70940;
    private static boolean daym_fe702a940;
    public static float daym_669c17750;
    public static int tutorialID;
    
    public RenderSetup(final DayM mod) {
        this.anims = new AnimationHandler[16];
        this.daym_eed696130 = 0;
        this.prevRotationYaw = 0.0f;
        this.daym_1d1fc56a0 = new ArrayList<GunAttachment>();
        this.daym_240c5bb60 = 0.0f;
        this.mc = Minecraft.func_71410_x();
        this.daym = mod;
        AnimationEnum[] animList = new AnimationEnum[8];
        animList[0] = AnimationEnum.ak47_shoot;
        animList[1] = AnimationEnum.ak47_zoom;
        animList[2] = AnimationEnum.ak47_reload;
        this.daym_2da23e540 = new AnimationHandler(animList, true);
        animList = new AnimationEnum[8];
        animList[0] = AnimationEnum.rem700_shoot;
        animList[1] = AnimationEnum.rem700_zoom;
        animList[2] = AnimationEnum.ak47_reload;
        this.daym_90be45d10 = new AnimationHandler(animList, true);
        animList = new AnimationEnum[8];
        animList[0] = AnimationEnum.ak47_shoot;
        animList[1] = AnimationEnum.makarov_zoom;
        animList[2] = AnimationEnum.makarov_reload;
        this.daym_36b44b4d0 = new AnimationHandler(animList, true);
        animList = new AnimationEnum[8];
        animList[0] = AnimationEnum.global_sprint;
        animList[1] = AnimationEnum.global_sprint_handgun;
        this.daym_843ef91a0 = new AnimationHandler(animList, true);
        animList = new AnimationEnum[8];
        animList[0] = AnimationEnum.global_viewgun;
        this.daym_e69239f30 = new AnimationHandler(animList, false);
        animList = new AnimationEnum[8];
        animList[0] = AnimationEnum.ak47_shoot;
        this.daym_681d4bc70 = new AnimationHandler(animList, true);
        animList = new AnimationEnum[] { AnimationEnum.ak47_reload_lh, AnimationEnum.rem700_reload_lh, AnimationEnum.makarov_reload_lh, AnimationEnum.makarov_reload_lh2, null, null, null, null };
        this.daym_dd45bd2d0 = new AnimationHandler(animList, true);
        animList = new AnimationEnum[8];
        animList[0] = AnimationEnum.ak47_reload_rh;
        animList[1] = AnimationEnum.rem700_reload_rh;
        animList[2] = AnimationEnum.reset;
        this.daym_3abbb09d0 = new AnimationHandler(animList, true);
        RenderSetup.daym_8ff2912f0 = new AnimationHandler("special");
        RenderSetup.daym_3c8b8d790 = new DayMGunRender(true, null, 0, new String[] { "gun_ak47", "mag_ak47" });
        this.daym_32733c920 = new DayM_Model("/com/daym/models/guns/ak47_chamber.obj");
        animList = new AnimationEnum[8];
        animList[0] = AnimationEnum.rem700_bolt;
        final AnimationHandler animhandler = new AnimationHandler(animList, false);
        RenderSetup.daym_09732d150 = new DayMGunRender(true, animhandler, 2, new String[] { "remington_700_base", "remington_700_mag", "remington_700_bolt" });
        RenderSetup.daym_7636fa700 = new DayMGunRender(true, null, 0, new String[] { "remington_700_scope" });
        RenderSetup.daym_4e230c440 = new DayMGunRender(true, null, 0, new String[] { "makarov_pm", "makarov_pm_mag", "makarov_pm_slider" });
        RenderSetup.modelbiped = new ModelBiped();
        RenderSetup.daym_52058ee50 = new ModelBipedDayM();
        RenderSetup.daym_7636fa700_render = new DayM_Model("/com/daym/models/guns/scope_zoom.obj");
        RenderSetup.daym_736d8e4e0 = new DayM_Model("/com/daym/models/misc/parachute.obj");
        RenderSetup.speed[0] = 0.001f;
        RenderSetup.speed[1] = 0.001f;
        RenderSetup.speed[2] = 0.001f;
    }
    
    public static void daym_d4b78e250(final int animation) {
        RenderSetup.daym_6b1c3e8e0 = animation;
    }
    
    private AnimationHandler daym_2ce7d3ed0(final String gun) {
        if (gun == "ak47") {
            return this.daym_2da23e540;
        }
        if (gun == "rem700") {
            return this.daym_90be45d10;
        }
        if (gun == "makarov") {
            return this.daym_36b44b4d0;
        }
        return this.daym_2da23e540;
    }
    
    public static long getTime() {
        return Sys.getTime() * 1000L / Sys.getTimerResolution();
    }
    
    public static int setDelta() {
        final long time = getTime();
        final int delta = (int)(time - RenderSetup.daym_f54ccc6f0);
        RenderSetup.daym_f54ccc6f0 = time;
        return delta;
    }
    
    private static void daym_c75419e80(final Minecraft mc) {
        if (RenderSetup.daym_839b70940 > 0) {
            RenderSetup.daym_839b70940 -= (int)(1.0f * RenderSetup.partialTicks);
            RenderSetup.daym_fe702a940 = true;
        }
        else if (RenderSetup.daym_fe702a940) {
            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_Suicide((byte)0));
            mc.field_71439_g.func_70097_a(DamageSource.field_76377_j, 100.0f);
            RenderSetup.daym_fe702a940 = false;
            RenderSetup.daym_839b70940 = 0;
        }
    }
    
    public static void daym_fb4863ec0(final RenderHandEvent event) {
        final Minecraft mc = Minecraft.func_71410_x();
        daym_c75419e80(mc);
        boolean renderZS = false;
        boolean render = false;
        boolean hasGun = false;
        boolean daym_c46b8fa90 = false;
        RenderSetup.partialTicks = event.partialTicks;
        if (mc.field_71439_g != null) {
            if (mc.field_71439_g.field_71071_by.func_70448_g() == null) {
                render = true;
                if (DayMConfig.renderBody) {
                    event.setCanceled(true);
                }
            }
            else {
                if (mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() == ItemRegistry.debugGlobalTools) {
                    renderZS = true;
                }
                if (!ItemRegistry.gunList.contains(mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b())) {
                    if (DayMConfig.renderBody) {
                        event.setCanceled(true);
                    }
                }
                else {
                    hasGun = true;
                    if (((ItemDayMGun)mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b()).daym_c46b8fa90) {
                        daym_c46b8fa90 = true;
                    }
                    if (RenderSetup.daym_a169211b0 == null) {
                        RenderSetup.daym_a169211b0 = new DynamicSmoke(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
                    }
                    else {
                        GL11.glPushMatrix();
                        GL11.glPopMatrix();
                    }
                }
            }
            if (renderZS && event.context != null) {
                final String[] data = WorldHandler.daym_4524cfb60(WorldHandler.daym_5635fd3d0, null);
                if (data != null) {
                    for (final String d : data) {
                        final String[] sd = d.split("\\.");
                        if (sd != null) {
                            try {
                                renderZSTag(mc, sd);
                            }
                            catch (Exception ex) {}
                        }
                    }
                }
                final String[] data2 = WorldHandler.daym_4524cfb60(WorldHandler.daym_24d72dcb0, null);
                if (data2 != null) {
                    for (final String d2 : data2) {
                        final String[] sd2 = d2.split("\\.");
                        if (sd2 != null) {
                            try {
                                renderPLTag(mc, sd2);
                            }
                            catch (Exception ex2) {}
                        }
                    }
                }
                final String[] data3 = WorldHandler.daym_4524cfb60(WorldHandler.daym_28d3f01a0, null);
                if (data3 != null) {
                    for (final String d3 : data3) {
                        final String[] sd3 = d3.split("\\.");
                        if (sd3 != null) {
                            try {
                                renderLSTag(mc, sd3);
                            }
                            catch (Exception ex3) {}
                        }
                    }
                }
            }
            final Render rendertest = RenderManager.field_78727_a.func_78715_a((Class)EntityPlayer.class);
            if (rendertest != null && rendertest instanceof RenderPlayerDayM) {
                final RenderPlayerDayM renderplayer = (RenderPlayerDayM)rendertest;
                final EntityLivingBase living = (EntityLivingBase)mc.field_71439_g;
                renderplayer.field_77109_a.field_78116_c.field_78807_k = false;
                renderplayer.field_77109_a.field_78114_d.field_78807_k = false;
                renderplayer.field_77109_a.field_78112_f.field_78807_k = false;
                renderplayer.field_77109_a.field_78113_g.field_78807_k = false;
                if (mc.field_71474_y.field_74320_O == 0 && mc.field_71439_g.field_70173_aa > 25 && !mc.field_71474_y.field_74319_N && !(mc.field_71462_r instanceof GuiPlayerInventoryDayM) && !(mc.field_71462_r instanceof GuiContainerCreative) && DayMConfig.renderBody) {
                    try {
                        GL11.glPushMatrix();
                        GL11.glScalef(0.8f, 0.8f, 0.8f);
                        if (!living.func_70093_af()) {
                            GL11.glTranslatef(0.0f, -0.05f, 0.0f);
                        }
                        else {
                            GL11.glTranslatef(0.0f, 0.1f, 0.0f);
                        }
                        float var = 0.4f;
                        var = Math.max(var, 0.23f);
                        final float vary = Math.abs((90.0f - mc.field_71439_g.field_70125_A) / 270.0f);
                        GL11.glTranslatef((float)Math.sin(mc.field_71439_g.field_70177_z / 180.0f * 3.1415927f) * var, 0.34f - vary, -(float)Math.cos(mc.field_71439_g.field_70177_z / 180.0f * 3.1415927f) * var);
                        GL11.glScalef(1.0f, 1.35f, 1.0f);
                        if (hasGun && !mc.field_71439_g.func_70051_ag() && !daym_c46b8fa90) {
                            GL11.glRotatef(65.0f, 0.0f, 1.0f, 0.0f);
                        }
                        RenderHelper.func_74518_a();
                        mc.field_71460_t.func_78463_b(0.0);
                        GL11.glTranslatef(-(float)living.field_70165_t, -(float)living.field_70163_u, -(float)living.field_70161_v);
                        final double offsetX = 0.0;
                        final double offsetZ = 0.0;
                        final Block block = mc.field_71441_e.func_147439_a((int)Math.round(living.field_70165_t - 0.7), (int)living.field_70163_u, (int)Math.round(living.field_70161_v - 0.5));
                        int l = 0;
                        l = mc.field_71441_e.func_72802_i((int)Math.round(living.field_70165_t - 0.7), (int)living.field_70163_u, (int)Math.round(living.field_70161_v - 0.5), 0);
                        final int l2 = l % 65536;
                        final int l3 = l / 65536;
                        OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, (float)l2, (float)l3);
                        renderplayer.func_76986_a(living, (double)(float)living.field_70165_t, (double)(float)living.field_70163_u, (double)(float)living.field_70161_v, 0.0f, event.partialTicks);
                        mc.field_71460_t.func_78483_a(0.0);
                        GL11.glPopMatrix();
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
    
    public void daym_94e38d0a0(final String gun, final ItemStack is, final RenderItemDayM renderItem) {
        if (RenderSetup.daym_fdec667d0 != "") {
            final Item test = ItemRegistry.getByUnlocname(RenderSetup.daym_fdec667d0);
            if (test instanceof ItemDayMGun) {
                RenderSetup.daym_c46b8fa90 = ((ItemDayMGun)test).daym_c46b8fa90;
                this.daym_0c2ff39f0 = ((ItemDayMGun)test).daym_0c2ff39f0;
            }
        }
        GL11.glPushMatrix();
        this.daym_3ac7bf540();
        this.daym_3d1e07830(gun);
        this.daym_c292044e0(gun);
        this.daym_9db96d540(is, renderItem);
        this.daym_77c289620(gun, is, renderItem);
        this.daym_9d79209a0();
        GL11.glPopMatrix();
        GL11.glPopMatrix();
    }
    
    private void daym_9d79209a0() {
        ItemStack myGun = null;
        if (Minecraft.func_71410_x().field_71439_g != null && Minecraft.func_71410_x().field_71439_g.field_71071_by.func_70448_g() != null) {
            myGun = Minecraft.func_71410_x().field_71439_g.field_71071_by.func_70448_g();
        }
        final ArrayList<GunAttachment> list = ItemDayMGun.getAttachments(myGun);
        if (list != null && !list.isEmpty()) {
            this.daym_1d1fc56a0 = list;
        }
        if (myGun != null) {
            final int c = ItemDayMGun.getCamo(myGun);
            if (c > -1) {
                RenderSetup.daym_150173cf0 = c;
            }
        }
        if (myGun != null) {
            for (final GunAttachment ga : this.daym_1d1fc56a0) {
                if (ga != null && ga.id != -1) {
                    GL11.glPushMatrix();
                    GL11.glTranslatef(ga.x, ga.y, ga.z);
                    if (ga.id != 1) {
                        ModelRegistry.gunAttachments[ga.id].renderTextured(TextureRegistry.gunAttachments[ga.id]);
                    }
                    else {
                        this.defaultRenderLoc();
                        GL11.glTranslatef(-0.1f, 0.22f, -0.3f);
                        RenderSetup.daym_7636fa700.render(0);
                        GL11.glTranslatef(-0.0f, 0.0f, 0.05f);
                        RenderSetup.daym_7636fa700_render.renderTextured(TextureRegistry.render_scope);
                    }
                    if (ga.doesOffset) {
                        this.daym_240c5bb60 = ga.z;
                    }
                    GL11.glPopMatrix();
                }
            }
        }
    }
    
    private void daym_3ac7bf540() {
        GL11.glTranslatef(0.0f, 0.0f, -1.2f);
        GL11.glRotatef(1.8f, 0.0f, 0.0f, 1.0f);
        final DayMConfig daym_748d583f0 = DayM.daym_748d583f0;
        if (!DayMConfig.daym_8fd972390) {
            GL11.glTranslatef(0.0f, -0.35f, 0.2f);
        }
        if (RenderSetup.daym_c46b8fa90) {
            GL11.glTranslatef(0.0f, 0.0f, -0.7f);
        }
        if (Minecraft.func_71410_x().field_71439_g != null) {
            final EntityPlayer player = (EntityPlayer)Minecraft.func_71410_x().field_71439_g;
            float rp = player.field_70125_A;
            float ry1 = 0.0f;
            if (this.prevRotationYaw != player.field_70177_z) {
                ry1 = this.prevRotationYaw - player.field_70177_z;
                this.prevRotationYaw = player.field_70177_z;
            }
            if (rp < 0.0f) {
                rp = 0.0f;
            }
            if (player.func_70051_ag()) {
                RenderSetup.daym_76fabd190 = -(rp / 80.0f);
                if (RenderSetup.daym_c46b8fa90) {
                    RenderSetup.daym_76fabd190 = -(rp / 140.0f);
                    GL11.glTranslatef(-RenderSetup.daym_76fabd190 / 2.0f, RenderSetup.daym_76fabd190 / 4.0f, RenderSetup.daym_76fabd190 * 1.2f);
                    GL11.glRotatef(RenderSetup.daym_76fabd190 * 35.0f, 5.0f, 0.0f, 10.0f);
                }
                else {
                    GL11.glTranslatef(-RenderSetup.daym_76fabd190, RenderSetup.daym_76fabd190, RenderSetup.daym_76fabd190 * 2.2f);
                    GL11.glRotatef(RenderSetup.daym_76fabd190 * 25.0f, 0.0f, 1.0f, -1.5f);
                }
            }
        }
        GL11.glTranslatef(0.0f, this.daym_240c5bb60 / 6.0f, 0.0f);
    }
    
    private void daym_c292044e0(final String gun) {
        if (gun == "rem700") {
            this.renderZoomer();
        }
    }
    
    private void daym_77c289620(final String gun, final ItemStack is, final RenderItemDayM renderItem) {
        final float fov = (1.2222222f - Minecraft.func_71410_x().field_71474_y.field_74334_X / 90.0f) / 3.5f;
        GL11.glDisable(2896);
        DayMGunRender dgr = RenderSetup.daym_3c8b8d790;
        RenderSetup.daym_86ce1c790 = null;
        final GunStatEnum gstat = GunStatEnum.getStatFromGun(RenderSetup.daym_fdec667d0);
        final ReloadEnum re = gstat.reloadStat;
        final int tt2 = re.target1;
        final int tt3 = re.target2;
        final int tt3o = re.target2_delay;
        final int tt4 = re.target3;
        final int tt5 = re.target6;
        final int tt6 = re.target7;
        if (gun == "ak47") {
            final DayMConfig daym_748d583f0 = DayM.daym_748d583f0;
            if (DayMConfig.daym_8fd972390) {
                RenderSetup.daym_7ac4aa4e0 = dgr;
                this.defaultRenderLoc();
                dgr.render(0);
                dgr.currentCamo = RenderSetup.daym_150173cf0;
                RenderSetup.daym_86ce1c790 = dgr;
                if (gun != "" && RenderSetup.daym_86ce1c790 != null && !RenderSetup.daym_1bcc50820) {
                    if (RenderSetup.daym_8a1531e40 != 3) {
                        if (RenderSetup.daym_a5d853260 < tt2 || RenderSetup.daym_a5d853260 > tt4 + tt4 / 2) {
                            this.renderCurrentMag(false, null, null, null);
                        }
                    }
                    else if (RenderSetup.daym_a5d853260 < tt2) {
                        this.renderCurrentMag(false, null, null, null);
                    }
                }
                if (RenderSetup.daym_a5d853260 < tt5 || RenderSetup.daym_a5d853260 > tt6) {
                    this.daym_32733c920.renderTextured(dgr.curtexture);
                }
            }
            else if (is.func_77973_b() instanceof ItemDayMGun) {
                final ItemDayMGun daymgun = (ItemDayMGun)is.func_77973_b();
                final ItemStack is2 = new ItemStack((Item)daymgun.daym_511e1e650);
                GL11.glPushMatrix();
                GL11.glPushMatrix();
                RenderSetup.daym_86ce1c790 = RenderSetup.daym_3c8b8d790;
                if (gun != "" && RenderSetup.daym_86ce1c790 != null && !RenderSetup.daym_1bcc50820) {
                    if (RenderSetup.daym_8a1531e40 != 3) {
                        if (RenderSetup.daym_a5d853260 < tt2 || RenderSetup.daym_a5d853260 > tt4 + tt4 / 2) {
                            this.renderCurrentMag(false, renderItem, is, is2);
                        }
                    }
                    else if (RenderSetup.daym_a5d853260 < tt2) {
                        this.renderCurrentMag(false, renderItem, is, is2);
                    }
                }
                GL11.glPopMatrix();
                GL11.glPushMatrix();
                GL11.glScalef(8.0f, 7.0f, 5.0f);
                GL11.glRotatef(181.0f, 0.0f, 1.0f, 0.0f);
                GL11.glRotatef(5.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
                GL11.glTranslatef(-0.55f, -0.07f, -0.55f);
                GL11.glDisable(2896);
                ItemRendererHook.renderDroppedItem(renderItem, is, is.func_77954_c(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0, 1.0f, 1.0f, 1.0f);
                GL11.glPopMatrix();
                GL11.glPopMatrix();
            }
            if (RenderSetup.daym_a13965e60) {
                this.renderMuzzleFlash();
            }
        }
        dgr = RenderSetup.daym_09732d150;
        if (gun == "rem700") {
            final DayMConfig daym_748d583f2 = DayM.daym_748d583f0;
            if (DayMConfig.daym_8fd972390) {
                RenderSetup.daym_7ac4aa4e0 = dgr;
                GL11.glPushMatrix();
                this.defaultRenderLoc();
                GL11.glTranslatef(-0.1f, 0.22f, -0.3f);
                dgr.render(0);
                dgr.currentCamo = RenderSetup.daym_150173cf0;
                RenderSetup.daym_86ce1c790 = dgr;
                if (gun != "" && RenderSetup.daym_86ce1c790 != null && !RenderSetup.daym_1bcc50820) {
                    if (RenderSetup.daym_8a1531e40 != 3) {
                        if (RenderSetup.daym_a5d853260 < tt2 || RenderSetup.daym_a5d853260 > tt4 + tt4 / 2) {
                            this.renderCurrentMag(false, null, null, null);
                        }
                    }
                    else if (RenderSetup.daym_a5d853260 < tt2) {
                        this.renderCurrentMag(false, null, null, null);
                    }
                }
                if (RenderSetup.daym_a5d853260 > tt5 - tt3o * 3 && dgr.subAnimation != null) {
                    if (!dgr.subAnimation.isUsingAnimation(0)) {
                        dgr.subAnimation.setAnimation(0);
                        dgr.subAnimation.daym_0667df810 = true;
                    }
                    dgr.subAnimation.setAnimationFrame(0);
                }
                if (RenderSetup.daym_a5d853260 > tt6 - tt3o && dgr.subAnimation != null) {
                    dgr.subAnimation.setAnimationFrame(1);
                }
                GL11.glPushMatrix();
                dgr.render(2);
                GL11.glPopMatrix();
                GL11.glPopMatrix();
            }
            else if (is.func_77973_b() instanceof ItemDayMGun) {
                final ItemDayMGun daymgun = (ItemDayMGun)is.func_77973_b();
                final ItemStack is2 = new ItemStack((Item)daymgun.daym_511e1e650);
                GL11.glPushMatrix();
                GL11.glPushMatrix();
                GL11.glTranslatef(-0.7f, 0.0f, 0.0f);
                RenderSetup.daym_86ce1c790 = RenderSetup.daym_3c8b8d790;
                if (gun != "" && RenderSetup.daym_86ce1c790 != null && !RenderSetup.daym_1bcc50820) {
                    if (RenderSetup.daym_8a1531e40 != 3) {
                        if (RenderSetup.daym_a5d853260 < tt2 || RenderSetup.daym_a5d853260 > tt4 + tt4 / 2) {
                            this.renderCurrentMag(false, renderItem, is, is2);
                        }
                    }
                    else if (RenderSetup.daym_a5d853260 < tt2) {
                        this.renderCurrentMag(false, renderItem, is, is2);
                    }
                }
                GL11.glPopMatrix();
                GL11.glPushMatrix();
                GL11.glScalef(8.0f, 7.0f, 5.0f);
                GL11.glRotatef(181.0f, 0.0f, 1.0f, 0.0f);
                GL11.glRotatef(5.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
                GL11.glTranslatef(-0.55f, -0.07f, -0.55f);
                GL11.glDisable(2896);
                ItemRendererHook.renderDroppedItem(renderItem, is, is.func_77954_c(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0, 1.0f, 1.0f, 1.0f);
                GL11.glPopMatrix();
                GL11.glPopMatrix();
            }
            if (RenderSetup.daym_658294230 > 0) {
                --RenderSetup.daym_658294230;
            }
        }
        dgr = RenderSetup.daym_4e230c440;
        if (gun == "makarov") {
            final DayMConfig daym_748d583f3 = DayM.daym_748d583f0;
            if (DayMConfig.daym_8fd972390) {
                RenderSetup.daym_7ac4aa4e0 = dgr;
                GL11.glPushMatrix();
                this.defaultRenderLoc();
                GL11.glTranslatef(0.25f, -0.18f, 0.1f);
                GL11.glTranslatef(-0.1f, 0.0f, 1.25f);
                GL11.glScalef(1.2f, 1.2f, 1.2f);
                dgr.currentCamo = RenderSetup.daym_150173cf0;
                dgr.render(0);
                RenderSetup.daym_86ce1c790 = dgr;
                if (gun != "" && RenderSetup.daym_86ce1c790 != null && !RenderSetup.daym_1bcc50820) {
                    if (RenderSetup.daym_8a1531e40 != 3) {
                        if (RenderSetup.daym_a5d853260 < tt2 || RenderSetup.daym_a5d853260 > tt4 + tt4 / 2) {
                            this.renderCurrentMag(false, null, null, null);
                        }
                    }
                    else if (RenderSetup.daym_a5d853260 < tt2) {
                        this.renderCurrentMag(false, null, null, null);
                    }
                }
                boolean lis = RenderSetup.daym_a13965e60;
                if (Minecraft.func_71410_x().field_71439_g != null && Minecraft.func_71410_x().field_71439_g.field_71071_by.func_70448_g() != null) {
                    final ItemStack cii = Minecraft.func_71410_x().field_71439_g.field_71071_by.func_70448_g();
                    if (cii.func_77973_b() instanceof ItemDayMGun && !ItemDayMGun.hasMagazine(cii) && !ItemDayMGun.isChambered(cii)) {
                        lis = true;
                    }
                }
                if ((lis || RenderSetup.daym_8a1531e40 == 1) && RenderSetup.daym_8a1531e40 != -1) {
                    GL11.glTranslatef(0.25f, 0.0f, 0.0f);
                }
                dgr.render(2);
                GL11.glPopMatrix();
            }
            else if (is.func_77973_b() instanceof ItemDayMGun) {
                final ItemDayMGun daymgun = (ItemDayMGun)is.func_77973_b();
                final ItemStack is2 = new ItemStack((Item)daymgun.daym_511e1e650);
                GL11.glPushMatrix();
                GL11.glScalef(0.5f, 0.5f, 1.0f);
                GL11.glPushMatrix();
                RenderSetup.daym_86ce1c790 = RenderSetup.daym_3c8b8d790;
                if (gun != "" && RenderSetup.daym_86ce1c790 != null && !RenderSetup.daym_1bcc50820) {
                    if (RenderSetup.daym_8a1531e40 != 3) {
                        if (RenderSetup.daym_a5d853260 < tt2 || RenderSetup.daym_a5d853260 > tt4 + tt4 / 2) {
                            this.renderCurrentMag(false, renderItem, is, is2);
                        }
                    }
                    else if (RenderSetup.daym_a5d853260 < tt2) {
                        this.renderCurrentMag(false, renderItem, is, is2);
                    }
                }
                GL11.glPopMatrix();
                GL11.glPushMatrix();
                GL11.glScalef(8.0f, 7.0f, 5.0f);
                GL11.glRotatef(181.0f, 0.0f, 1.0f, 0.0f);
                GL11.glRotatef(5.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
                GL11.glTranslatef(-0.8f, -0.16f, -0.6f);
                GL11.glDisable(2896);
                ItemRendererHook.renderDroppedItem(renderItem, is, is.func_77954_c(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0, 1.0f, 1.0f, 1.0f);
                GL11.glPopMatrix();
                GL11.glPopMatrix();
            }
            if (RenderSetup.daym_658294230 > 0) {
                --RenderSetup.daym_658294230;
            }
        }
        GL11.glEnable(2896);
    }
    
    private void renderMuzzleFlash() {
        GL11.glPushMatrix();
        GL11.glDisable(2896);
        OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, 240.0f, 240.0f);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        RenderHelper.func_74518_a();
        GL11.glScalef(2.0f, 2.0f, 2.0f);
        GL11.glTranslatef(2.5f, 0.0f, 3.53f);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
        ModelRegistry.muzzleflash.renderTextured(TextureRegistry.muzzleflash);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.75f);
        ModelRegistry.front_muzzleflash.renderTextured(TextureRegistry.front_muzzleflash);
        GL11.glDisable(3042);
        RenderHelper.func_74519_b();
        GL11.glPopMatrix();
    }
    
    private void renderMagPixelated(final RenderItem renderItem, final ItemStack is, final ItemStack is2) {
        GL11.glPushMatrix();
        GL11.glScalef(0.25f, 0.25f, 0.9f);
        GL11.glTranslatef(-0.3f, -0.5f, 0.0f);
        ItemRendererHook.renderDroppedItem(renderItem, is2, is2.func_77954_c(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    private void daym_9db96d540(final ItemStack is, final RenderItemDayM renderItem) {
        ItemDayMGun daymgun = null;
        ItemStack is2 = null;
        if (is != null && is.func_77973_b() instanceof ItemDayMGun) {
            daymgun = (ItemDayMGun)is.func_77973_b();
            is2 = new ItemStack((Item)daymgun.daym_511e1e650);
        }
        final RenderPlayer renderplayer = (RenderPlayer)RenderManager.field_78727_a.func_78715_a((Class)EntityPlayer.class);
        if (renderplayer != null && Minecraft.func_71410_x().field_71439_g != null) {
            GL11.glPushMatrix();
            GL11.glTranslatef(RenderSetup.lx[1], RenderSetup.ly[1], RenderSetup.lz[1]);
            GL11.glRotatef(RenderSetup.rx[1], 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(RenderSetup.ry[1], 0.0f, 1.0f, 0.0f);
            GL11.glRotatef(RenderSetup.rz[1], 0.0f, 0.0f, 1.0f);
            final GunStatEnum gstat = GunStatEnum.getStatFromGun(RenderSetup.daym_fdec667d0);
            final ReloadEnum re = gstat.reloadStat;
            final int tt1 = re.target0;
            final int tt2 = re.target1;
            final int tt3 = re.target2;
            final int tt3o = re.target2_delay;
            final int tt4 = re.target3;
            final int tt5 = re.target4;
            final int tt6 = re.target5;
            final int tt7 = re.target6;
            final int tt8 = re.target7;
            int animID = 0;
            if (RenderSetup.daym_fdec667d0.contains("ak47")) {
                animID = 0;
            }
            if (RenderSetup.daym_fdec667d0.contains("rem700")) {
                animID = 1;
            }
            if (RenderSetup.daym_fdec667d0.contains("makarov")) {
                if (RenderSetup.daym_a5d853260 > tt4) {
                    animID = 3;
                }
                else {
                    animID = 2;
                }
            }
            if (!this.daym_dd45bd2d0.isUsingAnimation(animID)) {
                this.daym_dd45bd2d0.setAnimation(animID);
                this.daym_dd45bd2d0.setAnimationFrame(0);
            }
            if (RenderSetup.daym_8a1531e40 == 0) {
                if (RenderSetup.daym_a5d853260 > tt1 && RenderSetup.daym_a5d853260 < tt2) {
                    this.daym_dd45bd2d0.setAnimationFrame(0);
                }
                if (RenderSetup.daym_a5d853260 > tt2 && RenderSetup.daym_a5d853260 < tt3) {
                    this.daym_dd45bd2d0.setAnimationFrame(1);
                }
                if (RenderSetup.daym_a5d853260 > tt3 + tt3o && RenderSetup.daym_a5d853260 < tt4) {
                    this.daym_dd45bd2d0.setAnimationFrame(2);
                }
            }
            if (RenderSetup.daym_8a1531e40 == 2) {
                if (RenderSetup.daym_a5d853260 > tt1 && RenderSetup.daym_a5d853260 < tt2) {
                    this.daym_dd45bd2d0.setAnimationFrame(1);
                }
                if (RenderSetup.daym_a5d853260 > tt2 && RenderSetup.daym_a5d853260 < tt3) {
                    this.daym_dd45bd2d0.setAnimationFrame(1);
                }
                if (RenderSetup.daym_a5d853260 > tt3 + tt3o && RenderSetup.daym_a5d853260 < tt4) {
                    this.daym_dd45bd2d0.setAnimationFrame(2);
                }
            }
            if (RenderSetup.daym_8a1531e40 == 1 && RenderSetup.daym_c46b8fa90) {
                if (RenderSetup.daym_a5d853260 > tt4 && RenderSetup.daym_a5d853260 < tt5) {
                    this.daym_dd45bd2d0.setAnimationFrame(0);
                }
                if (RenderSetup.daym_a5d853260 > tt5 && RenderSetup.daym_a5d853260 < tt6) {
                    this.daym_dd45bd2d0.setAnimationFrame(1);
                }
                if (RenderSetup.daym_a5d853260 > tt6 && RenderSetup.daym_a5d853260 < tt7) {
                    this.daym_dd45bd2d0.setAnimationFrame(2);
                }
                if (RenderSetup.daym_a5d853260 > tt7 && RenderSetup.daym_a5d853260 < tt8) {
                    this.daym_dd45bd2d0.setAnimationFrame(3);
                }
            }
            if (RenderSetup.daym_8a1531e40 == 3) {
                if (RenderSetup.daym_a5d853260 > tt1 && RenderSetup.daym_a5d853260 < tt2) {
                    this.daym_dd45bd2d0.setAnimationFrame(0);
                }
                if (RenderSetup.daym_a5d853260 > tt2 && RenderSetup.daym_a5d853260 < tt3) {
                    this.daym_dd45bd2d0.setAnimationFrame(1);
                }
                if (RenderSetup.daym_a5d853260 > tt3 + tt3o * 3) {
                    this.daym_dd45bd2d0.setAnimationFrame(3);
                }
            }
            if (RenderSetup.daym_8a1531e40 == -1) {
                this.daym_dd45bd2d0.setAnimationFrame(3);
            }
            this.daym_dd45bd2d0.doAnimation("");
            this.renderLeftHand(renderplayer);
            if (RenderSetup.daym_8a1531e40 != -1) {
                final DayMConfig daym_748d583f0 = DayM.daym_748d583f0;
                if (DayMConfig.daym_8fd972390) {
                    this.defaultRenderLoc();
                }
                else {
                    GL11.glTranslatef(2.2f, 1.1f, 0.6f);
                }
                if (RenderSetup.daym_c46b8fa90) {
                    GL11.glTranslatef(1.24f, -0.15f, 0.7f);
                }
                if (RenderSetup.daym_8a1531e40 != 2 && RenderSetup.daym_8a1531e40 != 3 && RenderSetup.daym_a5d853260 >= tt2 && RenderSetup.daym_a5d853260 < tt4 + tt4 / 2) {
                    GL11.glTranslatef(-1.24f, -0.05f, -0.6f);
                    this.renderCurrentMag(true, renderItem, is, is2);
                }
                if (RenderSetup.daym_8a1531e40 == 2 && RenderSetup.daym_a5d853260 >= tt3 && RenderSetup.daym_a5d853260 < tt4 + tt4 / 2) {
                    GL11.glTranslatef(-1.24f, -0.05f, -0.6f);
                    this.renderCurrentMag(true, renderItem, is, is2);
                }
                if (RenderSetup.daym_8a1531e40 == 3 && RenderSetup.daym_a5d853260 >= tt2 && RenderSetup.daym_a5d853260 < tt3 + tt3o * 2.5) {
                    GL11.glTranslatef(-1.24f, -0.05f, -0.6f);
                    if (!RenderSetup.daym_1bcc50820) {
                        this.renderCurrentMag(true, renderItem, is, is2);
                    }
                }
            }
            GL11.glPopMatrix();
            GL11.glPushMatrix();
            GL11.glTranslatef(RenderSetup.lx[2], RenderSetup.ly[2], RenderSetup.lz[2]);
            GL11.glRotatef(RenderSetup.rx[2], 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(RenderSetup.ry[2], 0.0f, 1.0f, 0.0f);
            GL11.glRotatef(RenderSetup.rz[2], 0.0f, 0.0f, 1.0f);
            if (!RenderSetup.daym_c46b8fa90) {
                if (!this.daym_3abbb09d0.isUsingAnimation(animID)) {
                    this.daym_3abbb09d0.setAnimation(animID);
                    this.daym_3abbb09d0.setAnimationFrame(animID);
                }
                if (RenderSetup.daym_8a1531e40 == 1) {
                    final int rtt1 = re.target4;
                    final int rtt2 = re.target5;
                    final int rtt3 = re.target6;
                    final int rtt4 = re.target7;
                    if (RenderSetup.daym_a5d853260 > rtt1 && RenderSetup.daym_a5d853260 < rtt2) {
                        this.daym_3abbb09d0.setAnimationFrame(0);
                    }
                    if (RenderSetup.daym_a5d853260 > rtt2 && RenderSetup.daym_a5d853260 < rtt3) {
                        this.daym_3abbb09d0.setAnimationFrame(1);
                    }
                    if (RenderSetup.daym_a5d853260 > rtt3 && RenderSetup.daym_a5d853260 < rtt4) {
                        this.daym_3abbb09d0.setAnimationFrame(2);
                    }
                }
                if (RenderSetup.daym_8a1531e40 == -1) {
                    this.daym_3abbb09d0.setAnimationFrame(3);
                }
                this.daym_3abbb09d0.doAnimation("");
            }
            this.renderRightHand(renderplayer);
            GL11.glRotatef(90.0f, -0.8f, 1.9f, 0.0f);
            GL11.glTranslatef(-1.5f, -0.5f, -3.0f);
            GL11.glRotatef(45.0f, -1.0f, 1.0f, 0.0f);
            GL11.glTranslatef(-2.6f, -1.09f, -1.67f);
            GL11.glRotatef(10.0f, 5.0f, 2.0f, 1.0f);
            GL11.glRotatef(15.0f, 0.0f, 1.0f, 0.0f);
            GL11.glScalef(1.0f, 1.0f, 0.935f);
            GL11.glRotatef(5.0f, -1.0f, 1.0f, 1.0f);
            this.renderRightHand(renderplayer);
            GL11.glPopMatrix();
        }
    }
    
    private void renderCurrentMag(final boolean bypass, final RenderItemDayM renderItem, final ItemStack is, final ItemStack is2) {
        GL11.glDisable(2896);
        if (Minecraft.func_71410_x().field_71439_g != null && Minecraft.func_71410_x().field_71439_g.field_71071_by.func_70448_g() != null) {
            final ItemStack cii = Minecraft.func_71410_x().field_71439_g.field_71071_by.func_70448_g();
            if (ItemRegistry.gunList.contains(cii.func_77973_b()) && cii.field_77990_d != null && (cii.field_77990_d.func_74767_n("hasMagazine") || bypass)) {
                final DayMConfig daym_748d583f0 = DayM.daym_748d583f0;
                if (DayMConfig.daym_8fd972390) {
                    if (RenderSetup.daym_86ce1c790 != null) {
                        RenderSetup.daym_86ce1c790.render(1);
                    }
                }
                else if (is2 != null && renderItem != null) {
                    GL11.glScalef(8.0f, 7.0f, 5.0f);
                    GL11.glRotatef(181.0f, 0.0f, 1.0f, 0.0f);
                    GL11.glRotatef(5.0f, 1.0f, 0.0f, 0.0f);
                    GL11.glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
                    GL11.glTranslatef(-0.55f, -0.07f, -0.55f);
                    this.renderMagPixelated(renderItem, is, is2);
                }
            }
        }
        GL11.glEnable(2896);
    }
    
    private void daym_3d1e07830(final String gun) {
        final Minecraft mc = Minecraft.func_71410_x();
        GL11.glPushMatrix();
        this.anims[0] = this.getAnimationGlobal("global");
        this.anims[1] = this.daym_2ce7d3ed0(gun);
        (this.anims[2] = this.daym_681d4bc70).setAnimationFrame(1);
        boolean sprinting = false;
        final float zoomAm = 50.0f;
        if (KeybindRegistry.keypressed[2]) {
            if (!this.daym_e69239f30.isUsingAnimation(0)) {
                this.daym_e69239f30.setAnimation(0);
                this.daym_e69239f30.setAnimationFrame(0);
            }
        }
        else {
            this.daym_e69239f30.setAnimationFrame(3);
        }
        if (mc.field_71439_g != null) {
            int varihg = 0;
            if (RenderSetup.daym_c46b8fa90) {
                varihg = 1;
            }
            if (!this.anims[0].isUsingAnimation(varihg)) {
                this.anims[0].setAnimation(varihg);
            }
            if (mc.field_71439_g.func_70051_ag() && RenderSetup.daym_8a1531e40 == -1) {
                this.anims[0].setAnimationFrame(0);
                RenderSetup.daym_2b3b426c0 = false;
                sprinting = true;
            }
            else {
                this.anims[0].setAnimationFrame(1);
            }
        }
        if (RenderSetup.daym_8a1531e40 == -1 || this.daym_0c2ff39f0) {
            if (RenderSetup.daym_2b3b426c0) {
                if (!this.anims[1].isUsingAnimation(1)) {
                    this.anims[1].setAnimation(1);
                }
                this.anims[1].setAnimationFrame(0);
            }
            else if (this.anims[1].isUsingAnimation(1)) {
                this.anims[1].setAnimationFrame(1);
            }
            if (!sprinting) {
                if (RenderSetup.daym_a13965e60) {
                    this.anims[2].setAnimation(0);
                    this.anims[2].setAnimationFrame(0);
                }
                else if (this.anims[2].isUsingAnimation(0)) {
                    this.anims[2].setAnimationFrame(1);
                }
            }
        }
        else if (!this.anims[1].isUsingAnimation(2)) {
            this.anims[1].setAnimation(2);
            this.anims[1].setAnimationFrame(0);
            this.anims[1].daym_0667df810 = false;
        }
        if (this.anims[1].isUsingAnimation(2)) {
            if (RenderSetup.daym_8a1531e40 != -1) {
                if (RenderSetup.daym_8a1531e40 != 2 && RenderSetup.daym_8a1531e40 != 3) {
                    this.anims[1].setAnimationFrame(RenderSetup.daym_8a1531e40);
                }
                else {
                    this.anims[1].setAnimationFrame(0);
                }
                this.anims[1].daym_0667df810 = false;
            }
            else {
                this.anims[1].setAnimationFrame(2);
                this.anims[1].daym_0667df810 = true;
            }
        }
        this.anims[0].doAnimation("");
        this.anims[1].doAnimation("");
        this.anims[2].doAnimation("");
        RenderSetup.daym_8ff2912f0.doAnimation("");
        this.daym_e69239f30.doAnimation("");
        GL11.glTranslatef(RenderSetup.lx[0], RenderSetup.ly[0], RenderSetup.lz[0]);
        GL11.glRotatef(RenderSetup.rx[0], 1.0f, 0.0f, 0.0f);
        GL11.glRotatef(RenderSetup.ry[0], 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(RenderSetup.rz[0], 0.0f, 0.0f, 1.0f);
    }
    
    private AnimationHandler getAnimationGlobal(final String str) {
        if (str == "global") {
            return this.daym_843ef91a0;
        }
        return null;
    }
    
    public static void renderGunTP(final ItemStack phis, final String gun, final RenderPlayerDayM renderplayer, final EntityPlayer player) {
        DayMGunRender dgr = RenderSetup.daym_3c8b8d790;
        if (gun.contains("ak47")) {
            GL11.glPushMatrix();
            defaultRenderLocTP();
            dgr.currentCamo = ItemDayMGun.getCamo(phis);
            dgr.render(0);
            if (ItemDayMGun.hasMagazine(phis)) {
                dgr.render(1);
            }
            if (player == ClientProxy.daym_baccf3380.mc.field_71439_g && RenderSetup.daym_a13965e60) {
                GL11.glPushMatrix();
                GL11.glDisable(2896);
                OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, 240.0f, 240.0f);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                RenderHelper.func_74518_a();
                GL11.glScalef(2.0f, 2.0f, 2.0f);
                GL11.glTranslatef(2.5f, 0.0f, 3.53f);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
                ModelRegistry.muzzleflash.renderTextured(TextureRegistry.muzzleflash);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.4f);
                ModelRegistry.front_muzzleflash.renderTextured(TextureRegistry.front_muzzleflash);
                GL11.glDisable(3042);
                GL11.glPopMatrix();
            }
            GL11.glPopMatrix();
            GL11.glPopMatrix();
        }
        dgr = RenderSetup.daym_09732d150;
        if (gun.contains("rem700")) {
            GL11.glPushMatrix();
            defaultRenderLocTP();
            dgr.currentCamo = ItemDayMGun.getCamo(phis);
            dgr.render(0);
            if (ItemDayMGun.hasMagazine(phis)) {
                dgr.render(1);
            }
            dgr.render(2);
            GL11.glPopMatrix();
            GL11.glPopMatrix();
        }
        dgr = RenderSetup.daym_4e230c440;
        if (gun.contains("makarov")) {
            GL11.glPushMatrix();
            defaultRenderLocTP();
            GL11.glTranslatef(0.35f, 0.5f, 0.0f);
            GL11.glRotatef(20.0f, 0.0f, 0.0f, 1.0f);
            GL11.glTranslatef(0.0f, 0.0f, 1.25f);
            GL11.glScalef(1.2f, 1.2f, 1.2f);
            dgr.currentCamo = ItemDayMGun.getCamo(phis);
            dgr.render(0);
            dgr.render(1);
            dgr.render(2);
            GL11.glPopMatrix();
            GL11.glPopMatrix();
        }
    }
    
    private static void defaultRenderLocTP() {
        GL11.glScalef(0.59f, 0.59f, 0.59f);
        GL11.glTranslatef(-2.1f, -6.1f, 1.75f);
        GL11.glPushMatrix();
        GL11.glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(110.0f, 1.0f, 0.0f, 0.0f);
        GL11.glRotatef(-65.0f, 0.0f, 0.0f, 1.0f);
        GL11.glRotatef(6.0f, 0.0f, 1.0f, 0.0f);
        GL11.glScalef(0.8f, 0.8f, 0.8f);
        GL11.glTranslatef(0.7f, 0.04f, -1.45f);
    }
    
    private void renderLeftHand(final RenderPlayer renderplayer) {
        GL11.glPushMatrix();
        GL11.glScalef(4.0f, 4.0f, 4.0f);
        GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
        GL11.glTranslatef(1.0f, 0.0f, 0.0f);
        GL11.glRotatef(20.0f, 0.0f, 1.0f, 0.0f);
        GL11.glScalef(2.0f, 1.0f, 1.0f);
        GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        GL11.glPushMatrix();
        GL11.glRotatef(35.0f, 0.0f, 0.0f, 0.0f);
        GL11.glRotatef(-63.0f, 0.0f, 1.0f, 0.0f);
        GL11.glTranslatef(0.54f, 0.14f, 0.15f);
        GL11.glScalef(2.0f, 0.9f, 0.9f);
        GL11.glRotatef(20.0f, 1.0f, 0.0f, 1.0f);
        if (RenderSetup.daym_c46b8fa90) {
            GL11.glRotatef(-20.0f, 1.0f, 0.0f, 1.0f);
            GL11.glRotatef(-15.0f, 0.0f, 1.0f, 0.0f);
            GL11.glTranslatef(-0.13f, -0.165f, 0.52f);
        }
        TextureRegistry.bindResource(TextureRegistry.handleSkin(DayMConfig.daym_d836addc0, DayMConfig.daym_8eb8ec9d0));
        RenderSetup.modelbiped.field_78112_f.func_78785_a(0.0625f);
        if (Minecraft.func_71410_x().field_71439_g != null) {
            final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get((EntityPlayer)Minecraft.func_71410_x().field_71439_g).inventory;
            if (inventorydaym != null && inventorydaym.inventory[1] != null && inventorydaym.inventory[1].func_77973_b() instanceof ItemClothing) {
                GL11.glPushMatrix();
                final ItemClothing ic = (ItemClothing)inventorydaym.inventory[1].func_77973_b();
                TextureRegistry.bindResource(TextureRegistry.c_shirt[ic.clothingID]);
                RenderSetup.modelbiped.field_78112_f.func_78785_a(0.0625f);
                GL11.glPopMatrix();
            }
            if (inventorydaym != null && inventorydaym.inventory[7] != null && inventorydaym.inventory[7].func_77973_b() instanceof ItemClothing) {
                GL11.glPushMatrix();
                final ItemClothing ic = (ItemClothing)inventorydaym.inventory[7].func_77973_b();
                TextureRegistry.bindResource(TextureRegistry.c_gloves[ic.clothingID]);
                RenderSetup.modelbiped.field_78112_f.func_78785_a(0.0625f);
                GL11.glPopMatrix();
            }
        }
        GL11.glPopMatrix();
        GL11.glPopMatrix();
    }
    
    private void renderRightHand(final RenderPlayer renderplayer) {
        GL11.glPushMatrix();
        GL11.glScalef(4.0f, 4.0f, 4.0f);
        GL11.glTranslatef(1.0f, 0.4f, 0.15f);
        GL11.glRotatef(10.0f, 1.0f, 0.0f, 0.0f);
        GL11.glPushMatrix();
        GL11.glRotatef(165.0f, 1.0f, 0.0f, 0.0f);
        GL11.glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
        GL11.glRotatef(-20.0f, 0.0f, 1.0f, 0.0f);
        GL11.glScalef(1.48f, 1.0f, 1.0f);
        GL11.glPushMatrix();
        GL11.glRotatef(-10.0f, 0.0f, 1.0f, 0.0f);
        GL11.glTranslatef(-0.49f, -0.015f, 0.12f);
        GL11.glPushMatrix();
        GL11.glRotatef(5.0f, 1.0f, 1.0f, -1.0f);
        TextureRegistry.bindResource(TextureRegistry.handleSkin(DayMConfig.daym_d836addc0, DayMConfig.daym_8eb8ec9d0));
        RenderSetup.modelbiped.field_78112_f.func_78785_a(0.0625f);
        if (Minecraft.func_71410_x().field_71439_g != null) {
            final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get((EntityPlayer)Minecraft.func_71410_x().field_71439_g).inventory;
            if (inventorydaym != null && inventorydaym.inventory[1] != null && inventorydaym.inventory[1].func_77973_b() instanceof ItemClothing) {
                GL11.glPushMatrix();
                final ItemClothing ic = (ItemClothing)inventorydaym.inventory[1].func_77973_b();
                TextureRegistry.bindResource(TextureRegistry.c_shirt[ic.clothingID]);
                RenderSetup.modelbiped.field_78112_f.func_78785_a(0.0625f);
                GL11.glPopMatrix();
            }
            if (inventorydaym != null && inventorydaym.inventory[7] != null && inventorydaym.inventory[7].func_77973_b() instanceof ItemClothing) {
                GL11.glPushMatrix();
                final ItemClothing ic = (ItemClothing)inventorydaym.inventory[7].func_77973_b();
                TextureRegistry.bindResource(TextureRegistry.c_gloves[ic.clothingID]);
                RenderSetup.modelbiped.field_78112_f.func_78785_a(0.0625f);
                GL11.glPopMatrix();
            }
        }
        GL11.glPopMatrix();
        GL11.glPopMatrix();
        GL11.glPopMatrix();
        GL11.glPopMatrix();
    }
    
    private void defaultRenderLoc() {
        GL11.glRotatef(226.0f, 0.0f, 0.0f, 1.0f);
        GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        GL11.glRotatef(20.0f, 0.0f, 1.0f, 0.0f);
        GL11.glTranslatef(-4.5f, -2.0f, 7.0f);
    }
    
    public static void renderPlayer(final RenderPlayer renderplayer, final float scale, final float x, final float y, final float z) {
        int i = 0;
        for (final Object o : RenderSetup.modelbiped.field_78092_r) {
            if (o instanceof ModelRenderer && i != 0) {
                GL11.glPushMatrix();
                GL11.glTranslatef(x, y, z);
                GL11.glScalef(scale, scale, scale);
                final ModelRenderer mr = (ModelRenderer)o;
                mr.func_78785_a(0.0625f);
                GL11.glPopMatrix();
            }
            ++i;
        }
    }
    
    public static void renderMainMenuPlayer(final int width, final int height, final float offsetx, final float offsety, final int par1, final int par2) {
        GL11.glPushMatrix();
        final float var0 = getTime() / 512.0f;
        GL11.glMatrixMode(5889);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GLU.gluPerspective(120.0f, 1.0f, 0.05f, 50.0f);
        GL11.glMatrixMode(5888);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        final float xx = (par1 - width / 2) / (width / 28);
        final float yy = -((par2 - height / 3) / (height / 28));
        final float var2 = 56.695778f + (float)(Math.cos(var0) / 180.0) * 8.0f;
        GL11.glTranslatef(-xx / 40.0f + (var2 - 57.0f) / 5.0f + -DayM.daym_e1d8ee710.mtcm_posX / 19.0f, -yy / 80.0f, 0.0f);
        GL11.glPushMatrix();
        GL11.glPushMatrix();
        GL11.glScalef(0.75f, 0.9f, 0.75f);
        GL11.glTranslatef(7.0f, -2.85f, -9.0f);
        GL11.glRotatef(-45.0f, 0.0f, 1.0f, 0.0f);
        final Random random = new Random();
        random.setSeed(DayM.daym_5aeef7d50);
        for (int i = 0; i < 32; ++i) {
            final int rx11 = random.nextInt(8);
            final int rz11 = random.nextInt(8);
            renderTallgrass(-((1.0f + rx11 / 3) * rx11) + 4.0f, 0.0f, (1.0f + rz11 / 3) * rz11);
        }
        renderTallgrass(0.0f, 0.0f, 9.5f);
        ModelRegistry.mainmenu_terrain.renderTextured(TextureRegistry.tex_mmbg_terrain);
        GL11.glPopMatrix();
        GL11.glScalef(1.0f, 1.75f, 1.0f);
        GL11.glTranslatef(0.75f, 0.0f, -2.2f);
        GL11.glTranslatef(offsetx, offsety, 0.0f);
        GL11.glPushMatrix();
        GL11.glRotatef(180.0f, 1.0f, 0.0f, 0.0f);
        GL11.glRotatef(-(xx * 1.3f) + -DayM.daym_e1d8ee710.mtcm_posX * 5.0f, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(65.0f, 0.0f, 1.0f, 0.0f);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        int i = 0;
        for (final Object o : RenderSetup.modelbiped.field_78092_r) {
            if (o instanceof ModelRenderer && i != 0) {
                final ModelRenderer mr = (ModelRenderer)o;
                mr.field_78795_f = 0.0f;
                mr.field_78796_g = 0.0f;
                mr.field_78808_h = 0.0f;
            }
            ++i;
        }
        RenderSetup.modelbiped.field_78116_c.field_78796_g = (-xx * 3.2f + DayM.daym_e1d8ee710.mtcm_posX * 2.0f) / 57.295776f - 0.6f + (float)(Math.cos(var0) / 180.0) * 8.0f;
        RenderSetup.modelbiped.field_78116_c.field_78795_f = -yy * 2.0f / 57.295776f + (float)(Math.sin(var0 / 2.0f) / 180.0) * 8.0f;
        RenderSetup.modelbiped.field_78114_d.field_78796_g = RenderSetup.modelbiped.field_78116_c.field_78796_g;
        RenderSetup.modelbiped.field_78114_d.field_78795_f = RenderSetup.modelbiped.field_78116_c.field_78795_f;
        RenderSetup.modelbiped.field_78115_e.field_78796_g = (float)(Math.sin(var0 / 3.0f) / 180.0) * 10.0f;
        RenderSetup.modelbiped.field_78112_f.field_78795_f = -1.4f + DayM.daym_e1d8ee710.mtcm_posX / 38.0f + (float)(Math.sin(var0) / 180.0);
        RenderSetup.modelbiped.field_78113_g.field_78795_f = -1.3f + DayM.daym_e1d8ee710.mtcm_posX / 38.0f + (float)(Math.cos(var0) / 180.0);
        RenderSetup.modelbiped.field_78112_f.field_78796_g = -1.1f + (float)(Math.sin(var0) / 180.0);
        RenderSetup.modelbiped.field_78113_g.field_78796_g = -1.0f + (float)(Math.cos(var0) / 180.0);
        GL11.glPushMatrix();
        TextureRegistry.bindResource(TextureRegistry.handleSkin(DayMConfig.daym_d836addc0, DayMConfig.daym_8eb8ec9d0));
        renderPlayer(null, 1.0f, 0.0f, 0.0f, 0.0f);
        TextureRegistry.bindResource(TextureRegistry.c_shirt[DayMConfig.daym_bed00c4b0]);
        renderPlayer(null, 1.0f, 0.0f, 0.0f, 0.0f);
        TextureRegistry.bindResource(TextureRegistry.c_pants[DayMConfig.daym_94a3461e0]);
        renderPlayer(null, 1.0f, 0.0f, 0.0f, 0.0f);
        TextureRegistry.bindResource(TextureRegistry.c_shoes[0]);
        renderPlayer(null, 1.0f, 0.0f, 0.0f, 0.0f);
        GL11.glPopMatrix();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(0.0f, -2.0f, 0.0f);
        GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
        GL11.glScalef(0.15f, 0.15f, 0.15f);
        GL11.glRotatef(-(xx * 1.3f) - 105.0f + -DayM.daym_e1d8ee710.mtcm_posX * 5.0f + DayM.daym_e1d8ee710.mtcm_posX / 4.0f, 0.0f, 0.0f, 1.0f);
        GL11.glRotatef(10.0f, 0.0f, 1.0f, 0.0f);
        GL11.glTranslatef(-1.5f + DayM.daym_e1d8ee710.mtcm_posX / 6.0f, -1.3f + -DayM.daym_e1d8ee710.mtcm_posX / 28.0f, -6.35f + DayM.daym_e1d8ee710.mtcm_posX / 10.0f);
        GL11.glPushMatrix();
        GL11.glRotatef(-(float)(Math.sin(var0) / 180.0) * 45.0f + DayM.daym_e1d8ee710.mtcm_posX * 1.4f, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(-(float)(Math.sin(var0) / 180.0) * 45.0f, 0.0f, 0.0f, 1.0f);
        RenderSetup.daym_3c8b8d790.render(0);
        RenderSetup.daym_3c8b8d790.render(1);
        GL11.glPopMatrix();
        GL11.glPopMatrix();
        GL11.glPopMatrix();
        GL11.glMatrixMode(5889);
        GL11.glPopMatrix();
        GL11.glMatrixMode(5888);
        GL11.glPopMatrix();
        GL11.glPopMatrix();
    }
    
    private static void renderTallgrass(final float f, final float g, final float h) {
        GL11.glPushMatrix();
        GL11.glScalef(1.0f, 0.75f, 1.0f);
        GL11.glTranslatef(f, g, h);
        GL11.glColor4f(0.6f, 0.75f, 0.35f, 1.0f);
        ModelRegistry.tallgrass.renderTextured(TextureRegistry.tallgrass);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    public static void renderDayMBackground(final double offsx, final double offsy, final int width, final int height, final ResourceLocation mainmenu_backgroundTexture) {
        GL11.glPushMatrix();
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(3008);
        GL11.glEnable(3042);
        TextureRegistry.bindResource(mainmenu_backgroundTexture);
        final Tessellator var3 = Tessellator.field_78398_a;
        var3.func_78382_b();
        var3.func_78374_a(offsx, offsy + height, -90.0, 0.0, 1.0);
        var3.func_78374_a(offsx + width, offsy + height, -90.0, 1.0, 1.0);
        var3.func_78374_a(offsx + width, offsy, -90.0, 1.0, 0.0);
        var3.func_78374_a(offsx, offsy, -90.0, 0.0, 0.0);
        var3.func_78381_a();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glEnable(3008);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    public static void setAnimationsGun3RDPerson(final Entity par7Entity, final ModelBipedDayM model, final float par5, final boolean daym_c46b8fa90) {
        if (!par7Entity.func_70051_ag() && !daym_c46b8fa90 && !par7Entity.func_70115_ae()) {
            GL11.glRotatef(65.0f, 0.0f, 1.0f, 0.0f);
        }
        float lockPar5 = par5;
        if (lockPar5 > 30.0f) {
            lockPar5 = 30.0f;
        }
        if (lockPar5 < -30.0f) {
            lockPar5 = -30.0f;
        }
        if (!daym_c46b8fa90) {
            model.field_78112_f.field_78808_h = 0.0f;
            model.field_78113_g.field_78808_h = 0.0f;
            model.field_78112_f.field_78795_f = lockPar5 / 57.295776f - 90.0f + 0.4f;
            model.field_78112_f.field_78796_g = -1.1f;
            model.field_78113_g.field_78795_f = (lockPar5 / 57.295776f - 1.5f + 0.4f) * 1.5f;
            model.field_78113_g.field_78796_g = -(0.45f - (par5 / 57.295776f - 75.0f + 0.4f) / 180.0f) + 0.5f;
            if (!par7Entity.func_70051_ag()) {
                model.field_78116_c.field_78796_g = -0.95f;
                model.field_78116_c.field_78795_f = lockPar5 / 57.295776f;
                model.field_78114_d.field_78796_g = -0.95f;
                model.field_78114_d.field_78795_f = lockPar5 / 57.295776f;
            }
            else {
                model.field_78116_c.field_78796_g = 0.0f;
                model.field_78116_c.field_78795_f = lockPar5 / 57.295776f;
                model.field_78114_d.field_78796_g = 0.0f;
                model.field_78114_d.field_78795_f = lockPar5 / 57.295776f;
            }
        }
        else {
            model.field_78112_f.field_78808_h = 0.0f;
            model.field_78113_g.field_78808_h = 0.0f;
            model.field_78112_f.field_78795_f = lockPar5 / 57.295776f - 90.0f + 0.4f;
            model.field_78112_f.field_78796_g = -0.4f;
            model.field_78113_g.field_78795_f = (lockPar5 / 90.29578f - 1.5f + 0.4f) * 1.5f;
            model.field_78113_g.field_78796_g = -(0.45f - (par5 / 57.295776f + 135.0f + 0.4f) / 180.0f) + 0.5f;
        }
    }
    
    public void renderZoomer() {
        GL11.glPushMatrix();
        RenderHelper.func_74518_a();
        GL11.glDisable(2896);
        GL11.glPushMatrix();
        GL11.glMatrixMode(5890);
        final int width = Minecraft.func_71410_x().field_71443_c / 2;
        final int height = Minecraft.func_71410_x().field_71440_d / 2;
        GL11.glPushMatrix();
        TextureRegistry.bindResource(TextureRegistry.render_scope);
        int x = 0;
        int y = 0;
        if (this.anims == null || this.anims[1] != null) {}
        if (Minecraft.func_71410_x().field_71439_g.func_70051_ag()) {
            x = (int)(-width / 2.5);
            y = -height / 6;
        }
        GL11.glCopyTexImage2D(3553, 0, 6407, width / 2 + width / 4 + x, height / 2 + y, width / 2 + x, height + y, 0);
        GL11.glTexParameteri(3553, 10240, 9728);
        GL11.glPopMatrix();
        GL11.glMatrixMode(5888);
        GL11.glEnable(2896);
        RenderHelper.func_74519_b();
        GL11.glPopMatrix();
        GL11.glPopMatrix();
    }
    
    public static void renderZSTag(final Minecraft mc, final String[] sd) throws Exception {
        final int type = Integer.parseInt(sd[0]);
        final int chance = Integer.parseInt(sd[1]);
        final int radius = Integer.parseInt(sd[2]);
        final int amount = Integer.parseInt(sd[3]);
        final int randomize = Integer.parseInt(sd[4]);
        final int x1 = Integer.parseInt(sd[5]);
        final int y1 = Integer.parseInt(sd[6]);
        final int z1 = Integer.parseInt(sd[7]);
        final float dist = (float)mc.field_71439_g.func_70011_f((double)x1, (double)y1, (double)z1);
        if (dist < 128.0f) {
            GL11.glPushMatrix();
            final float x2 = -(float)EntityFX.field_70556_an + x1 + 0.5f;
            final float y2 = -(float)EntityFX.field_70554_ao + y1 + 1.0f + 0.5f;
            final float z2 = -(float)EntityFX.field_70555_ap + z1 + 0.5f;
            final float scale = 4.0f;
            final FontRenderer localFontRenderer = mc.field_71466_p;
            final String p_147906_2_ = "Zombie Spawn(tick:" + DayM.daym_0445f76a0.daym_1fef99d20 + ") | type:" + type + ",chance:%" + (100 - chance) + ",radius:" + radius;
            final String pstr = "amount:" + amount + ",randomizeAmount:" + (randomize == 1);
            final float f1 = 1.6f;
            final float f2 = 0.01666667f * f1;
            GL11.glPushMatrix();
            GL11.glTranslatef(x2, y2, z2);
            GL11.glNormal3f(0.0f, 1.0f, 0.0f);
            final RenderManager renderManager = RenderManager.field_78727_a;
            GL11.glRotatef(-renderManager.field_78735_i, 0.0f, 1.0f, 0.0f);
            GL11.glScalef(-f2 * scale, -f2 * scale, f2 * scale);
            GL11.glDisable(2896);
            GL11.glDepthMask(false);
            GL11.glDisable(2929);
            GL11.glEnable(3042);
            OpenGlHelper.func_148821_a(770, 771, 1, 0);
            final Tessellator localTessellator = Tessellator.field_78398_a;
            int j = localFontRenderer.func_78256_a(p_147906_2_) / 2;
            final int i = 0;
            GL11.glDisable(3553);
            if (dist < 32.0f) {
                localTessellator.func_78382_b();
                if (dist < 24.0f) {
                    localTessellator.func_78369_a(0.0f, 0.0f, 0.0f, 0.45f);
                }
                else {
                    localTessellator.func_78369_a(0.0f, 0.0f, 0.0f, 0.25f);
                }
                localTessellator.func_78377_a((double)(-j - 1), (double)(-49 + i), 0.0);
                localTessellator.func_78377_a((double)(-j - 1), (double)(-32 + i), 0.0);
                localTessellator.func_78377_a((double)(j + 1), (double)(-32 + i), 0.0);
                localTessellator.func_78377_a((double)(j + 1), (double)(-49 + i), 0.0);
                localTessellator.func_78381_a();
            }
            localTessellator.func_78382_b();
            j = 4;
            localTessellator.func_78369_a(0.5f, 0.0f, 0.0f, 0.25f);
            localTessellator.func_78377_a((double)(-j - 1), (double)(-32 + i), 0.0);
            localTessellator.func_78377_a((double)(-j - 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(-32 + i), 0.0);
            localTessellator.func_78381_a();
            localTessellator.func_78382_b();
            j = 4;
            int timer = 0;
            if (DayM.daym_0445f76a0.daym_1fef99d20 % 2 == 0) {
                timer = DayM.daym_0445f76a0.daym_c14f56470;
            }
            localTessellator.func_78369_a(1.0f, timer / 240.0f, 0.0f, 0.25f);
            localTessellator.func_78377_a((double)(-j - 1), (double)(-2 + i), 0.0);
            localTessellator.func_78377_a((double)(-j - 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(-2 + i), 0.0);
            localTessellator.func_78381_a();
            GL11.glEnable(3553);
            if (dist < 24.0f) {
                localFontRenderer.func_78276_b(p_147906_2_, -localFontRenderer.func_78256_a(p_147906_2_) / 2, i - 51 + 2, 553648127);
                localFontRenderer.func_78276_b(pstr, -localFontRenderer.func_78256_a(pstr) / 2, i + 8 - 51 + 2, 553648127);
            }
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            if (dist < 24.0f) {
                localFontRenderer.func_78276_b(p_147906_2_, -localFontRenderer.func_78256_a(p_147906_2_) / 2, i - 51 + 2, -1);
                localFontRenderer.func_78276_b(pstr, -localFontRenderer.func_78256_a(pstr) / 2, i + 8 - 51 + 2, -1);
            }
            GL11.glDisable(3042);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glPopMatrix();
            GL11.glPopMatrix();
        }
    }
    
    public static void renderPLTag(final Minecraft mc, final String[] sd) throws Exception {
        final int chance = Integer.parseInt(sd[0]);
        final int x1 = Integer.parseInt(sd[1]);
        final int y1 = Integer.parseInt(sd[2]);
        final int z1 = Integer.parseInt(sd[3]);
        final float dist = (float)mc.field_71439_g.func_70011_f((double)x1, (double)y1, (double)z1);
        if (dist < 128.0f) {
            GL11.glPushMatrix();
            final float x2 = -(float)EntityFX.field_70556_an + x1 + 0.5f;
            final float y2 = -(float)EntityFX.field_70554_ao + y1 + 1.0f + 0.5f;
            final float z2 = -(float)EntityFX.field_70555_ap + z1 + 0.5f;
            final float scale = 4.0f;
            final FontRenderer localFontRenderer = mc.field_71466_p;
            final String p_147906_2_ = "Player Spawn | chance:%" + (100 - chance);
            final float f1 = 1.6f;
            final float f2 = 0.01666667f * f1;
            GL11.glPushMatrix();
            GL11.glTranslatef(x2, y2, z2);
            GL11.glNormal3f(0.0f, 1.0f, 0.0f);
            final RenderManager renderManager = RenderManager.field_78727_a;
            GL11.glRotatef(-renderManager.field_78735_i, 0.0f, 1.0f, 0.0f);
            GL11.glScalef(-f2 * scale, -f2 * scale, f2 * scale);
            GL11.glDisable(2896);
            GL11.glDepthMask(false);
            GL11.glDisable(2929);
            GL11.glEnable(3042);
            OpenGlHelper.func_148821_a(770, 771, 1, 0);
            final Tessellator localTessellator = Tessellator.field_78398_a;
            final int i = 0;
            GL11.glDisable(3553);
            int j = localFontRenderer.func_78256_a(p_147906_2_) / 2;
            if (dist < 32.0f) {
                localTessellator.func_78382_b();
                if (dist < 24.0f) {
                    localTessellator.func_78369_a(0.0f, 0.0f, 0.0f, 0.45f);
                }
                else {
                    localTessellator.func_78369_a(0.0f, 0.0f, 0.0f, 0.25f);
                }
                localTessellator.func_78377_a((double)(-j - 1), (double)(-33 + i), 0.0);
                localTessellator.func_78377_a((double)(-j - 1), (double)(-32 + i + 8), 0.0);
                localTessellator.func_78377_a((double)(j + 1), (double)(-32 + i + 8), 0.0);
                localTessellator.func_78377_a((double)(j + 1), (double)(-33 + i), 0.0);
                localTessellator.func_78381_a();
            }
            localTessellator.func_78382_b();
            j = 4;
            localTessellator.func_78369_a(0.0f, 0.0f, 0.5f, 0.25f);
            localTessellator.func_78377_a((double)(-j - 1), (double)(-32 + i + 8), 0.0);
            localTessellator.func_78377_a((double)(-j - 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(-32 + i + 8), 0.0);
            localTessellator.func_78381_a();
            localTessellator.func_78382_b();
            j = 4;
            localTessellator.func_78369_a(chance / 140.0f, (100 - chance) / 140.0f, 0.0f, 0.25f);
            localTessellator.func_78377_a((double)(-j - 1), (double)(-2 + i), 0.0);
            localTessellator.func_78377_a((double)(-j - 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(-2 + i), 0.0);
            localTessellator.func_78381_a();
            GL11.glEnable(3553);
            if (dist < 24.0f) {
                localFontRenderer.func_78276_b(p_147906_2_, -localFontRenderer.func_78256_a(p_147906_2_) / 2, i - 51 + 2 + 16, 553648127);
            }
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            if (dist < 24.0f) {
                localFontRenderer.func_78276_b(p_147906_2_, -localFontRenderer.func_78256_a(p_147906_2_) / 2, i - 51 + 2 + 16, -1);
            }
            GL11.glDisable(3042);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glPopMatrix();
            GL11.glPopMatrix();
        }
    }
    
    public static void renderLSTag(final Minecraft mc, final String[] sd) {
        final ArrayList<String> loots = LootSpawn.decodeLootTable(sd[0]);
        final ArrayList<Integer> loot1 = new ArrayList<Integer>();
        final ArrayList<Integer> loot2 = new ArrayList<Integer>();
        for (final String ll : loots) {
            final String[] ss = ll.split("\\?");
            loot1.add(Integer.parseInt(ss[0]));
            loot2.add(Integer.parseInt(ss[1]));
        }
        final int lid = Integer.parseInt(sd[1]);
        final int radius = Integer.parseInt(sd[2]);
        final int chance = Integer.parseInt(sd[3]);
        final int x1 = Integer.parseInt(sd[4]);
        final int y1 = Integer.parseInt(sd[5]);
        final int z1 = Integer.parseInt(sd[6]);
        final float dist = (float)mc.field_71439_g.func_70011_f((double)x1, (double)y1, (double)z1);
        if (dist < 128.0f) {
            GL11.glPushMatrix();
            final float x2 = -(float)EntityFX.field_70556_an + x1 + 0.5f;
            final float y2 = -(float)EntityFX.field_70554_ao + y1 + 1.0f + 0.5f;
            final float z2 = -(float)EntityFX.field_70555_ap + z1 + 0.5f;
            final float scale = 3.0f;
            final FontRenderer localFontRenderer = mc.field_71466_p;
            final String[] p_147906_2_ = new String[128];
            p_147906_2_[0] = "Loot Spawn | radius:" + radius + ", chance:%" + (100 - chance);
            int ini2 = 0;
            if (dist < 32 + ini2) {
                for (final Integer in : loot1) {
                    try {
                        final Item item = ItemRegistry.lootTable.get(in);
                        if (item == null) {
                            continue;
                        }
                        ++ini2;
                    }
                    catch (Exception ex) {}
                }
            }
            int ini3 = 0;
            if (dist < 32 + ini2) {
                try {
                    for (final Integer in2 : loot1) {
                        if (in2 != -1) {
                            final Item item2 = ItemRegistry.lootTable.get(in2);
                            final int ini4 = ItemRegistry.lootTable.indexOf(item2);
                            if (item2 == null) {
                                continue;
                            }
                            p_147906_2_[ini3 + 1] = "" + I18n.func_135052_a(item2.func_77658_a() + ".name", new Object[0]) + ":%" + loot2.get(in2);
                            ++ini3;
                        }
                    }
                }
                catch (Exception ex2) {}
            }
            final float f1 = 1.6f;
            final float f2 = 0.01666667f * f1;
            GL11.glPushMatrix();
            GL11.glTranslatef(x2, y2, z2);
            GL11.glNormal3f(0.0f, 1.0f, 0.0f);
            final RenderManager renderManager = RenderManager.field_78727_a;
            GL11.glRotatef(-renderManager.field_78735_i, 0.0f, 1.0f, 0.0f);
            GL11.glScalef(-f2 * scale, -f2 * scale, f2 * scale);
            GL11.glDisable(2896);
            GL11.glDepthMask(false);
            GL11.glDisable(2929);
            GL11.glEnable(3042);
            OpenGlHelper.func_148821_a(770, 771, 1, 0);
            final Tessellator localTessellator = Tessellator.field_78398_a;
            final int i = 0;
            GL11.glDisable(3553);
            int j = localFontRenderer.func_78256_a(p_147906_2_[0]) / 2;
            for (int a = 0; a < p_147906_2_.length; ++a) {
                final int kk = localFontRenderer.func_78256_a(p_147906_2_[a]) / 2;
                if (kk > j) {
                    j = kk;
                }
            }
            if (dist < 32 + ini2) {
                localTessellator.func_78382_b();
                if (dist < 24 + ini2) {
                    localTessellator.func_78369_a(0.0f, 0.0f, 0.0f, 0.35f);
                }
                else {
                    localTessellator.func_78369_a(0.0f, 0.0f, 0.0f, 0.25f);
                }
                localTessellator.func_78377_a((double)(-j - 1), (double)(-25 + i - ini2 * 10), 0.0);
                localTessellator.func_78377_a((double)(-j - 1), (double)(-16 + i), 0.0);
                localTessellator.func_78377_a((double)(j + 1), (double)(-16 + i), 0.0);
                localTessellator.func_78377_a((double)(j + 1), (double)(-25 + i - ini2 * 10), 0.0);
                localTessellator.func_78381_a();
            }
            localTessellator.func_78382_b();
            j = 4;
            localTessellator.func_78369_a(0.5f, 0.5f, 0.5f, 0.4f);
            localTessellator.func_78377_a((double)(-j - 1), (double)(-16 + i), 0.0);
            localTessellator.func_78377_a((double)(-j - 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(-16 + i), 0.0);
            localTessellator.func_78381_a();
            localTessellator.func_78382_b();
            j = 4;
            int timer = 0;
            if (DayM.daym_0445f76a0.daym_1fef99d20 % 5 == 0) {
                timer = DayM.daym_0445f76a0.daym_c14f56470;
            }
            localTessellator.func_78369_a(1.0f, timer / 240.0f, 0.0f, 0.25f);
            localTessellator.func_78377_a((double)(-j - 1), (double)(-2 + i), 0.0);
            localTessellator.func_78377_a((double)(-j - 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(8 + i), 0.0);
            localTessellator.func_78377_a((double)(j + 1), (double)(-2 + i), 0.0);
            localTessellator.func_78381_a();
            GL11.glEnable(3553);
            if (dist < 24 + ini2) {
                for (int a2 = 0; a2 < p_147906_2_.length; ++a2) {
                    localFontRenderer.func_78276_b(p_147906_2_[a2], -localFontRenderer.func_78256_a(p_147906_2_[a2]) / 2, i - 34 + 1 + 8 - 10 * a2, 553648127);
                }
            }
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            if (dist < 24 + ini2) {
                for (int a2 = 0; a2 < p_147906_2_.length; ++a2) {
                    localFontRenderer.func_78276_b(p_147906_2_[a2], -localFontRenderer.func_78256_a(p_147906_2_[a2]) / 2, i - 34 + 1 + 8 - 10 * a2, -1);
                }
            }
            GL11.glDisable(3042);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glPopMatrix();
            GL11.glPopMatrix();
        }
    }
    
    public static void renderBackgroundAndPlayer(final int width, final int height, final int par1, final int par2, final float par3) {
        renderDayMBackground(0.0, 0.0, width, height, TextureRegistry.mainmenu_backgroundTextureUN);
        GL11.glPushMatrix();
        final float var0 = getTime() / 512.0f;
        final float var2 = 56.695778f + (float)(Math.cos(var0) / 180.0) * 8.0f;
        final float var3 = 56.695778f + (float)(Math.sin(var0) / 180.0) * 8.0f;
        final double xx = (par1 - width / 2) / (width / 28) + width / 8;
        final double yy = -((par2 - height / 3) / (height / 28)) - height / 24;
        GL11.glScalef(1.1f, 1.0f, 1.0f);
        GL11.glTranslatef(-5.0f - (var2 * 8.0f - 456.0f) / 3.0f, -5.0f - (var3 * 8.0f - 456.0f) / 5.0f, 0.0f);
        if (RenderSetup.daym_3af4fa140 < width) {
            RenderSetup.daym_3af4fa140 += par3 * 0.4f;
        }
        else {
            RenderSetup.daym_3af4fa140 = 0.0f;
        }
        renderDayMBackground(-xx / 9.0 + RenderSetup.daym_3af4fa140, yy / 12.0, width + width / 10, height - height / 6, TextureRegistry.mainmenu_backgroundTextureClouds);
        renderDayMBackground(-xx / 9.0 + RenderSetup.daym_3af4fa140 - width, yy / 12.0, width + width / 10, height - height / 6, TextureRegistry.mainmenu_backgroundTextureClouds);
        renderDayMBackground(-xx / 16.0, yy / 28.0, width + width / 8, height + height / 24, TextureRegistry.mainmenu_backgroundTexture);
        renderMainMenuPlayer(width, height, 0.0f, 0.0f, par1, par2);
        GL11.glPopMatrix();
        renderDayMBackground(0.0, 0.0, width, height, TextureRegistry.mainmenu_backgroundTextureOV);
    }
    
    public static void drawTexture(final double x, final double y, final double i, final double j, final double k, final double l, final float alpha, final ResourceLocation resourceLocation) {
        GL11.glPushMatrix();
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, alpha);
        GL11.glDisable(3008);
        GL11.glEnable(3042);
        GL11.glTranslatef(0.0f, 0.0f, 33.0f);
        if (resourceLocation != null) {
            TextureRegistry.bindResource(resourceLocation);
        }
        else {
            TextureRegistry.bindResource(TextureRegistry.solid);
        }
        final Tessellator var3 = Tessellator.field_78398_a;
        var3.func_78382_b();
        if (resourceLocation == null) {
            var3.func_78369_a(0.0f, 0.0f, 0.0f, alpha);
        }
        var3.func_78374_a(x + i, y + l, -90.0, 0.0, 1.0);
        var3.func_78374_a(x + k, y + l, -90.0, 1.0, 1.0);
        var3.func_78374_a(x + k, y + j, -90.0, 1.0, 0.0);
        var3.func_78374_a(x + i, y + j, -90.0, 0.0, 0.0);
        var3.func_78381_a();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glEnable(3008);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    public static void drawGradientRect(final int p_drawGradientRect_1_, final int p_drawGradientRect_2_, final int p_drawGradientRect_3_, final int p_drawGradientRect_4_, final int p_drawGradientRect_5_, final int p_drawGradientRect_6_, final float alpha) {
        final float f1 = (p_drawGradientRect_5_ >> 24 & 0xFF) / 255.0f;
        final float f2 = (p_drawGradientRect_5_ >> 16 & 0xFF) / 255.0f;
        final float f3 = (p_drawGradientRect_5_ >> 8 & 0xFF) / 255.0f;
        final float f4 = (p_drawGradientRect_5_ & 0xFF) / 255.0f;
        final float f5 = (p_drawGradientRect_6_ >> 24 & 0xFF) / 255.0f;
        final float f6 = (p_drawGradientRect_6_ >> 16 & 0xFF) / 255.0f;
        final float f7 = (p_drawGradientRect_6_ >> 8 & 0xFF) / 255.0f;
        final float f8 = (p_drawGradientRect_6_ & 0xFF) / 255.0f;
        GL11.glDisable(3553);
        GL11.glEnable(3042);
        GL11.glDisable(3008);
        OpenGlHelper.func_148821_a(770, 771, 1, 0);
        GL11.glShadeModel(7425);
        final Tessellator localTessellator = Tessellator.field_78398_a;
        localTessellator.func_78382_b();
        localTessellator.func_78369_a(f2, f3, f4, f1 + alpha);
        final double zLevel = 0.0;
        localTessellator.func_78377_a((double)p_drawGradientRect_3_, (double)p_drawGradientRect_2_, zLevel);
        localTessellator.func_78377_a((double)p_drawGradientRect_1_, (double)p_drawGradientRect_2_, zLevel);
        localTessellator.func_78369_a(f6, f7, f8, f5 + alpha);
        localTessellator.func_78377_a((double)p_drawGradientRect_1_, (double)p_drawGradientRect_4_, zLevel);
        localTessellator.func_78377_a((double)p_drawGradientRect_3_, (double)p_drawGradientRect_4_, zLevel);
        localTessellator.func_78381_a();
        GL11.glShadeModel(7424);
        GL11.glDisable(3042);
        GL11.glEnable(3008);
        GL11.glEnable(3553);
    }
    
    static {
        RenderSetup.daym_fdec667d0 = "error";
        RenderSetup.daym_150173cf0 = 0;
        RenderSetup.daym_6b1c3e8e0 = 0;
        RenderSetup.daym_2b3b426c0 = false;
        RenderSetup.daym_8a1531e40 = -1;
        RenderSetup.daym_a5d853260 = 0;
        RenderSetup.daym_a13965e60 = false;
        RenderSetup.delta = 0.0f;
        RenderSetup.deltaValue = 0.0f;
        RenderSetup.mcFov = 70.0f;
        RenderSetup.lx = new float[3];
        RenderSetup.ly = new float[3];
        RenderSetup.lz = new float[3];
        RenderSetup.r0 = new float[3];
        RenderSetup.rx = new float[3];
        RenderSetup.ry = new float[3];
        RenderSetup.rz = new float[3];
        RenderSetup.speed = new float[3];
        RenderSetup.animSensitivity = new float[3];
        RenderSetup.daym_6b1c3e8e0Debug = 0;
        RenderSetup.daym_76fabd190 = 0.0f;
        RenderSetup.daym_3ce7ac6c0 = new ArrayList<Integer>();
        RenderSetup.daym_b73359c80 = new ArrayList<String>();
        RenderSetup.daym_1bcc50820 = false;
        RenderSetup.partialTicks = 0.0f;
        RenderSetup.daym_c46b8fa90 = false;
        RenderSetup.daym_8bad1f340 = new RenderBlocks();
        RenderSetup.daym_3af4fa140 = 0.0f;
        RenderSetup.daym_a169211b0 = null;
        RenderSetup.daym_839b70940 = 0;
    }
}
