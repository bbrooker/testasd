package com.daym.render;

import com.daym.daymobjloader.*;
import net.minecraft.util.*;
import net.minecraft.client.*;
import org.lwjgl.opengl.*;
import com.daym.registry.*;

public class DayMGunRender
{
    public DayM_Model[] model_gun;
    private int amt;
    public ResourceLocation[] texture;
    public ResourceLocation curtexture;
    public int currentCamo;
    String[] gunstr;
    Minecraft mc;
    public boolean sameTexture;
    public boolean hasSubAnim;
    public int animToChange;
    public AnimationHandler subAnimation;
    
    public DayMGunRender(final boolean st, final AnimationHandler sa, final int atc, final String... gun) {
        this.amt = 3;
        this.currentCamo = 0;
        this.gunstr = new String[32];
        this.sameTexture = false;
        this.hasSubAnim = false;
        this.animToChange = 0;
        this.subAnimation = null;
        this.mc = Minecraft.func_71410_x();
        this.model_gun = new DayM_Model[gun.length];
        this.gunstr = gun;
        this.sameTexture = st;
        int i = 0;
        for (final String gn : gun) {
            this.model_gun[i] = new DayM_Model("/com/daym/models/guns/" + gn + ".obj");
            ++i;
        }
        if (sa != null) {
            this.subAnimation = sa;
            this.animToChange = atc;
            this.hasSubAnim = true;
        }
    }
    
    public void render(final int m) {
        GL11.glPushMatrix();
        if (this.texture == null) {
            this.texture = new ResourceLocation[2];
            int i = 0;
            for (String gn2 : this.gunstr) {
                final String gn1 = gn2;
                if (this.sameTexture) {
                    gn2 = this.gunstr[0];
                }
                if (!this.sameTexture || i == 0) {
                    this.texture[0] = TextureRegistry.setupTextures("textures/guns/" + gn2 + ".png");
                    this.texture[1] = TextureRegistry.setupTextures("textures/guns/" + gn2 + "_base.png");
                }
                ++i;
            }
        }
        ResourceLocation rendtex = this.texture[0];
        int var = 2;
        if (this.currentCamo == 0) {
            var = 1;
        }
        for (int ra = 0; ra < var; ++ra) {
            if (ra != 0) {
                rendtex = this.texture[1];
                GL11.glEnable(3042);
                GL11.glBlendFunc(774, 771);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            }
            else {
                float avar = 0.2f;
                if (this.currentCamo != 0) {
                    rendtex = TextureRegistry.camos[this.currentCamo - 1];
                }
                else {
                    rendtex = this.texture[0];
                    avar = 1.0f;
                }
                GL11.glColor4f(1.0f, 1.0f, 1.0f, avar);
            }
            this.curtexture = rendtex;
            int cm = 0;
            for (final DayM_Model dm : this.model_gun) {
                if (m == -1 || m == cm) {
                    if (this.hasSubAnim && this.animToChange == cm && this.subAnimation != null) {
                        this.subAnimation.doAnimation("");
                    }
                    if (rendtex != null && rendtex != null && dm != null) {
                        dm.renderTextured(rendtex);
                    }
                    else if (dm != null) {
                        if (rendtex != null && rendtex != null) {
                            dm.renderTextured(rendtex);
                        }
                        else {
                            dm.render();
                        }
                    }
                }
                ++cm;
            }
            if (ra != 0) {
                GL11.glDisable(3042);
            }
        }
        GL11.glPopMatrix();
    }
}
