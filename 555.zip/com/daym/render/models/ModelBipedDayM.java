package com.daym.render.models;

import cpw.mods.fml.relauncher.*;
import net.minecraft.client.model.*;
import net.minecraft.entity.*;
import org.lwjgl.opengl.*;
import net.minecraft.entity.player.*;
import com.daym.extended.*;
import com.daym.handlers.*;
import com.daym.inventory.*;
import net.minecraft.client.*;
import com.daym.gui.inventory.*;
import com.daym.registry.*;
import com.daym.render.*;
import org.lwjgl.input.*;
import net.minecraft.util.*;
import com.daym.items.*;
import com.daym.config.*;
import net.minecraft.client.entity.*;
import net.minecraft.block.material.*;

@SideOnly(Side.CLIENT)
public class ModelBipedDayM extends ModelBiped
{
    public ModelRendererExtended field_78116_c;
    public ModelRendererExtended field_78114_d;
    public ModelRendererExtended field_78115_e;
    public ModelRendererExtended field_78112_f;
    public ModelRendererExtended field_78113_g;
    public ModelRendererExtended field_78121_j;
    public ModelRendererExtended field_78122_k;
    public ModelRendererExtended field_78123_h;
    public ModelRendererExtended field_78124_i;
    public ModelRendererExtended bipedRightLeg2;
    public ModelRendererExtended bipedLeftLeg2;
    public ModelRenderer backpack;
    public ModelRenderer backpackP2;
    public ModelRenderer backpackP3;
    public ModelRenderer backpackP4;
    public ModelRenderer backpackP5;
    public ModelRenderer backpackP6;
    public ModelRenderer backpackSimple;
    public int field_78119_l;
    public int field_78120_m;
    public boolean field_78117_n;
    public boolean isProne;
    public boolean field_78118_o;
    public ModelBackpackAlice backpackAlice;
    public ModelBackpackCzech backpackCzech;
    public ModelBackpackCzechPouch backpackCzechPouch;
    public ModelBackpackCoyote backpackCoyote;
    public ModelRenderer finger01;
    public ModelRenderer finger02;
    
    public ModelBipedDayM() {
        this(0.0f);
    }
    
    public ModelBipedDayM(final float par1) {
        this(par1, 0.0f, 64, 32);
    }
    
    public ModelBipedDayM(final float par1, final float par2, final int par3, final int par4) {
        this.backpackAlice = new ModelBackpackAlice();
        this.backpackCzech = new ModelBackpackCzech();
        this.backpackCzechPouch = new ModelBackpackCzechPouch();
        this.backpackCoyote = new ModelBackpackCoyote();
        this.field_78119_l = 0;
        this.field_78120_m = 0;
        this.field_78117_n = false;
        this.isProne = false;
        this.field_78118_o = false;
        this.field_78090_t = par3;
        this.field_78089_u = par4;
        (this.finger01 = new ModelRenderer((ModelBase)this, 45, 28)).func_78789_a(-1.5f, 9.0f, -3.8f, 1, 1, 3);
        this.finger01.func_78793_a(-5.0f, 2.0f, 0.0f);
        this.finger01.func_78787_b(64, 32);
        this.finger01.field_78809_i = true;
        this.setRotation(this.finger01, -1.570796f, 0.0f, 0.0f);
        (this.finger02 = new ModelRenderer((ModelBase)this, 46, 28)).func_78789_a(-0.05f, 9.5f, -1.95f, 1, 3, 1);
        this.finger02.func_78793_a(-5.0f, 2.0f, 0.0f);
        this.finger02.func_78787_b(64, 32);
        this.finger02.field_78809_i = true;
        this.setRotation(this.finger02, -1.570796f, 0.0f, 0.0f);
        (this.field_78122_k = new ModelRendererExtended(this, 0, 0)).func_78790_a(-5.0f, 0.0f, -1.0f, 10, 16, 1, par1);
        (this.field_78121_j = new ModelRendererExtended(this, 24, 0)).func_78790_a(-3.0f, -6.0f, -1.0f, 6, 6, 1, par1);
        (this.field_78116_c = new ModelRendererExtended(this, 0, 0)).func_78790_a(-4.0f, -8.0f, -4.0f, 8, 8, 8, par1);
        this.field_78116_c.func_78793_a(0.0f, 0.0f + par2, 0.0f);
        (this.field_78114_d = new ModelRendererExtended(this, 32, 0)).func_78790_a(-4.0f, -8.0f, -4.0f, 8, 8, 8, par1 + 0.5f);
        this.field_78114_d.func_78793_a(0.0f, 0.0f + par2, 0.0f);
        (this.field_78115_e = new ModelRendererExtended(this, 16, 16)).func_78790_a(-4.0f, 0.0f, -2.0f, 8, 12, 4, par1);
        this.field_78115_e.func_78793_a(0.0f, 0.0f + par2, 0.0f);
        (this.field_78112_f = new ModelRendererExtended(this, 40, 16)).func_78790_a(-3.0f, -2.0f, -2.0f, 4, 12, 4, par1);
        this.field_78112_f.func_78793_a(-5.0f, 2.0f + par2, 0.0f);
        this.field_78113_g = new ModelRendererExtended(this, 40, 16);
        this.field_78113_g.field_78809_i = true;
        this.field_78113_g.func_78790_a(-1.0f, -2.0f, -2.0f, 4, 12, 4, par1);
        this.field_78113_g.func_78793_a(5.0f, 2.0f + par2, 0.0f);
        (this.field_78123_h = new ModelRendererExtended(this, 0, 16)).func_78789_a(-2.0f, 0.0f, -2.0f, 4, 6, 4);
        this.field_78123_h.func_78793_a(-2.0f, 12.0f, 0.0f);
        this.field_78123_h.func_78787_b(64, 32);
        this.setRotation(this.field_78123_h, 0.0f, 0.0f, 0.0f);
        (this.field_78124_i = new ModelRendererExtended(this, 0, 16)).func_78789_a(-2.0f, 0.0f, -2.0f, 4, 6, 4);
        this.field_78124_i.func_78793_a(2.0f, 12.0f, 0.0f);
        this.field_78124_i.func_78787_b(64, 32);
        this.field_78124_i.field_78809_i = true;
        this.setRotation(this.field_78124_i, 0.0f, 0.0f, 0.0f);
        (this.backpack = new ModelRenderer((ModelBase)this, 34, 10)).func_78789_a(-3.0f, 5.0f, 2.0f, 6, 4, 2);
        this.backpack.func_78793_a(0.0f, 0.0f, 0.0f);
        this.backpack.func_78787_b(64, 32);
        this.backpack.field_78809_i = true;
        (this.backpackP2 = new ModelRenderer((ModelBase)this, 37, 7)).func_78789_a(-2.3f, 1.0f, 2.48f, 3, 7, 2);
        this.backpackP2.func_78793_a(0.0f, 0.0f, 0.0f);
        this.backpackP2.func_78787_b(64, 32);
        this.backpackP2.field_78809_i = true;
        (this.backpackP3 = new ModelRenderer((ModelBase)this, 39, 8)).func_78789_a(-2.0f, 1.5f, 4.0f, 4, 6, 1);
        this.backpackP3.func_78793_a(0.0f, 0.0f, 0.0f);
        this.backpackP3.func_78787_b(64, 32);
        this.backpackP3.field_78809_i = true;
        (this.backpackP4 = new ModelRenderer((ModelBase)this, 35, 9)).func_78789_a(-2.5f, 0.0f, 2.0f, 5, 5, 2);
        this.backpackP4.func_78793_a(0.0f, 0.0f, 0.0f);
        this.backpackP4.func_78787_b(64, 32);
        this.backpackP4.field_78809_i = true;
        (this.backpackP5 = new ModelRenderer((ModelBase)this, 39, 7)).func_78789_a(0.3f, 1.0f, 2.5f, 2, 7, 2);
        this.backpackP5.func_78793_a(0.0f, 0.0f, 0.0f);
        this.backpackP5.func_78787_b(64, 32);
        this.backpackP5.field_78809_i = true;
        (this.backpackP6 = new ModelRenderer((ModelBase)this, 37, 9)).func_78789_a(-1.0f, 3.5f, 4.5f, 2, 3, 1);
        this.backpackP6.func_78793_a(0.0f, 0.0f, 0.0f);
        this.backpackP6.func_78787_b(64, 32);
        this.backpackP6.field_78809_i = true;
        (this.backpackSimple = new ModelRenderer((ModelBase)this, 32, 4)).func_78789_a(-3.0f, 0.0f, 2.0f, 6, 9, 3);
        this.backpackSimple.func_78793_a(0.0f, 0.0f, 0.0f);
        this.backpackSimple.func_78787_b(64, 32);
        this.backpackSimple.field_78809_i = true;
        (this.bipedRightLeg2 = new ModelRendererExtended(this, 0, 16)).func_78789_a(-2.0f, 0.0f, -2.0f, 4, 12, 4);
        this.bipedRightLeg2.func_78793_a(-2.0f, 12.0f, 0.0f);
        this.bipedRightLeg2.func_78787_b(64, 32);
        this.bipedRightLeg2.field_78809_i = true;
        this.setRotation(this.bipedRightLeg2, 0.0f, 0.0f, 0.0f);
        (this.bipedLeftLeg2 = new ModelRendererExtended(this, 0, 16)).func_78789_a(-2.0f, 0.0f, -2.0f, 4, 12, 4);
        this.bipedLeftLeg2.func_78793_a(2.0f, 12.0f, 0.0f);
        this.bipedLeftLeg2.func_78787_b(64, 32);
        this.bipedLeftLeg2.field_78809_i = true;
        this.setRotation(this.bipedLeftLeg2, 0.0f, 0.0f, 0.0f);
        (this.bipedLeftLeg2 = new ModelRendererExtended(this, 0, 22)).func_78789_a(-2.0f, 0.0f, -2.0f, 4, 6, 4);
        this.bipedLeftLeg2.func_78793_a(2.0f, 18.0f, 0.0f);
        this.bipedLeftLeg2.func_78787_b(64, 32);
        this.bipedLeftLeg2.field_78809_i = true;
        this.setRotation(this.bipedLeftLeg2, 0.0f, 0.0f, 0.0f);
        (this.bipedRightLeg2 = new ModelRendererExtended(this, 0, 22)).func_78789_a(-2.0f, 0.0f, -2.0f, 4, 6, 4);
        this.bipedRightLeg2.func_78793_a(-2.0f, 18.0f, 0.0f);
        this.bipedRightLeg2.func_78787_b(64, 32);
        this.setRotation(this.bipedRightLeg2, 0.0f, 0.0f, 0.0f);
    }
    
    private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
        model.field_78795_f = x;
        model.field_78796_g = y;
        model.field_78808_h = z;
    }
    
    public void func_78088_a(final Entity par1Entity, final float par2, final float par3, final float par4, final float par5, final float par6, final float par7) {
        this.func_78087_a(par2, par3, par4, par5, par6, par7, par1Entity);
        if (this.field_78116_c.field_78807_k && !par1Entity.func_70115_ae()) {
            if (par1Entity.field_70125_A > 0.0f) {
                GL11.glScalef(1.0f, 1.0f, 1.0f + Math.abs((90.0f - par1Entity.field_70125_A) / 40.0f) / 2.0f);
            }
            else {
                GL11.glScalef(1.0f, 1.0f, 1.0f + Math.abs((90.0f + par1Entity.field_70125_A) / 40.0f) / 2.0f);
            }
        }
        if (this.field_78116_c.field_78807_k && par1Entity.func_70115_ae()) {
            GL11.glScalef(1.0f, 1.0f, 1.3f);
            GL11.glRotatef(-10.0f, 1.0f, 0.0f, 0.0f);
        }
        ResourceLocation res = TextureRegistry.handleSkin(par1Entity);
        float scale = 1.0f;
        boolean shoes = false;
        boolean firstPass = true;
        for (int i = 0; i < 9; ++i) {
            GL11.glPushMatrix();
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            if (i >= 1) {
                firstPass = false;
                if (par1Entity instanceof EntityPlayer) {
                    final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get((EntityPlayer)par1Entity).inventory;
                    if (inventorydaym.inventory[i - 1] != null && inventorydaym.inventory[i - 1].func_77973_b() instanceof ItemClothing) {
                        final ItemClothing ic = (ItemClothing)inventorydaym.inventory[i - 1].func_77973_b();
                        scale = 1.0f + i / 10;
                        if (i == 1) {
                            res = TextureRegistry.c_headgear[ic.clothingID];
                        }
                        if (i == 2) {
                            res = TextureRegistry.c_shirt[ic.clothingID];
                        }
                        if (i == 3) {
                            res = TextureRegistry.c_pants[ic.clothingID];
                        }
                        if (i == 4) {
                            res = TextureRegistry.c_shoes[ic.clothingID];
                            shoes = true;
                        }
                        if (i == 8) {
                            res = TextureRegistry.c_gloves[ic.clothingID];
                            if (ic.clothingID == 2) {
                                firstPass = true;
                            }
                        }
                    }
                }
            }
            TextureRegistry.bindResource(res);
            if (this.field_78091_s) {
                final float var8 = 2.0f;
                GL11.glPushMatrix();
                GL11.glScalef(1.5f / var8, 1.5f / var8, 1.5f / var8);
                GL11.glTranslatef(0.0f, 16.0f * par7, 0.0f);
                this.field_78116_c.render(par7, scale);
                GL11.glPopMatrix();
                GL11.glPushMatrix();
                GL11.glScalef(1.0f / var8, 1.0f / var8, 1.0f / var8);
                GL11.glTranslatef(0.0f, 24.0f * par7, 0.0f);
                this.field_78112_f.render(par7, scale);
                this.field_78113_g.render(par7, scale);
                if (!shoes) {
                    this.field_78115_e.render(par7, scale);
                    this.field_78114_d.render(par7, scale);
                    this.field_78123_h.render(par7, scale);
                    this.field_78124_i.render(par7, scale);
                }
                this.bipedRightLeg2.render(par7, scale);
                this.bipedLeftLeg2.render(par7, scale);
                GL11.glPopMatrix();
            }
            else {
                if (!this.field_78117_n || par1Entity.field_70169_q != par1Entity.field_70165_t || par1Entity.field_70166_s != par1Entity.field_70161_v || par1Entity instanceof EntityPlayerSP) {}
                this.field_78112_f.render(par7, scale);
                this.field_78113_g.render(par7, scale);
                if (par1Entity instanceof EntityPlayer && firstPass && ((EntityPlayer)par1Entity).field_71071_by.func_70448_g() == null && PlayerVarHandler.daym_b73359c80.get(par1Entity.func_70005_c_()) != null && (PlayerVarHandler.daym_b73359c80.get(par1Entity.func_70005_c_()) == 2 || PlayerVarHandler.daym_b73359c80.get(par1Entity.func_70005_c_()) == 4)) {
                    GL11.glPushMatrix();
                    if (PlayerVarHandler.daym_b73359c80.get(par1Entity.func_70005_c_()) == 2) {
                        GL11.glTranslatef(0.0f, -0.005f, 0.0f);
                        this.finger01.func_78785_a(par7);
                    }
                    if (PlayerVarHandler.daym_b73359c80.get(par1Entity.func_70005_c_()) == 4) {
                        this.finger02.func_78785_a(par7);
                    }
                    GL11.glPopMatrix();
                }
                if (!shoes) {
                    this.field_78116_c.render(par7, scale);
                    this.field_78115_e.render(par7, scale);
                    this.field_78114_d.render(par7, scale);
                    this.field_78123_h.render(par7, scale);
                    this.field_78124_i.render(par7, scale);
                }
                if (this.field_78093_q) {
                    GL11.glTranslatef(0.0f, -0.3f, 0.1f);
                    GL11.glRotatef(-20.0f, 1.0f, 0.0f, 0.0f);
                    GL11.glTranslatef(-0.1f, 0.0f, 0.0f);
                    this.bipedRightLeg2.render(par7, scale);
                    GL11.glTranslatef(0.2f, 0.0f, 0.0f);
                    this.bipedLeftLeg2.render(par7, scale);
                }
                else {
                    this.bipedRightLeg2.render(par7, scale);
                    this.bipedLeftLeg2.render(par7, scale);
                }
            }
            GL11.glDisable(3042);
            GL11.glPopMatrix();
        }
        this.renderBackpack(par7, par1Entity);
        this.renderVest(par7, par1Entity);
    }
    
    private void renderVest(final float par7, final Entity par1Entity) {
        if (par1Entity instanceof EntityPlayer) {
            final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get((EntityPlayer)par1Entity).inventory;
            if (inventorydaym.inventory[6] != null && inventorydaym.inventory[6].func_77973_b() instanceof ItemClothing) {
                GL11.glPushMatrix();
                GL11.glScalef(0.5f, -0.5f, 0.5f);
                GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
                if (par1Entity.func_70093_af()) {
                    if (par1Entity.field_70169_q != par1Entity.field_70165_t || par1Entity.field_70166_s != par1Entity.field_70161_v || par1Entity instanceof EntityPlayerSP) {}
                    GL11.glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
                    GL11.glTranslatef(0.0f, 0.0f, 0.1f);
                }
                GL11.glRotatef(this.field_78115_e.field_78796_g * 55.0f, 0.0f, 1.0f, 0.0f);
                GL11.glTranslatef(0.0f, -3.0f, 0.0f);
                final ItemClothing ic = (ItemClothing)inventorydaym.inventory[6].func_77973_b();
                ModelRegistry.playerVests[ic.clothingID].renderTextured(TextureRegistry.c_vest[ic.clothingID]);
                GL11.glPopMatrix();
            }
            boolean shouldRender = true;
            boolean isMenu = false;
            float rot = 0.0f;
            final Minecraft mc = Minecraft.func_71410_x();
            if (par1Entity == mc.field_71439_g) {
                if (mc.field_71462_r == null) {
                    if (mc.field_71474_y.field_74320_O == 0) {
                        shouldRender = false;
                    }
                }
                else {
                    isMenu = true;
                    if (mc.field_71462_r instanceof GuiPlayerInventoryDayM) {
                        rot = ((GuiPlayerInventoryDayM)mc.field_71462_r).xSize_lo;
                    }
                }
            }
            if (shouldRender && inventorydaym.inventory[4] != null && inventorydaym.inventory[4].func_77973_b() instanceof ItemClothing) {
                GL11.glPushMatrix();
                GL11.glScalef(0.65f, -0.65f, 0.65f);
                if (isMenu) {
                    GL11.glScalef(1.05f, 1.05f, 1.05f);
                }
                if (par1Entity.func_70093_af()) {
                    GL11.glTranslatef(0.0f, -0.23f, 0.13f);
                }
                if (!isMenu) {
                    GL11.glRotatef(180.0f + this.field_78116_c.field_78796_g * 55.0f, 0.0f, 1.0f, 0.0f);
                }
                else {
                    final EntityPlayer ent = (EntityPlayer)par1Entity;
                    if (ent.field_71071_by.func_70448_g() != null) {
                        if (ItemRegistry.gunList.contains(ent.field_71071_by.func_70448_g().func_77973_b())) {
                            if (!((ItemDayMGun)ent.field_71071_by.func_70448_g().func_77973_b()).daym_c46b8fa90) {
                                GL11.glRotatef(125.0f, 0.0f, 1.0f, 0.0f);
                            }
                            else {
                                GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
                            }
                        }
                        else {
                            GL11.glRotatef(180.0f + mc.field_71439_g.field_70177_z / 2.0f, 0.0f, 1.0f, 0.0f);
                        }
                    }
                    else {
                        GL11.glRotatef(180.0f + mc.field_71439_g.field_70177_z / 2.0f, 0.0f, 1.0f, 0.0f);
                    }
                }
                if (!isMenu) {
                    GL11.glRotatef(this.field_78116_c.field_78795_f * 55.0f, 1.0f, 0.0f, 0.0f);
                }
                else {
                    GL11.glTranslatef(0.0f, -0.03f, 0.0f);
                }
                GL11.glTranslatef(0.0f, -3.35f, 0.0f);
                if (par1Entity.func_70093_af()) {
                    GL11.glTranslatef(0.0f, 0.0f, 0.14f);
                }
                final ItemClothing ic2 = (ItemClothing)inventorydaym.inventory[4].func_77973_b();
                ModelRegistry.playerHats[ic2.clothingID].renderTextured(TextureRegistry.c_headwear[ic2.clothingID]);
                GL11.glPopMatrix();
            }
        }
    }
    
    public void func_78087_a(final float par1, final float par2, final float par3, final float par4, final float par5, final float par6, final Entity par7Entity) {
        boolean renderGun = false;
        boolean daym_c46b8fa90 = false;
        boolean applyingRot = false;
        final Minecraft mc = Minecraft.func_71410_x();
        if (par7Entity instanceof EntityPlayer) {
            final EntityPlayer ent = (EntityPlayer)par7Entity;
            if (ent.field_71071_by.func_70448_g() != null && ItemRegistry.gunList.contains(ent.field_71071_by.func_70448_g().func_77973_b())) {
                renderGun = true;
                daym_c46b8fa90 = ((ItemDayMGun)ent.field_71071_by.func_70448_g().func_77973_b()).daym_c46b8fa90;
                if (!this.field_78116_c.field_78807_k || mc.field_71474_y.field_74320_O != 0 || mc.field_71439_g != par7Entity) {
                    GL11.glRotatef(par4, 0.0f, 1.0f, 0.0f);
                }
            }
        }
        if (this.field_78116_c.field_78807_k && mc.field_71474_y.field_74320_O == 0 && mc.field_71439_g == par7Entity) {
            final float speed = 1.0f + Math.abs((RenderSetup.daym_669c17750 - par4) / 45.0f);
            float offset = 0.0f;
            if (Keyboard.isKeyDown(mc.field_71474_y.field_74370_x.func_151463_i()) && !renderGun && mc.field_71462_r == null) {
                offset = -25.0f;
            }
            if ((Keyboard.isKeyDown(mc.field_71474_y.field_74366_z.func_151463_i()) && !renderGun && mc.field_71462_r == null) || RenderSetup.daym_2b3b426c0) {
                if (RenderSetup.daym_2b3b426c0) {
                    offset = 20.0f;
                }
                else {
                    offset = 25.0f;
                }
            }
            if (RenderSetup.daym_669c17750 > par4 + offset) {
                RenderSetup.daym_669c17750 -= (float)(1.2 + speed * RenderSetup.partialTicks);
            }
            if (RenderSetup.daym_669c17750 < par4 + offset) {
                RenderSetup.daym_669c17750 += (float)(1.2 + speed * RenderSetup.partialTicks);
            }
            applyingRot = true;
            GL11.glRotatef(RenderSetup.daym_669c17750, 0.0f, 1.0f, 0.0f);
        }
        this.field_78123_h.field_78795_f = 0.0f;
        this.field_78124_i.field_78795_f = 0.0f;
        this.field_78123_h.field_78808_h = 0.0f;
        this.field_78124_i.field_78808_h = 0.0f;
        this.bipedRightLeg2.field_78795_f = 0.0f;
        this.bipedLeftLeg2.field_78795_f = 0.0f;
        this.bipedRightLeg2.field_78808_h = 0.0f;
        this.bipedLeftLeg2.field_78808_h = 0.0f;
        this.bipedRightLeg2.field_82906_o = 0.0f;
        this.bipedLeftLeg2.field_82906_o = 0.0f;
        this.bipedRightLeg2.field_82908_p = 0.0f;
        this.bipedLeftLeg2.field_82908_p = 0.0f;
        this.bipedRightLeg2.field_82907_q = 0.0f;
        this.bipedLeftLeg2.field_82907_q = 0.0f;
        float par7 = par1;
        float par8 = par2;
        if (this.field_78117_n && par7Entity.field_70169_q == par7Entity.field_70165_t && par7Entity.field_70166_s == par7Entity.field_70161_v) {
            par7 = par1;
            par8 = 0.2f;
        }
        this.field_78116_c.field_78796_g = par4 / 57.295776f;
        this.field_78116_c.field_78795_f = par5 / 57.295776f;
        if (daym_c46b8fa90) {
            this.field_78116_c.field_78796_g = 0.0f;
        }
        this.field_78114_d.field_78796_g = this.field_78116_c.field_78796_g;
        this.field_78114_d.field_78795_f = this.field_78116_c.field_78795_f;
        this.field_78112_f.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f + 3.1415927f) * 2.0f * par2 * 0.5f;
        this.field_78113_g.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f) * 2.0f * par2 * 0.5f;
        this.field_78112_f.field_78808_h = 0.0f;
        this.field_78113_g.field_78808_h = 0.0f;
        this.field_78123_h.field_78795_f = MathHelper.func_76134_b(par7 * 0.6662f) * 1.4f * par8;
        this.field_78124_i.field_78795_f = MathHelper.func_76134_b(par7 * 0.6662f + 3.1415927f) * 1.4f * par8;
        this.field_78123_h.field_78796_g = 0.0f;
        this.field_78124_i.field_78796_g = 0.0f;
        if (this.field_78117_n) {
            this.bipedRightLeg2.field_78795_f = MathHelper.func_76134_b(par7 * 0.6662f) * 1.4f * par8 * 2.0f;
            this.bipedLeftLeg2.field_78795_f = MathHelper.func_76134_b(par7 * 0.6662f + 3.1415927f) * 1.4f * par8 * 2.0f;
        }
        else {
            this.bipedRightLeg2.field_78795_f = MathHelper.func_76134_b(par7 * 0.6662f) * 1.4f * par8 * 1.4f;
            this.bipedLeftLeg2.field_78795_f = MathHelper.func_76134_b(par7 * 0.6662f + 3.1415927f) * 1.4f * par8 * 1.4f;
        }
        if (this.bipedRightLeg2.field_78795_f < this.field_78123_h.field_78795_f) {
            this.bipedRightLeg2.field_78795_f = this.field_78123_h.field_78795_f;
        }
        if (this.bipedLeftLeg2.field_78795_f < this.field_78124_i.field_78795_f) {
            this.bipedLeftLeg2.field_78795_f = this.field_78124_i.field_78795_f;
        }
        this.bipedRightLeg2.field_78796_g = 0.0f;
        this.bipedLeftLeg2.field_78796_g = 0.0f;
        float var2 = MathHelper.func_76134_b(par7 * 0.6662f) * 1.4f * par8 / 3.5f;
        if (var2 < -0.3) {
            var2 /= 2.0f;
        }
        float var3 = MathHelper.func_76134_b(par7 * 0.6662f + 3.1415927f) * 1.4f * par8 / 3.5f;
        if (var3 < -0.3) {
            var3 /= 2.0f;
        }
        this.bipedRightLeg2.field_82907_q = var2;
        this.bipedLeftLeg2.field_82907_q = var3;
        float var4 = MathHelper.func_76134_b(par7 * 0.6662f) * 1.4f * par8 / 4.0f;
        if (var4 < 0.0f) {
            var4 = -var4;
        }
        float var5 = MathHelper.func_76134_b(par7 * 0.6662f + 3.1415927f) * 1.4f * par8 / 4.0f;
        if (var5 < 0.0f) {
            var5 = -var4;
        }
        this.bipedRightLeg2.field_82908_p = -var4;
        this.bipedLeftLeg2.field_82908_p = -var4;
        if (this.field_78117_n) {
            final ModelRendererExtended bipedRightLeg2 = this.bipedRightLeg2;
            bipedRightLeg2.field_82907_q -= 0.06f;
            final ModelRendererExtended bipedLeftLeg2 = this.bipedLeftLeg2;
            bipedLeftLeg2.field_82907_q -= 0.06f;
        }
        if (this.field_78093_q) {
            final ModelRendererExtended field_78112_f = this.field_78112_f;
            field_78112_f.field_78795_f -= 0.62831855f;
            final ModelRendererExtended field_78113_g = this.field_78113_g;
            field_78113_g.field_78795_f -= 0.62831855f;
            this.field_78123_h.field_78795_f = -1.2566371f;
            this.field_78124_i.field_78795_f = -1.2566371f;
            this.field_78123_h.field_78796_g = 0.31415927f;
            this.field_78124_i.field_78796_g = -0.31415927f;
        }
        if (this.field_78119_l != 0) {
            this.field_78113_g.field_78795_f = this.field_78113_g.field_78795_f * 0.5f - 0.31415927f * this.field_78119_l;
        }
        if (this.field_78120_m != 0) {
            this.field_78112_f.field_78795_f = this.field_78112_f.field_78795_f * 0.5f - 0.31415927f * this.field_78120_m;
        }
        this.field_78112_f.field_78796_g = 0.0f;
        this.field_78113_g.field_78796_g = 0.0f;
        if (this.field_78095_p > -9990.0f) {
            float var6 = this.field_78095_p;
            this.field_78115_e.field_78796_g = MathHelper.func_76126_a(MathHelper.func_76129_c(var6) * 3.1415927f * 2.0f) * 0.2f;
            this.field_78112_f.field_78798_e = MathHelper.func_76126_a(this.field_78115_e.field_78796_g) * 5.0f;
            this.field_78112_f.field_78800_c = -MathHelper.func_76134_b(this.field_78115_e.field_78796_g) * 5.0f;
            this.field_78113_g.field_78798_e = -MathHelper.func_76126_a(this.field_78115_e.field_78796_g) * 5.0f;
            this.field_78113_g.field_78800_c = MathHelper.func_76134_b(this.field_78115_e.field_78796_g) * 5.0f;
            final ModelRendererExtended field_78112_f2 = this.field_78112_f;
            field_78112_f2.field_78796_g += this.field_78115_e.field_78796_g;
            final ModelRendererExtended field_78113_g2 = this.field_78113_g;
            field_78113_g2.field_78796_g += this.field_78115_e.field_78796_g;
            final ModelRendererExtended field_78113_g3 = this.field_78113_g;
            field_78113_g3.field_78795_f += this.field_78115_e.field_78796_g;
            var6 = 1.0f - this.field_78095_p;
            var6 *= var6;
            var6 *= var6;
            var6 = 1.0f - var6;
            final float var7 = MathHelper.func_76126_a(var6 * 3.1415927f);
            final float var8 = MathHelper.func_76126_a(this.field_78095_p * 3.1415927f) * -(this.field_78116_c.field_78795_f - 0.7f) * 0.75f;
            this.field_78112_f.field_78795_f -= (float)(var7 * 1.2 + var8);
            final ModelRendererExtended field_78112_f3 = this.field_78112_f;
            field_78112_f3.field_78796_g += this.field_78115_e.field_78796_g * 2.0f;
            this.field_78112_f.field_78808_h = MathHelper.func_76126_a(this.field_78095_p * 3.1415927f) * -0.4f;
        }
        if (this.field_78117_n) {
            this.field_78115_e.field_78795_f = 0.5f;
            this.field_78115_e.field_78797_d = 1.5f;
            this.field_78123_h.field_78798_e = 5.0f;
            this.field_78124_i.field_78798_e = 5.0f;
            this.field_78123_h.field_78797_d = 11.0f;
            this.field_78124_i.field_78797_d = 11.0f;
            this.field_78116_c.field_78797_d = 3.0f;
            this.field_78114_d.field_78797_d = 3.0f;
            this.field_78112_f.field_78797_d = 4.0f;
            this.field_78113_g.field_78797_d = 4.0f;
            this.bipedRightLeg2.field_78798_e = 6.0f;
            this.bipedLeftLeg2.field_78798_e = 6.0f;
            this.bipedRightLeg2.field_78797_d = 17.0f;
            this.bipedLeftLeg2.field_78797_d = 17.0f;
        }
        else {
            this.field_78115_e.field_78797_d = 0.0f;
            this.field_78115_e.field_78795_f = 0.0f;
            this.field_78123_h.field_78798_e = 0.1f;
            this.field_78124_i.field_78798_e = 0.1f;
            this.field_78123_h.field_78797_d = 12.0f;
            this.field_78124_i.field_78797_d = 12.0f;
            this.field_78116_c.field_78797_d = 0.0f;
            this.field_78114_d.field_78797_d = 0.0f;
            this.field_78112_f.field_78797_d = 2.0f;
            this.field_78113_g.field_78797_d = 2.0f;
            this.bipedRightLeg2.field_78798_e = 0.1f;
            this.bipedLeftLeg2.field_78798_e = 0.1f;
            this.bipedRightLeg2.field_78797_d = 18.0f;
            this.bipedLeftLeg2.field_78797_d = 18.0f;
        }
        final ModelRendererExtended field_78112_f4 = this.field_78112_f;
        field_78112_f4.field_78808_h += MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
        final ModelRendererExtended field_78113_g4 = this.field_78113_g;
        field_78113_g4.field_78808_h -= MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
        final ModelRendererExtended field_78112_f5 = this.field_78112_f;
        field_78112_f5.field_78795_f += MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
        final ModelRendererExtended field_78113_g5 = this.field_78113_g;
        field_78113_g5.field_78795_f -= MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
        if (this.field_78118_o) {
            final float var6 = 0.0f;
            final float var7 = 0.0f;
            this.field_78112_f.field_78808_h = 0.0f;
            this.field_78113_g.field_78808_h = 0.0f;
            this.field_78112_f.field_78796_g = -(0.1f - var6 * 0.6f) + this.field_78116_c.field_78796_g;
            this.field_78113_g.field_78796_g = 0.1f - var6 * 0.6f + this.field_78116_c.field_78796_g + 0.4f;
            this.field_78112_f.field_78795_f = -1.5707964f + this.field_78116_c.field_78795_f;
            this.field_78113_g.field_78795_f = -1.5707964f + this.field_78116_c.field_78795_f;
            final ModelRendererExtended field_78112_f6 = this.field_78112_f;
            field_78112_f6.field_78795_f -= var6 * 1.2f - var7 * 0.4f;
            final ModelRendererExtended field_78113_g6 = this.field_78113_g;
            field_78113_g6.field_78795_f -= var6 * 1.2f - var7 * 0.4f;
            final ModelRendererExtended field_78112_f7 = this.field_78112_f;
            field_78112_f7.field_78808_h += MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
            final ModelRendererExtended field_78113_g7 = this.field_78113_g;
            field_78113_g7.field_78808_h -= MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
            final ModelRendererExtended field_78112_f8 = this.field_78112_f;
            field_78112_f8.field_78795_f += MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
            final ModelRendererExtended field_78113_g8 = this.field_78113_g;
            field_78113_g8.field_78795_f -= MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
        }
        if (renderGun) {
            RenderSetup.setAnimationsGun3RDPerson(par7Entity, this, par5, daym_c46b8fa90);
        }
        if (par7Entity instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)par7Entity;
            if (PlayerVarHandler.daym_b73359c80.get(par7Entity.func_70005_c_()) != null) {
                if (PlayerVarHandler.daym_b73359c80.get(par7Entity.func_70005_c_()) == 0) {
                    this.field_78115_e.field_78796_g = 0.0f;
                    this.field_78113_g.field_78796_g = 0.0f;
                    this.field_78113_g.field_78795_f = 0.0f;
                    this.field_78113_g.field_78808_h = 0.0f;
                    this.field_78112_f.field_78796_g = 0.0f;
                    this.field_78112_f.field_78795_f = 0.0f;
                    this.field_78112_f.field_78808_h = 0.0f;
                    this.field_78112_f.field_78795_f = -3.0f + MathHelper.func_76126_a(par7 * 0.6662f) * 1.4f * par8 * 0.025f;
                    this.field_78113_g.field_78795_f = -3.0f + MathHelper.func_76134_b(par7 * 0.6662f) * 1.4f * par8 * 0.025f;
                    this.field_78112_f.field_78808_h = -0.15f + MathHelper.func_76134_b(par7 * 0.6662f) * 1.4f * par8 * 0.025f;
                    this.field_78113_g.field_78808_h = 0.15f + MathHelper.func_76126_a(par7 * 0.6662f) * 1.4f * par8 * 0.025f;
                }
                if (PlayerVarHandler.daym_b73359c80.get(par7Entity.func_70005_c_()) == 1) {
                    if (player.field_70733_aJ > 0.0f) {
                        this.field_78115_e.field_78796_g = 0.0f;
                    }
                    this.field_78112_f.field_78796_g = 0.0f;
                    this.field_78112_f.field_78795_f = -3.0f;
                    this.field_78112_f.field_78808_h = (player.field_70733_aJ - 0.5f) / 5.0f - 0.15f + MathHelper.func_76134_b(par7 * 0.6662f) * 1.4f * par8 * 0.2f;
                    if (player.func_70093_af()) {
                        this.field_78112_f.field_78808_h = (player.field_70733_aJ - 0.5f) / 5.0f - 0.15f + MathHelper.func_76134_b(par7 * 0.6662f) * 0.3f * par8 * 8.0f;
                    }
                }
                if (PlayerVarHandler.daym_b73359c80.get(par7Entity.func_70005_c_()) == 2 || PlayerVarHandler.daym_b73359c80.get(par7Entity.func_70005_c_()) == 4) {
                    if (this.field_78116_c.field_78807_k) {
                        this.field_78112_f.field_78796_g = 0.0f;
                    }
                    else {
                        this.field_78112_f.field_78796_g = this.field_78116_c.field_78796_g;
                    }
                    this.field_78112_f.field_78795_f = -1.5f + this.field_78116_c.field_78795_f;
                    this.field_78112_f.field_78808_h = this.field_78116_c.field_78808_h;
                }
                if (PlayerVarHandler.daym_b73359c80.get(par7Entity.func_70005_c_()) == 3) {
                    this.field_78113_g.field_78796_g = 0.0f;
                    this.field_78113_g.field_78795_f = 0.5f;
                    this.field_78113_g.field_78808_h = 0.5f;
                    this.field_78112_f.field_78796_g = 0.0f;
                    this.field_78112_f.field_78795_f = 0.5f;
                    this.field_78112_f.field_78808_h = -0.5f;
                    if (par7Entity.func_70093_af()) {
                        this.field_78113_g.field_78795_f = 0.9f;
                        this.field_78112_f.field_78795_f = 0.9f;
                        this.field_78113_g.field_78808_h = 0.8f;
                        this.field_78112_f.field_78808_h = -0.8f;
                    }
                }
            }
        }
        this.finger01.field_78795_f = this.field_78112_f.field_78795_f;
        this.finger01.field_78796_g = this.field_78112_f.field_78796_g;
        this.finger01.field_78808_h = this.field_78112_f.field_78808_h;
        this.finger01.field_78800_c = this.field_78112_f.field_78800_c;
        this.finger01.field_78797_d = this.field_78112_f.field_78797_d;
        this.finger01.field_78798_e = this.field_78112_f.field_78798_e;
        this.finger01.field_78807_k = this.field_78112_f.field_78807_k;
        this.finger01.field_82906_o = this.field_78112_f.field_82906_o;
        this.finger01.field_82908_p = this.field_78112_f.field_82908_p;
        this.finger01.field_82907_q = this.field_78112_f.field_82907_q;
        this.finger02.field_78795_f = this.field_78112_f.field_78795_f;
        this.finger02.field_78796_g = this.field_78112_f.field_78796_g;
        this.finger02.field_78808_h = this.field_78112_f.field_78808_h;
        this.finger02.field_78800_c = this.field_78112_f.field_78800_c - 0.2f;
        this.finger02.field_78797_d = this.field_78112_f.field_78797_d;
        this.finger02.field_78798_e = this.field_78112_f.field_78798_e;
        this.finger02.field_78807_k = this.field_78112_f.field_78807_k;
        this.finger02.field_82906_o = this.field_78112_f.field_82906_o;
        this.finger02.field_82908_p = this.field_78112_f.field_82908_p;
        this.finger02.field_82907_q = this.field_78112_f.field_82907_q;
    }
    
    public void func_78110_b(final float par1) {
        this.field_78121_j.field_78796_g = this.field_78116_c.field_78796_g;
        this.field_78121_j.field_78795_f = this.field_78116_c.field_78795_f;
        this.field_78121_j.field_78800_c = 0.0f;
        this.field_78121_j.field_78797_d = 0.0f;
        this.field_78121_j.func_78785_a(par1);
    }
    
    public void func_78111_c(final float par1) {
        this.field_78122_k.func_78785_a(par1);
    }
    
    public void renderBackpack(final float par7, final Entity par1Entity) {
        if (par1Entity instanceof EntityPlayer) {
            GL11.glPushMatrix();
            final EntityPlayer entp = (EntityPlayer)par1Entity;
            int backpackType = 0;
            final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get(entp).inventory;
            if (inventorydaym.inventory == null || inventorydaym.inventory[5] == null) {
                GL11.glPopMatrix();
                return;
            }
            if (inventorydaym.inventory[5].func_77973_b() instanceof ItemWithInventory) {
                final ItemWithInventory iwi = (ItemWithInventory)inventorydaym.inventory[5].func_77973_b();
                backpackType = iwi.clothingID;
                TextureRegistry.bindResource(TextureRegistry.backpack[backpackType]);
            }
            if (inventorydaym.inventory[5].func_77973_b() == ItemRegistry.item_parachute) {
                backpackType = 2;
                TextureRegistry.bindResource(TextureRegistry.backpack[backpackType]);
            }
            if (this.field_78117_n) {
                if (par1Entity.field_70169_q != par1Entity.field_70165_t || par1Entity.field_70166_s != par1Entity.field_70161_v || par1Entity instanceof EntityPlayerSP) {}
                GL11.glTranslatef(0.0f, 0.1f, 0.0f);
                GL11.glRotatef(25.0f, 1.0f, 0.0f, 0.0f);
            }
            if (backpackType == 2 || backpackType == 5) {
                if (!DayMConfig.daym_8fd972390) {
                    this.backpackSimple.func_78785_a(par7);
                }
                else {
                    GL11.glTranslatef(0.0f, 0.03f, -0.07f);
                    GL11.glScalef(1.0f, 1.0f, 1.3f);
                    this.backpack.func_78785_a(par7);
                    this.backpackP2.func_78785_a(par7);
                    this.backpackP3.func_78785_a(par7);
                    this.backpackP4.func_78785_a(par7);
                    this.backpackP5.func_78785_a(par7);
                    this.backpackP6.func_78785_a(par7);
                    GL11.glScalef(0.8f, 0.8f, 0.6f);
                }
            }
            if (backpackType == 0) {
                GL11.glScalef(0.8f, 0.95f, 0.85f);
                GL11.glTranslatef(0.0f, -0.065f, 0.0f);
                this.backpackCoyote.func_78088_a(par1Entity, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
            }
            if (backpackType == 1) {
                GL11.glScalef(1.3f, 1.3f, 1.3f);
                GL11.glTranslatef(0.0f, 0.0f, -0.04f);
                this.backpackAlice.func_78088_a(par1Entity, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
            }
            if (backpackType == 3) {
                this.backpackCzech.func_78088_a(par1Entity, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
            }
            if (backpackType == 4) {
                this.backpackCzechPouch.func_78088_a(par1Entity, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
            }
            if (this.field_78117_n) {
                GL11.glRotatef(25.0f, -1.0f, 0.0f, 0.0f);
            }
            this.renderParachute(par7, entp);
            GL11.glPopMatrix();
        }
    }
    
    private void renderParachute(final float par7, final EntityPlayer entp) {
        final PlayerInventoryDayM inventorydaym = ExtendedPlayer.get(entp).inventory;
        if (entp instanceof EntityOtherPlayerMP) {
            boolean onGround = true;
            if (entp.field_70170_p.func_147439_a((int)entp.field_70165_t, (int)entp.field_70163_u, (int)entp.field_70161_v).func_149688_o() == Material.field_151579_a && entp.field_70170_p.func_147439_a((int)entp.field_70165_t, (int)entp.field_70163_u - 1, (int)entp.field_70161_v).func_149688_o() == Material.field_151579_a) {
                onGround = false;
            }
            if (inventorydaym.inventory[5] != null && inventorydaym.inventory[5].func_77973_b() == ItemRegistry.item_parachute && entp.field_70167_r + 0.01 > entp.field_70163_u - 0.01 && !onGround) {
                GL11.glPushMatrix();
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                final double motionX = entp.field_70169_q - entp.field_70165_t;
                final double motionZ = entp.field_70166_s - entp.field_70161_v;
                GL11.glRotatef(180.0f - (float)((Math.abs(motionX / 2.0) + Math.abs(motionZ / 2.0)) * 90.0), 1.0f, 0.0f, 0.0f);
                GL11.glScalef(0.6f, 0.6f, 0.6f);
                GL11.glTranslatef(0.0f, 0.3f, -0.3f);
                if (entp.func_70093_af()) {
                    GL11.glTranslatef(0.0f, 0.2f, 0.0f);
                }
                RenderSetup.daym_736d8e4e0.renderTextured(TextureRegistry.tex_parachute);
                GL11.glDisable(3042);
                GL11.glPopMatrix();
            }
        }
        else if (inventorydaym.inventory[5] != null && inventorydaym.inventory[5].func_77973_b() == ItemRegistry.item_parachute && entp.field_70143_R > 3.0f) {
            GL11.glPushMatrix();
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            final float fallAlpha = Math.abs((2.0f - entp.field_70143_R) / 6.0f);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, fallAlpha);
            GL11.glRotatef(180.0f - (float)((Math.abs(entp.field_70159_w) + Math.abs(entp.field_70179_y)) * 90.0), 1.0f, 0.0f, 0.0f);
            GL11.glScalef(0.6f, 0.6f, 0.6f);
            GL11.glTranslatef(0.0f, 0.3f, -0.3f);
            if (entp.func_70093_af()) {
                GL11.glTranslatef(0.0f, 0.2f, 0.0f);
            }
            RenderSetup.daym_736d8e4e0.renderTextured(TextureRegistry.tex_parachute);
            GL11.glDisable(3042);
            GL11.glPopMatrix();
        }
    }
}
