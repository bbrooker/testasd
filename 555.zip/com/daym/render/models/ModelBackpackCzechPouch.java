package com.daym.render.models;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelBackpackCzechPouch extends ModelBase
{
    public ModelRenderer BackPack_Main1;
    public ModelRenderer BackPack_Main2;
    public ModelRenderer BackPack_Main3;
    public ModelRenderer BackPack_Main4;
    public ModelRenderer BackPack_Back;
    
    public ModelBackpackCzechPouch() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        (this.BackPack_Back = new ModelRenderer((ModelBase)this, 48, 7)).func_78793_a(-3.5f, 0.6f, 1.4f);
        this.BackPack_Back.func_78789_a(0.0f, 0.0f, 0.0f, 7, 11, 1);
        (this.BackPack_Main3 = new ModelRenderer((ModelBase)this, 0, 16)).func_78793_a(-2.5f, 1.2f, 3.2f);
        this.BackPack_Main3.func_78789_a(0.0f, 0.0f, 0.0f, 5, 4, 1);
        (this.BackPack_Main2 = new ModelRenderer((ModelBase)this, 0, 0)).func_78793_a(-3.5f, 6.5f, 1.5f);
        this.BackPack_Main2.func_78789_a(0.0f, 0.0f, 0.0f, 7, 5, 2);
        (this.BackPack_Main4 = new ModelRenderer((ModelBase)this, 0, 16)).func_78793_a(-2.5f, 7.0f, 3.2f);
        this.BackPack_Main4.func_78789_a(0.0f, 0.0f, 0.0f, 5, 4, 1);
        (this.BackPack_Main1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78793_a(-3.5f, 0.7f, 1.5f);
        this.BackPack_Main1.func_78789_a(0.0f, 0.0f, 0.0f, 7, 5, 2);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.BackPack_Back.func_78785_a(f5);
        this.BackPack_Main3.func_78785_a(f5);
        this.BackPack_Main2.func_78785_a(f5);
        this.BackPack_Main4.func_78785_a(f5);
        this.BackPack_Main1.func_78785_a(f5);
    }
    
    public void setRotateAngle(final ModelRenderer modelRenderer, final float x, final float y, final float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }
}
