package com.daym.render.models;

import net.minecraft.client.model.*;
import org.lwjgl.opengl.*;

public class ModelRendererExtended extends ModelRenderer
{
    public ModelRendererExtended(final ModelBase arg0) {
        super(arg0);
    }
    
    public ModelRendererExtended(final ModelBipedDayM modelBipedDayM, final int i, final int j) {
        super((ModelBase)modelBipedDayM, i, j);
    }
    
    public void render(final float r, final float sc) {
        GL11.glPushMatrix();
        GL11.glScalef(sc, sc, sc);
        super.func_78785_a(r);
        GL11.glPopMatrix();
    }
}
