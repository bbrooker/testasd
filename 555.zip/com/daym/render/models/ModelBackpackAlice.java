package com.daym.render.models;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelBackpackAlice extends ModelBase
{
    ModelRenderer BackpackMain;
    ModelRenderer BackPackTop;
    ModelRenderer BackPackFront1;
    ModelRenderer BackPackFront2;
    ModelRenderer BackPackFront3;
    ModelRenderer BackPackSide1;
    ModelRenderer BackPackSide2;
    
    public ModelBackpackAlice() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        (this.BackpackMain = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 7, 6, 3);
        this.BackpackMain.func_78793_a(-3.5f, 1.5f, 2.0f);
        this.BackpackMain.func_78787_b(64, 32);
        this.BackpackMain.field_78809_i = true;
        this.setRotation(this.BackpackMain, 0.0f, 0.0f, 0.0f);
        (this.BackPackTop = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 6, 1, 2);
        this.BackPackTop.func_78793_a(-3.0f, 1.0f, 2.5f);
        this.BackPackTop.func_78787_b(64, 32);
        this.BackPackTop.field_78809_i = true;
        this.setRotation(this.BackPackTop, 0.0f, 0.0f, 0.0f);
        (this.BackPackFront1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 2, 4, 1);
        this.BackPackFront1.func_78793_a(1.2f, 2.5f, 4.8f);
        this.BackPackFront1.func_78787_b(64, 32);
        this.BackPackFront1.field_78809_i = true;
        this.setRotation(this.BackPackFront1, 0.0f, 0.0f, 0.0f);
        (this.BackPackFront2 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 2, 4, 1);
        this.BackPackFront2.func_78793_a(-1.0f, 2.5f, 4.8f);
        this.BackPackFront2.func_78787_b(64, 32);
        this.BackPackFront2.field_78809_i = true;
        this.setRotation(this.BackPackFront2, 0.0f, 0.0f, 0.0f);
        (this.BackPackFront3 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 2, 4, 1);
        this.BackPackFront3.func_78793_a(-3.2f, 2.5f, 4.8f);
        this.BackPackFront3.func_78787_b(64, 32);
        this.BackPackFront3.field_78809_i = true;
        this.setRotation(this.BackPackFront3, 0.0f, 0.0f, 0.0f);
        (this.BackPackSide1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 5, 2);
        this.BackPackSide1.func_78793_a(-3.8f, 2.0f, 2.5f);
        this.BackPackSide1.func_78787_b(64, 32);
        this.BackPackSide1.field_78809_i = true;
        this.setRotation(this.BackPackSide1, 0.0f, 0.0f, 0.0f);
        (this.BackPackSide2 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 5, 2);
        this.BackPackSide2.func_78793_a(2.8f, 2.0f, 2.5f);
        this.BackPackSide2.func_78787_b(64, 32);
        this.BackPackSide2.field_78809_i = true;
        this.setRotation(this.BackPackSide2, 0.0f, 0.0f, 0.0f);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
        this.func_78087_a(f, f1, f2, f3, f4, f5, entity);
        this.BackpackMain.func_78785_a(f5);
        this.BackPackTop.func_78785_a(f5);
        this.BackPackFront1.func_78785_a(f5);
        this.BackPackFront2.func_78785_a(f5);
        this.BackPackFront3.func_78785_a(f5);
        this.BackPackSide1.func_78785_a(f5);
        this.BackPackSide2.func_78785_a(f5);
    }
    
    private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
        model.field_78795_f = x;
        model.field_78796_g = y;
        model.field_78808_h = z;
    }
    
    public void func_78087_a(final float f, final float f1, final float f2, final float f3, final float f4, final float f5, final Entity ent) {
        super.func_78087_a(f, f1, f2, f3, f4, f5, ent);
    }
}
