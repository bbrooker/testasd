package com.daym.render.models;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelBackpackCzech extends ModelBase
{
    public ModelRenderer BackPack_Main;
    public ModelRenderer BackPack_BottomPouch;
    public ModelRenderer BackPack_RightPouch;
    public ModelRenderer BackPack_LeftPouch;
    public ModelRenderer BackPack_TopPouch;
    public ModelRenderer BackPack_Top;
    
    public ModelBackpackCzech() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        (this.BackPack_TopPouch = new ModelRenderer((ModelBase)this, 28, 2)).func_78793_a(-2.5f, 0.7f, 4.3f);
        this.BackPack_TopPouch.func_78789_a(0.0f, 0.0f, 0.0f, 5, 5, 1);
        (this.BackPack_LeftPouch = new ModelRenderer((ModelBase)this, 22, 9)).func_78793_a(2.3f, 6.0f, 2.5f);
        this.BackPack_LeftPouch.func_78789_a(0.0f, 0.0f, 0.0f, 2, 5, 3);
        (this.BackPack_BottomPouch = new ModelRenderer((ModelBase)this, 30, 18)).func_78793_a(-2.0f, 6.5f, 5.8f);
        this.BackPack_BottomPouch.func_78789_a(0.0f, 0.0f, 0.0f, 4, 4, 1);
        (this.BackPack_RightPouch = new ModelRenderer((ModelBase)this, 40, 9)).func_78793_a(-4.3f, 6.0f, 2.5f);
        this.BackPack_RightPouch.func_78789_a(0.0f, 0.0f, 0.0f, 2, 5, 3);
        (this.BackPack_Main = new ModelRenderer((ModelBase)this, 1, 14)).func_78793_a(-3.0f, -0.5f, 2.0f);
        this.BackPack_Main.func_78789_a(0.0f, 0.0f, 0.0f, 6, 12, 4);
        (this.BackPack_Top = new ModelRenderer((ModelBase)this, 1, 14)).func_78793_a(-2.5f, -0.9f, 2.5f);
        this.BackPack_Top.func_78789_a(0.0f, 0.0f, 0.0f, 5, 1, 3);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.BackPack_TopPouch.func_78785_a(f5);
        this.BackPack_LeftPouch.func_78785_a(f5);
        this.BackPack_BottomPouch.func_78785_a(f5);
        this.BackPack_RightPouch.func_78785_a(f5);
        this.BackPack_Main.func_78785_a(f5);
        this.BackPack_Top.func_78785_a(f5);
    }
    
    public void setRotateAngle(final ModelRenderer modelRenderer, final float x, final float y, final float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }
}
