package com.daym.render.models;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelBackpackCoyote extends ModelBase
{
    public ModelRenderer BackPack_Main1;
    public ModelRenderer BackPack_Main2;
    public ModelRenderer BackPack_RightPouch1;
    public ModelRenderer BackPack_RightPouch2;
    public ModelRenderer BackPack_LeftPouch1;
    public ModelRenderer BackPack_LeftPouch2;
    public ModelRenderer BackPack_FrontPouch1;
    public ModelRenderer BackPack_FrontPouch1_1;
    public ModelRenderer BackPack_Top;
    
    public ModelBackpackCoyote() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        (this.BackPack_Main2 = new ModelRenderer((ModelBase)this, 28, 20)).func_78793_a(-4.0f, 2.0f, 6.0f);
        this.BackPack_Main2.func_78789_a(0.0f, 0.0f, 0.0f, 8, 10, 1);
        (this.BackPack_LeftPouch1 = new ModelRenderer((ModelBase)this, 9, 19)).func_78793_a(3.7f, 5.3f, 2.5f);
        this.BackPack_LeftPouch1.func_78789_a(0.0f, 0.0f, 0.0f, 2, 6, 4);
        (this.BackPack_FrontPouch1_1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78793_a(-3.0f, 3.5f, 6.7f);
        this.BackPack_FrontPouch1_1.func_78789_a(0.0f, 0.0f, 0.0f, 6, 8, 1);
        (this.BackPack_LeftPouch2 = new ModelRenderer((ModelBase)this, 0, 19)).func_78793_a(3.7f, 4.8f, 3.0f);
        this.BackPack_LeftPouch2.func_78789_a(0.0f, 0.0f, 0.0f, 1, 7, 3);
        (this.BackPack_Main1 = new ModelRenderer((ModelBase)this, 24, 4)).func_78793_a(-4.0f, 0.9f, 2.0f);
        this.BackPack_Main1.func_78789_a(0.0f, 0.0f, 0.0f, 8, 11, 4);
        (this.BackPack_FrontPouch1 = new ModelRenderer((ModelBase)this, 0, 10)).func_78793_a(-3.0f, 7.0f, 6.5f);
        this.BackPack_FrontPouch1.func_78789_a(0.0f, 0.0f, 0.0f, 6, 4, 2);
        (this.BackPack_RightPouch2 = new ModelRenderer((ModelBase)this, 0, 19)).func_78793_a(-4.7f, 4.8f, 3.0f);
        this.BackPack_RightPouch2.func_78789_a(0.0f, 0.0f, 0.0f, 1, 7, 3);
        (this.BackPack_RightPouch1 = new ModelRenderer((ModelBase)this, 9, 19)).func_78793_a(-5.3f, 5.3f, 2.5f);
        this.BackPack_RightPouch1.func_78789_a(0.0f, 0.0f, 0.0f, 2, 6, 4);
        (this.BackPack_Top = new ModelRenderer((ModelBase)this, 27, 0)).func_78793_a(-3.5f, 0.7f, 2.0f);
        this.BackPack_Top.func_78789_a(0.0f, 0.0f, 0.0f, 7, 1, 2);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.BackPack_Main2.func_78785_a(f5);
        this.BackPack_LeftPouch1.func_78785_a(f5);
        this.BackPack_FrontPouch1_1.func_78785_a(f5);
        this.BackPack_LeftPouch2.func_78785_a(f5);
        this.BackPack_Main1.func_78785_a(f5);
        this.BackPack_FrontPouch1.func_78785_a(f5);
        this.BackPack_RightPouch2.func_78785_a(f5);
        this.BackPack_RightPouch1.func_78785_a(f5);
        this.BackPack_Top.func_78785_a(f5);
    }
    
    public void setRotateAngle(final ModelRenderer modelRenderer, final float x, final float y, final float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }
}
