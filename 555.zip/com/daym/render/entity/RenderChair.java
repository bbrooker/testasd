package com.daym.render.entity;

import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;

public class RenderChair extends Render
{
    public void func_76986_a(final Entity chair, final double arg1, final double arg2, final double arg3, final float arg4, final float arg5) {
    }
    
    protected ResourceLocation func_110775_a(final Entity arg0) {
        return null;
    }
}
