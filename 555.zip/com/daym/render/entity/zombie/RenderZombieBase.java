package com.daym.render.entity.zombie;

import net.minecraft.client.renderer.entity.*;
import net.minecraft.util.*;
import net.minecraft.client.model.*;
import net.minecraft.entity.*;
import com.daym.entity.zombie.*;
import com.daym.registry.*;

public class RenderZombieBase extends RenderLiving
{
    protected ResourceLocation renderTexture;
    
    public RenderZombieBase() {
        super((ModelBase)new ModelBiped(), 0.0f);
    }
    
    protected ResourceLocation func_110775_a(final Entity ent) {
        ResourceLocation res = null;
        if (ent instanceof EntityZombieBase) {
            res = TextureRegistry.getZombieTexture(((EntityZombieBase)ent).zombieTexture);
        }
        return res;
    }
}
