package com.daym.render.entity;

import cpw.mods.fml.relauncher.*;
import com.daym.render.models.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.model.*;
import net.minecraftforge.common.*;
import net.minecraftforge.client.event.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.eventhandler.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.*;
import com.daym.gui.*;
import com.daym.registry.*;
import com.daym.items.*;
import net.minecraft.client.entity.*;
import net.minecraftforge.client.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.*;
import net.minecraft.init.*;
import java.util.*;
import com.mojang.authlib.*;
import net.minecraft.client.renderer.tileentity.*;
import net.minecraft.util.*;
import com.daym.*;
import com.daym.config.*;
import com.daym.handlers.*;
import net.minecraft.item.*;
import com.daym.render.*;
import net.minecraft.nbt.*;
import net.minecraft.scoreboard.*;

@SideOnly(Side.CLIENT)
public class RenderPlayerDayM extends RenderPlayer
{
    private static final ResourceLocation steveTextures;
    public ModelBipedDayM field_77109_a;
    public ModelBipedDayM field_77108_b;
    public ModelBipedDayM field_77111_i;
    private static final String __OBFID = "CL_00001020";
    
    public RenderPlayerDayM() {
        this.field_77045_g = (ModelBase)new ModelBipedDayM(0.0f);
        super.field_77045_g = this.field_77045_g;
        this.field_77109_a = (ModelBipedDayM)this.field_77045_g;
        this.field_77108_b = new ModelBipedDayM(1.0f);
        this.field_77111_i = new ModelBipedDayM(0.5f);
    }
    
    protected int func_77032_a(final AbstractClientPlayer p_77032_1_, final int p_77032_2_, final float p_77032_3_) {
        final ItemStack itemstack = p_77032_1_.field_71071_by.func_70440_f(3 - p_77032_2_);
        if (itemstack != null) {
            final Item item = itemstack.func_77973_b();
            if (item instanceof ItemArmor && !(item instanceof ItemDayMArmor)) {
                final ItemArmor itemarmor = (ItemArmor)item;
                this.func_110776_a(RenderBiped.getArmorResource((Entity)p_77032_1_, itemstack, p_77032_2_, (String)null));
                ModelBiped modelbiped = (p_77032_2_ == 2) ? super.field_77111_i : super.field_77108_b;
                modelbiped.field_78116_c.field_78806_j = (p_77032_2_ == 0);
                modelbiped.field_78114_d.field_78806_j = (p_77032_2_ == 0);
                modelbiped.field_78115_e.field_78806_j = (p_77032_2_ == 1 || p_77032_2_ == 2);
                modelbiped.field_78112_f.field_78806_j = (p_77032_2_ == 1);
                modelbiped.field_78113_g.field_78806_j = (p_77032_2_ == 1);
                modelbiped.field_78123_h.field_78806_j = (p_77032_2_ == 2 || p_77032_2_ == 3);
                modelbiped.field_78124_i.field_78806_j = (p_77032_2_ == 2 || p_77032_2_ == 3);
                modelbiped = ForgeHooksClient.getArmorModel((EntityLivingBase)p_77032_1_, itemstack, p_77032_2_, modelbiped);
                this.func_77042_a((ModelBase)modelbiped);
                modelbiped.field_78095_p = this.field_77045_g.field_78095_p;
                modelbiped.field_78093_q = this.field_77045_g.field_78093_q;
                modelbiped.field_78091_s = this.field_77045_g.field_78091_s;
                final int j = -1;
                if (j != -1) {
                    final float f1 = (j >> 16 & 0xFF) / 255.0f;
                    final float f2 = (j >> 8 & 0xFF) / 255.0f;
                    final float f3 = (j & 0xFF) / 255.0f;
                    GL11.glColor3f(f1, f2, f3);
                    if (itemstack.func_77948_v()) {
                        return 31;
                    }
                    return 16;
                }
                else {
                    GL11.glColor3f(1.0f, 1.0f, 1.0f);
                    if (itemstack.func_77948_v()) {
                        return 15;
                    }
                    return 1;
                }
            }
        }
        return -1;
    }
    
    public void func_76986_a(final AbstractClientPlayer p_76986_1_, final double p_76986_2_, final double p_76986_4_, final double p_76986_6_, final float p_76986_8_, final float p_76986_9_) {
        if (MinecraftForge.EVENT_BUS.post((Event)new RenderPlayerEvent.Pre((EntityPlayer)p_76986_1_, (RenderPlayer)this, p_76986_9_))) {
            return;
        }
        final Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71462_r == null || mc.field_71462_r instanceof GuiIngameMenuDayM || mc.field_71462_r instanceof GuiChat || mc.field_71462_r instanceof GuiDayMOptions || mc.field_71462_r instanceof GuiLootSpawner || mc.field_71462_r instanceof GuiZombieSpawner || mc.field_71462_r instanceof GuiPlayerSpawner) {
            if (p_76986_1_ == mc.field_71439_g && mc.field_71474_y.field_74320_O == 0) {
                if (!mc.field_71439_g.field_70128_L) {
                    this.field_77109_a.field_78116_c.field_78807_k = true;
                    this.field_77109_a.field_78114_d.field_78807_k = true;
                }
                boolean hasGun = false;
                boolean daym_c46b8fa90 = false;
                if (mc.field_71439_g.field_71071_by.func_70448_g() != null && ItemRegistry.gunList.contains(mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b())) {
                    hasGun = true;
                    if (((ItemDayMGun)mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b()).daym_c46b8fa90) {
                        daym_c46b8fa90 = true;
                    }
                }
                if (hasGun) {
                    this.field_77109_a.field_78112_f.field_78807_k = true;
                    this.field_77109_a.field_78113_g.field_78807_k = true;
                }
            }
            else {
                this.field_77109_a.field_78116_c.field_78807_k = false;
                this.field_77109_a.field_78114_d.field_78807_k = false;
                this.field_77109_a.field_78112_f.field_78807_k = false;
                this.field_77109_a.field_78113_g.field_78807_k = false;
            }
        }
        else {
            this.field_77109_a.field_78116_c.field_78807_k = false;
            this.field_77109_a.field_78114_d.field_78807_k = false;
            this.field_77109_a.field_78112_f.field_78807_k = false;
            this.field_77109_a.field_78113_g.field_78807_k = false;
        }
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        final ItemStack itemstack = p_76986_1_.field_71071_by.func_70448_g();
        final ModelBipedDayM field_77108_b = this.field_77108_b;
        final ModelBipedDayM field_77111_i = this.field_77111_i;
        final ModelBipedDayM field_77109_a = this.field_77109_a;
        final boolean field_78120_m;
        final boolean b = field_78120_m = (((itemstack != null) ? 1 : 0) != 0);
        field_77109_a.field_78120_m = (b ? 1 : 0);
        field_77111_i.field_78120_m = (b ? 1 : 0);
        field_77108_b.field_78120_m = (field_78120_m ? 1 : 0);
        if (itemstack != null && p_76986_1_.func_71052_bv() > 0) {
            final EnumAction enumaction = itemstack.func_77975_n();
            if (enumaction == EnumAction.block) {
                final ModelBipedDayM field_77108_b2 = this.field_77108_b;
                final ModelBipedDayM field_77111_i2 = this.field_77111_i;
                final ModelBipedDayM field_77109_a2 = this.field_77109_a;
                final int field_78120_m2 = 3;
                field_77109_a2.field_78120_m = field_78120_m2;
                field_77111_i2.field_78120_m = field_78120_m2;
                field_77108_b2.field_78120_m = field_78120_m2;
            }
            else if (enumaction == EnumAction.bow) {
                final ModelBipedDayM field_77108_b3 = this.field_77108_b;
                final ModelBipedDayM field_77111_i3 = this.field_77111_i;
                final ModelBipedDayM field_77109_a3 = this.field_77109_a;
                final boolean field_78118_o = true;
                field_77109_a3.field_78118_o = field_78118_o;
                field_77111_i3.field_78118_o = field_78118_o;
                field_77108_b3.field_78118_o = field_78118_o;
            }
        }
        final ModelBipedDayM field_77108_b4 = this.field_77108_b;
        final ModelBipedDayM field_77111_i4 = this.field_77111_i;
        final ModelBipedDayM field_77109_a4 = this.field_77109_a;
        final boolean func_70093_af = p_76986_1_.func_70093_af();
        field_77109_a4.field_78117_n = func_70093_af;
        field_77111_i4.field_78117_n = func_70093_af;
        field_77108_b4.field_78117_n = func_70093_af;
        double d3 = p_76986_4_ - p_76986_1_.field_70129_M;
        if (p_76986_1_.func_70093_af() && !(p_76986_1_ instanceof EntityPlayerSP)) {
            d3 -= 0.125;
        }
        GL11.glPushMatrix();
        if (p_76986_1_ instanceof EntityPlayerSP) {
            GL11.glTranslatef(0.0f, 1.6f, 0.0f);
        }
        super.func_76986_a(p_76986_1_, p_76986_2_, d3, p_76986_6_, p_76986_8_, p_76986_9_);
        GL11.glPopMatrix();
        final ModelBipedDayM field_77108_b5 = this.field_77108_b;
        final ModelBipedDayM field_77111_i5 = this.field_77111_i;
        final ModelBipedDayM field_77109_a5 = this.field_77109_a;
        final boolean field_78118_o2 = false;
        field_77109_a5.field_78118_o = field_78118_o2;
        field_77111_i5.field_78118_o = field_78118_o2;
        field_77108_b5.field_78118_o = field_78118_o2;
        final ModelBipedDayM field_77108_b6 = this.field_77108_b;
        final ModelBipedDayM field_77111_i6 = this.field_77111_i;
        final ModelBipedDayM field_77109_a6 = this.field_77109_a;
        final boolean field_78117_n = false;
        field_77109_a6.field_78117_n = field_78117_n;
        field_77111_i6.field_78117_n = field_78117_n;
        field_77108_b6.field_78117_n = field_78117_n;
        final ModelBipedDayM field_77108_b7 = this.field_77108_b;
        final ModelBipedDayM field_77111_i7 = this.field_77111_i;
        final ModelBipedDayM field_77109_a7 = this.field_77109_a;
        final boolean field_78120_m3 = false;
        field_77109_a7.field_78120_m = (field_78120_m3 ? 1 : 0);
        field_77111_i7.field_78120_m = (field_78120_m3 ? 1 : 0);
        field_77108_b7.field_78120_m = (field_78120_m3 ? 1 : 0);
        MinecraftForge.EVENT_BUS.post((Event)new RenderPlayerEvent.Post((EntityPlayer)p_76986_1_, (RenderPlayer)this, p_76986_9_));
    }
    
    protected ResourceLocation func_110775_a(final AbstractClientPlayer p_110775_1_) {
        return p_110775_1_.func_110306_p();
    }
    
    public void func_77029_c(final AbstractClientPlayer p_77029_1_, final float p_77029_2_) {
        final RenderPlayerEvent.Specials.Pre event = new RenderPlayerEvent.Specials.Pre((EntityPlayer)p_77029_1_, (RenderPlayer)this, p_77029_2_);
        if (MinecraftForge.EVENT_BUS.post((Event)event)) {
            return;
        }
        final float f14 = p_77029_1_.func_70013_c(p_77029_2_);
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        if (this.field_77109_a.field_78116_c.field_78807_k && !p_77029_1_.func_70115_ae()) {
            if (p_77029_1_.field_70125_A > 0.0f) {
                GL11.glScalef(1.0f, 1.0f, 1.0f - Math.abs((90.0f - p_77029_1_.field_70125_A) / 40.0f) / 2.0f / 4.0f);
                GL11.glTranslatef(0.0f, 0.0f, -(Math.abs((90.0f - p_77029_1_.field_70125_A) / 40.0f) / 2.0f / 10.0f) - 0.05f);
            }
            else {
                GL11.glScalef(1.0f, 1.0f, 1.0f - Math.abs((90.0f + p_77029_1_.field_70125_A) / 40.0f) / 2.0f / 4.0f);
                GL11.glTranslatef(0.0f, 0.0f, -(Math.abs((90.0f + p_77029_1_.field_70125_A) / 40.0f) / 2.0f / 10.0f) - 0.05f);
            }
        }
        super.func_85093_e((EntityLivingBase)p_77029_1_, p_77029_2_);
        final ItemStack itemstack = p_77029_1_.field_71071_by.func_70440_f(3);
        if (itemstack != null && event.renderHelmet) {
            GL11.glPushMatrix();
            this.field_77109_a.field_78116_c.func_78794_c(0.0625f);
            if (itemstack.func_77973_b() instanceof ItemBlock) {
                final IItemRenderer customRenderer = MinecraftForgeClient.getItemRenderer(itemstack, IItemRenderer.ItemRenderType.EQUIPPED);
                final boolean is3D = customRenderer != null && customRenderer.shouldUseRenderHelper(IItemRenderer.ItemRenderType.EQUIPPED, itemstack, IItemRenderer.ItemRendererHelper.BLOCK_3D);
                if (is3D || RenderBlocks.func_147739_a(Block.func_149634_a(itemstack.func_77973_b()).func_149645_b())) {
                    final float f15 = 0.625f;
                    GL11.glTranslatef(0.0f, -0.25f, 0.0f);
                    GL11.glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
                    GL11.glScalef(f15, -f15, -f15);
                }
                this.field_76990_c.field_78721_f.func_78443_a((EntityLivingBase)p_77029_1_, itemstack, 0);
            }
            else if (itemstack.func_77973_b() == Items.field_151144_bL) {
                final float f16 = 1.0625f;
                GL11.glScalef(f16, -f16, -f16);
                GameProfile gameprofile = null;
                if (itemstack.func_77942_o()) {
                    final NBTTagCompound nbttagcompound = itemstack.func_77978_p();
                    if (nbttagcompound.func_150297_b("SkullOwner", 10)) {
                        gameprofile = NBTUtil.func_152459_a(nbttagcompound.func_74775_l("SkullOwner"));
                    }
                    else if (nbttagcompound.func_150297_b("SkullOwner", 8) && !StringUtils.func_151246_b(nbttagcompound.func_74779_i("SkullOwner"))) {
                        gameprofile = new GameProfile((UUID)null, nbttagcompound.func_74779_i("SkullOwner"));
                    }
                }
                TileEntitySkullRenderer.field_147536_b.func_152674_a(-0.5f, 0.0f, -0.5f, 1, 180.0f, itemstack.func_77960_j(), gameprofile);
            }
            GL11.glPopMatrix();
        }
        if (p_77029_1_.func_70005_c_().equals("deadmau5") && p_77029_1_.func_152123_o()) {
            this.func_110776_a(p_77029_1_.func_110306_p());
            for (int j = 0; j < 2; ++j) {
                final float f17 = p_77029_1_.field_70126_B + (p_77029_1_.field_70177_z - p_77029_1_.field_70126_B) * p_77029_2_ - (p_77029_1_.field_70760_ar + (p_77029_1_.field_70761_aq - p_77029_1_.field_70760_ar) * p_77029_2_);
                final float f18 = p_77029_1_.field_70127_C + (p_77029_1_.field_70125_A - p_77029_1_.field_70127_C) * p_77029_2_;
                GL11.glPushMatrix();
                GL11.glRotatef(f17, 0.0f, 1.0f, 0.0f);
                GL11.glRotatef(f18, 1.0f, 0.0f, 0.0f);
                GL11.glTranslatef(0.375f * (j * 2 - 1), 0.0f, 0.0f);
                GL11.glTranslatef(0.0f, -0.375f, 0.0f);
                GL11.glRotatef(-f18, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(-f17, 0.0f, 1.0f, 0.0f);
                final float f19 = 1.333333f;
                GL11.glScalef(f19, f19, f19);
                this.field_77109_a.func_78110_b(0.0625f);
                GL11.glPopMatrix();
            }
        }
        boolean flag = p_77029_1_.func_152122_n();
        flag = (event.renderCape && flag);
        if (flag && !p_77029_1_.func_82150_aj() && !p_77029_1_.func_82238_cc()) {
            this.func_110776_a(p_77029_1_.func_110303_q());
            GL11.glPushMatrix();
            GL11.glTranslatef(0.0f, 0.0f, 0.125f);
            final double d3 = p_77029_1_.field_71091_bM + (p_77029_1_.field_71094_bP - p_77029_1_.field_71091_bM) * p_77029_2_ - (p_77029_1_.field_70169_q + (p_77029_1_.field_70165_t - p_77029_1_.field_70169_q) * p_77029_2_);
            final double d4 = p_77029_1_.field_71096_bN + (p_77029_1_.field_71095_bQ - p_77029_1_.field_71096_bN) * p_77029_2_ - (p_77029_1_.field_70167_r + (p_77029_1_.field_70163_u - p_77029_1_.field_70167_r) * p_77029_2_);
            final double d5 = p_77029_1_.field_71097_bO + (p_77029_1_.field_71085_bR - p_77029_1_.field_71097_bO) * p_77029_2_ - (p_77029_1_.field_70166_s + (p_77029_1_.field_70161_v - p_77029_1_.field_70166_s) * p_77029_2_);
            final float f20 = p_77029_1_.field_70760_ar + (p_77029_1_.field_70761_aq - p_77029_1_.field_70760_ar) * p_77029_2_;
            final double d6 = MathHelper.func_76126_a(f20 * 3.141593f / 180.0f);
            final double d7 = -MathHelper.func_76134_b(f20 * 3.141593f / 180.0f);
            float f21 = (float)d4 * 10.0f;
            if (f21 < -6.0f) {
                f21 = -6.0f;
            }
            if (f21 > 32.0f) {
                f21 = 32.0f;
            }
            float f22 = (float)(d3 * d6 + d5 * d7) * 100.0f;
            final float f23 = (float)(d3 * d7 - d5 * d6) * 100.0f;
            if (f22 < 0.0f) {
                f22 = 0.0f;
            }
            final float f24 = p_77029_1_.field_71107_bF + (p_77029_1_.field_71109_bG - p_77029_1_.field_71107_bF) * p_77029_2_;
            f21 += MathHelper.func_76126_a((p_77029_1_.field_70141_P + (p_77029_1_.field_70140_Q - p_77029_1_.field_70141_P) * p_77029_2_) * 6.0f) * 32.0f * f24;
            if (p_77029_1_.func_70093_af()) {
                f21 += 25.0f;
            }
            GL11.glRotatef(6.0f + f22 / 2.0f + f21, 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(f23 / 2.0f, 0.0f, 0.0f, 1.0f);
            GL11.glRotatef(-f23 / 2.0f, 0.0f, 1.0f, 0.0f);
            GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
            this.field_77109_a.func_78111_c(0.0625f);
            GL11.glPopMatrix();
        }
        ItemStack itemstack2 = p_77029_1_.field_71071_by.func_70448_g();
        GL11.glPushMatrix();
        if (!this.field_77109_a.field_78116_c.field_78807_k && itemstack2 != null && ItemRegistry.gunList.contains(itemstack2.func_77973_b())) {
            final DayMConfig daym_748d583f0 = DayM.daym_748d583f0;
            if (!DayMConfig.daym_8fd972390) {
                final ItemDayMGun gun = (ItemDayMGun)itemstack2.func_77973_b();
                GL11.glScalef(gun.daym_a179deca0 / 1.3f, 1.5384616f, gun.daym_6d067a4e0 / 1.3f);
            }
        }
        if (PlayerVarHandler.daym_b73359c80.get(p_77029_1_.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(p_77029_1_.func_70005_c_()) == 3) {
            GL11.glTranslatef(0.0f, 0.0f, 0.4f);
        }
        if (itemstack2 != null && event.renderItem) {
            GL11.glPushMatrix();
            this.field_77109_a.field_78112_f.func_78794_c(0.0625f);
            GL11.glTranslatef(-0.0625f, 0.4375f, 0.0625f);
            if (p_77029_1_.field_71104_cf != null) {
                itemstack2 = new ItemStack(Items.field_151055_y);
            }
            EnumAction enumaction = null;
            if (p_77029_1_.func_71052_bv() > 0) {
                enumaction = itemstack2.func_77975_n();
            }
            final IItemRenderer customRenderer2 = MinecraftForgeClient.getItemRenderer(itemstack2, IItemRenderer.ItemRenderType.EQUIPPED);
            final boolean is3D2 = customRenderer2 != null && customRenderer2.shouldUseRenderHelper(IItemRenderer.ItemRenderType.EQUIPPED, itemstack2, IItemRenderer.ItemRendererHelper.BLOCK_3D);
            if (is3D2 || (itemstack2.func_77973_b() instanceof ItemBlock && RenderBlocks.func_147739_a(Block.func_149634_a(itemstack2.func_77973_b()).func_149645_b()))) {
                float f25 = 0.5f;
                GL11.glTranslatef(0.0f, 0.1875f, -0.3125f);
                f25 *= 0.75f;
                GL11.glRotatef(20.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
                GL11.glScalef(-f25, -f25, f25);
            }
            else if (itemstack2.func_77973_b() == Items.field_151031_f) {
                final float f25 = 0.625f;
                GL11.glTranslatef(0.0f, 0.125f, 0.3125f);
                GL11.glRotatef(-20.0f, 0.0f, 1.0f, 0.0f);
                GL11.glScalef(f25, -f25, f25);
                GL11.glRotatef(-100.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
            }
            else if (itemstack2.func_77973_b().func_77662_d()) {
                final float f25 = 0.625f;
                if (itemstack2.func_77973_b().func_77629_n_()) {
                    GL11.glRotatef(180.0f, 0.0f, 0.0f, 1.0f);
                    GL11.glTranslatef(0.0f, -0.125f, 0.0f);
                }
                if (p_77029_1_.func_71052_bv() > 0 && enumaction == EnumAction.block) {
                    GL11.glTranslatef(0.05f, 0.0f, -0.1f);
                    GL11.glRotatef(-50.0f, 0.0f, 1.0f, 0.0f);
                    GL11.glRotatef(-10.0f, 1.0f, 0.0f, 0.0f);
                    GL11.glRotatef(-60.0f, 0.0f, 0.0f, 1.0f);
                }
                GL11.glTranslatef(0.0f, 0.1875f, 0.0f);
                GL11.glScalef(f25, -f25, f25);
                GL11.glRotatef(-100.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
            }
            else {
                final float f25 = 0.375f;
                GL11.glTranslatef(0.25f, 0.1875f, -0.1875f);
                GL11.glScalef(f25, f25, f25);
                GL11.glRotatef(60.0f, 0.0f, 0.0f, 1.0f);
                GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(20.0f, 0.0f, 0.0f, 1.0f);
            }
            if (itemstack2.func_77973_b().func_77623_v()) {
                for (int k = 0; k < itemstack2.func_77973_b().getRenderPasses(itemstack2.func_77960_j()); ++k) {
                    if (!(itemstack2.func_77973_b() instanceof ItemPotion)) {
                        final int i = itemstack2.func_77973_b().func_82790_a(itemstack2, k);
                        final float f26 = (i >> 16 & 0xFF) / 255.0f;
                        final float f27 = (i >> 8 & 0xFF) / 255.0f;
                        final float f28 = (i & 0xFF) / 255.0f;
                        GL11.glColor4f(f26, f27, f28, 1.0f);
                        this.field_76990_c.field_78721_f.func_78443_a((EntityLivingBase)p_77029_1_, itemstack2, k);
                    }
                    else if (!this.field_77109_a.field_78116_c.field_78807_k) {
                        final int i = itemstack2.func_77973_b().func_82790_a(itemstack2, k);
                        final float f26 = (i >> 16 & 0xFF) / 255.0f;
                        final float f27 = (i >> 8 & 0xFF) / 255.0f;
                        final float f28 = (i & 0xFF) / 255.0f;
                        GL11.glColor4f(f26, f27, f28, 1.0f);
                        this.field_76990_c.field_78721_f.func_78443_a((EntityLivingBase)p_77029_1_, itemstack2, k);
                    }
                }
            }
            if (itemstack2 != null) {
                if (!(itemstack2.func_77973_b() instanceof ItemPotion)) {
                    if (!ItemRegistry.gunList.contains(itemstack2.func_77973_b())) {
                        final int k = itemstack2.func_77973_b().func_82790_a(itemstack2, 0);
                        final float f29 = (k >> 16 & 0xFF) / 255.0f;
                        final float f26 = (k >> 8 & 0xFF) / 255.0f;
                        final float f27 = (k & 0xFF) / 255.0f;
                        GL11.glColor4f(f29, f26, f27, 1.0f);
                        this.field_76990_c.field_78721_f.func_78443_a((EntityLivingBase)p_77029_1_, itemstack2, 0);
                        GL11.glColor4f(f14, f14, f14, 1.0f);
                    }
                }
                else if (!this.field_77109_a.field_78116_c.field_78807_k) {
                    final int k = itemstack2.func_77973_b().func_82790_a(itemstack2, 0);
                    final float f29 = (k >> 16 & 0xFF) / 255.0f;
                    final float f26 = (k >> 8 & 0xFF) / 255.0f;
                    final float f27 = (k & 0xFF) / 255.0f;
                    GL11.glColor4f(f29, f26, f27, 1.0f);
                    this.field_76990_c.field_78721_f.func_78443_a((EntityLivingBase)p_77029_1_, itemstack2, 0);
                    GL11.glColor4f(f14, f14, f14, 1.0f);
                }
            }
            if (!this.field_77109_a.field_78116_c.field_78807_k && itemstack2 != null && ItemRegistry.gunList.contains(itemstack2.func_77973_b())) {
                final DayMConfig daym_748d583f2 = DayM.daym_748d583f0;
                if (DayMConfig.daym_8fd972390) {
                    final String name = itemstack2.func_77973_b().func_77658_a().replace("item.item_daym_", "");
                    RenderSetup.renderGunTP(itemstack2, name, this, (EntityPlayer)p_77029_1_);
                }
                else {
                    final int k = itemstack2.func_77973_b().func_82790_a(itemstack2, 0);
                    final float f29 = (k >> 16 & 0xFF) / 255.0f;
                    final float f26 = (k >> 8 & 0xFF) / 255.0f;
                    final float f27 = (k & 0xFF) / 255.0f;
                    GL11.glColor4f(f29, f26, f27, 1.0f);
                    final float var = Math.abs(this.field_77109_a.field_78112_f.field_78795_f + 89.0f) / 4.0f;
                    GL11.glTranslatef(-0.3f + var, -0.4f + -var, 0.385f + var / 1.5f);
                    GL11.glRotatef(-90.0f, -0.1f, 1.0f, 0.0f);
                    GL11.glRotatef(-22.0f, 1.0f, -1.6f, -1.0f);
                    this.field_76990_c.field_78721_f.func_78443_a((EntityLivingBase)p_77029_1_, itemstack2, 0);
                    GL11.glColor4f(f14, f14, f14, 1.0f);
                }
            }
            GL11.glPopMatrix();
        }
        GL11.glPopMatrix();
        if (!p_77029_1_.field_71075_bZ.field_75098_d) {
            ItemStack lastgun = null;
            final ItemStack[] lastpistol = new ItemStack[2];
            if (p_77029_1_ != null) {
                for (int a = 0; a < ((EntityPlayer)p_77029_1_).field_71071_by.field_70462_a.length; ++a) {
                    final ItemStack isi = ((EntityPlayer)p_77029_1_).field_71071_by.field_70462_a[a];
                    if (isi != null && isi.func_77973_b() instanceof ItemDayMGun) {
                        final ItemDayMGun gun2 = (ItemDayMGun)isi.func_77973_b();
                        if (!gun2.daym_c46b8fa90) {
                            if (isi != itemstack2) {
                                lastgun = isi;
                            }
                        }
                        else if (lastpistol[0] == null) {
                            lastpistol[0] = isi;
                        }
                        else {
                            lastpistol[1] = isi;
                        }
                    }
                }
                if (((EntityPlayer)p_77029_1_).func_70005_c_().contains("3")) {}
                if (lastgun != null && !this.field_77109_a.field_78116_c.field_78807_k) {
                    final DayMConfig daym_748d583f3 = DayM.daym_748d583f0;
                    if (DayMConfig.daym_8fd972390) {
                        final String name = lastgun.func_77973_b().func_77658_a().replace("item.item_daym_", "");
                        GL11.glPushMatrix();
                        GL11.glRotatef(-55.0f, 0.0f, 1.0f, 0.0f);
                        GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
                        GL11.glRotatef(90.0f, 0.55f, 1.0f, -0.2f);
                        GL11.glRotatef(40.0f, 1.0f, 0.7f, 0.2f);
                        GL11.glRotatef(-25.0f, 1.0f, -0.2f, 0.4f);
                        GL11.glScalef(0.3f, 0.3f, 0.3f);
                        if (((EntityPlayer)p_77029_1_).func_70093_af()) {
                            GL11.glRotatef(30.0f, 0.0f, 1.0f, 0.0f);
                            GL11.glRotatef(10.0f, 1.0f, 0.0f, 1.0f);
                            GL11.glTranslatef(-0.25f, 0.3f, -0.6f);
                        }
                        GL11.glTranslatef(-1.2f, -0.2f, -0.9f);
                        GL11.glRotatef(-57.0f, 0.0f, 0.0f, 1.0f);
                        GL11.glScalef(1.0f, -1.0f, 1.0f);
                        RenderSetup.renderGunTP(lastgun, name, this, (EntityPlayer)p_77029_1_);
                        GL11.glPopMatrix();
                    }
                    else {
                        GL11.glPushMatrix();
                        GL11.glRotatef(90.0f, 1.0f, 0.2f, -1.0f);
                        GL11.glRotatef(-30.0f, 0.6f, 1.0f, 1.0f);
                        GL11.glRotatef(180.0f, 1.0f, -0.2f, 0.5f);
                        if (((EntityPlayer)p_77029_1_).func_70093_af()) {
                            GL11.glRotatef(-25.0f, 0.0f, 1.0f, 0.0f);
                            GL11.glTranslatef(-0.2f, 0.0f, 0.0f);
                        }
                        GL11.glTranslatef(0.1f, -0.2f, -0.1f);
                        GL11.glScalef(0.85f, 0.85f, 0.85f);
                        final int k = lastgun.func_77973_b().func_82790_a(lastgun, 0);
                        final float f29 = (k >> 16 & 0xFF) / 255.0f;
                        final float f26 = (k >> 8 & 0xFF) / 255.0f;
                        final float f27 = (k & 0xFF) / 255.0f;
                        GL11.glColor4f(f29, f26, f27, 1.0f);
                        GL11.glRotatef(-90.0f, -0.1f, 1.0f, 0.0f);
                        GL11.glRotatef(-22.0f, 1.0f, -1.6f, -1.0f);
                        this.field_76990_c.field_78721_f.func_78443_a((EntityLivingBase)p_77029_1_, lastgun, 0);
                        GL11.glColor4f(f14, f14, f14, 1.0f);
                        GL11.glPopMatrix();
                    }
                }
                for (int lp = 0; lp < lastpistol.length; ++lp) {
                    if (lastpistol[lp] != null && lastpistol[lp] != itemstack2) {
                        final DayMConfig daym_748d583f4 = DayM.daym_748d583f0;
                        if (DayMConfig.daym_8fd972390) {
                            final String name2 = lastpistol[lp].func_77973_b().func_77658_a().replace("item.item_daym_", "");
                            GL11.glPushMatrix();
                            GL11.glRotatef(-55.0f, 0.0f, 1.0f, 0.0f);
                            GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
                            GL11.glRotatef(90.0f, 0.55f, 1.0f, -0.2f);
                            GL11.glRotatef(40.0f, 1.0f, 0.7f, 0.2f);
                            GL11.glRotatef(-25.0f, 1.0f, -0.2f, 0.4f);
                            GL11.glRotatef(100.0f, 0.0f, 1.0f, 0.0f);
                            GL11.glRotatef(55.0f, -1.0f, 1.0f, -0.8f);
                            GL11.glScalef(0.3f, 0.3f, 0.3f);
                            if (((EntityPlayer)p_77029_1_).func_70093_af()) {
                                GL11.glTranslatef(-0.5f, 0.35f, -0.79f);
                            }
                            if (lastpistol[lp] != itemstack2) {
                                if (lp != 0 || lastpistol[1] == null) {
                                    GL11.glTranslatef(2.28f, 1.7f, -0.8f);
                                }
                                else {
                                    GL11.glTranslatef(1.0f, 2.4f, 0.2f);
                                }
                            }
                            GL11.glRotatef(57.0f, -1.0f, 0.3f, 0.3f);
                            GL11.glRotatef(20.0f, -1.0f, -1.0f, -1.0f);
                            GL11.glScalef(1.0f, -1.0f, 1.0f);
                            RenderSetup.renderGunTP(lastpistol[lp], name2, this, (EntityPlayer)p_77029_1_);
                            GL11.glPopMatrix();
                        }
                        else {
                            GL11.glPushMatrix();
                            GL11.glRotatef(90.0f, 1.0f, 0.2f, -1.0f);
                            GL11.glRotatef(-30.0f, 0.6f, 1.0f, 1.0f);
                            GL11.glRotatef(180.0f, 1.0f, -0.2f, 0.5f);
                            if (((EntityPlayer)p_77029_1_).func_70093_af()) {
                                GL11.glRotatef(-25.0f, 0.0f, 1.0f, 0.0f);
                                GL11.glTranslatef(-0.2f, 0.0f, 0.0f);
                            }
                            GL11.glTranslatef(0.1f, -0.2f, -0.1f);
                            GL11.glScalef(0.85f, 0.85f, 0.85f);
                            final int l = lastpistol[lp].func_77973_b().func_82790_a(lastpistol[lp], 0);
                            final float f30 = (l >> 16 & 0xFF) / 255.0f;
                            final float f31 = (l >> 8 & 0xFF) / 255.0f;
                            final float f32 = (l & 0xFF) / 255.0f;
                            GL11.glColor4f(f30, f31, f32, 1.0f);
                            GL11.glRotatef(-90.0f, -0.1f, 1.0f, 0.0f);
                            GL11.glRotatef(-22.0f, 1.0f, -1.6f, -1.0f);
                            this.field_76990_c.field_78721_f.func_78443_a((EntityLivingBase)p_77029_1_, lastpistol[lp], 0);
                            GL11.glColor4f(f14, f14, f14, 1.0f);
                            GL11.glPopMatrix();
                        }
                    }
                }
            }
        }
        MinecraftForge.EVENT_BUS.post((Event)new RenderPlayerEvent.Specials.Post((EntityPlayer)p_77029_1_, (RenderPlayer)this, p_77029_2_));
    }
    
    protected void func_96449_a(final AbstractClientPlayer p_96449_1_, final double p_96449_2_, double p_96449_4_, final double p_96449_6_, final String p_96449_8_, final float p_96449_9_, final double p_96449_10_) {
        if (p_96449_10_ < 12.0) {
            final Scoreboard scoreboard = p_96449_1_.func_96123_co();
            final ScoreObjective scoreobjective = scoreboard.func_96539_a(2);
            if (scoreobjective != null) {
                final Score score = scoreboard.func_96529_a(p_96449_1_.func_70005_c_(), scoreobjective);
                if (p_96449_1_.func_70608_bn()) {
                    this.func_147906_a((Entity)p_96449_1_, score.func_96652_c() + " " + scoreobjective.func_96678_d(), p_96449_2_, p_96449_4_ - 1.5, p_96449_6_, 64);
                }
                else {
                    this.func_147906_a((Entity)p_96449_1_, score.func_96652_c() + " " + scoreobjective.func_96678_d(), p_96449_2_, p_96449_4_, p_96449_6_, 64);
                }
                p_96449_4_ += this.func_76983_a().field_78288_b * 1.15f * p_96449_9_;
            }
            super.func_96449_a(p_96449_1_, p_96449_2_, p_96449_4_, p_96449_6_, p_96449_8_, p_96449_9_, p_96449_10_);
        }
    }
    
    public void func_82441_a(final EntityPlayer p_82441_1_) {
        final float f = 1.0f;
        GL11.glColor3f(f, f, f);
    }
    
    static {
        steveTextures = new ResourceLocation("textures/entity/steve.png");
    }
}
