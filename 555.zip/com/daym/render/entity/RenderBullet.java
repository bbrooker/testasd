package com.daym.render.entity;

import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;

public class RenderBullet extends Render
{
    public void func_76986_a(final Entity bullet, final double arg1, final double arg2, final double arg3, final float arg4, final float arg5) {
        final float scale = bullet.field_70173_aa / 10.0f;
    }
    
    protected ResourceLocation func_110775_a(final Entity arg0) {
        return null;
    }
}
