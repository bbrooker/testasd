package com.daym.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import net.minecraft.tileentity.*;
import com.daym.blocks.tileentity.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;
import net.minecraft.client.model.*;
import com.daym.models.*;
import com.daym.registry.*;
import com.daym.daymobjloader.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.block.*;

public class RenderCustomBlock extends TileEntitySpecialRenderer
{
    public void func_147500_a(final TileEntity tileEntity, final double d, final double d1, final double d2, final float f) {
        DayM_Model currentModel = null;
        if (tileEntity instanceof TileCustomRender) {
            GL11.glPushMatrix();
            GL11.glTranslatef((float)d + 0.5f, (float)d1, (float)d2 + 0.5f);
            GL11.glScalef(0.5f, 0.5f, 0.5f);
            final Tessellator var12 = Tessellator.field_78398_a;
            final TileCustomRender tcr = (TileCustomRender)tileEntity;
            if (tcr.modelID == 0) {
                currentModel = this.renderSlope(tcr);
            }
            if (tcr.modelID == 1) {
                currentModel = this.renderCustom(tcr);
            }
            if (tcr.modelID == 2) {
                currentModel = this.renderLetters(tcr);
            }
            else if (tcr.modelID != 3) {
                if (tcr.textureHandle != 0) {
                    currentModel.renderTextured(tcr.textureHandle);
                }
                else {
                    final ITextureObject ito = Minecraft.func_71410_x().field_71446_o.func_110581_b(tcr.textureRes);
                    if (ito != null) {
                        tcr.textureHandle = ito.func_110552_b();
                    }
                    else {
                        Minecraft.func_71410_x().field_71446_o.func_110577_a(tcr.textureRes);
                    }
                }
            }
            else {
                GL11.glRotatef(180.0f, 0.0f, 0.0f, 1.0f);
                GL11.glScalef(2.0f, 2.0f, 2.0f);
                GL11.glTranslatef(0.0f, -1.49f, 0.0f);
                final int md = tcr.func_145832_p();
                if (!(tcr.mainModel instanceof ModelTable1) && !(tcr.mainModel instanceof ModelTable2)) {
                    float rot = 0.0f;
                    int blockmd = 0;
                    if (md == 2 || md == 6) {
                        rot = 90.0f;
                        blockmd = 1;
                    }
                    if (md == 3 || md == 7) {
                        rot = -90.0f;
                        blockmd = 3;
                    }
                    if (md == 1 || md == 5) {
                        rot = 180.0f;
                        blockmd = 2;
                    }
                    GL11.glRotatef(rot + 90.0f, 0.0f, 1.0f, 0.0f);
                    if (tcr.mainModel instanceof ModelBench1) {
                        final ModelBench1 bench = (ModelBench1)tcr.mainModel;
                        final World world = tcr.func_145831_w();
                        final TileEntity blockfxp = world.func_147438_o(tcr.field_145851_c + 1, tcr.field_145848_d, tcr.field_145849_e);
                        final TileEntity blockfxn = world.func_147438_o(tcr.field_145851_c - 1, tcr.field_145848_d, tcr.field_145849_e);
                        final TileEntity blockfzp = world.func_147438_o(tcr.field_145851_c, tcr.field_145848_d, tcr.field_145849_e + 1);
                        final TileEntity blockfzn = world.func_147438_o(tcr.field_145851_c, tcr.field_145848_d, tcr.field_145849_e - 1);
                        boolean blockxp = false;
                        boolean blockxn = false;
                        boolean blockzp = false;
                        boolean blockzn = false;
                        if (blockfxp != null) {
                            blockxp = (blockfxp.func_145838_q() == BlockRegistry.woodenBench1);
                        }
                        if (blockfxn != null) {
                            blockxn = (blockfxn.func_145838_q() == BlockRegistry.woodenBench1);
                        }
                        if (blockfzp != null) {
                            blockzp = (blockfzp.func_145838_q() == BlockRegistry.woodenBench1);
                        }
                        if (blockfzn != null) {
                            blockzn = (blockfzn.func_145838_q() == BlockRegistry.woodenBench1);
                        }
                        for (final Object models : bench.field_78092_r) {
                            if (models instanceof ModelRenderer) {
                                final ModelRenderer box = (ModelRenderer)models;
                                box.field_78807_k = false;
                            }
                        }
                        if (blockmd == 0) {
                            if (blockzp && this.getBenchMetadata(blockfzp) == 0) {
                                bench.LegSupport1.field_78807_k = true;
                                bench.Leg1.field_78807_k = true;
                                bench.Leg2.field_78807_k = true;
                            }
                            if (blockzn && this.getBenchMetadata(blockfzn) == 0) {
                                bench.LegSupport2.field_78807_k = true;
                                bench.Leg3.field_78807_k = true;
                                bench.Leg4.field_78807_k = true;
                            }
                        }
                        if (blockmd == 2) {
                            if (blockzn && this.getBenchMetadata(blockfzn) == 2) {
                                bench.LegSupport1.field_78807_k = true;
                                bench.Leg1.field_78807_k = true;
                                bench.Leg2.field_78807_k = true;
                            }
                            if (blockzp && this.getBenchMetadata(blockfzp) == 2) {
                                bench.LegSupport2.field_78807_k = true;
                                bench.Leg3.field_78807_k = true;
                                bench.Leg4.field_78807_k = true;
                            }
                        }
                        if (blockmd == 1) {
                            if (blockxn && this.getBenchMetadata(blockfxn) == 1) {
                                bench.LegSupport1.field_78807_k = true;
                                bench.Leg1.field_78807_k = true;
                                bench.Leg2.field_78807_k = true;
                            }
                            if (blockxp && this.getBenchMetadata(blockfxp) == 1) {
                                bench.LegSupport2.field_78807_k = true;
                                bench.Leg3.field_78807_k = true;
                                bench.Leg4.field_78807_k = true;
                            }
                        }
                        if (blockmd == 3) {
                            if (blockxp && this.getBenchMetadata(blockfxp) == 3) {
                                bench.LegSupport1.field_78807_k = true;
                                bench.Leg1.field_78807_k = true;
                                bench.Leg2.field_78807_k = true;
                            }
                            if (blockxn && this.getBenchMetadata(blockfxn) == 3) {
                                bench.LegSupport2.field_78807_k = true;
                                bench.Leg3.field_78807_k = true;
                                bench.Leg4.field_78807_k = true;
                            }
                        }
                    }
                    if (tcr.mainModel instanceof ModelShelf1) {
                        final ModelShelf1 shelf = (ModelShelf1)tcr.mainModel;
                        int h = 0;
                        for (int i = 0; i < tcr.randomBoxNumber; ++i) {
                            GL11.glPushMatrix();
                            shelf.box.field_78807_k = false;
                            final int n = -1 + i;
                            if (i == 3 || i == 6) {
                                ++h;
                            }
                            boolean hide = false;
                            if (tcr.randomBoxNumber == 4 || (i & 0x3) == tcr.randomBoxNumber / 3) {
                                hide = true;
                            }
                            if (!hide) {
                                GL11.glTranslatef((float)(n - h * 3), h * 0.93f - 0.9f, 0.0f);
                                GL11.glScalef(0.6f, 0.6f, 0.6f);
                                GL11.glRotatef(-90.0f, 0.0f, 0.0f, 1.0f);
                                GL11.glRotatef(tcr.randomBoxNumber + n * 35.0f, 1.0f, 0.0f, 0.0f);
                                ModelRegistry.box.renderTextured(TextureRegistry.cardboard_box);
                            }
                            GL11.glPopMatrix();
                        }
                        shelf.box.field_78807_k = true;
                    }
                }
                else if (!(tcr.mainModel instanceof ModelTable2)) {
                    final ModelTable1 table = (ModelTable1)tcr.mainModel;
                    final World world2 = tcr.func_145831_w();
                    final boolean blockxp2 = world2.func_147439_a(tcr.field_145851_c + 1, tcr.field_145848_d, tcr.field_145849_e) == BlockRegistry.woodenTable1;
                    final boolean blockxn2 = world2.func_147439_a(tcr.field_145851_c - 1, tcr.field_145848_d, tcr.field_145849_e) == BlockRegistry.woodenTable1;
                    final boolean blockzp2 = world2.func_147439_a(tcr.field_145851_c, tcr.field_145848_d, tcr.field_145849_e + 1) == BlockRegistry.woodenTable1;
                    final boolean blockzn2 = world2.func_147439_a(tcr.field_145851_c, tcr.field_145848_d, tcr.field_145849_e - 1) == BlockRegistry.woodenTable1;
                    for (final Object models2 : table.field_78092_r) {
                        if (models2 instanceof ModelRenderer) {
                            final ModelRenderer box2 = (ModelRenderer)models2;
                            box2.field_78807_k = false;
                        }
                    }
                    table.StumpHolder1.field_78807_k = true;
                    table.StumpHolder2.field_78807_k = true;
                    table.StumpHolder3.field_78807_k = true;
                    table.StumpHolder4.field_78807_k = true;
                    if (blockzp2) {
                        table.Stump1.field_78807_k = true;
                        table.Stump2.field_78807_k = true;
                    }
                    if (blockxn2) {
                        table.Stump2.field_78807_k = true;
                        table.Stump4.field_78807_k = true;
                    }
                    if (blockxp2) {
                        table.Stump1.field_78807_k = true;
                        table.Stump3.field_78807_k = true;
                    }
                    if (blockzn2) {
                        table.Stump3.field_78807_k = true;
                        table.Stump4.field_78807_k = true;
                    }
                    if (!table.Stump3.field_78807_k && !table.Stump1.field_78807_k) {
                        table.StumpHolder1.field_78807_k = false;
                    }
                    if (!table.Stump1.field_78807_k && !table.Stump2.field_78807_k) {
                        table.StumpHolder4.field_78807_k = false;
                    }
                    if (!table.Stump3.field_78807_k && !table.Stump4.field_78807_k) {
                        table.StumpHolder3.field_78807_k = false;
                    }
                    if (!table.Stump2.field_78807_k && !table.Stump4.field_78807_k) {
                        table.StumpHolder2.field_78807_k = false;
                    }
                }
                else {
                    final ModelTable2 table2 = (ModelTable2)tcr.mainModel;
                    final World world2 = tcr.func_145831_w();
                    final boolean blockxp2 = world2.func_147439_a(tcr.field_145851_c + 1, tcr.field_145848_d, tcr.field_145849_e) == BlockRegistry.woodenTable2;
                    final boolean blockxn2 = world2.func_147439_a(tcr.field_145851_c - 1, tcr.field_145848_d, tcr.field_145849_e) == BlockRegistry.woodenTable2;
                    final boolean blockzp2 = world2.func_147439_a(tcr.field_145851_c, tcr.field_145848_d, tcr.field_145849_e + 1) == BlockRegistry.woodenTable2;
                    final boolean blockzn2 = world2.func_147439_a(tcr.field_145851_c, tcr.field_145848_d, tcr.field_145849_e - 1) == BlockRegistry.woodenTable2;
                    for (final Object models2 : table2.field_78092_r) {
                        if (models2 instanceof ModelRenderer) {
                            final ModelRenderer box2 = (ModelRenderer)models2;
                            box2.field_78807_k = false;
                        }
                    }
                    table2.StumpHolder1.field_78807_k = true;
                    table2.StumpHolder2.field_78807_k = true;
                    table2.StumpHolder3.field_78807_k = true;
                    table2.StumpHolder4.field_78807_k = true;
                    if (blockzp2) {
                        table2.Stump1.field_78807_k = true;
                        table2.Stump2.field_78807_k = true;
                    }
                    if (blockxn2) {
                        table2.Stump2.field_78807_k = true;
                        table2.Stump4.field_78807_k = true;
                    }
                    if (blockxp2) {
                        table2.Stump1.field_78807_k = true;
                        table2.Stump3.field_78807_k = true;
                    }
                    if (blockzn2) {
                        table2.Stump3.field_78807_k = true;
                        table2.Stump4.field_78807_k = true;
                    }
                    if (!table2.Stump3.field_78807_k && !table2.Stump1.field_78807_k) {
                        table2.StumpHolder1.field_78807_k = false;
                    }
                    if (!table2.Stump1.field_78807_k && !table2.Stump2.field_78807_k) {
                        table2.StumpHolder4.field_78807_k = false;
                    }
                    if (!table2.Stump3.field_78807_k && !table2.Stump4.field_78807_k) {
                        table2.StumpHolder3.field_78807_k = false;
                    }
                    if (!table2.Stump2.field_78807_k && !table2.Stump4.field_78807_k) {
                        table2.StumpHolder2.field_78807_k = false;
                    }
                }
                Minecraft.func_71410_x().field_71446_o.func_110577_a(tcr.textureRes);
                ModelRegistry.renderTechne(tcr.mainModel);
            }
            GL11.glPopMatrix();
        }
    }
    
    public int getBenchMetadata(final TileEntity tileentity) {
        int blockmd = 0;
        final int md = tileentity.func_145832_p();
        if (md == 2 || md == 6) {
            blockmd = 1;
        }
        if (md == 3 || md == 7) {
            blockmd = 3;
        }
        if (md == 1 || md == 5) {
            blockmd = 2;
        }
        return blockmd;
    }
    
    private DayM_Model renderLetters(final TileCustomRender tcr) {
        DayM_Model currentModel = null;
        GL11.glTranslatef(0.0f, 0.01f, 0.0f);
        float rot = 0.0f;
        final int md = tcr.func_145832_p();
        if (md == 2 || md == 6) {
            rot = -90.0f;
        }
        if (md == 3 || md == 7) {
            rot = 90.0f;
        }
        if (md == 1 || md == 5) {
            rot = 180.0f;
        }
        GL11.glRotatef(rot + 90.0f + 180.0f, 0.0f, 1.0f, 0.0f);
        int i = 0;
        GL11.glTranslatef(-2.7f * (tcr.letters.length() / 2) - 1.0f, 0.0f, 0.0f);
        tcr.letters = "LONG123";
        for (final char ch : tcr.letters.toCharArray()) {
            currentModel = ModelRegistry.letterModels[i];
            if (tcr.textureHandle != 0) {
                GL11.glTranslatef(2.7f, 0.0f, 0.0f);
                currentModel.renderTextured(tcr.textureRes);
            }
            ++i;
        }
        return null;
    }
    
    private DayM_Model renderCustom(final TileCustomRender tcr) {
        GL11.glTranslatef(0.0f, 0.01f, 0.0f);
        return tcr.currentModel;
    }
    
    private DayM_Model renderSlope(final TileCustomRender tcr) {
        DayM_Model currentModel = null;
        float rot = 0.0f;
        float scale = 0.0f;
        final int md = tcr.func_145832_p();
        if (md == 2 || md == 6) {
            rot = -90.0f;
        }
        if (md == 3 || md == 7) {
            rot = 90.0f;
        }
        if (md == 1 || md == 5) {
            rot = 180.0f;
        }
        if (md == 5 || md == 7 || md == 6 || md == 4) {
            scale = -180.0f;
        }
        if (scale != 0.0f) {
            GL11.glTranslatef(0.0f, 2.0f, 0.0f);
            GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
        }
        GL11.glRotatef(rot, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(scale, 0.0f, 0.0f, 1.0f);
        final Random random = new Random();
        final int updateRate = (int)Minecraft.func_71410_x().field_71439_g.func_70011_f((double)tcr.field_145851_c, (double)tcr.field_145848_d, (double)tcr.field_145849_e);
        boolean force = false;
        int var = 50 - updateRate + 1;
        if (var < 2) {
            var = 5;
        }
        if (random.nextInt(var) > updateRate * 2) {
            tcr.onBlockUpdated();
        }
        else if (random.nextInt(90) > 88) {
            force = true;
        }
        if (force) {
            tcr.onBlockUpdated();
        }
        GL11.glRotatef(tcr.yRot, 0.0f, 1.0f, 0.0f);
        currentModel = tcr.currentModel;
        if (currentModel == null) {
            currentModel = ModelRegistry.blockSlanted[0];
        }
        return currentModel;
    }
    
    private DayM_Model getSlopeModelMD(final TileEntity te) {
        if (!(te instanceof TileCustomRender)) {
            return ModelRegistry.blockSlanted[0];
        }
        final TileCustomRender tcr = (TileCustomRender)te;
        return tcr.currentModel;
    }
    
    public void renderBlockYour(final TileEntity tl, final World world, final int i, final int j, final int k, final Block block) {
    }
    
    public void rotate(final float f, final float g, final float h, final float l) {
        GL11.glRotatef(f, g, h, l);
    }
}
