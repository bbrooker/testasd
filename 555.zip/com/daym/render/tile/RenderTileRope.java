package com.daym.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import net.minecraft.tileentity.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;
import net.minecraft.world.*;
import net.minecraft.block.*;

public class RenderTileRope extends TileEntitySpecialRenderer
{
    public void func_147500_a(final TileEntity tileEntity, final double d, final double d1, final double d2, final float f) {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d, (float)d1, (float)d2);
        final Tessellator var12 = Tessellator.field_78398_a;
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        var12.func_78371_b(3);
        var12.func_78378_d(0);
        final byte var13 = 16;
        for (int var14 = 0; var14 <= var13; ++var14) {
            final float var15 = var14 / var13;
            var12.func_78377_a(Minecraft.func_71410_x().field_71439_g.field_70165_t * var15, d1 * (var15 * var15 + var15) * 0.5 + 0.25, Minecraft.func_71410_x().field_71439_g.field_70161_v * var15 / 2.0);
        }
        var12.func_78381_a();
        GL11.glEnable(2896);
        GL11.glEnable(3553);
        GL11.glPopMatrix();
    }
    
    public void renderBlockYour(final TileEntity tl, final World world, final int i, final int j, final int k, final Block block) {
    }
}
