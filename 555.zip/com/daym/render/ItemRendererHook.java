package com.daym.render;

import net.minecraftforge.client.*;
import com.daym.*;
import java.util.*;
import com.daym.config.*;
import com.daym.items.*;
import com.daym.clientproxy.*;
import net.minecraft.item.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.*;
import com.daym.gui.inventory.*;
import com.daym.registry.*;
import net.minecraft.entity.*;
import net.minecraft.client.gui.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.texture.*;
import com.daym.handlers.*;
import net.minecraft.client.renderer.*;

public class ItemRendererHook implements IItemRenderer
{
    private static RenderItemDayM renderItem;
    DayM daym;
    private static Random random;
    
    public ItemRendererHook() {
        this.daym = DayM.getInstance();
    }
    
    public boolean handleRenderType(final ItemStack itemStack, final IItemRenderer.ItemRenderType type) {
        if (itemStack == null) {
            return false;
        }
        if (itemStack.func_77973_b() instanceof ItemZombieSpawner && type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON) {
            return true;
        }
        if ((itemStack.func_77973_b() instanceof DayMItem || itemStack.func_77973_b() instanceof ItemMelee) && ((type == IItemRenderer.ItemRenderType.ENTITY && !itemStack.func_82839_y()) || type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON)) {
            return true;
        }
        if ((itemStack.func_77973_b() instanceof DayMFood || itemStack.func_77973_b() instanceof ItemWithInventory || itemStack.func_77973_b() instanceof ItemClothing) && type == IItemRenderer.ItemRenderType.ENTITY && !itemStack.func_82839_y()) {
            return true;
        }
        if (itemStack.func_77973_b() instanceof ItemAmmo && (type == IItemRenderer.ItemRenderType.INVENTORY || (type == IItemRenderer.ItemRenderType.ENTITY && !itemStack.func_82839_y()))) {
            return true;
        }
        if (itemStack.func_77973_b() instanceof ItemDayMGun) {
            if (type != IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON) {
                if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
                    final DayMConfig daym_748d583f0 = DayM.daym_748d583f0;
                    if (DayMConfig.daym_8fd972390) {
                        return true;
                    }
                }
                if ((type != IItemRenderer.ItemRenderType.ENTITY || itemStack.func_82839_y()) && type != IItemRenderer.ItemRenderType.INVENTORY) {
                    return itemStack.func_77973_b() instanceof ItemMagazine && (type == IItemRenderer.ItemRenderType.INVENTORY || (type == IItemRenderer.ItemRenderType.ENTITY && !itemStack.func_82839_y()));
                }
            }
            return true;
        }
        return itemStack.func_77973_b() instanceof ItemMagazine && (type == IItemRenderer.ItemRenderType.INVENTORY || (type == IItemRenderer.ItemRenderType.ENTITY && !itemStack.func_82839_y()));
    }
    
    public boolean shouldUseRenderHelper(final IItemRenderer.ItemRenderType type, final ItemStack item, final IItemRenderer.ItemRendererHelper helper) {
        return false;
    }
    
    public void renderItem(final IItemRenderer.ItemRenderType type, final ItemStack itemStack, final Object... data) {
        if (itemStack == null) {
            return;
        }
        if (itemStack.func_77973_b() instanceof ItemDayMGun) {
            if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON) {
                if (itemStack.func_77973_b() == ItemRegistry.item_ak47) {
                    ClientProxy.daym_baccf3380.daym_94e38d0a0("ak47", itemStack, ItemRendererHook.renderItem);
                }
                else if (itemStack.func_77973_b() == ItemRegistry.item_rem700) {
                    ClientProxy.daym_baccf3380.daym_94e38d0a0("rem700", itemStack, ItemRendererHook.renderItem);
                }
                else if (itemStack.func_77973_b() == ItemRegistry.item_makarov) {
                    ClientProxy.daym_baccf3380.daym_94e38d0a0("makarov", itemStack, ItemRendererHook.renderItem);
                }
                else {
                    ClientProxy.daym_baccf3380.daym_94e38d0a0("", null, null);
                }
            }
            final ItemDayMGun daymgun = (ItemDayMGun)itemStack.func_77973_b();
            final ItemStack is = new ItemStack((Item)daymgun.daym_511e1e650);
            if (type == IItemRenderer.ItemRenderType.ENTITY && !itemStack.func_82839_y()) {
                GL11.glPushMatrix();
                GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef((float)itemStack.hashCode(), 0.0f, 0.0f, 1.0f);
                if (!daymgun.daym_c46b8fa90) {
                    GL11.glTranslatef(1.2f, -1.2f, 0.0f);
                }
                if (ItemDayMGun.hasMagazine(itemStack) && !daymgun.daym_c46b8fa90) {
                    GL11.glPushMatrix();
                    float var0 = 0.0f;
                    float var2 = 0.0f;
                    final float var3 = 0.0f;
                    if (daymgun == ItemRegistry.item_rem700) {
                        var0 = 0.3f;
                        var2 = 0.05f;
                    }
                    GL11.glTranslatef(-1.4f + var0, 0.95f + var2, 0.05f + var3);
                    final DayMConfig daym_748d583f0 = DayM.daym_748d583f0;
                    if (!DayMConfig.daym_8fd972390GroundItem) {
                        renderDroppedItem(ItemRendererHook.renderItem, itemStack, is.func_77954_c(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0, daymgun.daym_a179deca0 / 4.61538f, daymgun.daym_6d067a4e0 / 4.61538f, 2.0f);
                    }
                    else {
                        GL11.glScalef(0.3f, 0.3f, 0.35f);
                        GL11.glTranslatef(1.0f, -5.5f, 0.5f);
                        GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
                        if (itemStack.func_77973_b() == ItemRegistry.item_ak47) {
                            RenderSetup.daym_3c8b8d790.render(1);
                        }
                        if (itemStack.func_77973_b() == ItemRegistry.item_rem700) {
                            GL11.glTranslatef(-0.85f, -0.2f, 0.3f);
                            RenderSetup.daym_09732d150.render(1);
                        }
                    }
                    GL11.glPopMatrix();
                }
                final DayMConfig daym_748d583f2 = DayM.daym_748d583f0;
                if (!DayMConfig.daym_8fd972390GroundItem) {
                    renderDroppedItem(ItemRendererHook.renderItem, itemStack, itemStack.func_77954_c(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0, daymgun.daym_a179deca0, daymgun.daym_6d067a4e0, 2.5f);
                }
                else {
                    GL11.glScalef(0.3f, 0.3f, 0.35f);
                    GL11.glTranslatef(-3.5f, -2.5f, 0.5f);
                    GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
                    if (itemStack.func_77973_b() == ItemRegistry.item_ak47) {
                        RenderSetup.daym_3c8b8d790.render(0);
                    }
                    if (itemStack.func_77973_b() == ItemRegistry.item_rem700) {
                        RenderSetup.daym_09732d150.render(0);
                        RenderSetup.daym_09732d150.render(2);
                    }
                    if (itemStack.func_77973_b() == ItemRegistry.item_makarov) {
                        GL11.glTranslatef(2.9f, 0.0f, 4.2f);
                        RenderSetup.daym_4e230c440.render(0);
                        RenderSetup.daym_4e230c440.render(2);
                    }
                }
                GL11.glPopMatrix();
            }
            if (type == IItemRenderer.ItemRenderType.INVENTORY) {
                GL11.glEnable(3008);
                if (!daymgun.daym_c46b8fa90 && ItemDayMGun.hasMagazine(itemStack)) {
                    int var4 = 6;
                    final int var5 = 7;
                    final int var6 = 3;
                    int var7 = 4;
                    if (daymgun == ItemRegistry.item_rem700) {
                        var4 = 7;
                        var7 = 3;
                    }
                    ItemRendererHook.renderItem.func_94149_a(var4, var5, is.func_77954_c(), var6, var7);
                }
                ItemRendererHook.renderItem.func_94149_a(0, 0, itemStack.func_77954_c(), 16, 16);
                GL11.glDisable(3008);
            }
            return;
        }
        if (itemStack.func_77973_b() instanceof ItemMagazine && type == IItemRenderer.ItemRenderType.INVENTORY) {
            final FontRenderer fontRenderer = Minecraft.func_71410_x().field_71466_p;
            GL11.glEnable(3008);
            ItemRendererHook.renderItem.func_94149_a(1, 1, itemStack.func_77954_c(), 14, 14);
            GL11.glDisable(3008);
            if (!(Minecraft.func_71410_x().field_71462_r instanceof GuiPlayerInventoryDayM)) {
                final int bul = ItemMagazine.getBullets(itemStack);
                if (bul != 0) {
                    final String text = "" + bul;
                    fontRenderer.func_78261_a(text, 16 - fontRenderer.func_78256_a(text), 9, 16777215);
                }
            }
        }
        if (itemStack.func_77973_b() instanceof ItemAmmo) {
            if (type == IItemRenderer.ItemRenderType.INVENTORY) {
                GL11.glEnable(3008);
                GL11.glPushMatrix();
                GL11.glScalef(0.5f, 1.0f, 1.0f);
                GL11.glTranslatef(8.0f, 0.0f, 0.0f);
                ItemRendererHook.renderItem.func_94149_a(1, 1, itemStack.func_77954_c(), 14, 14);
                GL11.glPopMatrix();
                GL11.glDisable(3008);
            }
            if (type == IItemRenderer.ItemRenderType.ENTITY && !itemStack.func_82839_y()) {
                GL11.glPushMatrix();
                GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef((float)itemStack.hashCode(), 0.0f, 0.0f, 1.0f);
                GL11.glTranslatef(0.0f, 0.0f, 0.005f);
                renderDroppedItem(ItemRendererHook.renderItem, itemStack, itemStack.func_77954_c(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0, 0.25f, 0.7f, 1.6f);
                GL11.glPopMatrix();
            }
            return;
        }
        if (itemStack.func_77973_b() instanceof DayMItem || itemStack.func_77973_b() instanceof DayMFood || itemStack.func_77973_b() instanceof ItemWithInventory || itemStack.func_77973_b() instanceof ItemClothing || itemStack.func_77973_b() instanceof ItemMelee) {
            if (type == IItemRenderer.ItemRenderType.ENTITY && !itemStack.func_82839_y()) {
                GL11.glPushMatrix();
                GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
                GL11.glTranslatef(0.0f, 0.0f, -0.01f);
                GL11.glRotatef((float)itemStack.hashCode(), 0.0f, 0.0f, 1.0f);
                float zsco = 0.0f;
                if (itemStack.func_77973_b() instanceof DayMFood && itemStack.func_77973_b().func_77658_a().contains("fc")) {
                    GL11.glTranslatef(0.0f, 0.0f, -0.3f);
                    GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
                    zsco = 3.0f;
                }
                if (itemStack.func_77973_b() instanceof ItemMelee) {
                    GL11.glScalef(2.0f, 2.0f, 1.0f);
                }
                if (itemStack.func_77973_b() instanceof ItemClothing) {
                    if (!itemStack.func_77973_b().func_77658_a().contains("bp")) {
                        GL11.glTranslatef(0.0f, 0.0f, -0.08f);
                        renderDroppedItem(ItemRendererHook.renderItem, itemStack, itemStack.func_77954_c(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0, 2.0f, 2.0f, 4.0f);
                    }
                    else {
                        GL11.glRotatef(180.0f, 1.0f, 0.0f, 0.0f);
                        GL11.glTranslatef(0.0f, -0.5f, -0.5f);
                        GL11.glScalef(2.25f, 2.25f, 2.25f);
                        int backpackType = 0;
                        if (itemStack.func_77973_b() instanceof ItemWithInventory) {
                            final ItemWithInventory iwi = (ItemWithInventory)itemStack.func_77973_b();
                            backpackType = iwi.clothingID;
                            TextureRegistry.bindResource(TextureRegistry.backpack[backpackType]);
                        }
                        if (itemStack.func_77973_b() == ItemRegistry.item_parachute) {
                            backpackType = 2;
                            TextureRegistry.bindResource(TextureRegistry.backpack[backpackType]);
                        }
                        if (backpackType == 2 || backpackType == 5) {
                            if (!DayMConfig.daym_8fd972390) {
                                RenderSetup.daym_52058ee50.backpackSimple.func_78785_a(0.0625f);
                            }
                            else {
                                GL11.glTranslatef(0.0f, 0.03f, -0.07f);
                                GL11.glScalef(1.0f, 1.0f, 1.3f);
                                RenderSetup.daym_52058ee50.backpack.func_78785_a(0.0625f);
                                RenderSetup.daym_52058ee50.backpackP2.func_78785_a(0.0625f);
                                RenderSetup.daym_52058ee50.backpackP3.func_78785_a(0.0625f);
                                RenderSetup.daym_52058ee50.backpackP4.func_78785_a(0.0625f);
                                RenderSetup.daym_52058ee50.backpackP5.func_78785_a(0.0625f);
                                RenderSetup.daym_52058ee50.backpackP6.func_78785_a(0.0625f);
                                GL11.glScalef(0.8f, 0.8f, 0.6f);
                            }
                        }
                        if (backpackType == 0) {
                            GL11.glScalef(0.8f, 0.95f, 0.85f);
                            GL11.glTranslatef(0.0f, -0.065f, 0.0f);
                            RenderSetup.daym_52058ee50.backpackCoyote.func_78088_a(null, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
                        }
                        if (backpackType == 1) {
                            RenderSetup.daym_52058ee50.backpackAlice.func_78088_a(null, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
                        }
                        if (backpackType == 3) {
                            RenderSetup.daym_52058ee50.backpackCzech.func_78088_a(null, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
                        }
                        if (backpackType == 4) {
                            RenderSetup.daym_52058ee50.backpackCzechPouch.func_78088_a(null, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
                        }
                    }
                }
                else {
                    renderDroppedItem(ItemRendererHook.renderItem, itemStack, itemStack.func_77954_c(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0, 0.75f, 0.75f, 2.2f + zsco);
                }
                GL11.glPopMatrix();
            }
            if (type == IItemRenderer.ItemRenderType.EQUIPPED_FIRST_PERSON) {}
        }
    }
    
    public static void renderDroppedItem(final RenderItem renderItem, final ItemStack itemstack, final IIcon iicon, final int int1, final float float1, final float float2, final float float3, final float float4, final int pass, final float scX, final float scY, final float scZ) {
        final boolean renderInFrame = true;
        final Tessellator tessellator = Tessellator.field_78398_a;
        if (iicon == null) {
            return;
        }
        final float f14 = iicon.func_94209_e();
        final float f15 = iicon.func_94212_f();
        final float f16 = iicon.func_94206_g();
        final float f17 = iicon.func_94210_h();
        final float f18 = 1.0f;
        final float f19 = 0.5f;
        final float f20 = 0.25f;
        GL11.glTranslatef(0.0f, -0.25f, 0.0f);
        GL11.glPushMatrix();
        if (renderInFrame) {
            GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
        }
        final float f21 = 0.0625f;
        final float f22 = 0.021875f;
        final int j = itemstack.field_77994_a;
        byte b0 = (byte)j;
        if (j > 3) {
            b0 = 3;
        }
        GL11.glTranslatef(-f19, -f20, -(f21 + f22));
        for (int k = 0; k < b0; ++k) {
            final boolean shouldSpreadItems = true;
            final float test = 0.0f;
            final float test2 = k;
            final int n = 0;
            final int n2 = 9;
            final boolean su = false;
            final Random random = new Random();
            random.setSeed(renderItem.hashCode());
            if (k != 0) {
                GL11.glTranslatef(0.0f, 0.0f, 0.12f);
            }
            if (su) {
                GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
            }
            GL11.glPushMatrix();
            GL11.glScalef(scX, scY, scZ);
            RenderManager.field_78727_a.field_78724_e.func_110577_a(TextureMap.field_110576_c);
            if (TickHandler.daym_6f4591d50 == itemstack && !Minecraft.func_71410_x().field_71474_y.field_74319_N) {
                GL11.glColor4f(0.0f, 0.5f, 0.5f, 1.0f);
            }
            if (k != 0) {
                GL11.glRotatef((test + random.nextInt(k + 4) * 5) * 1.0f, 0.0f, 0.0f, 1.0f);
            }
            ItemRenderer.func_78439_a(tessellator, f15, f16, f14, f17, iicon.func_94211_a(), iicon.func_94216_b(), f21);
            GL11.glPopMatrix();
        }
        GL11.glPopMatrix();
    }
    
    static {
        ItemRendererHook.renderItem = new RenderItemDayM();
        ItemRendererHook.random = new Random();
    }
}
