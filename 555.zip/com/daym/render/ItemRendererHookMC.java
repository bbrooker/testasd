package com.daym.render;

import net.minecraftforge.client.*;
import net.minecraft.item.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.entity.*;

public class ItemRendererHookMC implements IItemRenderer
{
    private static RenderItemDayM renderItem;
    
    public boolean handleRenderType(final ItemStack itemStack, final IItemRenderer.ItemRenderType type) {
        return type == IItemRenderer.ItemRenderType.ENTITY && !itemStack.func_82839_y();
    }
    
    public void renderItem(final IItemRenderer.ItemRenderType type, final ItemStack itemStack, final Object... data) {
        if (type == IItemRenderer.ItemRenderType.ENTITY && !itemStack.func_82839_y()) {
            GL11.glPushMatrix();
            GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
            GL11.glTranslatef(0.0f, 0.0f, -0.01f);
            GL11.glRotatef((float)itemStack.hashCode(), 0.0f, 0.0f, 1.0f);
            ItemRendererHook.renderDroppedItem(ItemRendererHookMC.renderItem, itemStack, itemStack.func_77954_c(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0, 1.25f, 1.25f, 2.5f);
            GL11.glPopMatrix();
        }
    }
    
    public boolean shouldUseRenderHelper(final IItemRenderer.ItemRenderType arg0, final ItemStack arg1, final IItemRenderer.ItemRendererHelper arg2) {
        return false;
    }
    
    static {
        ItemRendererHookMC.renderItem = new RenderItemDayM();
    }
}
