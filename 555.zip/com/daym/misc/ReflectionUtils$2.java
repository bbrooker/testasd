package com.daym.misc;

import java.lang.reflect.*;

static final class ReflectionUtils$2 implements FieldCallback {
    final /* synthetic */ Object val$src;
    final /* synthetic */ Object val$dest;
    
    @Override
    public void doWith(final Field field) throws IllegalArgumentException, IllegalAccessException {
        ReflectionUtils.makeAccessible(field);
        final Object srcValue = field.get(this.val$src);
        field.set(this.val$dest, srcValue);
    }
}