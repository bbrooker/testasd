package com.daym.misc;

import java.util.*;
import java.lang.reflect.*;

public class DayMSort
{
    public static <T> void sortList(final List<T> list, final String propertyName) {
        if (list.size() > 0) {
            Collections.sort(list, new Comparator<T>() {
                @Override
                public int compare(final T object1, final T object2) {
                    final String property1 = (String)DayMSort.getSpecifiedFieldValue(propertyName, object1);
                    final String property2 = (String)DayMSort.getSpecifiedFieldValue(propertyName, object2);
                    return property1.compareToIgnoreCase(property2);
                }
            });
        }
    }
    
    public static Object getSpecifiedFieldValue(final String property, final Object obj) {
        Object result = null;
        try {
            final Class<?> objectClass = obj.getClass();
            final Field objectField = getDeclaredField(property, objectClass);
            if (objectField != null) {
                objectField.setAccessible(true);
                result = objectField.get(obj);
            }
        }
        catch (Exception ex) {}
        return result;
    }
    
    public static Field getDeclaredField(final String fieldName, final Class<?> type) {
        Field result = null;
        try {
            result = type.getDeclaredField(fieldName);
        }
        catch (Exception ex) {}
        if (result == null) {
            final Class<?> superclass = type.getSuperclass();
            if (superclass != null && !superclass.getName().equals("java.lang.Object")) {
                return getDeclaredField(fieldName, type.getSuperclass());
            }
        }
        return result;
    }
}
