package com.daym.misc;

public class DayMBoundingBox
{
    public float minX;
    public float minY;
    public float minZ;
    public float maxX;
    public float maxY;
    public float maxZ;
    
    public DayMBoundingBox(final float x, final float y, final float z, final float mx, final float my, final float mz) {
        this.minX = 0.0f;
        this.minY = 0.0f;
        this.minZ = 0.0f;
        this.maxX = 1.0f;
        this.maxY = 1.0f;
        this.maxZ = 1.0f;
        this.minX = x;
        this.minY = y;
        this.minZ = z;
        this.maxX = mx;
        this.maxY = my;
        this.maxZ = mz;
    }
}
