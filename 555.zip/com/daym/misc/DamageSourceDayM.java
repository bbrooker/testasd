package com.daym.misc;

import net.minecraft.entity.*;
import net.minecraft.util.*;

public class DamageSourceDayM extends DamageSource
{
    protected DamageSourceDayM(final String par1Str) {
        super(par1Str);
    }
    
    public static DamageSource causeBulletDamage(final Entity par0Entity, final Entity par1Entity) {
        return new EntityDamageSourceIndirect("bullet", par0Entity, par1Entity).func_76349_b();
    }
}
