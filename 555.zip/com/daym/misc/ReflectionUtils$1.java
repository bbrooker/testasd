package com.daym.misc;

import java.util.*;
import java.lang.reflect.*;

static final class ReflectionUtils$1 implements MethodCallback {
    final /* synthetic */ List val$list;
    
    @Override
    public void doWith(final Method method) {
        this.val$list.add(method);
    }
}