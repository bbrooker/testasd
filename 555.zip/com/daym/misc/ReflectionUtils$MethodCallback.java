package com.daym.misc;

import java.lang.reflect.*;

public interface MethodCallback
{
    void doWith(final Method p0) throws IllegalArgumentException, IllegalAccessException;
}
