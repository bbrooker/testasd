package com.daym.misc;

import java.util.*;

public class GunUtils
{
    public static ArrayList<Integer> daym_fdec667d0IDs;
    public static HashMap<Integer, Integer> gid_timer;
    public static HashMap<Integer, Boolean> gid_reloading;
    public static HashMap<Integer, Boolean> gid_chamber;
    public static HashMap<Integer, Boolean> gid_unloading;
    
    public static void setTimer(final int gunID, final int timer) {
        if (gunID != 0) {
            GunUtils.gid_timer.put(gunID, timer);
        }
    }
    
    public static void setChambering(final int gunID, final boolean rel) {
        if (gunID != 0) {
            GunUtils.gid_chamber.put(gunID, rel);
        }
    }
    
    public static void setReloading(final int gunID, final boolean rel) {
        if (gunID != 0) {
            GunUtils.gid_reloading.put(gunID, rel);
        }
    }
    
    public static void setUnloading(final int gunID, final boolean unl) {
        if (gunID != 0) {
            GunUtils.gid_unloading.put(gunID, unl);
        }
    }
    
    public static int getTimer(final int gunID) {
        final Integer timer = GunUtils.gid_timer.get(gunID);
        if (timer == null) {
            return 0;
        }
        return timer;
    }
    
    public static boolean getReloading(final int gunID) {
        final Boolean reloading = GunUtils.gid_reloading.get(gunID);
        return reloading != null && reloading;
    }
    
    public static boolean getChambering(final int gunID) {
        final Boolean chambading = GunUtils.gid_chamber.get(gunID);
        return chambading != null && chambading;
    }
    
    public static boolean getUnloading(final int gunID) {
        final Boolean unloading = GunUtils.gid_unloading.get(gunID);
        return unloading != null && unloading;
    }
    
    static {
        GunUtils.daym_fdec667d0IDs = new ArrayList<Integer>();
        GunUtils.gid_timer = new HashMap<Integer, Integer>();
        GunUtils.gid_reloading = new HashMap<Integer, Boolean>();
        GunUtils.gid_chamber = new HashMap<Integer, Boolean>();
        GunUtils.gid_unloading = new HashMap<Integer, Boolean>();
    }
}
