package com.daym.misc;

import java.lang.reflect.*;

public interface FieldFilter
{
    boolean matches(final Field p0);
}
