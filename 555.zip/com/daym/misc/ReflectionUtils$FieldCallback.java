package com.daym.misc;

import java.lang.reflect.*;

public interface FieldCallback
{
    void doWith(final Field p0) throws IllegalArgumentException, IllegalAccessException;
}
