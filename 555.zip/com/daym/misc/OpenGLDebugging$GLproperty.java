package com.daym.misc;

public class GLproperty
{
    public int gLconstant;
    public String name;
    public String description;
    public String category;
    public String fetchCommand;
    
    public GLproperty(final int init_gLconstant, final String init_name, final String init_description, final String init_category, final String init_fetchCommand) {
        this.gLconstant = init_gLconstant;
        this.name = init_name;
        this.description = init_description;
        this.category = init_category;
        this.fetchCommand = init_fetchCommand;
    }
}
