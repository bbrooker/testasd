package com.daym.misc;

import net.minecraft.entity.player.*;
import com.daym.extended.*;
import com.daym.inventory.*;
import net.minecraft.item.*;
import java.util.*;
import com.daym.items.*;

public class PlayerInventoryManager
{
    public static boolean consumeInventoryItem(final EntityPlayer player, final Item item) {
        final PlayerInventoryDayM inventory = ExtendedPlayer.get(player).inventory;
        final boolean result = false;
        if (inventory != null) {
            for (int a = 0; a < 4; ++a) {
                final ItemInventory inv = getItemInventory(a, inventory);
                if (inv != null) {
                    final boolean worked = inv.consumeInventoryItem(item);
                    if (worked) {
                        return true;
                    }
                }
            }
        }
        return result;
    }
    
    public static void saveItemInventory(final ItemInventory inv) {
        if (inv.invItem != null && inv.invItem.field_77990_d != null) {
            inv.writeToNBT(inv.invItem.field_77990_d);
        }
    }
    
    public static ItemInventory getItemInventory(final int a, final PlayerInventoryDayM inventory) {
        int var = -1;
        if (a == 0) {
            var = 1;
        }
        if (a == 1) {
            var = 2;
        }
        if (a == 2) {
            var = 5;
        }
        if (a == 3) {
            var = 6;
        }
        if (var == -1) {
            return null;
        }
        final ItemStack is = inventory.inventory[var];
        if (is != null && is.func_77973_b() instanceof ItemWithInventory) {
            return new ItemInventory(is);
        }
        return null;
    }
    
    public static int getItemAms(final ItemInventory inv, final Item item) {
        for (int i = 0; i < inv.inventory.length; ++i) {
            if (inv.inventory[i] != null && inv.inventory[i].func_77973_b() == item) {
                return i;
            }
        }
        return -1;
    }
    
    public static int getFirstEmptyStack(final ItemInventory inv, final ItemStack stack) {
        final ItemWithInventory item = (ItemWithInventory)inv.invItem.func_77973_b();
        final ArrayList<Integer> bl = new ArrayList<Integer>();
        boolean doesSimpleCheck = false;
        for (int i = 1; i < inv.inventory.length; ++i) {
            if (stack != null && stack.func_77973_b() instanceof DayMItem) {
                final DayMItem daymitem = (DayMItem)stack.func_77973_b();
                final int sx = daymitem.slotSizeX;
                final int sy = daymitem.slotSizeY;
                final int ins = item.invSize / (item.invRows + 1);
                if (sx == 1 && sy == 1) {
                    doesSimpleCheck = true;
                }
                if (!doesSimpleCheck) {
                    for (int a = 0; a < sy; ++a) {
                        for (int b = 0; b < sx; ++b) {
                            final int blint = ins * a + b + i;
                            if (blint > inv.inventory.length - 1) {
                                if (!bl.contains(i)) {
                                    bl.add(i);
                                }
                            }
                            else if (blint < inv.inventory.length && inv.inventory[blint] != null && !bl.contains(i)) {
                                bl.add(i);
                            }
                        }
                    }
                }
            }
            if (inv.inventory[i] != null && inv.inventory[i].func_77973_b() instanceof DayMItem) {
                final DayMItem daymitem = (DayMItem)inv.inventory[i].func_77973_b();
                final int sx = daymitem.slotSizeX;
                final int sy = daymitem.slotSizeY;
                final int ins = item.invSize / (item.invRows + 1);
                for (int a = 0; a < sy; ++a) {
                    for (int b = 0; b < sx; ++b) {
                        final int blint = ins * a + b + i;
                        if (!bl.contains(blint)) {
                            bl.add(blint);
                        }
                    }
                }
            }
        }
        final int result = -1;
        for (int j = 1; j < inv.inventory.length; ++j) {
            if (inv.inventory[j] == null) {
                if (!doesSimpleCheck) {
                    if (!bl.contains(j)) {
                        return j;
                    }
                }
                else if (!bl.contains(j)) {
                    return j;
                }
            }
        }
        return result;
    }
    
    public static boolean addItemStackToInventory(final ItemStack itemstack, final EntityPlayer player) {
        final boolean result = false;
        for (int a = 0; a < 4; ++a) {
            final ItemInventory inv = getItemInventory(a, ExtendedPlayer.get(player).inventory);
            if (inv != null) {
                final boolean worked = inv.addItemStackToInventory(itemstack, player);
                if (worked) {
                    return true;
                }
            }
        }
        return result;
    }
    
    public static boolean hasItem(final EntityPlayer player, final Item am) {
        for (int a = 0; a < 4; ++a) {
            final ItemInventory inv = getItemInventory(a, ExtendedPlayer.get(player).inventory);
            if (inv != null) {
                for (final ItemStack is : inv.inventory) {
                    if (is != null && is.func_77973_b() == am) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
