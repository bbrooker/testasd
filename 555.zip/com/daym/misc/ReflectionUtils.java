package com.daym.misc;

import java.sql.*;
import java.lang.reflect.*;
import java.util.*;

public abstract class ReflectionUtils
{
    public static FieldFilter COPYABLE_FIELDS;
    
    public static Field findField(final Class clazz, final String name, final Class type) {
        for (Class searchType = clazz; !Object.class.equals(searchType) && searchType != null; searchType = searchType.getSuperclass()) {
            final Field[] fields = searchType.getDeclaredFields();
            for (int i = 0; i < fields.length; ++i) {
                final Field field = fields[i];
                if (name.equals(field.getName()) && type.equals(field.getType())) {
                    return field;
                }
            }
        }
        return null;
    }
    
    public static void setField(final Field field, final Object target, final Object value) {
        try {
            field.set(target, value);
        }
        catch (IllegalAccessException ex) {
            handleReflectionException(ex);
            throw new IllegalStateException("Unexpected reflection exception - " + ex.getClass().getName() + ": " + ex.getMessage());
        }
    }
    
    public static Method findMethod(final Class clazz, final String name) {
        return findMethod(clazz, name, new Class[0]);
    }
    
    public static Method findMethod(final Class clazz, final String name, final Class[] paramTypes) {
        for (Class searchType = clazz; !Object.class.equals(searchType) && searchType != null; searchType = searchType.getSuperclass()) {
            final Method[] methods = searchType.isInterface() ? searchType.getMethods() : searchType.getDeclaredMethods();
            for (int i = 0; i < methods.length; ++i) {
                final Method method = methods[i];
                if (name.equals(method.getName()) && Arrays.equals(paramTypes, method.getParameterTypes())) {
                    return method;
                }
            }
        }
        return null;
    }
    
    public static Object invokeMethod(final Method method, final Object target) {
        return invokeMethod(method, target, null);
    }
    
    public static Object invokeMethod(final Method method, final Object target, final Object[] args) {
        try {
            return method.invoke(target, args);
        }
        catch (Exception ex) {
            handleReflectionException(ex);
            throw new IllegalStateException("Should never get here");
        }
    }
    
    public static Object invokeJdbcMethod(final Method method, final Object target) throws SQLException {
        return invokeJdbcMethod(method, target, null);
    }
    
    public static Object invokeJdbcMethod(final Method method, final Object target, final Object[] args) throws SQLException {
        try {
            return method.invoke(target, args);
        }
        catch (IllegalAccessException ex) {
            handleReflectionException(ex);
        }
        catch (InvocationTargetException ex2) {
            if (ex2.getTargetException() instanceof SQLException) {
                throw (SQLException)ex2.getTargetException();
            }
            handleInvocationTargetException(ex2);
        }
        throw new IllegalStateException("Should never get here");
    }
    
    public static void handleReflectionException(final Exception ex) {
        if (ex instanceof NoSuchMethodException) {
            throw new IllegalStateException("Method not found: " + ex.getMessage());
        }
        if (ex instanceof IllegalAccessException) {
            throw new IllegalStateException("Could not access method: " + ex.getMessage());
        }
        if (ex instanceof InvocationTargetException) {
            handleInvocationTargetException((InvocationTargetException)ex);
        }
        if (ex instanceof RuntimeException) {
            throw (RuntimeException)ex;
        }
        handleUnexpectedException(ex);
    }
    
    public static void handleInvocationTargetException(final InvocationTargetException ex) {
        rethrowRuntimeException(ex.getTargetException());
    }
    
    public static void rethrowRuntimeException(final Throwable ex) {
        if (ex instanceof RuntimeException) {
            throw (RuntimeException)ex;
        }
        if (ex instanceof Error) {
            throw (Error)ex;
        }
        handleUnexpectedException(ex);
    }
    
    public static void rethrowException(final Throwable ex) throws Exception {
        if (ex instanceof Exception) {
            throw (Exception)ex;
        }
        if (ex instanceof Error) {
            throw (Error)ex;
        }
        handleUnexpectedException(ex);
    }
    
    private static void handleUnexpectedException(final Throwable ex) {
        final IllegalStateException isex = new IllegalStateException("Unexpected exception thrown");
        isex.initCause(ex);
        throw isex;
    }
    
    public static boolean declaresException(final Method method, final Class exceptionType) {
        final Class[] declaredExceptions = method.getExceptionTypes();
        for (int i = 0; i < declaredExceptions.length; ++i) {
            final Class declaredException = declaredExceptions[i];
            if (declaredException.isAssignableFrom(exceptionType)) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean isPublicStaticFinal(final Field field) {
        final int modifiers = field.getModifiers();
        return Modifier.isPublic(modifiers) && Modifier.isStatic(modifiers) && Modifier.isFinal(modifiers);
    }
    
    public static void makeAccessible(final Field field) {
        if (!Modifier.isPublic(field.getModifiers()) || !Modifier.isPublic(field.getDeclaringClass().getModifiers())) {
            field.setAccessible(true);
        }
    }
    
    public static void makeAccessible(final Method method) {
        if (!Modifier.isPublic(method.getModifiers()) || !Modifier.isPublic(method.getDeclaringClass().getModifiers())) {
            method.setAccessible(true);
        }
    }
    
    public static void makeAccessible(final Constructor ctor) {
        if (!Modifier.isPublic(ctor.getModifiers()) || !Modifier.isPublic(ctor.getDeclaringClass().getModifiers())) {
            ctor.setAccessible(true);
        }
    }
    
    public static void doWithMethods(final Class targetClass, final MethodCallback mc) throws IllegalArgumentException {
        doWithMethods(targetClass, mc, null);
    }
    
    public static void doWithMethods(Class targetClass, final MethodCallback mc, final MethodFilter mf) throws IllegalArgumentException {
        do {
            final Method[] methods = targetClass.getDeclaredMethods();
            for (int i = 0; i < methods.length; ++i) {
                if (mf == null || mf.matches(methods[i])) {
                    try {
                        mc.doWith(methods[i]);
                    }
                    catch (IllegalAccessException ex) {
                        throw new IllegalStateException("Shouldn't be illegal to access method '" + methods[i].getName() + "': " + ex);
                    }
                }
            }
            targetClass = targetClass.getSuperclass();
        } while (targetClass != null);
    }
    
    public static Method[] getAllDeclaredMethods(final Class leafClass) throws IllegalArgumentException {
        final List list = new ArrayList(32);
        doWithMethods(leafClass, new MethodCallback() {
            @Override
            public void doWith(final Method method) {
                list.add(method);
            }
        });
        return list.toArray(new Method[list.size()]);
    }
    
    public static void doWithFields(final Class targetClass, final FieldCallback fc) throws IllegalArgumentException {
        doWithFields(targetClass, fc, null);
    }
    
    public static void doWithFields(Class targetClass, final FieldCallback fc, final FieldFilter ff) throws IllegalArgumentException {
        do {
            final Field[] fields = targetClass.getDeclaredFields();
            for (int i = 0; i < fields.length; ++i) {
                if (ff == null || ff.matches(fields[i])) {
                    try {
                        fc.doWith(fields[i]);
                    }
                    catch (IllegalAccessException ex) {
                        throw new IllegalStateException("Shouldn't be illegal to access field '" + fields[i].getName() + "': " + ex);
                    }
                }
            }
            targetClass = targetClass.getSuperclass();
        } while (targetClass != null && targetClass != Object.class);
    }
    
    public static void shallowCopyFieldState(final Object src, final Object dest) throws IllegalArgumentException {
        if (src == null) {
            throw new IllegalArgumentException("Source for field copy cannot be null");
        }
        if (dest == null) {
            throw new IllegalArgumentException("Destination for field copy cannot be null");
        }
        if (!src.getClass().isAssignableFrom(dest.getClass())) {
            throw new IllegalArgumentException("Destination class [" + dest.getClass().getName() + "] must be same or subclass as source class [" + src.getClass().getName() + "]");
        }
        doWithFields(src.getClass(), new FieldCallback() {
            @Override
            public void doWith(final Field field) throws IllegalArgumentException, IllegalAccessException {
                ReflectionUtils.makeAccessible(field);
                final Object srcValue = field.get(src);
                field.set(dest, srcValue);
            }
        }, ReflectionUtils.COPYABLE_FIELDS);
    }
    
    static {
        ReflectionUtils.COPYABLE_FIELDS = new FieldFilter() {
            @Override
            public boolean matches(final Field field) {
                return !Modifier.isStatic(field.getModifiers()) && !Modifier.isFinal(field.getModifiers());
            }
        };
    }
    
    public interface FieldFilter
    {
        boolean matches(final Field p0);
    }
    
    public interface FieldCallback
    {
        void doWith(final Field p0) throws IllegalArgumentException, IllegalAccessException;
    }
    
    public interface MethodFilter
    {
        boolean matches(final Method p0);
    }
    
    public interface MethodCallback
    {
        void doWith(final Method p0) throws IllegalArgumentException, IllegalAccessException;
    }
}
