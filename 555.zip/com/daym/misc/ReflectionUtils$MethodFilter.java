package com.daym.misc;

import java.lang.reflect.*;

public interface MethodFilter
{
    boolean matches(final Method p0);
}
