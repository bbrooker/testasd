package com.daym.misc;

import net.minecraft.creativetab.*;
import net.minecraft.item.*;
import com.daym.registry.*;
import cpw.mods.fml.relauncher.*;

static final class DayMTabHandler$7 extends CreativeTabs {
    @SideOnly(Side.CLIENT)
    public Item func_78016_d() {
        return Item.func_150898_a(BlockRegistry.tileFloor[0]);
    }
}