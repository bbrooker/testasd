package com.daym.misc;

import java.lang.reflect.*;

static final class ReflectionUtils$3 implements FieldFilter {
    @Override
    public boolean matches(final Field field) {
        return !Modifier.isStatic(field.getModifiers()) && !Modifier.isFinal(field.getModifiers());
    }
}