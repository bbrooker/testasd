package com.daym.misc;

import net.minecraft.creativetab.*;
import net.minecraft.item.*;
import cpw.mods.fml.relauncher.*;
import com.daym.registry.*;

public class DayMTabHandler
{
    public static CreativeTabs tabGuns;
    public static CreativeTabs tabAmmo;
    public static CreativeTabs tabDayMItems;
    public static CreativeTabs tabDayMFood;
    public static CreativeTabs tabDayMClothing;
    public static CreativeTabs tabDayMDecoration;
    public static CreativeTabs tabDayMBlocks;
    public static CreativeTabs tabDayMStairs;
    public static CreativeTabs tabDayMSlabs;
    public static CreativeTabs tabDayMSlopes;
    
    static {
        DayMTabHandler.tabGuns = new CreativeTabs("tabGuns") {
            @SideOnly(Side.CLIENT)
            public Item func_78016_d() {
                return ItemRegistry.item_ak47;
            }
        };
        DayMTabHandler.tabAmmo = new CreativeTabs("tabAmmo") {
            @SideOnly(Side.CLIENT)
            public Item func_78016_d() {
                return ItemRegistry.mag_ak47;
            }
        };
        DayMTabHandler.tabDayMItems = new CreativeTabs("tabDayMItems") {
            @SideOnly(Side.CLIENT)
            public Item func_78016_d() {
                return ItemRegistry.item_axe;
            }
        };
        DayMTabHandler.tabDayMFood = new CreativeTabs("tabDayMFood") {
            @SideOnly(Side.CLIENT)
            public Item func_78016_d() {
                return ItemRegistry.item_fc_bakedbeans;
            }
        };
        DayMTabHandler.tabDayMClothing = new CreativeTabs("tabDayMClothing") {
            @SideOnly(Side.CLIENT)
            public Item func_78016_d() {
                return ItemRegistry.item_c_shirt_0;
            }
        };
        DayMTabHandler.tabDayMDecoration = new CreativeTabs("tabDayMDecoration") {
            @SideOnly(Side.CLIENT)
            public Item func_78016_d() {
                return Item.func_150898_a(BlockRegistry.woodenChair2);
            }
        };
        DayMTabHandler.tabDayMBlocks = new CreativeTabs("tabDayMBlocks") {
            @SideOnly(Side.CLIENT)
            public Item func_78016_d() {
                return Item.func_150898_a(BlockRegistry.tileFloor[0]);
            }
        };
        DayMTabHandler.tabDayMStairs = new CreativeTabs("tabDayMStairs") {
            @SideOnly(Side.CLIENT)
            public Item func_78016_d() {
                return Item.func_150898_a(BlockRegistry.tileFloorStairs[0]);
            }
        };
        DayMTabHandler.tabDayMSlabs = new CreativeTabs("tabDayMSlabs") {
            @SideOnly(Side.CLIENT)
            public Item func_78016_d() {
                return Item.func_150898_a(BlockRegistry.tileFloorSlabs[0]);
            }
        };
        DayMTabHandler.tabDayMSlopes = new CreativeTabs("tabDayMSlopes") {
            @SideOnly(Side.CLIENT)
            public Item func_78016_d() {
                return Item.func_150898_a(BlockRegistry.tileFloorSlopes[0]);
            }
        };
    }
}
