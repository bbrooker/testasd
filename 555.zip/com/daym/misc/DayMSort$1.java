package com.daym.misc;

import java.util.*;

static final class DayMSort$1 implements Comparator<T> {
    final /* synthetic */ String val$propertyName;
    
    @Override
    public int compare(final T object1, final T object2) {
        final String property1 = (String)DayMSort.getSpecifiedFieldValue(this.val$propertyName, object1);
        final String property2 = (String)DayMSort.getSpecifiedFieldValue(this.val$propertyName, object2);
        return property1.compareToIgnoreCase(property2);
    }
}