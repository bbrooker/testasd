package com.daym.config;

import java.util.*;
import com.daym.logger.*;
import java.io.*;
import cpw.mods.fml.common.*;

public class DayMConfig
{
    public static final Properties props;
    public static final File cfgdir;
    public static final File cfgfile;
    public static boolean daym_8fd972390;
    public static boolean daym_8fd972390GroundItem;
    public static boolean daym_fe7a127e0;
    public static int daym_d836addc0;
    public static int daym_bed00c4b0;
    public static int daym_94a3461e0;
    public static boolean daym_8eb8ec9d0;
    public static boolean renderBody;
    public static boolean didTutorial;
    
    public DayMConfig() {
        daym_df85ad1e0(DayMConfig.cfgdir, DayMConfig.cfgfile, DayMConfig.props);
        DayMConfig.daym_8fd972390 = (boolean)loadProp(DayMConfig.props, DayMConfig.daym_8fd972390, true, "HDModels");
        DayMConfig.daym_8fd972390GroundItem = (boolean)loadProp(DayMConfig.props, DayMConfig.daym_8fd972390GroundItem, false, "HDGroundItem");
        DayMConfig.daym_fe7a127e0 = (boolean)loadProp(DayMConfig.props, DayMConfig.daym_fe7a127e0, true, "AutoUnzoom");
        DayMConfig.daym_d836addc0 = (int)loadProp(DayMConfig.props, DayMConfig.daym_d836addc0, 1, "playerSkin");
        DayMConfig.daym_bed00c4b0 = (int)loadProp(DayMConfig.props, DayMConfig.daym_bed00c4b0, 2, "playerSkinShirt");
        DayMConfig.daym_94a3461e0 = (int)loadProp(DayMConfig.props, DayMConfig.daym_94a3461e0, 2, "playerSkinPants");
        DayMConfig.daym_8eb8ec9d0 = (boolean)loadProp(DayMConfig.props, DayMConfig.daym_8eb8ec9d0, false, "daym_8eb8ec9d0");
        DayMConfig.renderBody = (boolean)loadProp(DayMConfig.props, DayMConfig.renderBody, true, "renderBody");
        DayMConfig.didTutorial = (boolean)loadProp(DayMConfig.props, DayMConfig.didTutorial, false, "finishedTutorial");
        daym_c651688a0(DayMConfig.cfgdir, DayMConfig.cfgfile, DayMConfig.props);
    }
    
    public static Object loadProp(final Properties p, Object o, final Object def, final String pname) {
        if (p.containsKey(pname)) {
            o = parseObject(o, p.getProperty(pname));
            daymlog.out("Loaded config property '" + pname + "' = " + o);
            return o;
        }
        p.setProperty(pname, toStringObject(def));
        daymlog.out("Setup config property '" + pname + "'(" + def + ")");
        return def;
    }
    
    public static void saveProp(final Properties p, final Object o, final String pname) {
        p.setProperty(pname, toStringObject(o));
    }
    
    private static String toStringObject(final Object o) {
        if (o instanceof Boolean) {
            return ((Boolean)o).toString();
        }
        if (o instanceof String) {
            return (String)o;
        }
        if (o instanceof Integer) {
            return ((Integer)o).toString();
        }
        if (o instanceof Float) {
            return ((Float)o).toString();
        }
        return "";
    }
    
    private static Object parseObject(final Object o, final String property) {
        if (o instanceof Boolean) {
            final Boolean b = (Boolean)o;
            return Boolean.parseBoolean(property);
        }
        if (o instanceof String) {
            return property;
        }
        if (o instanceof Integer) {
            final Integer n = (Integer)o;
            return Integer.parseInt(property);
        }
        if (o instanceof Float) {
            final Float n2 = (Float)o;
            return Float.parseFloat(property);
        }
        return "";
    }
    
    public static void daym_df85ad1e0(final File dir, final File file, final Properties prop) {
        try {
            dir.mkdir();
            if (!file.exists() && !file.createNewFile()) {
                return;
            }
            if (file.canRead()) {
                final FileInputStream fileinputstream = new FileInputStream(file);
                prop.load(fileinputstream);
                fileinputstream.close();
            }
        }
        catch (IOException ex) {
            daymlog.out("Could not load DayM Config file.");
        }
    }
    
    public static void daym_c651688a0(final File dir, final File file, final Properties prop) {
        try {
            dir.mkdir();
            if (!file.exists() && !file.createNewFile()) {
                return;
            }
            if (file.canWrite()) {
                final FileOutputStream fileoutputstream = new FileOutputStream(file);
                prop.store(fileoutputstream, "~DayM Configuration File~ \n\nNote: Do not remove IgnoreNull from disabledEntities.\n");
                fileoutputstream.close();
            }
        }
        catch (IOException ex) {
            daymlog.out("Could not save DayM Config file.");
        }
    }
    
    static {
        props = new Properties();
        cfgdir = new File(Loader.instance().getConfigDir(), "/DayM/");
        cfgfile = new File(DayMConfig.cfgdir, "DayM.cfg");
        DayMConfig.daym_8fd972390 = true;
        DayMConfig.daym_8fd972390GroundItem = true;
        DayMConfig.daym_fe7a127e0 = true;
        DayMConfig.daym_d836addc0 = 0;
        DayMConfig.daym_bed00c4b0 = 0;
        DayMConfig.daym_94a3461e0 = 0;
        DayMConfig.daym_8eb8ec9d0 = false;
        DayMConfig.renderBody = true;
        DayMConfig.didTutorial = false;
    }
}
