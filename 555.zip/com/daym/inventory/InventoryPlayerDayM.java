package com.daym.inventory;

import cpw.mods.fml.relauncher.*;
import net.minecraft.entity.player.*;
import java.util.concurrent.*;
import net.minecraft.util.*;
import net.minecraft.crash.*;
import net.minecraft.block.*;
import net.minecraft.nbt.*;
import net.minecraft.item.*;
import net.minecraft.entity.*;

public class InventoryPlayerDayM extends InventoryPlayer
{
    public ItemStack[] field_70462_a;
    public ItemStack[] field_70460_b;
    public int field_70461_c;
    @SideOnly(Side.CLIENT)
    private ItemStack currentItemStack;
    public EntityPlayer field_70458_d;
    private ItemStack itemStack;
    public boolean field_70459_e;
    private static final String __OBFID = "CL_00001709";
    
    public InventoryPlayerDayM(final EntityPlayer p_i1750_1_) {
        super(p_i1750_1_);
        this.field_70462_a = new ItemStack[36];
        this.field_70460_b = new ItemStack[4];
        this.field_70458_d = p_i1750_1_;
    }
    
    public ItemStack func_70448_g() {
        return (this.field_70461_c < 9 && this.field_70461_c >= 0) ? this.field_70462_a[this.field_70461_c] : null;
    }
    
    public static int getHotbarSize() {
        return 9;
    }
    
    private int func_146029_c(final Item p_146029_1_) {
        for (int i = 0; i < this.field_70462_a.length; ++i) {
            if (this.field_70462_a[i] != null && this.field_70462_a[i].func_77973_b() == p_146029_1_) {
                return i;
            }
        }
        return -1;
    }
    
    @SideOnly(Side.CLIENT)
    private int func_146024_c(final Item p_146024_1_, final int p_146024_2_) {
        for (int j = 0; j < this.field_70462_a.length; ++j) {
            if (this.field_70462_a[j] != null && this.field_70462_a[j].func_77973_b() == p_146024_1_ && this.field_70462_a[j].func_77960_j() == p_146024_2_) {
                return j;
            }
        }
        return -1;
    }
    
    private int storeItemStack(final ItemStack p_70432_1_) {
        for (int i = 0; i < this.field_70462_a.length; ++i) {
            if (this.field_70462_a[i] != null && this.field_70462_a[i].func_77973_b() == p_70432_1_.func_77973_b() && this.field_70462_a[i].func_77985_e() && this.field_70462_a[i].field_77994_a < this.field_70462_a[i].func_77976_d() && this.field_70462_a[i].field_77994_a < this.func_70297_j_() && (!this.field_70462_a[i].func_77981_g() || this.field_70462_a[i].func_77960_j() == p_70432_1_.func_77960_j()) && ItemStack.func_77970_a(this.field_70462_a[i], p_70432_1_)) {
                return i;
            }
        }
        return -1;
    }
    
    public int func_70447_i() {
        for (int i = 0; i < this.field_70462_a.length; ++i) {
            if (this.field_70462_a[i] == null) {
                return i;
            }
        }
        return -1;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_146030_a(final Item p_146030_1_, final int p_146030_2_, final boolean p_146030_3_, final boolean p_146030_4_) {
        final boolean flag2 = true;
        this.currentItemStack = this.func_70448_g();
        int k;
        if (p_146030_3_) {
            k = this.func_146024_c(p_146030_1_, p_146030_2_);
        }
        else {
            k = this.func_146029_c(p_146030_1_);
        }
        if (k >= 0 && k < 9) {
            this.field_70461_c = k;
        }
        else if (p_146030_4_ && p_146030_1_ != null) {
            final int j = this.func_70447_i();
            if (j >= 0 && j < 9) {
                this.field_70461_c = j;
            }
            this.func_70439_a(p_146030_1_, p_146030_2_);
        }
    }
    
    public int func_146027_a(final Item p_146027_1_, final int p_146027_2_) {
        int j = 0;
        for (int k = 0; k < this.field_70462_a.length; ++k) {
            final ItemStack itemstack = this.field_70462_a[k];
            if (itemstack != null && (p_146027_1_ == null || itemstack.func_77973_b() == p_146027_1_) && (p_146027_2_ <= -1 || itemstack.func_77960_j() == p_146027_2_)) {
                j += itemstack.field_77994_a;
                this.field_70462_a[k] = null;
            }
        }
        for (int k = 0; k < this.field_70460_b.length; ++k) {
            final ItemStack itemstack = this.field_70460_b[k];
            if (itemstack != null && (p_146027_1_ == null || itemstack.func_77973_b() == p_146027_1_) && (p_146027_2_ <= -1 || itemstack.func_77960_j() == p_146027_2_)) {
                j += itemstack.field_77994_a;
                this.field_70460_b[k] = null;
            }
        }
        if (this.itemStack != null) {
            if (p_146027_1_ != null && this.itemStack.func_77973_b() != p_146027_1_) {
                return j;
            }
            if (p_146027_2_ > -1 && this.itemStack.func_77960_j() != p_146027_2_) {
                return j;
            }
            j += this.itemStack.field_77994_a;
            this.func_70437_b(null);
        }
        return j;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_70453_c(int p_70453_1_) {
        if (p_70453_1_ > 0) {
            p_70453_1_ = 1;
        }
        if (p_70453_1_ < 0) {
            p_70453_1_ = -1;
        }
        this.field_70461_c -= p_70453_1_;
        while (this.field_70461_c < 0) {
            this.field_70461_c += 9;
        }
        while (this.field_70461_c >= 9) {
            this.field_70461_c -= 9;
        }
    }
    
    @SideOnly(Side.CLIENT)
    public void func_70439_a(final Item p_70439_1_, final int p_70439_2_) {
        if (p_70439_1_ != null) {
            if (this.currentItemStack != null && this.currentItemStack.func_77956_u() && this.func_146024_c(this.currentItemStack.func_77973_b(), this.currentItemStack.func_77952_i()) == this.field_70461_c) {
                return;
            }
            final int j = this.func_146024_c(p_70439_1_, p_70439_2_);
            if (j >= 0) {
                final int k = this.field_70462_a[j].field_77994_a;
                this.field_70462_a[j] = this.field_70462_a[this.field_70461_c];
                this.field_70462_a[this.field_70461_c] = new ItemStack(p_70439_1_, k, p_70439_2_);
            }
            else {
                this.field_70462_a[this.field_70461_c] = new ItemStack(p_70439_1_, 1, p_70439_2_);
            }
        }
    }
    
    private int storePartialItemStack(final ItemStack p_70452_1_) {
        final Item item = p_70452_1_.func_77973_b();
        int i = p_70452_1_.field_77994_a;
        if (p_70452_1_.func_77976_d() == 1) {
            final int j = this.func_70447_i();
            if (j < 0) {
                return i;
            }
            if (this.field_70462_a[j] == null) {
                this.field_70462_a[j] = ItemStack.func_77944_b(p_70452_1_);
            }
            return 0;
        }
        else {
            int j = this.storeItemStack(p_70452_1_);
            if (j < 0) {
                j = this.func_70447_i();
            }
            if (j < 0) {
                return i;
            }
            if (this.field_70462_a[j] == null) {
                this.field_70462_a[j] = new ItemStack(item, 0, p_70452_1_.func_77960_j());
                if (p_70452_1_.func_77942_o()) {
                    this.field_70462_a[j].func_77982_d((NBTTagCompound)p_70452_1_.func_77978_p().func_74737_b());
                }
            }
            int k;
            if ((k = i) > this.field_70462_a[j].func_77976_d() - this.field_70462_a[j].field_77994_a) {
                k = this.field_70462_a[j].func_77976_d() - this.field_70462_a[j].field_77994_a;
            }
            if (k > this.func_70297_j_() - this.field_70462_a[j].field_77994_a) {
                k = this.func_70297_j_() - this.field_70462_a[j].field_77994_a;
            }
            if (k == 0) {
                return i;
            }
            i -= k;
            final ItemStack itemStack = this.field_70462_a[j];
            itemStack.field_77994_a += k;
            this.field_70462_a[j].field_77992_b = 5;
            return i;
        }
    }
    
    public void func_70429_k() {
        for (int i = 0; i < this.field_70462_a.length; ++i) {
            if (this.field_70462_a[i] != null) {
                this.field_70462_a[i].func_77945_a(this.field_70458_d.field_70170_p, (Entity)this.field_70458_d, i, this.field_70461_c == i);
            }
        }
        for (int i = 0; i < this.field_70460_b.length; ++i) {
            if (this.field_70460_b[i] != null) {
                this.field_70460_b[i].func_77973_b().onArmorTick(this.field_70458_d.field_70170_p, this.field_70458_d, this.field_70460_b[i]);
            }
        }
    }
    
    public boolean func_146026_a(final Item p_146026_1_) {
        final int i = this.func_146029_c(p_146026_1_);
        if (i < 0) {
            return false;
        }
        final ItemStack itemStack = this.field_70462_a[i];
        if (--itemStack.field_77994_a <= 0) {
            this.field_70462_a[i] = null;
        }
        return true;
    }
    
    public boolean func_146028_b(final Item p_146028_1_) {
        final int i = this.func_146029_c(p_146028_1_);
        return i >= 0;
    }
    
    public boolean func_70441_a(final ItemStack p_70441_1_) {
        if (p_70441_1_ != null && p_70441_1_.field_77994_a != 0 && p_70441_1_.func_77973_b() != null) {
            try {
                if (p_70441_1_.func_77951_h()) {
                    final int i = this.func_70447_i();
                    if (i >= 0) {
                        this.field_70462_a[i] = ItemStack.func_77944_b(p_70441_1_);
                        this.field_70462_a[i].field_77992_b = 5;
                        p_70441_1_.field_77994_a = 0;
                        return true;
                    }
                    if (this.field_70458_d.field_71075_bZ.field_75098_d) {
                        p_70441_1_.field_77994_a = 0;
                        return true;
                    }
                    return false;
                }
                else {
                    int i;
                    do {
                        i = p_70441_1_.field_77994_a;
                        p_70441_1_.field_77994_a = this.storePartialItemStack(p_70441_1_);
                    } while (p_70441_1_.field_77994_a > 0 && p_70441_1_.field_77994_a < i);
                    if (p_70441_1_.field_77994_a == i && this.field_70458_d.field_71075_bZ.field_75098_d) {
                        p_70441_1_.field_77994_a = 0;
                        return true;
                    }
                    return p_70441_1_.field_77994_a < i;
                }
            }
            catch (Throwable throwable) {
                final CrashReport crashreport = CrashReport.func_85055_a(throwable, "Adding item to inventory");
                final CrashReportCategory crashreportcategory = crashreport.func_85058_a("Item being added");
                crashreportcategory.func_71507_a("Item ID", (Object)Item.func_150891_b(p_70441_1_.func_77973_b()));
                crashreportcategory.func_71507_a("Item data", (Object)p_70441_1_.func_77960_j());
                crashreportcategory.func_71500_a("Item name", (Callable)new Callable() {
                    private static final String __OBFID = "CL_00001710";
                    
                    @Override
                    public String call() {
                        return p_70441_1_.func_82833_r();
                    }
                });
                throw new ReportedException(crashreport);
            }
        }
        return false;
    }
    
    public ItemStack func_70298_a(int p_70298_1_, final int p_70298_2_) {
        ItemStack[] aitemstack = this.field_70462_a;
        if (p_70298_1_ >= this.field_70462_a.length) {
            aitemstack = this.field_70460_b;
            p_70298_1_ -= this.field_70462_a.length;
        }
        if (aitemstack[p_70298_1_] == null) {
            return null;
        }
        if (aitemstack[p_70298_1_].field_77994_a <= p_70298_2_) {
            final ItemStack itemstack = aitemstack[p_70298_1_];
            aitemstack[p_70298_1_] = null;
            return itemstack;
        }
        final ItemStack itemstack = aitemstack[p_70298_1_].func_77979_a(p_70298_2_);
        if (aitemstack[p_70298_1_].field_77994_a == 0) {
            aitemstack[p_70298_1_] = null;
        }
        return itemstack;
    }
    
    public ItemStack func_70304_b(int p_70304_1_) {
        ItemStack[] aitemstack = this.field_70462_a;
        if (p_70304_1_ >= this.field_70462_a.length) {
            aitemstack = this.field_70460_b;
            p_70304_1_ -= this.field_70462_a.length;
        }
        if (aitemstack[p_70304_1_] != null) {
            final ItemStack itemstack = aitemstack[p_70304_1_];
            aitemstack[p_70304_1_] = null;
            return itemstack;
        }
        return null;
    }
    
    public void func_70299_a(int p_70299_1_, final ItemStack p_70299_2_) {
        ItemStack[] aitemstack = this.field_70462_a;
        if (p_70299_1_ >= aitemstack.length) {
            p_70299_1_ -= aitemstack.length;
            aitemstack = this.field_70460_b;
        }
        aitemstack[p_70299_1_] = p_70299_2_;
    }
    
    public float func_146023_a(final Block p_146023_1_) {
        float f = 1.0f;
        if (this.field_70462_a[this.field_70461_c] != null) {
            f *= this.field_70462_a[this.field_70461_c].func_150997_a(p_146023_1_);
        }
        return f;
    }
    
    public NBTTagList func_70442_a(final NBTTagList p_70442_1_) {
        for (int i = 0; i < this.field_70462_a.length; ++i) {
            if (this.field_70462_a[i] != null) {
                final NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.func_74774_a("Slot", (byte)i);
                this.field_70462_a[i].func_77955_b(nbttagcompound);
                p_70442_1_.func_74742_a((NBTBase)nbttagcompound);
            }
        }
        for (int i = 0; i < this.field_70460_b.length; ++i) {
            if (this.field_70460_b[i] != null) {
                final NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.func_74774_a("Slot", (byte)(i + 100));
                this.field_70460_b[i].func_77955_b(nbttagcompound);
                p_70442_1_.func_74742_a((NBTBase)nbttagcompound);
            }
        }
        return p_70442_1_;
    }
    
    public void func_70443_b(final NBTTagList p_70443_1_) {
        this.field_70462_a = new ItemStack[36];
        this.field_70460_b = new ItemStack[4];
        for (int i = 0; i < p_70443_1_.func_74745_c(); ++i) {
            final NBTTagCompound nbttagcompound = p_70443_1_.func_150305_b(i);
            final int j = nbttagcompound.func_74771_c("Slot") & 0xFF;
            final ItemStack itemstack = ItemStack.func_77949_a(nbttagcompound);
            if (itemstack != null) {
                if (j >= 0 && j < this.field_70462_a.length) {
                    this.field_70462_a[j] = itemstack;
                }
                if (j >= 100 && j < this.field_70460_b.length + 100) {
                    this.field_70460_b[j - 100] = itemstack;
                }
            }
        }
    }
    
    public int func_70302_i_() {
        return this.field_70462_a.length + 4;
    }
    
    public ItemStack func_70301_a(int p_70301_1_) {
        ItemStack[] aitemstack = this.field_70462_a;
        if (p_70301_1_ >= aitemstack.length) {
            p_70301_1_ -= aitemstack.length;
            aitemstack = this.field_70460_b;
        }
        return aitemstack[p_70301_1_];
    }
    
    public String func_145825_b() {
        return "container.inventory";
    }
    
    public boolean func_145818_k_() {
        return false;
    }
    
    public int func_70297_j_() {
        return 64;
    }
    
    public boolean func_146025_b(final Block p_146025_1_) {
        if (p_146025_1_.func_149688_o().func_76229_l()) {
            return true;
        }
        final ItemStack itemstack = this.func_70301_a(this.field_70461_c);
        return itemstack != null && itemstack.func_150998_b(p_146025_1_);
    }
    
    public ItemStack func_70440_f(final int p_70440_1_) {
        return this.field_70460_b[p_70440_1_];
    }
    
    public int func_70430_l() {
        int i = 0;
        for (int j = 0; j < this.field_70460_b.length; ++j) {
            if (this.field_70460_b[j] != null && this.field_70460_b[j].func_77973_b() instanceof ItemArmor) {
                final int k = ((ItemArmor)this.field_70460_b[j].func_77973_b()).field_77879_b;
                i += k;
            }
        }
        return i;
    }
    
    public void func_70449_g(float p_70449_1_) {
        p_70449_1_ /= 4.0f;
        if (p_70449_1_ < 1.0f) {
            p_70449_1_ = 1.0f;
        }
        for (int i = 0; i < this.field_70460_b.length; ++i) {
            if (this.field_70460_b[i] != null && this.field_70460_b[i].func_77973_b() instanceof ItemArmor) {
                this.field_70460_b[i].func_77972_a((int)p_70449_1_, (EntityLivingBase)this.field_70458_d);
                if (this.field_70460_b[i].field_77994_a == 0) {
                    this.field_70460_b[i] = null;
                }
            }
        }
    }
    
    public void func_70436_m() {
        for (int i = 0; i < this.field_70462_a.length; ++i) {
            if (this.field_70462_a[i] != null) {
                this.field_70458_d.func_146097_a(this.field_70462_a[i], true, false);
                this.field_70462_a[i] = null;
            }
        }
        for (int i = 0; i < this.field_70460_b.length; ++i) {
            if (this.field_70460_b[i] != null) {
                this.field_70458_d.func_146097_a(this.field_70460_b[i], true, false);
                this.field_70460_b[i] = null;
            }
        }
    }
    
    public void func_70296_d() {
        this.field_70459_e = true;
    }
    
    public void func_70437_b(final ItemStack p_70437_1_) {
        this.itemStack = p_70437_1_;
    }
    
    public ItemStack func_70445_o() {
        return this.itemStack;
    }
    
    public boolean func_70300_a(final EntityPlayer p_70300_1_) {
        return !this.field_70458_d.field_70128_L;
    }
    
    public boolean func_70431_c(final ItemStack p_70431_1_) {
        for (int i = 0; i < this.field_70460_b.length; ++i) {
            if (this.field_70460_b[i] != null && this.field_70460_b[i].func_77969_a(p_70431_1_)) {
                return true;
            }
        }
        for (int i = 0; i < this.field_70462_a.length; ++i) {
            if (this.field_70462_a[i] != null && this.field_70462_a[i].func_77969_a(p_70431_1_)) {
                return true;
            }
        }
        return false;
    }
    
    public void func_70295_k_() {
    }
    
    public void func_70305_f() {
    }
    
    public boolean func_94041_b(final int p_94041_1_, final ItemStack p_94041_2_) {
        return true;
    }
    
    public void copyInventory(final InventoryPlayerDayM p_70455_1_) {
        for (int i = 0; i < this.field_70462_a.length; ++i) {
            this.field_70462_a[i] = ItemStack.func_77944_b(p_70455_1_.field_70462_a[i]);
        }
        for (int i = 0; i < this.field_70460_b.length; ++i) {
            this.field_70460_b[i] = ItemStack.func_77944_b(p_70455_1_.field_70460_b[i]);
        }
        this.field_70461_c = p_70455_1_.field_70461_c;
    }
}
