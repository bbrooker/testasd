package com.daym.inventory;

import net.minecraft.inventory.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import net.minecraft.nbt.*;

public class PlayerInventoryDayM implements IInventory
{
    private final String name = "Inventory";
    private final String tagName = "DayMInventory";
    public static final int INV_SIZE = 8;
    public ItemStack[] inventory;
    
    public PlayerInventoryDayM() {
        this.inventory = new ItemStack[8];
    }
    
    public int func_70302_i_() {
        return this.inventory.length;
    }
    
    public ItemStack func_70301_a(final int slot) {
        return this.inventory[slot];
    }
    
    public ItemStack func_70298_a(final int slot, final int amount) {
        ItemStack stack = this.func_70301_a(slot);
        if (stack != null) {
            if (stack.field_77994_a > amount) {
                stack = stack.func_77979_a(amount);
                if (stack.field_77994_a == 0) {
                    this.func_70299_a(slot, null);
                }
            }
            else {
                this.func_70299_a(slot, null);
            }
            this.func_70296_d();
        }
        return stack;
    }
    
    public void dropAllItems(final EntityPlayer player) {
        for (ItemStack is : this.inventory) {
            if (is != null) {
                player.func_146097_a(is, false, false);
                is = null;
            }
        }
        this.func_70296_d();
    }
    
    public ItemStack func_70304_b(final int slot) {
        final ItemStack stack = this.func_70301_a(slot);
        if (stack != null) {
            this.func_70299_a(slot, null);
        }
        return stack;
    }
    
    public void func_70299_a(final int slot, final ItemStack itemstack) {
        this.inventory[slot] = itemstack;
        if (itemstack != null && itemstack.field_77994_a > this.func_70297_j_()) {
            itemstack.field_77994_a = this.func_70297_j_();
        }
        this.func_70296_d();
    }
    
    public String func_145825_b() {
        return "Inventory";
    }
    
    public int func_70297_j_() {
        return 1;
    }
    
    public void func_70296_d() {
        for (int i = 0; i < this.func_70302_i_(); ++i) {
            if (this.func_70301_a(i) != null && this.func_70301_a(i).field_77994_a == 0) {
                this.func_70299_a(i, null);
            }
        }
    }
    
    public boolean func_70300_a(final EntityPlayer entityplayer) {
        return true;
    }
    
    public void func_70295_k_() {
    }
    
    public void func_70305_f() {
    }
    
    public boolean func_94041_b(final int slot, final ItemStack itemstack) {
        return true;
    }
    
    public void writeToNBT(final NBTTagCompound compound) {
        final NBTTagList items = new NBTTagList();
        for (int i = 0; i < this.func_70302_i_(); ++i) {
            if (this.func_70301_a(i) != null) {
                final NBTTagCompound item = new NBTTagCompound();
                item.func_74774_a("Slot", (byte)i);
                this.func_70301_a(i).func_77955_b(item);
                items.func_74742_a((NBTBase)item);
            }
        }
        compound.func_74782_a("DayMInventory", (NBTBase)items);
    }
    
    public void readFromNBT(final NBTTagCompound compound) {
        final NBTTagList items = compound.func_150295_c("DayMInventory", (int)compound.func_74732_a());
        for (int i = 0; i < items.func_74745_c(); ++i) {
            final NBTTagCompound item = items.func_150305_b(i);
            final byte slot = item.func_74771_c("Slot");
            if (slot >= 0 && slot < this.func_70302_i_()) {
                this.inventory[slot] = ItemStack.func_77949_a(item);
            }
        }
    }
    
    public boolean func_145818_k_() {
        return true;
    }
}
