package com.daym.inventory;

import net.minecraft.inventory.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import net.minecraft.nbt.*;

public class ItemPickupInventory implements IInventory
{
    private String name;
    protected String uniqueID;
    public static int INV_SIZE;
    public ItemStack[] inventory;
    
    public ItemPickupInventory() {
        this.name = "Storage";
        this.inventory = new ItemStack[ItemPickupInventory.INV_SIZE];
    }
    
    public int func_70302_i_() {
        return this.inventory.length;
    }
    
    public ItemStack func_70301_a(final int slot) {
        return this.inventory[slot];
    }
    
    public ItemStack func_70298_a(final int slot, final int amount) {
        ItemStack stack = this.func_70301_a(slot);
        if (stack != null) {
            if (stack.field_77994_a > amount) {
                stack = stack.func_77979_a(amount);
                this.func_70296_d();
            }
            else {
                this.func_70299_a(slot, null);
            }
        }
        return stack;
    }
    
    public ItemStack func_70304_b(final int slot) {
        final ItemStack stack = this.func_70301_a(slot);
        if (stack != null) {
            this.func_70299_a(slot, null);
        }
        return stack;
    }
    
    public boolean consumeInventoryItem(final Item p_146026_1_) {
        final int i = this.func_146029_c(p_146026_1_);
        if (i < 0) {
            return false;
        }
        final ItemStack itemStack = this.inventory[i];
        if (--itemStack.field_77994_a <= 0) {
            this.inventory[i] = null;
        }
        this.func_70296_d();
        return true;
    }
    
    private int func_146029_c(final Item p_146029_1_) {
        for (int i = 0; i < this.inventory.length; ++i) {
            if (this.inventory[i] != null && this.inventory[i].func_77973_b() == p_146029_1_) {
                return i;
            }
        }
        return -1;
    }
    
    public void func_70299_a(final int slot, final ItemStack itemstack) {
        this.inventory[slot] = itemstack;
        if (itemstack != null && itemstack.field_77994_a > this.func_70297_j_()) {
            itemstack.field_77994_a = this.func_70297_j_();
        }
        this.func_70296_d();
    }
    
    public String func_145825_b() {
        return this.name;
    }
    
    public boolean func_145818_k_() {
        return this.name.length() > 0;
    }
    
    public int func_70297_j_() {
        return 64;
    }
    
    public void func_70296_d() {
        for (int i = 0; i < this.func_70302_i_(); ++i) {
            if (this.func_70301_a(i) != null && this.func_70301_a(i).field_77994_a == 0) {
                this.inventory[i] = null;
            }
        }
    }
    
    public boolean func_70300_a(final EntityPlayer player) {
        return true;
    }
    
    public void func_70295_k_() {
    }
    
    public void func_70305_f() {
    }
    
    public boolean func_94041_b(final int slot, final ItemStack itemstack) {
        return true;
    }
    
    public void readFromNBT(final NBTTagCompound tagcompound) {
    }
    
    public void writeToNBT(final NBTTagCompound tagcompound) {
    }
    
    static {
        ItemPickupInventory.INV_SIZE = 1;
    }
}
