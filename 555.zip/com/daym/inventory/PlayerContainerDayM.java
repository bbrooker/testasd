package com.daym.inventory;

import net.minecraft.inventory.*;
import com.daym.items.*;
import com.daym.gui.inventory.slot.*;
import net.minecraft.nbt.*;
import java.util.*;
import net.minecraft.item.*;
import cpw.mods.fml.common.*;
import com.daym.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.entity.player.*;

public class PlayerContainerDayM extends ContainerPlayer
{
    private static final int ARMOR_START = 8;
    private static final int ARMOR_END = 11;
    private static final int INV_START = 12;
    private static final int INV_END = 38;
    private static final int HOTBAR_START = 39;
    private static final int HOTBAR_END = 47;
    protected static EntityPlayer thePlayer;
    private InventoryPlayer inventoryPlayer;
    private PlayerInventoryDayM inventoryCustom;
    public ItemInventory[] daym_c8ee2c4b0;
    public int[] inventoryGuiOffset;
    public List daym_00e776590;
    public int daym_a58cb7bc0;
    public int daym_a58cb7bc0gui;
    public int daym_72bd6ea70;
    public int daym_1bb3e1050;
    public int daym_1bb3e10502;
    public ArrayList<Integer> daym_610d19f40;
    
    public PlayerContainerDayM(final EntityPlayer player, final InventoryPlayer ip, final PlayerInventoryDayM ic) {
        super(ip, player.field_70170_p.field_72995_K, player);
        this.daym_c8ee2c4b0 = new ItemInventory[16];
        this.inventoryGuiOffset = new int[16];
        this.daym_00e776590 = new ArrayList();
        this.daym_a58cb7bc0 = 0;
        this.daym_a58cb7bc0gui = 0;
        this.daym_72bd6ea70 = 0;
        this.daym_1bb3e1050 = 0;
        this.daym_1bb3e10502 = 0;
        this.daym_610d19f40 = new ArrayList<Integer>();
        PlayerContainerDayM.thePlayer = player;
        this.inventoryPlayer = ip;
        this.inventoryCustom = ic;
        this.addInventorySlots(player, true);
    }
    
    public void addInventorySlots(final EntityPlayer player, final boolean addAll) {
        this.daym_c8ee2c4b0 = new ItemInventory[16];
        this.inventoryGuiOffset = new int[16];
        this.field_75151_b.clear();
        this.field_75153_a.clear();
        this.daym_c8ee2c4b0[0] = null;
        this.daym_c8ee2c4b0[1] = null;
        this.daym_c8ee2c4b0[2] = null;
        this.daym_c8ee2c4b0[3] = null;
        this.daym_c8ee2c4b0[4] = null;
        this.daym_c8ee2c4b0[5] = null;
        this.daym_c8ee2c4b0[6] = null;
        this.daym_c8ee2c4b0[7] = null;
        this.daym_c8ee2c4b0[8] = null;
        this.daym_c8ee2c4b0[9] = null;
        this.daym_c8ee2c4b0[10] = null;
        if (addAll) {
            for (int i = 0; i < 4; ++i) {
                this.func_75146_a((Slot)new SlotClothing((IInventory)this.inventoryCustom, i, 42, -6 + i * 24));
            }
            for (int i = 4; i < 8; ++i) {
                this.func_75146_a((Slot)new SlotClothing((IInventory)this.inventoryCustom, i, 118, -6 + (i - 4) * 24));
            }
            final int offsc = 26;
            final int offsc2 = 8;
            final int offscy = 78;
            this.func_75146_a((Slot)new SlotCrafting(player, (IInventory)this.field_75181_e, this.field_75179_f, 0, 144 - offsc, 36 + offscy));
            for (int i = 0; i < 2; ++i) {
                for (int j = 0; j < 2; ++j) {
                    this.func_75146_a(new Slot((IInventory)this.field_75181_e, j + i * 2, 88 + j * 18 - offsc + offsc2, 26 + i * 18 + offscy));
                }
            }
        }
        this.daym_a58cb7bc0 = 0;
        if (this.field_75151_b.size() != this.daym_00e776590.size()) {
            this.daym_00e776590.clear();
            this.daym_00e776590.addAll(this.field_75151_b);
        }
        for (final Object o : this.daym_00e776590) {
            if (o instanceof SlotClothing) {
                final SlotClothing slot = (SlotClothing)o;
                if (slot.field_75222_d != 5 && slot.field_75222_d != 6 && slot.field_75222_d != 1 && slot.field_75222_d != 2) {
                    continue;
                }
                boolean createdinv = false;
                final ItemStack is = slot.func_75211_c();
                if (is != null && is.func_77973_b() instanceof ItemWithInventory) {
                    final ItemWithInventory item = (ItemWithInventory)is.func_77973_b();
                    if (slot.field_75222_d == 1) {
                        this.daym_a58cb7bc0 = 0;
                    }
                    if (slot.field_75222_d == 2) {
                        this.daym_a58cb7bc0 = 1;
                    }
                    if (slot.field_75222_d == 5) {
                        this.daym_a58cb7bc0 = 2;
                    }
                    if (slot.field_75222_d == 6) {
                        this.daym_a58cb7bc0 = 3;
                    }
                    if (this.daym_a58cb7bc0 >= 0) {
                        this.daym_c8ee2c4b0[this.daym_a58cb7bc0] = new ItemInventory(is);
                        createdinv = true;
                        if (this.daym_c8ee2c4b0[this.daym_a58cb7bc0].inventory != null) {
                            int id = 0;
                            for (int k = 0; k < item.invRows + 1; ++k) {
                                for (int i = 0; i < item.invSize / (item.invRows + 1); ++i) {
                                    ++id;
                                    final Slot test = this.func_75146_a((Slot)new SlotSized((IInventory)this.daym_c8ee2c4b0[this.daym_a58cb7bc0], id, 102 + 18 * i + 50, 20 + this.daym_1bb3e1050 + 10 - 32 + 18 * k));
                                }
                            }
                        }
                    }
                }
                else {
                    this.daym_c8ee2c4b0[this.daym_a58cb7bc0] = null;
                }
                if (!createdinv) {
                    continue;
                }
                if (this.daym_c8ee2c4b0[this.daym_a58cb7bc0] != null && this.daym_c8ee2c4b0[this.daym_a58cb7bc0].invItem != null) {
                    this.inventoryGuiOffset[this.daym_a58cb7bc0] = this.daym_1bb3e1050;
                    this.daym_1bb3e1050 += ((ItemWithInventory)this.daym_c8ee2c4b0[this.daym_a58cb7bc0].invItem.func_77973_b()).invRows * 18 + 32;
                    final ItemStack is2 = this.daym_c8ee2c4b0[this.daym_a58cb7bc0].invItem;
                    if (!is2.func_77942_o()) {
                        is2.field_77990_d = new NBTTagCompound();
                    }
                    is2.field_77990_d.func_74768_a("itemInventoryDayMID", this.daym_a58cb7bc0);
                    ++this.daym_a58cb7bc0;
                }
                ++this.daym_a58cb7bc0gui;
            }
        }
        if (addAll) {
            for (int i = 0; i < 5; ++i) {
                this.func_75146_a(new Slot((IInventory)this.inventoryPlayer, i, 8 + i * 18 + 36, 146));
            }
        }
    }
    
    public void func_75142_b() {
        super.func_75142_b();
    }
    
    public void func_75134_a(final EntityPlayer player) {
        super.func_75134_a(player);
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isServer()) {
            DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_SyncPlayerProps(0, player));
        }
    }
    
    public ItemStack func_75144_a(final int par1, final int par2, final int par3, final EntityPlayer player) {
        final ItemStack buffer = super.func_75144_a(par1, par2, par3, player);
        for (final Object ents : player.field_70170_p.field_73010_i) {
            if (ents instanceof EntityPlayerMP && ents != player) {
                DayM.daym_6cbaa18a0.sendTo((IMessage)new MSG_SyncPlayerProps(0, player), (EntityPlayerMP)ents);
            }
        }
        return buffer;
    }
    
    public boolean func_75145_c(final EntityPlayer player) {
        return true;
    }
    
    public ItemStack func_82846_b(final EntityPlayer player, final int par2) {
        return null;
    }
}
