package com.daym.inventory;

import net.minecraft.inventory.*;
import com.daym.items.*;
import java.util.*;
import net.minecraft.item.*;
import com.daym.misc.*;
import net.minecraft.entity.player.*;
import net.minecraft.nbt.*;

public class ItemInventory implements IInventory
{
    private String name;
    protected String uniqueID;
    public static int INV_SIZE;
    public ItemStack[] inventory;
    public final ItemStack invItem;
    
    public ItemInventory(final ItemStack stack) {
        this.name = "Storage";
        if (stack != null && stack.func_77973_b() instanceof ItemWithInventory) {
            ItemInventory.INV_SIZE = ((ItemWithInventory)stack.func_77973_b()).invSize;
            this.inventory = new ItemStack[ItemInventory.INV_SIZE + 1];
        }
        this.invItem = stack;
        this.name = stack.func_82833_r();
        this.uniqueID = "";
        if (!stack.func_77942_o()) {
            stack.func_77982_d(new NBTTagCompound());
            this.uniqueID = UUID.randomUUID().toString();
        }
        this.readFromNBT(stack.func_77978_p());
    }
    
    public int func_70302_i_() {
        return this.inventory.length;
    }
    
    public ItemStack func_70301_a(final int slot) {
        return this.inventory[slot];
    }
    
    public ItemStack func_70298_a(final int slot, final int amount) {
        ItemStack stack = this.func_70301_a(slot);
        if (stack != null) {
            if (stack.field_77994_a > amount) {
                stack = stack.func_77979_a(amount);
                this.func_70296_d();
            }
            else {
                this.func_70299_a(slot, null);
            }
        }
        return stack;
    }
    
    public ItemStack func_70304_b(final int slot) {
        final ItemStack stack = this.func_70301_a(slot);
        if (stack != null) {
            this.func_70299_a(slot, null);
        }
        return stack;
    }
    
    public boolean consumeInventoryItem(final Item p_146026_1_) {
        final int i = this.func_146029_c(p_146026_1_);
        if (i < 0) {
            return false;
        }
        final ItemStack itemStack = this.inventory[i];
        if (--itemStack.field_77994_a <= 0) {
            this.inventory[i] = null;
        }
        this.func_70296_d();
        return true;
    }
    
    private int func_146029_c(final Item p_146029_1_) {
        for (int i = 0; i < this.inventory.length; ++i) {
            if (this.inventory[i] != null && this.inventory[i].func_77973_b() == p_146029_1_) {
                return i;
            }
        }
        return -1;
    }
    
    public void func_70299_a(final int slot, final ItemStack itemstack) {
        this.inventory[slot] = itemstack;
        if (itemstack != null && itemstack.field_77994_a > this.func_70297_j_()) {
            itemstack.field_77994_a = this.func_70297_j_();
        }
        this.func_70296_d();
    }
    
    public String func_145825_b() {
        return this.name;
    }
    
    public boolean func_145818_k_() {
        return this.name.length() > 0;
    }
    
    public int func_70297_j_() {
        return 64;
    }
    
    public int getFirstEmptyStack(final ItemStack stack) {
        return PlayerInventoryManager.getFirstEmptyStack(this, stack);
    }
    
    public boolean addItemStackToInventory(final ItemStack p_70441_1_, final EntityPlayer player) {
        if (p_70441_1_ != null && p_70441_1_.field_77994_a != 0 && p_70441_1_.func_77973_b() != null) {
            try {
                int i = this.getFirstEmptyStack(p_70441_1_);
                if (i < 0) {
                    return false;
                }
                if (p_70441_1_.func_77951_h()) {
                    if (i >= 0) {
                        this.inventory[i] = ItemStack.func_77944_b(p_70441_1_);
                        this.inventory[i].field_77992_b = 5;
                        p_70441_1_.field_77994_a = 0;
                        this.func_70296_d();
                        return true;
                    }
                    if (player.field_71075_bZ.field_75098_d) {
                        p_70441_1_.field_77994_a = 0;
                        this.func_70296_d();
                        return true;
                    }
                    this.func_70296_d();
                    return false;
                }
                else {
                    do {
                        i = p_70441_1_.field_77994_a;
                        p_70441_1_.field_77994_a = this.storePartialItemStack(p_70441_1_);
                        this.func_70296_d();
                    } while (p_70441_1_.field_77994_a > 0 && p_70441_1_.field_77994_a < i);
                    if (p_70441_1_.field_77994_a == i && player.field_71075_bZ.field_75098_d) {
                        p_70441_1_.field_77994_a = 0;
                        this.func_70296_d();
                        return true;
                    }
                    this.func_70296_d();
                    return p_70441_1_.field_77994_a < i;
                }
            }
            catch (Throwable throwable) {
                throwable.printStackTrace();
            }
        }
        return false;
    }
    
    private int storePartialItemStack(final ItemStack p_70452_1_) {
        final Item item = p_70452_1_.func_77973_b();
        int i = p_70452_1_.field_77994_a;
        if (p_70452_1_.func_77976_d() == 1) {
            final int j = this.getFirstEmptyStack(p_70452_1_);
            if (j < 0) {
                return i;
            }
            if (this.inventory[j] == null) {
                this.inventory[j] = ItemStack.func_77944_b(p_70452_1_);
                this.func_70296_d();
            }
            return 0;
        }
        else {
            int j = this.storeItemStack(p_70452_1_);
            if (j < 0) {
                j = this.getFirstEmptyStack(p_70452_1_);
            }
            if (j < 0) {
                return i;
            }
            if (this.inventory[j] == null) {
                this.inventory[j] = new ItemStack(item, 0, p_70452_1_.func_77960_j());
                if (p_70452_1_.func_77942_o()) {
                    this.inventory[j].func_77982_d((NBTTagCompound)p_70452_1_.func_77978_p().func_74737_b());
                }
            }
            int k = i;
            if (this.inventory[j] != null) {
                if (i > this.inventory[j].func_77976_d() - this.inventory[j].field_77994_a) {
                    k = this.inventory[j].func_77976_d() - this.inventory[j].field_77994_a;
                }
                if (k > this.func_70297_j_() - this.inventory[j].field_77994_a) {
                    k = this.func_70297_j_() - this.inventory[j].field_77994_a;
                }
            }
            if (k == 0) {
                return i;
            }
            i -= k;
            if (this.inventory[j] != null) {
                final ItemStack itemStack = this.inventory[j];
                itemStack.field_77994_a += k;
                this.inventory[j].field_77992_b = 5;
            }
            return i;
        }
    }
    
    private int storeItemStack(final ItemStack p_70432_1_) {
        for (int i = 0; i < this.inventory.length; ++i) {
            if (this.inventory[i] != null && this.inventory[i].func_77973_b() == p_70432_1_.func_77973_b() && this.inventory[i].func_77985_e() && this.inventory[i].field_77994_a < this.inventory[i].func_77976_d() && this.inventory[i].field_77994_a < this.func_70297_j_() && (!this.inventory[i].func_77981_g() || this.inventory[i].func_77960_j() == p_70432_1_.func_77960_j()) && ItemStack.func_77970_a(this.inventory[i], p_70432_1_)) {
                return i;
            }
        }
        return -1;
    }
    
    public void func_70296_d() {
        for (int i = 0; i < this.func_70302_i_(); ++i) {
            if (this.func_70301_a(i) != null && this.func_70301_a(i).field_77994_a == 0) {
                this.inventory[i] = null;
            }
        }
        this.writeToNBT(this.invItem.func_77978_p());
    }
    
    public boolean func_70300_a(final EntityPlayer player) {
        return player.func_70694_bm() == this.invItem;
    }
    
    public void func_70295_k_() {
    }
    
    public void func_70305_f() {
    }
    
    public boolean func_94041_b(final int slot, final ItemStack itemstack) {
        return true;
    }
    
    public void readFromNBT(final NBTTagCompound tagcompound) {
        final NBTTagList items = tagcompound.func_150295_c("ItemInventory", (int)tagcompound.func_74732_a());
        for (int i = 0; i < items.func_74745_c(); ++i) {
            final NBTTagCompound item = items.func_150305_b(i);
            final byte slot = item.func_74771_c("Slot");
            if (slot >= 0 && slot < this.func_70302_i_()) {
                this.inventory[slot] = ItemStack.func_77949_a(item);
            }
        }
        if ("".equals(this.uniqueID)) {
            this.uniqueID = tagcompound.func_74779_i("uniqueID");
            if ("".equals(this.uniqueID)) {
                this.uniqueID = UUID.randomUUID().toString();
            }
        }
    }
    
    public void writeToNBT(final NBTTagCompound tagcompound) {
        if (tagcompound == null) {
            return;
        }
        final NBTTagList items = new NBTTagList();
        for (int i = 0; i < this.func_70302_i_(); ++i) {
            if (this.func_70301_a(i) != null) {
                final NBTTagCompound item = new NBTTagCompound();
                item.func_74768_a("Slot", i);
                this.func_70301_a(i).func_77955_b(item);
                items.func_74742_a((NBTBase)item);
            }
        }
        tagcompound.func_74782_a("ItemInventory", (NBTBase)items);
        tagcompound.func_74778_a("uniqueID", this.uniqueID);
    }
    
    static {
        ItemInventory.INV_SIZE = 8;
    }
}
