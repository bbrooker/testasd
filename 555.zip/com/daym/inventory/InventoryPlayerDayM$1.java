package com.daym.inventory;

import java.util.concurrent.*;
import net.minecraft.item.*;

class InventoryPlayerDayM$1 implements Callable {
    private static final String __OBFID = "CL_00001710";
    final /* synthetic */ ItemStack val$p_70441_1_;
    
    @Override
    public String call() {
        return this.val$p_70441_1_.func_82833_r();
    }
}