package com.daym.inventory;

import net.minecraft.entity.player.*;
import com.daym.items.*;
import net.minecraft.inventory.*;
import net.minecraft.item.*;

public class ContainerItem extends Container
{
    public final ItemInventory inventory;
    private static final int INV_START;
    private static final int INV_END;
    private static final int HOTBAR_START;
    private static final int HOTBAR_END;
    
    public ContainerItem(final EntityPlayer par1Player, final InventoryPlayer inventoryPlayer, final ItemInventory inventoryItem) {
        this.inventory = inventoryItem;
        final ItemStack stack = inventoryItem.invItem;
        final int numRows = ((ItemWithInventory)stack.func_77973_b()).invRows;
        int id = 0;
        for (int j = 0; j < numRows; ++j) {
            for (int k = 0; k < ((ItemWithInventory)stack.func_77973_b()).invSize / (((ItemWithInventory)stack.func_77973_b()).invRows + 1); ++k) {
                ++id;
                this.func_75146_a(new Slot((IInventory)this.inventory, id, 8 + k * 18, (int)(74.8 + j * 18)));
            }
        }
    }
    
    public boolean func_75145_c(final EntityPlayer player) {
        return this.inventory.func_70300_a(player);
    }
    
    public ItemStack func_82846_b(final EntityPlayer par1EntityPlayer, final int par2) {
        ItemStack itemstack = null;
        final Slot slot = this.field_75151_b.get(par2);
        if (slot != null && slot.func_75216_d()) {
            final ItemStack itemstack2 = slot.func_75211_c();
            itemstack = itemstack2.func_77946_l();
            if (par2 < ContainerItem.INV_START) {
                if (!this.func_75135_a(itemstack2, ContainerItem.INV_START, ContainerItem.HOTBAR_END + 1, true)) {
                    return null;
                }
                slot.func_75220_a(itemstack2, itemstack);
            }
            else if (par2 >= ContainerItem.INV_START && par2 < ContainerItem.HOTBAR_START) {
                if (!this.func_75135_a(itemstack2, ContainerItem.HOTBAR_START, ContainerItem.HOTBAR_END + 1, false)) {
                    return null;
                }
            }
            else if (par2 >= ContainerItem.HOTBAR_START && par2 < ContainerItem.HOTBAR_END + 1 && !this.func_75135_a(itemstack2, ContainerItem.INV_START, ContainerItem.INV_END + 1, false)) {
                return null;
            }
            if (itemstack2.field_77994_a == 0) {
                slot.func_75215_d((ItemStack)null);
            }
            else {
                slot.func_75218_e();
            }
            if (itemstack2.field_77994_a == itemstack.field_77994_a) {
                return null;
            }
            slot.func_82870_a(par1EntityPlayer, itemstack2);
        }
        return itemstack;
    }
    
    public ItemStack func_75144_a(final int slot, final int button, final int flag, final EntityPlayer player) {
        if (slot >= 0 && this.func_75139_a(slot) != null && this.func_75139_a(slot).func_75211_c() == player.func_70694_bm()) {
            return null;
        }
        return super.func_75144_a(slot, button, flag, player);
    }
    
    static {
        INV_START = ItemInventory.INV_SIZE;
        INV_END = ContainerItem.INV_START + 26;
        HOTBAR_START = ContainerItem.INV_END + 1;
        HOTBAR_END = ContainerItem.HOTBAR_START + 8;
    }
}
