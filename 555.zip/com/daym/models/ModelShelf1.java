package com.daym.models;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelShelf1 extends ModelBase
{
    public ModelRenderer Stand1;
    public ModelRenderer Stand2;
    public ModelRenderer Stand3;
    public ModelRenderer Stand4;
    public ModelRenderer Stand5;
    public ModelRenderer Stand6;
    public ModelRenderer Stand7;
    public ModelRenderer Stand8;
    public ModelRenderer Shelf1;
    public ModelRenderer Shelf2;
    public ModelRenderer Shelf3;
    public ModelRenderer box;
    
    public ModelShelf1() {
        this.field_78090_t = 128;
        this.field_78089_u = 64;
        (this.box = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(-8.0f, -8.0f, -8.0f, 16, 16, 16);
        this.box.func_78793_a(0.0f, 16.0f, 0.0f);
        this.box.func_78787_b(128, 128);
        this.box.field_78809_i = true;
        this.setRotation(this.box, 0.0f, 0.0f, 0.0f);
        (this.Stand1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 2, 48, 1);
        this.Stand1.func_78793_a(-24.0f, -24.0f, 7.0f);
        this.Stand1.func_78787_b(64, 32);
        this.Stand1.field_78809_i = true;
        this.setRotation(this.Stand1, 0.0f, 0.0f, 0.0f);
        (this.Stand2 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 48, 1);
        this.Stand2.func_78793_a(-24.0f, -24.0f, 6.0f);
        this.Stand2.func_78787_b(64, 32);
        this.Stand2.field_78809_i = true;
        this.setRotation(this.Stand2, 0.0f, 0.0f, 0.0f);
        (this.Stand3 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 2, 48, 1);
        this.Stand3.func_78793_a(22.0f, -24.0f, 7.0f);
        this.Stand3.func_78787_b(64, 32);
        this.Stand3.field_78809_i = true;
        this.setRotation(this.Stand3, 0.0f, 0.0f, 0.0f);
        (this.Stand4 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 48, 1);
        this.Stand4.func_78793_a(23.0f, -24.0f, 6.0f);
        this.Stand4.func_78787_b(64, 32);
        this.Stand4.field_78809_i = true;
        this.setRotation(this.Stand4, 0.0f, 0.0f, 0.0f);
        (this.Stand5 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 2, 48, 1);
        this.Stand5.func_78793_a(-24.0f, -24.0f, -8.0f);
        this.Stand5.func_78787_b(64, 32);
        this.Stand5.field_78809_i = true;
        this.setRotation(this.Stand5, 0.0f, 0.0f, 0.0f);
        (this.Stand6 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 48, 1);
        this.Stand6.func_78793_a(-24.0f, -24.0f, -7.0f);
        this.Stand6.func_78787_b(64, 32);
        this.Stand6.field_78809_i = true;
        this.setRotation(this.Stand6, 0.0f, 0.0f, 0.0f);
        (this.Stand7 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 48, 1);
        this.Stand7.func_78793_a(23.0f, -24.0f, -7.0f);
        this.Stand7.func_78787_b(64, 32);
        this.Stand7.field_78809_i = true;
        this.setRotation(this.Stand7, 0.0f, 0.0f, 0.0f);
        (this.Stand8 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 2, 48, 1);
        this.Stand8.func_78793_a(22.0f, -24.0f, -8.0f);
        this.Stand8.func_78787_b(64, 32);
        this.Stand8.field_78809_i = true;
        this.setRotation(this.Stand8, 0.0f, 0.0f, 0.0f);
        (this.Shelf1 = new ModelRenderer((ModelBase)this, 6, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 46, 1, 14);
        this.Shelf1.func_78793_a(-23.0f, 20.0f, -7.0f);
        this.Shelf1.func_78787_b(64, 32);
        this.Shelf1.field_78809_i = true;
        this.setRotation(this.Shelf1, 0.0f, 0.0f, 0.0f);
        (this.Shelf2 = new ModelRenderer((ModelBase)this, 6, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 46, 1, 14);
        this.Shelf2.func_78793_a(-23.0f, 5.0f, -7.0f);
        this.Shelf2.func_78787_b(64, 32);
        this.Shelf2.field_78809_i = true;
        this.setRotation(this.Shelf2, 0.0f, 0.0f, 0.0f);
        (this.Shelf3 = new ModelRenderer((ModelBase)this, 6, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 46, 1, 14);
        this.Shelf3.func_78793_a(-23.0f, -10.0f, -7.0f);
        this.Shelf3.func_78787_b(64, 32);
        this.Shelf3.field_78809_i = true;
        this.setRotation(this.Shelf3, 0.0f, 0.0f, 0.0f);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
        this.func_78087_a(f, f1, f2, f3, f4, f5, entity);
        this.Stand1.func_78785_a(f5);
        this.Stand2.func_78785_a(f5);
        this.Stand3.func_78785_a(f5);
        this.Stand4.func_78785_a(f5);
        this.Stand5.func_78785_a(f5);
        this.Stand6.func_78785_a(f5);
        this.Stand7.func_78785_a(f5);
        this.Stand8.func_78785_a(f5);
        this.Shelf1.func_78785_a(f5);
        this.Shelf2.func_78785_a(f5);
        this.Shelf3.func_78785_a(f5);
    }
    
    private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
        model.field_78795_f = x;
        model.field_78796_g = y;
        model.field_78808_h = z;
    }
    
    public void func_78087_a(final float f, final float f1, final float f2, final float f3, final float f4, final float f5, final Entity entity) {
        super.func_78087_a(f, f1, f2, f3, f4, f5, entity);
    }
}
