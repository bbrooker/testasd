package com.daym.models;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelBench1 extends ModelBase
{
    public ModelRenderer Leg1;
    public ModelRenderer Leg2;
    public ModelRenderer Leg3;
    public ModelRenderer Leg4;
    public ModelRenderer BenchSeat1;
    public ModelRenderer BenchSeat2;
    public ModelRenderer LegSupport1;
    public ModelRenderer LegSupport2;
    public ModelRenderer BenchBack1;
    public ModelRenderer BenchBack2;
    
    public ModelBench1() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        (this.BenchSeat2 = new ModelRenderer((ModelBase)this, 0, 0)).func_78793_a(-8.0f, 15.9f, 0.2f);
        this.BenchSeat2.func_78789_a(0.0f, 0.0f, 0.0f, 16, 1, 6);
        (this.Leg2 = new ModelRenderer((ModelBase)this, 8, 12)).func_78793_a(0.0f, 18.3f, 1.0f);
        this.Leg2.func_78789_a(-4.0f, 0.0f, -5.0f, 1, 8, 1);
        this.setRotateAngle(this.Leg2, -0.34906584f, 0.0f, 0.0f);
        (this.BenchBack1 = new ModelRenderer((ModelBase)this, 0, 22)).func_78793_a(-8.0f, 4.5f, 5.0f);
        this.BenchBack1.func_78789_a(0.0f, 0.0f, 0.0f, 16, 4, 1);
        this.setRotateAngle(this.BenchBack1, -0.05235988f, 0.0f, 0.0f);
        (this.LegSupport1 = new ModelRenderer((ModelBase)this, 8, 12)).func_78793_a(0.0f, 17.0f, -3.6f);
        this.LegSupport1.func_78789_a(-4.0f, 0.0f, 0.0f, 1, 10, 1);
        this.setRotateAngle(this.LegSupport1, 1.0471976f, 0.0f, 0.0f);
        (this.BenchSeat1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78793_a(-8.0f, 15.9f, -6.2f);
        this.BenchSeat1.func_78789_a(0.0f, 0.0f, 0.0f, 16, 1, 6);
        (this.Leg1 = new ModelRenderer((ModelBase)this, 8, 12)).func_78793_a(0.0f, 6.0f, 1.6f);
        this.Leg1.func_78789_a(-4.0f, 0.0f, 4.0f, 1, 18, 1);
        this.setRotateAngle(this.Leg1, -0.05235988f, 0.0f, 0.0f);
        (this.BenchBack2 = new ModelRenderer((ModelBase)this, 0, 22)).func_78793_a(-8.0f, 10.0f, 4.7f);
        this.BenchBack2.func_78789_a(0.0f, 0.0f, 0.0f, 16, 4, 1);
        this.setRotateAngle(this.BenchBack2, -0.05235988f, 0.0f, 0.0f);
        (this.LegSupport2 = new ModelRenderer((ModelBase)this, 8, 12)).func_78793_a(7.0f, 17.0f, -3.6f);
        this.LegSupport2.func_78789_a(-4.0f, 0.0f, 0.0f, 1, 10, 1);
        this.setRotateAngle(this.LegSupport2, 1.0471976f, 0.0f, 0.0f);
        (this.Leg4 = new ModelRenderer((ModelBase)this, 8, 12)).func_78793_a(-1.0f, 6.0f, 1.6f);
        this.Leg4.func_78789_a(4.0f, 0.0f, 4.0f, 1, 18, 1);
        this.setRotateAngle(this.Leg4, -0.05235988f, 0.0f, 0.0f);
        (this.Leg3 = new ModelRenderer((ModelBase)this, 8, 12)).func_78793_a(-1.0f, 18.3f, 1.0f);
        this.Leg3.func_78789_a(4.0f, 0.0f, -5.0f, 1, 8, 1);
        this.setRotateAngle(this.Leg3, -0.34906584f, 0.0f, 0.0f);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.BenchSeat2.func_78785_a(f5);
        this.Leg2.func_78785_a(f5);
        this.BenchBack1.func_78785_a(f5);
        this.LegSupport1.func_78785_a(f5);
        this.BenchSeat1.func_78785_a(f5);
        this.Leg1.func_78785_a(f5);
        this.BenchBack2.func_78785_a(f5);
        this.LegSupport2.func_78785_a(f5);
        this.Leg4.func_78785_a(f5);
        this.Leg3.func_78785_a(f5);
    }
    
    public void setRotateAngle(final ModelRenderer modelRenderer, final float x, final float y, final float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }
}
