package com.daym.models;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelChair2 extends ModelBase
{
    ModelRenderer Support1;
    ModelRenderer Support2;
    ModelRenderer Support3;
    ModelRenderer Support4;
    ModelRenderer ChairTop;
    ModelRenderer ChairSide1;
    ModelRenderer ChairSide_2;
    ModelRenderer ChairSide3;
    ModelRenderer ChairSide4;
    ModelRenderer BottomSupport1;
    ModelRenderer BottomSupport2;
    ModelRenderer BottomSupport3;
    ModelRenderer BottomSupport4;
    
    public ModelChair2() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        (this.Support1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(3.0f, 0.0f, 3.0f, 1, 14, 1);
        this.Support1.func_78793_a(0.0f, 10.5f, 0.0f);
        this.Support1.func_78787_b(64, 32);
        this.Support1.field_78809_i = true;
        this.setRotation(this.Support1, 0.0523599f, 0.0f, -0.0523599f);
        (this.Support2 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(3.0f, 0.0f, -3.0f, 1, 14, 1);
        this.Support2.func_78793_a(0.0f, 10.5f, -1.0f);
        this.Support2.func_78787_b(64, 32);
        this.Support2.field_78809_i = true;
        this.setRotation(this.Support2, -0.0523599f, 0.0f, -0.0523599f);
        (this.Support3 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(-3.0f, 0.0f, 3.0f, 1, 14, 1);
        this.Support3.func_78793_a(-1.0f, 10.5f, 0.0f);
        this.Support3.func_78787_b(64, 32);
        this.Support3.field_78809_i = true;
        this.setRotation(this.Support3, 0.0523599f, 0.0f, 0.0523599f);
        (this.Support4 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(-3.0f, 0.0f, -3.0f, 1, 14, 1);
        this.Support4.func_78793_a(-1.0f, 10.5f, -1.0f);
        this.Support4.func_78787_b(64, 32);
        this.Support4.field_78809_i = true;
        this.setRotation(this.Support4, -0.0523599f, 0.0f, 0.0523599f);
        (this.ChairTop = new ModelRenderer((ModelBase)this, 32, 3)).func_78789_a(0.0f, 0.0f, 0.0f, 8, 2, 8);
        this.ChairTop.func_78793_a(-4.0f, 9.3f, -4.0f);
        this.ChairTop.func_78787_b(64, 32);
        this.ChairTop.field_78809_i = true;
        this.setRotation(this.ChairTop, 0.0f, 0.0f, 0.0f);
        (this.ChairSide1 = new ModelRenderer((ModelBase)this, 50, 13)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 1, 6);
        this.ChairSide1.func_78793_a(4.0f, 9.5f, -3.0f);
        this.ChairSide1.func_78787_b(64, 32);
        this.ChairSide1.field_78809_i = true;
        this.setRotation(this.ChairSide1, 0.0f, 0.0f, 0.0f);
        (this.ChairSide_2 = new ModelRenderer((ModelBase)this, 50, 13)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 1, 6);
        this.ChairSide_2.func_78793_a(-5.0f, 9.5f, -3.0f);
        this.ChairSide_2.func_78787_b(64, 32);
        this.ChairSide_2.field_78809_i = true;
        this.setRotation(this.ChairSide_2, 0.0f, 0.0f, 0.0f);
        (this.ChairSide3 = new ModelRenderer((ModelBase)this, 50, 13)).func_78789_a(0.0f, 0.0f, 0.0f, 6, 1, 1);
        this.ChairSide3.func_78793_a(-3.0f, 9.5f, -5.0f);
        this.ChairSide3.func_78787_b(64, 32);
        this.ChairSide3.field_78809_i = true;
        this.setRotation(this.ChairSide3, 0.0f, 0.0f, 0.0f);
        (this.ChairSide4 = new ModelRenderer((ModelBase)this, 50, 13)).func_78789_a(0.0f, 0.0f, 0.0f, 6, 1, 1);
        this.ChairSide4.func_78793_a(-3.0f, 9.5f, 4.0f);
        this.ChairSide4.func_78787_b(64, 32);
        this.ChairSide4.field_78809_i = true;
        this.setRotation(this.ChairSide4, 0.0f, 0.0f, 0.0f);
        (this.BottomSupport1 = new ModelRenderer((ModelBase)this, 46, 22)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 1, 8);
        this.BottomSupport1.func_78793_a(3.45f, 19.0f, -4.0f);
        this.BottomSupport1.func_78787_b(64, 32);
        this.BottomSupport1.field_78809_i = true;
        this.setRotation(this.BottomSupport1, 0.0f, 0.0f, -0.0436332f);
        (this.BottomSupport2 = new ModelRenderer((ModelBase)this, 46, 22)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 1, 8);
        this.BottomSupport2.func_78793_a(-4.45f, 19.0f, -4.0f);
        this.BottomSupport2.func_78787_b(64, 32);
        this.BottomSupport2.field_78809_i = true;
        this.setRotation(this.BottomSupport2, 0.0f, 0.0f, 0.0436332f);
        (this.BottomSupport3 = new ModelRenderer((ModelBase)this, 46, 22)).func_78789_a(0.0f, 0.0f, 0.0f, 8, 1, 1);
        this.BottomSupport3.func_78793_a(-3.75f, 19.0f, -4.45f);
        this.BottomSupport3.func_78787_b(64, 32);
        this.BottomSupport3.field_78809_i = true;
        this.setRotation(this.BottomSupport3, -0.0436332f, 0.0f, 0.0f);
        (this.BottomSupport4 = new ModelRenderer((ModelBase)this, 46, 22)).func_78789_a(0.0f, 0.0f, 0.0f, 8, 1, 1);
        this.BottomSupport4.func_78793_a(-3.8f, 19.0f, 3.45f);
        this.BottomSupport4.func_78787_b(64, 32);
        this.BottomSupport4.field_78809_i = true;
        this.setRotation(this.BottomSupport4, 0.0436332f, 0.0f, 0.0f);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
        this.func_78087_a(f, f1, f2, f3, f4, f5, entity);
        this.Support1.func_78785_a(f5);
        this.Support2.func_78785_a(f5);
        this.Support3.func_78785_a(f5);
        this.Support4.func_78785_a(f5);
        this.ChairTop.func_78785_a(f5);
        this.ChairSide1.func_78785_a(f5);
        this.ChairSide_2.func_78785_a(f5);
        this.ChairSide3.func_78785_a(f5);
        this.ChairSide4.func_78785_a(f5);
        this.BottomSupport1.func_78785_a(f5);
        this.BottomSupport2.func_78785_a(f5);
        this.BottomSupport3.func_78785_a(f5);
        this.BottomSupport4.func_78785_a(f5);
    }
    
    private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
        model.field_78795_f = x;
        model.field_78796_g = y;
        model.field_78808_h = z;
    }
    
    public void func_78087_a(final float f, final float f1, final float f2, final float f3, final float f4, final float f5, final Entity entity) {
        super.func_78087_a(f, f1, f2, f3, f4, f5, entity);
    }
}
