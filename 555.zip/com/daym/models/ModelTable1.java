package com.daym.models;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelTable1 extends ModelBase
{
    public ModelRenderer TableTop;
    public ModelRenderer Stump1;
    public ModelRenderer Stump2;
    public ModelRenderer Stump3;
    public ModelRenderer Stump4;
    public ModelRenderer StumpHolder1;
    public ModelRenderer StumpHolder2;
    public ModelRenderer StumpHolder3;
    public ModelRenderer StumpHolder4;
    
    public ModelTable1() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        (this.TableTop = new ModelRenderer((ModelBase)this, 0, 3)).func_78789_a(0.0f, 0.0f, 0.0f, 16, 1, 16);
        this.TableTop.func_78793_a(-8.0f, 7.5f, -8.0f);
        this.TableTop.func_78787_b(64, 32);
        this.TableTop.field_78809_i = true;
        this.setRotation(this.TableTop, 0.0f, 0.0f, 0.0f);
        (this.StumpHolder3 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 14, 1, 1);
        this.StumpHolder3.func_78793_a(-7.0f, 9.0f, -7.0f);
        this.StumpHolder3.func_78787_b(64, 32);
        this.StumpHolder3.field_78809_i = true;
        this.setRotation(this.StumpHolder3, 0.0f, 0.0f, 0.0f);
        (this.Stump1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(-6.0f, 0.0f, 6.0f, 1, 16, 1);
        this.Stump1.func_78793_a(-1.0f, 9.0f, 0.0f);
        this.Stump1.func_78787_b(64, 32);
        this.Stump1.field_78809_i = true;
        this.setRotation(this.Stump1, 0.0349066f, 0.0f, 0.0349066f);
        (this.Stump2 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(6.0f, 0.0f, 6.0f, 1, 16, 1);
        this.Stump2.func_78793_a(0.0f, 9.0f, 0.0f);
        this.Stump2.func_78787_b(64, 32);
        this.Stump2.field_78809_i = true;
        this.setRotation(this.Stump2, 0.0349066f, 0.0f, -0.0349066f);
        (this.Stump3 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(-6.0f, 0.0f, -6.0f, 1, 16, 1);
        this.Stump3.func_78793_a(-1.0f, 9.0f, -1.0f);
        this.Stump3.func_78787_b(64, 32);
        this.Stump3.field_78809_i = true;
        this.setRotation(this.Stump3, -0.0349066f, 0.0f, 0.0349066f);
        (this.Stump4 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(6.0f, 0.0f, -6.0f, 1, 16, 1);
        this.Stump4.func_78793_a(0.0f, 9.0f, -1.0f);
        this.Stump4.func_78787_b(64, 32);
        this.Stump4.field_78809_i = true;
        this.setRotation(this.Stump4, -0.0349066f, 0.0f, -0.0349066f);
        (this.StumpHolder1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 1, 14);
        this.StumpHolder1.func_78793_a(-7.0f, 9.0f, -7.0f);
        this.StumpHolder1.func_78787_b(64, 32);
        this.StumpHolder1.field_78809_i = true;
        this.setRotation(this.StumpHolder1, 0.0f, 0.0f, 0.0f);
        (this.StumpHolder2 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 1, 14);
        this.StumpHolder2.func_78793_a(6.0f, 9.0f, -7.0f);
        this.StumpHolder2.func_78787_b(64, 32);
        this.StumpHolder2.field_78809_i = true;
        this.setRotation(this.StumpHolder2, 0.0f, 0.0f, 0.0f);
        (this.StumpHolder4 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 14, 1, 1);
        this.StumpHolder4.func_78793_a(-7.0f, 9.0f, 6.0f);
        this.StumpHolder4.func_78787_b(64, 32);
        this.StumpHolder4.field_78809_i = true;
        this.setRotation(this.StumpHolder4, 0.0f, 0.0f, 0.0f);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
        this.func_78087_a(f, f1, f2, f3, f4, f5, entity);
        this.TableTop.func_78785_a(f5);
        this.StumpHolder3.func_78785_a(f5);
        this.Stump1.func_78785_a(f5);
        this.Stump2.func_78785_a(f5);
        this.Stump3.func_78785_a(f5);
        this.Stump4.func_78785_a(f5);
        this.StumpHolder1.func_78785_a(f5);
        this.StumpHolder2.func_78785_a(f5);
        this.StumpHolder4.func_78785_a(f5);
    }
    
    private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
        model.field_78795_f = x;
        model.field_78796_g = y;
        model.field_78808_h = z;
    }
    
    public void func_78087_a(final float f, final float f1, final float f2, final float f3, final float f4, final float f5, final Entity entity) {
        super.func_78087_a(f, f1, f2, f3, f4, f5, entity);
    }
}
