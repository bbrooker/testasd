package com.daym.models;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelChair1 extends ModelBase
{
    ModelRenderer BackPeg1;
    ModelRenderer BackPeg2;
    ModelRenderer FrontPeg1;
    ModelRenderer FrontPeg2;
    ModelRenderer Seat;
    ModelRenderer BackSupport1;
    ModelRenderer BackSupport2;
    ModelRenderer BackSupport3;
    ModelRenderer BackSupport4;
    ModelRenderer PegSupport1;
    ModelRenderer PegSupport2;
    ModelRenderer PegSupport3;
    ModelRenderer PegSupport4;
    
    public ModelChair1() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        (this.BackPeg1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 20, 1);
        this.BackPeg1.func_78793_a(3.8f, 4.0f, -6.0f);
        this.BackPeg1.func_78787_b(64, 32);
        this.BackPeg1.field_78809_i = true;
        this.setRotation(this.BackPeg1, 0.0349066f, 0.0f, 0.0f);
        (this.BackPeg2 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 20, 1);
        this.BackPeg2.func_78793_a(-4.8f, 4.0f, -6.0f);
        this.BackPeg2.func_78787_b(64, 32);
        this.BackPeg2.field_78809_i = true;
        this.setRotation(this.BackPeg2, 0.0349066f, 0.0f, 0.0f);
        (this.FrontPeg1 = new ModelRenderer((ModelBase)this, 0, 14)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 8, 1);
        this.FrontPeg1.func_78793_a(3.8f, 16.0f, 4.0f);
        this.FrontPeg1.func_78787_b(64, 32);
        this.FrontPeg1.field_78809_i = true;
        this.setRotation(this.FrontPeg1, 0.0174533f, 0.0f, 0.0f);
        (this.FrontPeg2 = new ModelRenderer((ModelBase)this, 0, 14)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 8, 1);
        this.FrontPeg2.func_78793_a(-4.8f, 16.0f, 4.0f);
        this.FrontPeg2.func_78787_b(64, 32);
        this.FrontPeg2.field_78809_i = true;
        this.setRotation(this.FrontPeg2, 0.0174533f, 0.0f, 0.0f);
        (this.Seat = new ModelRenderer((ModelBase)this, 5, 15)).func_78789_a(0.0f, 0.0f, 0.0f, 10, 1, 11);
        this.Seat.func_78793_a(-5.0f, 15.0f, -5.8f);
        this.Seat.func_78787_b(64, 32);
        this.Seat.field_78809_i = true;
        this.setRotation(this.Seat, 0.0f, 0.0f, 0.0f);
        (this.BackSupport1 = new ModelRenderer((ModelBase)this, 11, 0)).func_78789_a(0.0f, 1.0f, 0.0f, 4, 2, 1);
        this.BackSupport1.func_78793_a(-4.0f, 4.0f, -6.0f);
        this.BackSupport1.func_78787_b(64, 32);
        this.BackSupport1.field_78809_i = true;
        this.setRotation(this.BackSupport1, 0.0349066f, 0.0872665f, 0.0f);
        (this.BackSupport2 = new ModelRenderer((ModelBase)this, 5, 0)).func_78789_a(-4.0f, 1.0f, 0.0f, 4, 2, 1);
        this.BackSupport2.func_78793_a(4.0f, 4.0f, -6.0f);
        this.BackSupport2.func_78787_b(64, 32);
        this.BackSupport2.field_78809_i = true;
        this.setRotation(this.BackSupport2, 0.0349066f, -0.0872665f, 0.0f);
        (this.BackSupport3 = new ModelRenderer((ModelBase)this, 11, 0)).func_78789_a(0.0f, 6.0f, 0.0f, 4, 2, 1);
        this.BackSupport3.func_78793_a(-4.0f, 4.0f, -6.0f);
        this.BackSupport3.func_78787_b(64, 32);
        this.BackSupport3.field_78809_i = true;
        this.setRotation(this.BackSupport3, 0.0349066f, 0.0872665f, 0.0f);
        (this.BackSupport4 = new ModelRenderer((ModelBase)this, 5, 0)).func_78789_a(-4.0f, 6.0f, 0.0f, 4, 2, 1);
        this.BackSupport4.func_78793_a(4.0f, 4.0f, -6.0f);
        this.BackSupport4.func_78787_b(64, 32);
        this.BackSupport4.field_78809_i = true;
        this.setRotation(this.BackSupport4, 0.0349066f, -0.0872665f, 0.0f);
        (this.PegSupport1 = new ModelRenderer((ModelBase)this, 28, 4)).func_78789_a(0.0f, 4.0f, 0.0f, 8, 1, 1);
        this.PegSupport1.func_78793_a(-4.0f, 15.0f, 4.0f);
        this.PegSupport1.func_78787_b(64, 32);
        this.PegSupport1.field_78809_i = true;
        this.setRotation(this.PegSupport1, 0.0174533f, 0.0f, 0.0f);
        (this.PegSupport2 = new ModelRenderer((ModelBase)this, 28, 4)).func_78789_a(0.0f, 15.0f, 0.0f, 8, 1, 1);
        this.PegSupport2.func_78793_a(-4.0f, 4.0f, -6.0f);
        this.PegSupport2.func_78787_b(64, 32);
        this.PegSupport2.field_78809_i = true;
        this.setRotation(this.PegSupport2, 0.0349066f, 0.0f, 0.0f);
        (this.PegSupport3 = new ModelRenderer((ModelBase)this, 5, 4)).func_78789_a(0.0f, 16.0f, 0.0f, 1, 1, 10);
        this.PegSupport3.func_78793_a(-4.8f, 4.0f, -5.0f);
        this.PegSupport3.func_78787_b(64, 32);
        this.PegSupport3.field_78809_i = true;
        this.setRotation(this.PegSupport3, 0.0f, 0.0f, 0.0f);
        (this.PegSupport4 = new ModelRenderer((ModelBase)this, 5, 4)).func_78789_a(0.0f, 16.0f, 0.0f, 1, 1, 10);
        this.PegSupport4.func_78793_a(3.8f, 4.0f, -5.0f);
        this.PegSupport4.func_78787_b(64, 32);
        this.PegSupport4.field_78809_i = true;
        this.setRotation(this.PegSupport4, 0.0f, 0.0f, 0.0f);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
        this.func_78087_a(f, f1, f2, f3, f4, f5, entity);
        this.BackPeg1.func_78785_a(f5);
        this.BackPeg2.func_78785_a(f5);
        this.FrontPeg1.func_78785_a(f5);
        this.FrontPeg2.func_78785_a(f5);
        this.Seat.func_78785_a(f5);
        this.BackSupport1.func_78785_a(f5);
        this.BackSupport2.func_78785_a(f5);
        this.BackSupport3.func_78785_a(f5);
        this.BackSupport4.func_78785_a(f5);
        this.PegSupport1.func_78785_a(f5);
        this.PegSupport2.func_78785_a(f5);
        this.PegSupport3.func_78785_a(f5);
        this.PegSupport4.func_78785_a(f5);
    }
    
    private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
        model.field_78795_f = x;
        model.field_78796_g = y;
        model.field_78808_h = z;
    }
    
    public void func_78087_a(final float f, final float f1, final float f2, final float f3, final float f4, final float f5, final Entity entity) {
        super.func_78087_a(f, f1, f2, f3, f4, f5, entity);
    }
}
