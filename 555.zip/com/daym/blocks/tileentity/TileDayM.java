package com.daym.blocks.tileentity;

import net.minecraft.tileentity.*;

public class TileDayM extends TileEntity
{
}
