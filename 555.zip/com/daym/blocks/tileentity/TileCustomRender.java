package com.daym.blocks.tileentity;

import net.minecraft.util.*;
import com.daym.daymobjloader.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.client.model.*;
import scala.util.*;
import net.minecraft.world.*;
import net.minecraft.tileentity.*;
import cpw.mods.fml.common.*;
import net.minecraft.client.*;
import net.minecraft.nbt.*;
import net.minecraft.block.*;
import net.minecraft.entity.player.*;
import com.daym.registry.*;
import net.minecraft.entity.*;
import com.daym.entity.*;

public class TileCustomRender extends TileDayM
{
    public ResourceLocation textureRes;
    public int textureHandle;
    public int cornerMetadata;
    public int modelID;
    public String letters;
    public DayM_Model currentModel;
    public float x;
    public float y;
    public float z;
    public float i;
    public float j;
    public float k;
    @SideOnly(Side.CLIENT)
    public float yRot;
    public ModelBase mainModel;
    public int randomBoxNumber;
    public boolean isBeingRidden;
    
    public TileCustomRender() {
        this.textureRes = null;
        this.textureHandle = 0;
        this.cornerMetadata = -1;
        this.modelID = 0;
        this.letters = "DayM";
        this.currentModel = null;
        this.randomBoxNumber = 0;
        this.isBeingRidden = false;
        final Random random = new Random();
        this.randomBoxNumber = random.nextInt(10);
    }
    
    public void onBlockUpdated() {
        final TileCustomRender tcr = this;
        final int md = tcr.field_145847_g;
        final World world = tcr.func_145831_w();
        TileCustomRender XP = null;
        TileCustomRender XN = null;
        TileCustomRender ZP = null;
        TileCustomRender ZN = null;
        final TileEntity XP2 = world.func_147438_o(tcr.field_145851_c + 1, tcr.field_145848_d, tcr.field_145849_e);
        final TileEntity XN2 = world.func_147438_o(tcr.field_145851_c - 1, tcr.field_145848_d, tcr.field_145849_e);
        final TileEntity ZP2 = world.func_147438_o(tcr.field_145851_c, tcr.field_145848_d, tcr.field_145849_e + 1);
        final TileEntity ZN2 = world.func_147438_o(tcr.field_145851_c, tcr.field_145848_d, tcr.field_145849_e - 1);
        boolean xpV = false;
        boolean xnV = false;
        boolean zpV = false;
        boolean znV = false;
        boolean upd = false;
        if (md == 0 || md == 4 || md == 5 || md == 6 || md == 7) {
            upd = true;
        }
        if (XP2 != null && XP2 instanceof TileCustomRender) {
            xpV = true;
            XP = (TileCustomRender)XP2;
        }
        if (XN2 != null && XN2 instanceof TileCustomRender) {
            xnV = true;
            XN = (TileCustomRender)XN2;
        }
        if (ZP2 != null && ZP2 instanceof TileCustomRender) {
            zpV = true;
            ZP = (TileCustomRender)ZP2;
        }
        if (ZN2 != null && ZN2 instanceof TileCustomRender) {
            znV = true;
            ZN = (TileCustomRender)ZN2;
        }
        int offset = 0;
        if (upd) {
            offset = 0;
        }
        if (tcr.cornerMetadata == -1) {
            this.setCornerMetadata(tcr, tcr.field_145847_g + offset);
        }
        if (zpV && (md == 2 + offset || md == 3 + offset) && (ZP.cornerMetadata == 0 || ZP.cornerMetadata == 14 || ZP.cornerMetadata == 10 || ZP.cornerMetadata == 1 || ZP.cornerMetadata == 15 || ZP.cornerMetadata == 11)) {
            if (md == 3 + offset) {
                this.setCornerMetadata(tcr, 8);
                if (ZP.cornerMetadata == 0 || ZP.cornerMetadata == 14 || ZP.cornerMetadata == 10) {
                    this.rotateRender(-90.0f, 0.0f, 1.0f, 0.0f);
                }
                this.currentModel = ModelRegistry.blockSlanted[2];
                return;
            }
            this.setCornerMetadata(tcr, 9);
            if (ZP.cornerMetadata == 1 || ZP.cornerMetadata == 15 || ZP.cornerMetadata == 11) {
                this.rotateRender(-90.0f, 0.0f, 1.0f, 0.0f);
            }
            this.currentModel = ModelRegistry.blockSlanted[1];
        }
        else if (znV && (md == 2 + offset || md == 3 + offset) && (ZN.cornerMetadata == 0 || ZN.cornerMetadata == 10 || ZN.cornerMetadata == 14 || ZN.cornerMetadata == 9 || ZN.cornerMetadata == 1 || ZN.cornerMetadata == 15 || ZN.cornerMetadata == 11)) {
            if (md == 3 + offset) {
                this.setCornerMetadata(tcr, 12);
                if (ZN.cornerMetadata == 0 || ZN.cornerMetadata == 10 || ZN.cornerMetadata == 9 || ZN.cornerMetadata == 14) {
                    this.rotateRender(-90.0f, 0.0f, 1.0f, 0.0f);
                }
                this.currentModel = ModelRegistry.blockSlanted[1];
                return;
            }
            this.setCornerMetadata(tcr, 13);
            if (ZN.cornerMetadata == 1 || ZN.cornerMetadata == 11 || ZN.cornerMetadata == 15) {
                this.rotateRender(-90.0f, 0.0f, 1.0f, 0.0f);
            }
            this.currentModel = ModelRegistry.blockSlanted[2];
        }
        else if (xnV && (md == 0 + offset || md == 1 + offset) && (XN.cornerMetadata == 2 || XN.cornerMetadata == 9 || XN.cornerMetadata == 13 || XN.cornerMetadata == 3 || XN.cornerMetadata == 8 || XN.cornerMetadata == 12)) {
            if (md == 0 + offset) {
                this.setCornerMetadata(tcr, 10);
                if (XN.cornerMetadata == 2 || XN.cornerMetadata == 9 || XN.cornerMetadata == 13) {
                    this.rotateRender(-90.0f, 0.0f, 1.0f, 0.0f);
                }
                this.currentModel = ModelRegistry.blockSlanted[2];
                return;
            }
            this.setCornerMetadata(tcr, 11);
            if (XN.cornerMetadata == 3 || XN.cornerMetadata == 8 || XN.cornerMetadata == 12) {
                this.rotateRender(-90.0f, 0.0f, 1.0f, 0.0f);
            }
            this.currentModel = ModelRegistry.blockSlanted[1];
        }
        else {
            if (!xpV || (md != 0 + offset && md != 1 + offset) || (XP.cornerMetadata != 2 && (XP.cornerMetadata != 13 || tcr.cornerMetadata == 14) && XP.cornerMetadata != 9 && XP.cornerMetadata != 3 && XP.cornerMetadata != 12 && (XP.cornerMetadata != 8 || tcr.cornerMetadata == 14))) {
                if (this.currentModel == null) {
                    this.currentModel = ModelRegistry.blockSlanted[0];
                }
                return;
            }
            if (md == 0 + offset) {
                this.setCornerMetadata(tcr, 14);
                if (XP.cornerMetadata == 2 || XP.cornerMetadata == 13 || XP.cornerMetadata == 9) {
                    this.rotateRender(-90.0f, 0.0f, 1.0f, 0.0f);
                }
                this.currentModel = ModelRegistry.blockSlanted[1];
                return;
            }
            this.setCornerMetadata(tcr, 15);
            if (XP.cornerMetadata == 3 || XP.cornerMetadata == 8 || XP.cornerMetadata == 12) {
                this.rotateRender(-90.0f, 0.0f, 1.0f, 0.0f);
            }
            this.currentModel = ModelRegistry.blockSlanted[2];
        }
    }
    
    private void rotateRender(final float f, final float g, final float h, final float l) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            this.yRot = f;
        }
    }
    
    private void setCornerMetadata(final TileCustomRender tcr, final int i) {
        tcr.cornerMetadata = i;
    }
    
    @SideOnly(Side.CLIENT)
    public double func_145833_n() {
        final int max = Minecraft.func_71410_x().field_71474_y.field_151451_c / 4 + 2;
        return 4096.0 * max;
    }
    
    public void func_145841_b(final NBTTagCompound var1) {
        var1.func_74768_a("cornerMetadata", this.cornerMetadata);
        super.func_145841_b(var1);
    }
    
    public void func_145839_a(final NBTTagCompound var1) {
        this.cornerMetadata = var1.func_74762_e("cornerMetadata");
        super.func_145839_a(var1);
    }
    
    public void blockClicked(final Block block, final int x, final int y, final int z, final EntityPlayer player) {
        if ((block == BlockRegistry.woodenChair1 || block == BlockRegistry.woodenChair2 || block == BlockRegistry.woodenBench1) && !player.field_70170_p.field_72995_K && !this.isBeingRidden) {
            player.func_70078_a((Entity)null);
            this.isBeingRidden = true;
            double var = 0.5;
            if (block == BlockRegistry.woodenChair2) {
                var = 0.75;
            }
            if (block == BlockRegistry.woodenBench1) {
                var = 0.45;
            }
            final EntityChair chair = new EntityChair(player.field_70170_p, x + 0.5, y, z + 0.5, var, this);
            chair.tile = this;
            player.field_70170_p.func_72838_d((Entity)chair);
            chair.func_70107_b((double)x, (double)y, (double)z);
            chair.field_70153_n = (Entity)player;
            player.field_70154_o = chair;
            chair.tile = this;
            player.func_70078_a((Entity)chair);
        }
    }
}
