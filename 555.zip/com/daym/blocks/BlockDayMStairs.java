package com.daym.blocks;

import net.minecraft.block.*;

public class BlockDayMStairs extends BlockStairs
{
    public BlockDayMStairs(final Block p_i45428_1_, final int p_i45428_2_) {
        super(p_i45428_1_, p_i45428_2_);
    }
}
