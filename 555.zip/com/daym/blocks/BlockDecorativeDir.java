package com.daym.blocks;

import cpw.mods.fml.relauncher.*;
import net.minecraft.block.material.*;
import cpw.mods.fml.common.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.texture.*;

public class BlockDecorativeDir extends DayMBlock
{
    @SideOnly(Side.CLIENT)
    private IIcon texBlockTop;
    @SideOnly(Side.CLIENT)
    private IIcon texBlockTop2;
    @SideOnly(Side.CLIENT)
    private String texBlock;
    @SideOnly(Side.CLIENT)
    private String texTop;
    @SideOnly(Side.CLIENT)
    private String texTop2;
    
    public BlockDecorativeDir(final Material arg0) {
        super(arg0);
    }
    
    public BlockDecorativeDir(final Material arg0, final String tex, final String tex2, final String tex3) {
        super(arg0);
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            this.texBlock = tex;
            this.texTop = tex2;
            this.texTop2 = tex3;
        }
    }
    
    public IIcon func_149691_a(final int par1, final int par2) {
        if (par1 != 1) {
            return this.field_149761_L;
        }
        if (par2 == 4 || par2 == 5) {
            return this.texBlockTop2;
        }
        return this.texBlockTop;
    }
    
    public void func_149689_a(final World world, final int x, final int y, final int z, final EntityLivingBase p_onBlockPlacedBy_5_, final ItemStack p_onBlockPlacedBy_6_) {
        final int i = MathHelper.func_76128_c(p_onBlockPlacedBy_5_.field_70177_z * 4.0f / 360.0f + 0.5) & 0x3;
        if (i == 0) {
            world.func_72921_c(x, y, z, 2, 2);
        }
        if (i == 1) {
            world.func_72921_c(x, y, z, 5, 2);
        }
        if (i == 2) {
            world.func_72921_c(x, y, z, 3, 2);
        }
        if (i == 3) {
            world.func_72921_c(x, y, z, 4, 2);
        }
    }
    
    @SideOnly(Side.CLIENT)
    public void func_149651_a(final IIconRegister par1IconRegister) {
        this.field_149761_L = par1IconRegister.func_94245_a(this.texBlock);
        this.texBlockTop = par1IconRegister.func_94245_a(this.texTop);
        this.texBlockTop2 = par1IconRegister.func_94245_a(this.texTop2);
    }
}
