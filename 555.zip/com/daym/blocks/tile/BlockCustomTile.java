package com.daym.blocks.tile;

import net.minecraft.block.*;
import com.daym.daymobjloader.*;
import com.daym.misc.*;
import net.minecraft.block.material.*;
import cpw.mods.fml.common.*;
import com.daym.registry.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.world.*;
import net.minecraft.tileentity.*;
import net.minecraft.client.model.*;
import com.daym.blocks.tileentity.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.entity.player.*;

public class BlockCustomTile extends BlockContainer
{
    private Class rClass;
    public String texture;
    public int modelID;
    public DayM_Model currentModel;
    public Class mainModel;
    DayMBoundingBox myBox;
    public boolean keepBoundsOnRotation;
    
    public BlockCustomTile(final Material p_i45386_1_, final Class c, final String tex, final int mid, final int mid2, final Class model, final DayMBoundingBox bb, final boolean kbp) {
        super(p_i45386_1_);
        this.modelID = 0;
        this.currentModel = null;
        this.mainModel = null;
        this.myBox = null;
        this.keepBoundsOnRotation = false;
        this.rClass = c;
        this.texture = tex;
        this.modelID = mid;
        this.mainModel = model;
        this.setModel(mid2);
        this.myBox = bb;
        this.keepBoundsOnRotation = kbp;
        if (bb != null) {
            this.func_149676_a(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ);
        }
    }
    
    public void func_149719_a(final IBlockAccess block, final int arg1, final int arg2, final int arg3) {
        final int md = block.func_72805_g(arg1, arg2, arg3);
        if (this.myBox != null && this.keepBoundsOnRotation) {
            if (md == 1 || md == 3) {
                this.func_149676_a(this.myBox.minX, this.myBox.minY, this.myBox.minZ, this.myBox.maxX, this.myBox.maxY, this.myBox.maxZ);
            }
            else {
                this.func_149676_a(this.myBox.minZ, this.myBox.minY, this.myBox.minX, this.myBox.maxZ, this.myBox.maxY, this.myBox.maxX);
            }
        }
    }
    
    private void setModel(final int mid2) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (!side.isClient() || this.modelID == 0 || this.modelID == 2) {
            return;
        }
        if (mid2 == 0) {
            this.currentModel = ModelRegistry.traffic_cone;
        }
    }
    
    public TileEntity func_149915_a(final World arg0, final int arg1) {
        try {
            if (this.rClass != TileCustomRender.class) {
                return this.rClass.newInstance();
            }
            final TileCustomRender tcr = this.rClass.newInstance();
            if (this.texture.toLowerCase().contains("daym:") || this.texture.toLowerCase().contains("minecraft:")) {
                if (this.texture.toLowerCase().contains("daym:")) {
                    final String texname = this.texture.replace("daym:", "daym:textures/blocks/");
                    tcr.textureRes = new ResourceLocation(texname + ".png");
                }
                else {
                    final String texname = this.texture.replace("minecraft:", "minecraft:textures/blocks/");
                    tcr.textureRes = new ResourceLocation(texname + ".png");
                }
            }
            else {
                tcr.textureHandle = Integer.parseInt(this.texture);
            }
            if (this.mainModel != null) {
                tcr.mainModel = this.mainModel.newInstance();
            }
            tcr.modelID = this.modelID;
            tcr.currentModel = this.currentModel;
            return tcr;
        }
        catch (InstantiationException e) {
            e.printStackTrace();
        }
        catch (IllegalAccessException e2) {
            e2.printStackTrace();
        }
        return new TileDayM();
    }
    
    public void func_149689_a(final World world, final int x, final int y, final int z, final EntityLivingBase p_onBlockPlacedBy_5_, final ItemStack p_onBlockPlacedBy_6_) {
        final int i = MathHelper.func_76128_c(p_onBlockPlacedBy_5_.field_70177_z * 4.0f / 360.0f + 0.5) & 0x3;
        if (i == 0) {
            world.func_72921_c(x, y, z, 2, 2);
        }
        if (i == 1) {
            world.func_72921_c(x, y, z, 5, 2);
        }
        if (i == 2) {
            world.func_72921_c(x, y, z, 3, 2);
        }
        if (i == 3) {
            world.func_72921_c(x, y, z, 4, 2);
        }
    }
    
    public boolean func_149727_a(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer, final int par6, final float par7, final float par8, final float par9) {
        final TileEntity tile = world.func_147438_o(i, j, k);
        if (tile instanceof TileCustomRender) {
            ((TileCustomRender)tile).blockClicked(world.func_147439_a(i, j, k), i, j, k, entityplayer);
        }
        return true;
    }
    
    public int func_149645_b() {
        return -1;
    }
    
    public boolean func_149662_c() {
        return false;
    }
    
    public boolean func_149686_d() {
        return false;
    }
}
