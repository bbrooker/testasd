package com.daym.blocks.tile;

import net.minecraft.block.*;
import net.minecraft.block.material.*;
import com.daym.misc.*;
import java.util.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.entity.player.*;
import net.minecraft.init.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.util.*;

public class BlockCustomTileStair extends BlockCustomTile
{
    private static final int[][] field_150150_a;
    private final Block field_150149_b;
    private final int field_150151_M;
    private boolean field_150152_N;
    private int field_150153_O;
    
    public BlockCustomTileStair(final Material p_i45386_1_, final Class c, final String tex, final Block p_i45428_1_, final int p_i45428_2_) {
        super(p_i45386_1_, c, tex, 0, 0, null, null, false);
        this.field_150149_b = p_i45428_1_;
        this.field_150151_M = p_i45428_2_;
        this.func_149722_s();
    }
    
    public Item func_149650_a(final int metadata, final Random random, final int fortune) {
        return null;
    }
    
    public void func_149695_a(final World world, final int par1, final int par2, final int par3, final Block block) {
        super.func_149695_a(world, par1, par2, par3, block);
    }
    
    @Override
    public void func_149719_a(final IBlockAccess p_setBlockBoundsBasedOnState_1_, final int p_setBlockBoundsBasedOnState_2_, final int p_setBlockBoundsBasedOnState_3_, final int p_setBlockBoundsBasedOnState_4_) {
        if (this.field_150152_N) {
            this.func_149676_a(0.0f * (this.field_150153_O % 2), 0.0f * (this.field_150153_O / 2 % 2), 0.0f * (this.field_150153_O / 4 % 2), 0.5f + 0.5f * (this.field_150153_O % 2), 0.5f + 0.5f * (this.field_150153_O / 2 % 2), 0.5f + 0.5f * (this.field_150153_O / 4 % 2));
        }
        else {
            this.func_149676_a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        }
    }
    
    public void func_150147_e(final IBlockAccess p_150147_1_, final int p_150147_2_, final int p_150147_3_, final int p_150147_4_) {
        final int i = p_150147_1_.func_72805_g(p_150147_2_, p_150147_3_, p_150147_4_);
        if ((i & 0x4) != 0x0) {
            this.func_149676_a(0.0f, 0.5f, 0.0f, 1.0f, 1.0f, 1.0f);
        }
        else {
            this.func_149676_a(0.0f, 0.0f, 0.0f, 1.0f, 0.5f, 1.0f);
        }
    }
    
    public static boolean func_150148_a(final Block p_150148_0_) {
        return p_150148_0_ instanceof BlockCustomTileStair;
    }
    
    private boolean func_150146_f(final IBlockAccess p_150146_1_, final int p_150146_2_, final int p_150146_3_, final int p_150146_4_, final int p_150146_5_) {
        final Block localBlock = p_150146_1_.func_147439_a(p_150146_2_, p_150146_3_, p_150146_4_);
        return func_150148_a(localBlock) && p_150146_1_.func_72805_g(p_150146_2_, p_150146_3_, p_150146_4_) == p_150146_5_;
    }
    
    public boolean func_150145_f(final IBlockAccess p_150145_1_, final int p_150145_2_, final int p_150145_3_, final int p_150145_4_) {
        final int i = p_150145_1_.func_72805_g(p_150145_2_, p_150145_3_, p_150145_4_);
        final int j = i & 0x3;
        float f1 = 0.5f;
        float f2 = 1.0f;
        if ((i & 0x4) != 0x0) {
            f1 = 0.0f;
            f2 = 0.5f;
        }
        float f3 = 0.0f;
        float f4 = 1.0f;
        float f5 = 0.0f;
        float f6 = 0.5f;
        boolean bool = true;
        if (j == 0) {
            f3 = 0.5f;
            f6 = 1.0f;
            final Block localBlock = p_150145_1_.func_147439_a(p_150145_2_ + 1, p_150145_3_, p_150145_4_);
            final int k = p_150145_1_.func_72805_g(p_150145_2_ + 1, p_150145_3_, p_150145_4_);
            if (func_150148_a(localBlock) && (i & 0x4) == (k & 0x4)) {
                final int m = k & 0x3;
                if (m == 3 && !this.func_150146_f(p_150145_1_, p_150145_2_, p_150145_3_, p_150145_4_ + 1, i)) {
                    f6 = 0.5f;
                    bool = false;
                }
                else if (m == 2 && !this.func_150146_f(p_150145_1_, p_150145_2_, p_150145_3_, p_150145_4_ - 1, i)) {
                    f5 = 0.5f;
                    bool = false;
                }
            }
        }
        else if (j == 1) {
            f4 = 0.5f;
            f6 = 1.0f;
            final Block localBlock = p_150145_1_.func_147439_a(p_150145_2_ - 1, p_150145_3_, p_150145_4_);
            final int k = p_150145_1_.func_72805_g(p_150145_2_ - 1, p_150145_3_, p_150145_4_);
            if (func_150148_a(localBlock) && (i & 0x4) == (k & 0x4)) {
                final int m = k & 0x3;
                if (m == 3 && !this.func_150146_f(p_150145_1_, p_150145_2_, p_150145_3_, p_150145_4_ + 1, i)) {
                    f6 = 0.5f;
                    bool = false;
                }
                else if (m == 2 && !this.func_150146_f(p_150145_1_, p_150145_2_, p_150145_3_, p_150145_4_ - 1, i)) {
                    f5 = 0.5f;
                    bool = false;
                }
            }
        }
        else if (j == 2) {
            f5 = 0.5f;
            f6 = 1.0f;
            final Block localBlock = p_150145_1_.func_147439_a(p_150145_2_, p_150145_3_, p_150145_4_ + 1);
            final int k = p_150145_1_.func_72805_g(p_150145_2_, p_150145_3_, p_150145_4_ + 1);
            if (func_150148_a(localBlock) && (i & 0x4) == (k & 0x4)) {
                final int m = k & 0x3;
                if (m == 1 && !this.func_150146_f(p_150145_1_, p_150145_2_ + 1, p_150145_3_, p_150145_4_, i)) {
                    f4 = 0.5f;
                    bool = false;
                }
                else if (m == 0 && !this.func_150146_f(p_150145_1_, p_150145_2_ - 1, p_150145_3_, p_150145_4_, i)) {
                    f3 = 0.5f;
                    bool = false;
                }
            }
        }
        else if (j == 3) {
            final Block localBlock = p_150145_1_.func_147439_a(p_150145_2_, p_150145_3_, p_150145_4_ - 1);
            final int k = p_150145_1_.func_72805_g(p_150145_2_, p_150145_3_, p_150145_4_ - 1);
            if (func_150148_a(localBlock) && (i & 0x4) == (k & 0x4)) {
                final int m = k & 0x3;
                if (m == 1 && !this.func_150146_f(p_150145_1_, p_150145_2_ + 1, p_150145_3_, p_150145_4_, i)) {
                    f4 = 0.5f;
                    bool = false;
                }
                else if (m == 0 && !this.func_150146_f(p_150145_1_, p_150145_2_ - 1, p_150145_3_, p_150145_4_, i)) {
                    f3 = 0.5f;
                    bool = false;
                }
            }
        }
        this.func_149676_a(f3, f1, f5, f4, f2, f6);
        return bool;
    }
    
    public boolean func_150144_g(final IBlockAccess p_150144_1_, final int p_150144_2_, final int p_150144_3_, final int p_150144_4_) {
        final int i = p_150144_1_.func_72805_g(p_150144_2_, p_150144_3_, p_150144_4_);
        final int j = i & 0x3;
        float f1 = 0.5f;
        float f2 = 1.0f;
        if ((i & 0x4) != 0x0) {
            f1 = 0.0f;
            f2 = 0.5f;
        }
        float f3 = 0.0f;
        float f4 = 0.5f;
        float f5 = 0.5f;
        float f6 = 1.0f;
        boolean bool = false;
        if (j == 0) {
            final Block localBlock = p_150144_1_.func_147439_a(p_150144_2_ - 1, p_150144_3_, p_150144_4_);
            final int k = p_150144_1_.func_72805_g(p_150144_2_ - 1, p_150144_3_, p_150144_4_);
            if (func_150148_a(localBlock) && (i & 0x4) == (k & 0x4)) {
                final int m = k & 0x3;
                if (m == 3 && !this.func_150146_f(p_150144_1_, p_150144_2_, p_150144_3_, p_150144_4_ - 1, i)) {
                    f5 = 0.0f;
                    f6 = 0.5f;
                    bool = true;
                }
                else if (m == 2 && !this.func_150146_f(p_150144_1_, p_150144_2_, p_150144_3_, p_150144_4_ + 1, i)) {
                    f5 = 0.5f;
                    f6 = 1.0f;
                    bool = true;
                }
            }
        }
        else if (j == 1) {
            final Block localBlock = p_150144_1_.func_147439_a(p_150144_2_ + 1, p_150144_3_, p_150144_4_);
            final int k = p_150144_1_.func_72805_g(p_150144_2_ + 1, p_150144_3_, p_150144_4_);
            if (func_150148_a(localBlock) && (i & 0x4) == (k & 0x4)) {
                f3 = 0.5f;
                f4 = 1.0f;
                final int m = k & 0x3;
                if (m == 3 && !this.func_150146_f(p_150144_1_, p_150144_2_, p_150144_3_, p_150144_4_ - 1, i)) {
                    f5 = 0.0f;
                    f6 = 0.5f;
                    bool = true;
                }
                else if (m == 2 && !this.func_150146_f(p_150144_1_, p_150144_2_, p_150144_3_, p_150144_4_ + 1, i)) {
                    f5 = 0.5f;
                    f6 = 1.0f;
                    bool = true;
                }
            }
        }
        else if (j == 2) {
            final Block localBlock = p_150144_1_.func_147439_a(p_150144_2_, p_150144_3_, p_150144_4_ - 1);
            final int k = p_150144_1_.func_72805_g(p_150144_2_, p_150144_3_, p_150144_4_ - 1);
            if (func_150148_a(localBlock) && (i & 0x4) == (k & 0x4)) {
                f5 = 0.0f;
                f6 = 0.5f;
                final int m = k & 0x3;
                if (m == 1 && !this.func_150146_f(p_150144_1_, p_150144_2_ - 1, p_150144_3_, p_150144_4_, i)) {
                    bool = true;
                }
                else if (m == 0 && !this.func_150146_f(p_150144_1_, p_150144_2_ + 1, p_150144_3_, p_150144_4_, i)) {
                    f3 = 0.5f;
                    f4 = 1.0f;
                    bool = true;
                }
            }
        }
        else if (j == 3) {
            final Block localBlock = p_150144_1_.func_147439_a(p_150144_2_, p_150144_3_, p_150144_4_ + 1);
            final int k = p_150144_1_.func_72805_g(p_150144_2_, p_150144_3_, p_150144_4_ + 1);
            if (func_150148_a(localBlock) && (i & 0x4) == (k & 0x4)) {
                final int m = k & 0x3;
                if (m == 1 && !this.func_150146_f(p_150144_1_, p_150144_2_ - 1, p_150144_3_, p_150144_4_, i)) {
                    bool = true;
                }
                else if (m == 0 && !this.func_150146_f(p_150144_1_, p_150144_2_ + 1, p_150144_3_, p_150144_4_, i)) {
                    f3 = 0.5f;
                    f4 = 1.0f;
                    bool = true;
                }
            }
        }
        if (bool) {
            this.func_149676_a(f3, f1, f5, f4, f2, f6);
        }
        return bool;
    }
    
    public void func_149743_a(final World p_addCollisionBoxesToList_1_, final int p_addCollisionBoxesToList_2_, final int p_addCollisionBoxesToList_3_, final int p_addCollisionBoxesToList_4_, final AxisAlignedBB p_addCollisionBoxesToList_5_, final List p_addCollisionBoxesToList_6_, final Entity p_addCollisionBoxesToList_7_) {
        this.func_150147_e((IBlockAccess)p_addCollisionBoxesToList_1_, p_addCollisionBoxesToList_2_, p_addCollisionBoxesToList_3_, p_addCollisionBoxesToList_4_);
        super.func_149743_a(p_addCollisionBoxesToList_1_, p_addCollisionBoxesToList_2_, p_addCollisionBoxesToList_3_, p_addCollisionBoxesToList_4_, p_addCollisionBoxesToList_5_, p_addCollisionBoxesToList_6_, p_addCollisionBoxesToList_7_);
        final boolean bool = this.func_150145_f((IBlockAccess)p_addCollisionBoxesToList_1_, p_addCollisionBoxesToList_2_, p_addCollisionBoxesToList_3_, p_addCollisionBoxesToList_4_);
        super.func_149743_a(p_addCollisionBoxesToList_1_, p_addCollisionBoxesToList_2_, p_addCollisionBoxesToList_3_, p_addCollisionBoxesToList_4_, p_addCollisionBoxesToList_5_, p_addCollisionBoxesToList_6_, p_addCollisionBoxesToList_7_);
        if (bool && this.func_150144_g((IBlockAccess)p_addCollisionBoxesToList_1_, p_addCollisionBoxesToList_2_, p_addCollisionBoxesToList_3_, p_addCollisionBoxesToList_4_)) {
            super.func_149743_a(p_addCollisionBoxesToList_1_, p_addCollisionBoxesToList_2_, p_addCollisionBoxesToList_3_, p_addCollisionBoxesToList_4_, p_addCollisionBoxesToList_5_, p_addCollisionBoxesToList_6_, p_addCollisionBoxesToList_7_);
        }
        this.func_149676_a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
    }
    
    @SideOnly(Side.CLIENT)
    public void func_149734_b(final World p_randomDisplayTick_1_, final int p_randomDisplayTick_2_, final int p_randomDisplayTick_3_, final int p_randomDisplayTick_4_, final Random p_randomDisplayTick_5_) {
        this.field_150149_b.func_149734_b(p_randomDisplayTick_1_, p_randomDisplayTick_2_, p_randomDisplayTick_3_, p_randomDisplayTick_4_, p_randomDisplayTick_5_);
    }
    
    public void func_149699_a(final World p_onBlockClicked_1_, final int p_onBlockClicked_2_, final int p_onBlockClicked_3_, final int p_onBlockClicked_4_, final EntityPlayer p_onBlockClicked_5_) {
        this.field_150149_b.func_149699_a(p_onBlockClicked_1_, p_onBlockClicked_2_, p_onBlockClicked_3_, p_onBlockClicked_4_, p_onBlockClicked_5_);
    }
    
    public void func_149664_b(final World p_onBlockDestroyedByPlayer_1_, final int p_onBlockDestroyedByPlayer_2_, final int p_onBlockDestroyedByPlayer_3_, final int p_onBlockDestroyedByPlayer_4_, final int p_onBlockDestroyedByPlayer_5_) {
        this.field_150149_b.func_149664_b(p_onBlockDestroyedByPlayer_1_, p_onBlockDestroyedByPlayer_2_, p_onBlockDestroyedByPlayer_3_, p_onBlockDestroyedByPlayer_4_, p_onBlockDestroyedByPlayer_5_);
    }
    
    public float func_149638_a(final Entity p_getExplosionResistance_1_) {
        return this.field_150149_b.func_149638_a(p_getExplosionResistance_1_);
    }
    
    public int func_149738_a(final World p_tickRate_1_) {
        return this.field_150149_b.func_149738_a(p_tickRate_1_);
    }
    
    @SideOnly(Side.CLIENT)
    public AxisAlignedBB func_149633_g(final World p_getSelectedBoundingBoxFromPool_1_, final int p_getSelectedBoundingBoxFromPool_2_, final int p_getSelectedBoundingBoxFromPool_3_, final int p_getSelectedBoundingBoxFromPool_4_) {
        return this.field_150149_b.func_149633_g(p_getSelectedBoundingBoxFromPool_1_, p_getSelectedBoundingBoxFromPool_2_, p_getSelectedBoundingBoxFromPool_3_, p_getSelectedBoundingBoxFromPool_4_);
    }
    
    public void func_149640_a(final World p_velocityToAddToEntity_1_, final int p_velocityToAddToEntity_2_, final int p_velocityToAddToEntity_3_, final int p_velocityToAddToEntity_4_, final Entity p_velocityToAddToEntity_5_, final Vec3 p_velocityToAddToEntity_6_) {
        this.field_150149_b.func_149640_a(p_velocityToAddToEntity_1_, p_velocityToAddToEntity_2_, p_velocityToAddToEntity_3_, p_velocityToAddToEntity_4_, p_velocityToAddToEntity_5_, p_velocityToAddToEntity_6_);
    }
    
    public boolean func_149703_v() {
        return this.field_150149_b.func_149703_v();
    }
    
    public boolean func_149678_a(final int p_canCollideCheck_1_, final boolean p_canCollideCheck_2_) {
        return this.field_150149_b.func_149678_a(p_canCollideCheck_1_, p_canCollideCheck_2_);
    }
    
    public boolean func_149742_c(final World p_canPlaceBlockAt_1_, final int p_canPlaceBlockAt_2_, final int p_canPlaceBlockAt_3_, final int p_canPlaceBlockAt_4_) {
        return this.field_150149_b.func_149742_c(p_canPlaceBlockAt_1_, p_canPlaceBlockAt_2_, p_canPlaceBlockAt_3_, p_canPlaceBlockAt_4_);
    }
    
    public void func_149726_b(final World p_onBlockAdded_1_, final int p_onBlockAdded_2_, final int p_onBlockAdded_3_, final int p_onBlockAdded_4_) {
        this.func_149695_a(p_onBlockAdded_1_, p_onBlockAdded_2_, p_onBlockAdded_3_, p_onBlockAdded_4_, Blocks.field_150350_a);
        this.field_150149_b.func_149726_b(p_onBlockAdded_1_, p_onBlockAdded_2_, p_onBlockAdded_3_, p_onBlockAdded_4_);
    }
    
    public void func_149749_a(final World p_breakBlock_1_, final int p_breakBlock_2_, final int p_breakBlock_3_, final int p_breakBlock_4_, final Block p_breakBlock_5_, final int p_breakBlock_6_) {
        this.field_150149_b.func_149749_a(p_breakBlock_1_, p_breakBlock_2_, p_breakBlock_3_, p_breakBlock_4_, p_breakBlock_5_, p_breakBlock_6_);
    }
    
    public void func_149724_b(final World p_onEntityWalking_1_, final int p_onEntityWalking_2_, final int p_onEntityWalking_3_, final int p_onEntityWalking_4_, final Entity p_onEntityWalking_5_) {
        this.field_150149_b.func_149724_b(p_onEntityWalking_1_, p_onEntityWalking_2_, p_onEntityWalking_3_, p_onEntityWalking_4_, p_onEntityWalking_5_);
    }
    
    public void func_149674_a(final World p_updateTick_1_, final int p_updateTick_2_, final int p_updateTick_3_, final int p_updateTick_4_, final Random p_updateTick_5_) {
        this.field_150149_b.func_149674_a(p_updateTick_1_, p_updateTick_2_, p_updateTick_3_, p_updateTick_4_, p_updateTick_5_);
    }
    
    @Override
    public boolean func_149727_a(final World p_onBlockActivated_1_, final int p_onBlockActivated_2_, final int p_onBlockActivated_3_, final int p_onBlockActivated_4_, final EntityPlayer p_onBlockActivated_5_, final int p_onBlockActivated_6_, final float p_onBlockActivated_7_, final float p_onBlockActivated_8_, final float p_onBlockActivated_9_) {
        return this.field_150149_b.func_149727_a(p_onBlockActivated_1_, p_onBlockActivated_2_, p_onBlockActivated_3_, p_onBlockActivated_4_, p_onBlockActivated_5_, 0, 0.0f, 0.0f, 0.0f);
    }
    
    public void func_149723_a(final World p_onBlockDestroyedByExplosion_1_, final int p_onBlockDestroyedByExplosion_2_, final int p_onBlockDestroyedByExplosion_3_, final int p_onBlockDestroyedByExplosion_4_, final Explosion p_onBlockDestroyedByExplosion_5_) {
        this.field_150149_b.func_149723_a(p_onBlockDestroyedByExplosion_1_, p_onBlockDestroyedByExplosion_2_, p_onBlockDestroyedByExplosion_3_, p_onBlockDestroyedByExplosion_4_, p_onBlockDestroyedByExplosion_5_);
    }
    
    @Override
    public void func_149689_a(final World p_onBlockPlacedBy_1_, final int p_onBlockPlacedBy_2_, final int p_onBlockPlacedBy_3_, final int p_onBlockPlacedBy_4_, final EntityLivingBase p_onBlockPlacedBy_5_, final ItemStack p_onBlockPlacedBy_6_) {
        final int i = MathHelper.func_76128_c(p_onBlockPlacedBy_5_.field_70177_z * 4.0f / 360.0f + 0.5) & 0x3;
        final int j = p_onBlockPlacedBy_1_.func_72805_g(p_onBlockPlacedBy_2_, p_onBlockPlacedBy_3_, p_onBlockPlacedBy_4_) & 0x4;
        if (i == 0) {
            p_onBlockPlacedBy_1_.func_72921_c(p_onBlockPlacedBy_2_, p_onBlockPlacedBy_3_, p_onBlockPlacedBy_4_, 0x2 | j, 2);
        }
        if (i == 1) {
            p_onBlockPlacedBy_1_.func_72921_c(p_onBlockPlacedBy_2_, p_onBlockPlacedBy_3_, p_onBlockPlacedBy_4_, 0x1 | j, 2);
        }
        if (i == 2) {
            p_onBlockPlacedBy_1_.func_72921_c(p_onBlockPlacedBy_2_, p_onBlockPlacedBy_3_, p_onBlockPlacedBy_4_, 0x3 | j, 2);
        }
        if (i == 3) {
            p_onBlockPlacedBy_1_.func_72921_c(p_onBlockPlacedBy_2_, p_onBlockPlacedBy_3_, p_onBlockPlacedBy_4_, 0x0 | j, 2);
        }
    }
    
    public int func_149660_a(final World p_onBlockPlaced_1_, final int p_onBlockPlaced_2_, final int p_onBlockPlaced_3_, final int p_onBlockPlaced_4_, final int p_onBlockPlaced_5_, final float p_onBlockPlaced_6_, final float p_onBlockPlaced_7_, final float p_onBlockPlaced_8_, final int p_onBlockPlaced_9_) {
        if (p_onBlockPlaced_5_ == 0 || (p_onBlockPlaced_5_ != 1 && p_onBlockPlaced_7_ > 0.5)) {
            return p_onBlockPlaced_9_ | 0x4;
        }
        return p_onBlockPlaced_9_;
    }
    
    public MovingObjectPosition func_149731_a(final World p_collisionRayTrace_1_, final int p_collisionRayTrace_2_, final int p_collisionRayTrace_3_, final int p_collisionRayTrace_4_, final Vec3 p_collisionRayTrace_5_, final Vec3 p_collisionRayTrace_6_) {
        final MovingObjectPosition[] arrayOfMovingObjectPosition1 = new MovingObjectPosition[8];
        final int i = p_collisionRayTrace_1_.func_72805_g(p_collisionRayTrace_2_, p_collisionRayTrace_3_, p_collisionRayTrace_4_);
        final int j = i & 0x3;
        final int k = ((i & 0x4) == 0x4) ? 1 : 0;
        final int[] arrayOfInt1 = BlockCustomTileStair.field_150150_a[j + 0];
        this.field_150152_N = true;
        for (int m = 0; m < 8; ++m) {
            this.field_150153_O = m;
            for (int abc = 0; abc < arrayOfInt1.length; ++abc) {
                if (abc == m) {}
            }
            arrayOfMovingObjectPosition1[m] = super.func_149731_a(p_collisionRayTrace_1_, p_collisionRayTrace_2_, p_collisionRayTrace_3_, p_collisionRayTrace_4_, p_collisionRayTrace_5_, p_collisionRayTrace_6_);
        }
        for (int abc2 = 0; abc2 < arrayOfInt1.length; ++abc2) {
            arrayOfMovingObjectPosition1[abc2] = null;
        }
        final Integer i2 = null;
        double d1 = 0.0;
        MovingObjectPosition localMovingObjectPosition2 = null;
        for (final MovingObjectPosition localMovingObjectPosition3 : arrayOfMovingObjectPosition1) {
            if (localMovingObjectPosition3 != null) {
                final double d2 = localMovingObjectPosition3.field_72307_f.func_72436_e(p_collisionRayTrace_6_);
                if (d2 > d1) {
                    localMovingObjectPosition2 = localMovingObjectPosition3;
                    d1 = d2;
                }
            }
        }
        return localMovingObjectPosition2;
    }
    
    static {
        field_150150_a = new int[][] { { 2, 6 }, { 3, 7 }, { 2, 3 }, { 6, 7 }, { 0, 4 }, { 1, 5 }, { 0, 1 }, { 4, 5 } };
    }
}
