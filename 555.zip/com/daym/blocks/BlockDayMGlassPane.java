package com.daym.blocks;

import net.minecraft.block.material.*;
import net.minecraft.block.*;
import net.minecraft.init.*;
import net.minecraft.world.*;
import net.minecraftforge.common.util.*;
import cpw.mods.fml.relauncher.*;

public class BlockDayMGlassPane extends BlockPane
{
    public BlockDayMGlassPane(final String arg0, final String arg1, final Material arg2, final boolean arg3) {
        super(arg0, arg1, arg2, arg3);
    }
    
    public final boolean canPaneConnectToBlockDayM(final Block block) {
        return block.func_149730_j() || block == this || block == Blocks.field_150359_w || block == Blocks.field_150399_cn || block == Blocks.field_150397_co || block instanceof BlockPane || block instanceof BlockDayMGlassPane;
    }
    
    public boolean canPaneConnectTo(final IBlockAccess world, final int x, final int y, final int z, final ForgeDirection dir) {
        return this.canPaneConnectToBlockDayM(world.func_147439_a(x, y, z)) || world.isSideSolid(x, y, z, dir.getOpposite(), false);
    }
    
    @SideOnly(Side.CLIENT)
    public int func_149701_w() {
        return 1;
    }
}
