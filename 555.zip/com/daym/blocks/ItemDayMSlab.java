package com.daym.blocks;

import net.minecraft.item.*;
import net.minecraft.block.*;

public class ItemDayMSlab extends ItemSlab
{
    public ItemDayMSlab(final Block p_i45355_1_) {
        super(p_i45355_1_, (BlockSlab)p_i45355_1_, ((BlockDayMSlabBase)p_i45355_1_).getFullBlock(), false);
    }
}
