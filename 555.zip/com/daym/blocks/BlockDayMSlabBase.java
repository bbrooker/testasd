package com.daym.blocks;

import net.minecraft.block.*;
import net.minecraft.block.material.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.item.*;

public class BlockDayMSlabBase extends BlockSlab
{
    public Block fullBlock;
    public String slabname;
    
    public BlockDayMSlabBase(final boolean p_i45410_1_, final Material p_i45410_2_, final Block full, final String unloc) {
        super(p_i45410_1_, p_i45410_2_);
        this.fullBlock = full;
        this.slabname = unloc;
        this.func_149722_s();
    }
    
    public String func_150002_b(final int arg0) {
        return this.slabname;
    }
    
    public BlockSlab getFullBlock() {
        return (BlockSlab)this.fullBlock;
    }
    
    public ItemStack getPickBlock(final MovingObjectPosition pos, final World world, final int arg2, final int arg3, final int arg4) {
        return new ItemStack((Block)this);
    }
    
    public Item func_149650_a(final int metadata, final Random random, final int fortune) {
        return null;
    }
}
