package com.daym.blocks;

import net.minecraft.block.material.*;

public class BlockDecorative extends DayMBlock
{
    public BlockDecorative(final Material arg0) {
        super(arg0);
    }
}
