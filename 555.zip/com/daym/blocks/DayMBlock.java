package com.daym.blocks;

import net.minecraft.block.*;
import net.minecraft.block.material.*;
import java.util.*;
import net.minecraft.item.*;

public class DayMBlock extends Block
{
    public DayMBlock(final Material arg0) {
        super(arg0);
        this.func_149722_s();
    }
    
    public Item func_149650_a(final int metadata, final Random random, final int fortune) {
        return null;
    }
}
