package com.daym.blocks;

import net.minecraft.block.material.*;
import net.minecraft.block.*;

public class BlockDayMSlab extends BlockDayMSlabBase
{
    public String slabname;
    
    public BlockDayMSlab(final boolean p_i45410_1_, final Material p_i45410_2_, final Block full, final String unloc) {
        super(p_i45410_1_, p_i45410_2_, full, unloc);
        this.slabname = unloc;
    }
    
    @Override
    public String func_150002_b(final int arg0) {
        return "tile." + this.slabname;
    }
}
