package com.daym.blocks;

import net.minecraft.block.material.*;
import com.daym.misc.*;
import net.minecraft.world.*;
import java.util.*;

public class BlockLightFlash extends DayMBlock
{
    public BlockLightFlash(final Material arg0, final DayMBoundingBox bb) {
        super(arg0);
        if (bb != null) {
            this.func_149676_a(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ);
        }
    }
    
    public void func_149734_b(final World world, final int par1, final int par2, final int par3, final Random random) {
        world.func_147468_f(par1, par2, par3);
    }
    
    public boolean func_149662_c() {
        return false;
    }
    
    public boolean func_149703_v() {
        return false;
    }
    
    public boolean func_149686_d() {
        return false;
    }
}
