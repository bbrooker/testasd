package com.daym.blocks;

import net.minecraft.util.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.block.*;
import net.minecraft.block.material.*;
import cpw.mods.fml.common.*;
import net.minecraft.client.renderer.texture.*;

public class BlockDayMSlabMT extends BlockDayMSlabBase
{
    @SideOnly(Side.CLIENT)
    private IIcon texBlockSide;
    @SideOnly(Side.CLIENT)
    private String texBlock;
    @SideOnly(Side.CLIENT)
    private String texSide;
    public Block fullBlock;
    public String slabname;
    
    public BlockDayMSlabMT(final boolean p_i45410_1_, final Material p_i45410_2_, final Block full, final String unloc, final String tex, final String tex2) {
        super(p_i45410_1_, p_i45410_2_, full, unloc);
        this.slabname = unloc;
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            this.texBlock = tex;
            this.texSide = tex2;
        }
    }
    
    @Override
    public String func_150002_b(final int arg0) {
        return this.slabname;
    }
    
    public IIcon func_149691_a(final int par1, final int par2) {
        if (par1 == 1) {
            return this.field_149761_L;
        }
        if (par1 == 0) {
            return this.field_149761_L;
        }
        return this.texBlockSide;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_149651_a(final IIconRegister par1IconRegister) {
        this.field_149761_L = par1IconRegister.func_94245_a(this.texBlock);
        this.texBlockSide = par1IconRegister.func_94245_a(this.texSide);
    }
}
