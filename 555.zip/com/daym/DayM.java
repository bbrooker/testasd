package com.daym;

import com.daym.misc.*;
import com.daym.config.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import cpw.mods.fml.relauncher.*;
import com.daym.registry.*;
import com.daym.serverproxy.*;
import java.util.*;
import com.daym.enums.*;
import com.daym.handlers.*;
import com.daym.threads.*;
import cpw.mods.fml.common.*;
import com.daym.logger.*;
import com.daym.handlers.event.*;
import net.minecraftforge.common.*;
import cpw.mods.fml.common.network.*;
import org.apache.logging.log4j.*;
import java.io.*;
import java.nio.file.*;
import cpw.mods.fml.common.event.*;
import com.daym.handlers.commands.*;
import net.minecraft.server.*;
import net.minecraft.command.*;
import net.minecraft.client.*;

@Mod(modid = "DayM", version = "2.1.4_beta")
public class DayM
{
    public static final String MODID = "DayM";
    public static final String VERSION = "2.1.4_beta";
    private static int modGuiIndex;
    public static final int GUIID_ITEM;
    public static final int GUI_CUSTOM_INV;
    public static DayMTabHandler daym_d4179bfe0;
    public static LanguageHandler daym_b10b9dcb0;
    public static SoundHandlerDayM daym_f64079460;
    public static ItemRegistry daym_8fc6ef6a0;
    public static BlockRegistry daym_8226ac110;
    public static EntityRegistryDayM daym_1b073e6c0;
    public static PacketRegistry daym_f3e43a2f0;
    public static GunUtils daym_367420560;
    public static DayMConfig daym_748d583f0;
    public static TickHandler daym_0445f76a0;
    public static SimpleNetworkWrapper daym_6cbaa18a0;
    public static PlayerVarHandler daym_b6e4e1af0;
    public static WorldHandler daym_0c2009100;
    @SideOnly(Side.CLIENT)
    public static KeybindRegistry daym_71b251030;
    public static CraftingRegistry daym_b6377ffd0;
    @SideOnly(Side.CLIENT)
    public static GuiEventHandler daym_2a98747c0;
    @SideOnly(Side.CLIENT)
    public static GuiVarHandler daym_e1d8ee710;
    @SidedProxy(clientSide = "com.daym.clientproxy.ClientProxy", serverSide = "com.daym.serverproxy.CommonProxy")
    public static CommonProxy serverProxy;
    public static boolean daym_b564a6500;
    public static boolean daym_70a7d6d00;
    public static File daym_3247f27e0;
    public static File daym_9fb8d4510;
    public static File daym_697207960;
    public static boolean daym_053b870d0;
    public static ArrayList<DayMSoundEnum> sounds;
    public static boolean daym_2bb53b850;
    public static long daym_5aeef7d50;
    public static String daym_8907e7060;
    @Mod.Instance("DayM")
    public static DayM instance;
    public static String daym_9b02c5b00;
    public static boolean daym_a252379c0;
    public static final PacketPipeLine daym_1c1a73990;
    public static OfficialSLThread daym_c93febc30;
    public static String daym_f06245270;
    public static String daym_1a33edfd0;
    public static String daym_f51f5ec10;
    
    @Mod.EventHandler
    public void preInit(final FMLPreInitializationEvent event) {
        DayM.daym_9b02c5b00 = System.getProperty("java.version");
        if (!DayM.daym_9b02c5b00.startsWith("1.7.") && !DayM.daym_9b02c5b00.startsWith("1.8.")) {
            DayM.daym_a252379c0 = false;
        }
        DayM.daym_748d583f0 = new DayMConfig();
        DayM.daym_8fc6ef6a0 = new ItemRegistry();
        DayM.daym_8226ac110 = new BlockRegistry();
        DayM.daym_1b073e6c0 = new EntityRegistryDayM();
        DayM.daym_f64079460 = new SoundHandlerDayM();
        DayM.daym_b6e4e1af0 = new PlayerVarHandler();
        DayM.daym_b6377ffd0 = new CraftingRegistry();
        DayM.daym_0c2009100 = new WorldHandler();
        DayM.daym_6cbaa18a0 = NetworkRegistry.INSTANCE.newSimpleChannel("DayM");
        DayM.daym_f3e43a2f0 = new PacketRegistry(DayM.daym_6cbaa18a0);
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient() && DayM.daym_a252379c0) {
            this.createSLFiles(event.getModConfigurationDirectory());
        }
        if (DayM.daym_a252379c0) {
            daymlog.out("Valid Java version detected: " + DayM.daym_9b02c5b00);
        }
        else {
            daymlog.out("Unsupported Java version detected: " + DayM.daym_9b02c5b00);
            daymlog.out("Please download Java 7 and remove your current installation of java.");
        }
    }
    
    @Mod.EventHandler
    public void init(final FMLInitializationEvent event) {
        DayM.daym_1c1a73990.initialise();
        DayM.daym_0445f76a0 = new TickHandler();
        FMLCommonHandler.instance().bus().register((Object)DayM.daym_0445f76a0);
        final EventHandlerDayM eh = new EventHandlerDayM();
        MinecraftForge.EVENT_BUS.register((Object)eh);
        NetworkRegistry.INSTANCE.registerGuiHandler((Object)DayM.instance, (IGuiHandler)DayM.serverProxy);
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            this.clientSide();
        }
        if (side.isServer()) {
            if (!(DayM.daym_b564a6500 = (FMLCommonHandler.instance().getMinecraftServerInstance().func_71266_T() || DayM.daym_70a7d6d00))) {
                LogManager.getLogger().error("[DayM Server INIT - Startup error, the server port possibly was not portforwarded. Could not add server to public server list.]");
            }
            CommonProxy.letServerKnow(false);
        }
    }
    
    private void createSLFiles(final File fi) {
        DayM.daym_697207960 = new File(fi.getPath() + "/DayM");
        final boolean success = new File(fi.getPath() + "/DayM").mkdirs();
        if (success) {
            writeServerListFile("", "favorites");
            writeServerListFile("", "history");
        }
        else if (!DayM.daym_697207960.exists()) {
            daymlog.out("Could not make config/DayM folder! Something went wrong?");
        }
    }
    
    @Mod.EventHandler
    public void postInit(final FMLPostInitializationEvent evt) {
        DayM.daym_1c1a73990.postInitialise();
    }
    
    public static void removeServerListFile(final String server, final String listtype) {
        try {
            DayM.daym_3247f27e0 = new File(DayM.daym_697207960.getPath() + "/sl_favorites.daym");
            DayM.daym_9fb8d4510 = new File(DayM.daym_697207960.getPath() + "/sl_history.daym");
            File file = DayM.daym_3247f27e0;
            if (listtype == "history") {
                return;
            }
            if (listtype == "favorites") {
                file = DayM.daym_3247f27e0;
            }
            final File temp = File.createTempFile("temp_sl", ".daym", DayM.daym_697207960.getParentFile());
            final String charset = "UTF-8";
            final BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), charset));
            final PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(temp), charset));
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.replace(server, "");
                writer.print(line);
            }
            reader.close();
            writer.close();
            file.delete();
            temp.renameTo(file);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static String readFile(final String path) throws IOException {
        final byte[] encoded = Files.readAllBytes(Paths.get(path, new String[0]));
        return new String(encoded, "UTF-8");
    }
    
    public static void writeServerListFile(final String server, final String listtype) {
        try {
            if (listtype == "favorites") {
                DayM.daym_3247f27e0 = new File(DayM.daym_697207960.getPath() + "/sl_favorites.daym");
                final String add = readFile(DayM.daym_3247f27e0.getPath());
                final PrintWriter writer = new PrintWriter(DayM.daym_3247f27e0.getPath(), "UTF-8");
                writer.print("$" + add + server);
                writer.close();
            }
            if (listtype == "history") {
                DayM.daym_9fb8d4510 = new File(DayM.daym_697207960.getPath() + "/sl_history.daym");
                final String add = readFile(DayM.daym_9fb8d4510.getPath());
                final PrintWriter writer = new PrintWriter(DayM.daym_9fb8d4510.getPath(), "UTF-8");
                writer.print("$" + add + server);
                writer.close();
            }
            if (listtype == "history_clear") {
                DayM.daym_9fb8d4510 = new File(DayM.daym_697207960.getPath() + "/sl_history.daym");
                final PrintWriter writer2 = new PrintWriter(DayM.daym_9fb8d4510.getPath(), "UTF-8");
                writer2.print("$");
                writer2.close();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Mod.EventHandler
    public void serverStop(final FMLServerStoppedEvent event) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isServer()) {
            CommonProxy.letServerKnow(true);
        }
        WorldHandler.daym_9fe0fd250.clear();
        WorldHandler.daym_d9470e610.clear();
        WorldHandler.daym_4ceb36930.clear();
        WorldHandler.daym_54c1b80c0.clear();
        WorldHandler.daym_801545040.clear();
        WorldHandler.daym_d5981e440.clear();
        WorldHandler.daym_5635fd3d0 = "null";
        WorldHandler.daym_24d72dcb0 = "null";
        WorldHandler.daym_28d3f01a0 = "null";
        WorldHandler.daym_0b5a7f8a0 = "null";
        WorldHandler.daym_2e14bae20.clear();
        WorldHandler.daym_3c31c2bc0.clear();
        daymlog.out("DayM WD Reset | Server Stopped");
    }
    
    @Mod.EventHandler
    public void serverStart(final FMLServerStartingEvent event) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isServer()) {
            DayM.daym_2bb53b850 = false;
            WorldHandler.daym_54c1b80c0.clear();
            (DayM.daym_c93febc30 = new OfficialSLThread(DayM.daym_1a33edfd0 + "data/blacklist.daym", "bl")).start();
        }
        final MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        final ICommandManager command = server.func_71187_D();
        final ServerCommandManager manager = (ServerCommandManager)command;
        manager.func_71560_a((ICommand)new DayMCommandReload());
        daymlog.out("DayM | Server Started");
    }
    
    @SideOnly(Side.CLIENT)
    private void clientSide() {
        DayM.daym_053b870d0 = true;
        DayM.daym_2a98747c0 = new GuiEventHandler();
        NetworkRegistry.INSTANCE.registerGuiHandler((Object)this, (IGuiHandler)DayM.daym_2a98747c0);
        MinecraftForge.EVENT_BUS.register((Object)DayM.daym_2a98747c0);
        DayM.daym_71b251030 = new KeybindRegistry();
        FMLCommonHandler.instance().bus().register((Object)DayM.daym_71b251030);
        DayM.daym_e1d8ee710 = new GuiVarHandler();
        forceUnicode();
    }
    
    @SideOnly(Side.CLIENT)
    public static void forceUnicode() {
        if (!Minecraft.func_71410_x().field_71466_p.func_82883_a()) {
            Minecraft.func_71410_x().field_71466_p.func_78264_a(true);
        }
    }
    
    public static DayM getInstance() {
        return DayM.instance;
    }
    
    static {
        DayM.modGuiIndex = 0;
        GUIID_ITEM = DayM.modGuiIndex++;
        GUI_CUSTOM_INV = DayM.modGuiIndex++;
        DayM.daym_d4179bfe0 = new DayMTabHandler();
        DayM.daym_b10b9dcb0 = new LanguageHandler();
        DayM.daym_367420560 = new GunUtils();
        DayM.daym_b564a6500 = false;
        DayM.daym_70a7d6d00 = false;
        DayM.daym_053b870d0 = false;
        DayM.sounds = new ArrayList<DayMSoundEnum>();
        DayM.daym_2bb53b850 = true;
        DayM.daym_5aeef7d50 = 203L;
        DayM.daym_8907e7060 = "-1";
        DayM.daym_9b02c5b00 = "null";
        DayM.daym_a252379c0 = true;
        daym_1c1a73990 = new PacketPipeLine();
        DayM.daym_f06245270 = "$ERROR";
        DayM.daym_1a33edfd0 = "http://daymmod.com/";
        DayM.daym_f51f5ec10 = ".php";
    }
}
