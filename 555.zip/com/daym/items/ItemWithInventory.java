package com.daym.items;

import net.minecraft.item.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import cpw.mods.fml.common.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.nbt.*;

public class ItemWithInventory extends ItemClothing
{
    public Integer[] validslots;
    public int invSize;
    public int invRows;
    
    public ItemWithInventory(final int id, final int size, final int rows, final String icon, final String name, final int sx, final int sy, final Integer... in) {
        super(id, icon, name, sx, sy, in);
        this.invSize = 8;
        this.invRows = 1;
        this.invSize = size;
        this.invRows = rows;
        if (in != null) {
            this.validslots = in;
        }
        else {
            (this.validslots = new Integer[1])[0] = -1;
        }
    }
    
    public int func_77626_a(final ItemStack stack) {
        return 1;
    }
    
    public void func_77663_a(final ItemStack is, final World world, final Entity ent, final int arg3, final boolean arg4) {
        String uuid = "";
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (!(ent instanceof EntityPlayer)) {
            return;
        }
        makeNBT(is, (EntityPlayer)ent);
        uuid = ((EntityPlayer)ent).func_110124_au().toString();
        if (side.isClient()) {
            return;
        }
        final EntityPlayer player = (EntityPlayer)ent;
        if (!DayMItem.isInHand(ent, is)) {
            return;
        }
    }
    
    public ItemStack func_77659_a(final ItemStack is, final World world, final EntityPlayer player) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            return is;
        }
        return is;
    }
    
    public static ItemStack[] getBackpackSlotItems(final ItemStack is) {
        if (is == null) {
            return null;
        }
        if (is.field_77990_d == null) {
            return null;
        }
        final NBTTagCompound tagcompound = is.field_77990_d;
        ItemStack[] inventory = null;
        final NBTTagList items = tagcompound.func_150295_c("ItemInventory", (int)tagcompound.func_74732_a());
        for (int i = 0; i < items.func_74745_c(); ++i) {
            final NBTTagCompound item = items.func_150305_b(i);
            final byte slot = item.func_74771_c("Slot");
            if (slot >= 0 && slot < 9) {
                if (inventory == null) {
                    inventory = new ItemStack[9];
                }
                inventory[slot] = ItemStack.func_77949_a(item);
            }
        }
        return inventory;
    }
    
    public static void makeNBT(final ItemStack is, final EntityPlayer player) {
        if (is == null) {
            return;
        }
        if (is.field_77990_d == null) {
            return;
        }
        final NBTTagCompound tag = is.field_77990_d;
    }
}
