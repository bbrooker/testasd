package com.daym.items;

import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.util.*;
import com.daym.misc.*;
import net.minecraft.item.*;
import com.daym.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.entity.*;
import net.minecraft.nbt.*;

public class ItemMagazine extends DayMItem
{
    public ItemAmmo ammoType;
    public int maxAmmo;
    
    public ItemMagazine(final String icon, final String name, final ItemAmmo a, final int ma, final int sx, final int sy) {
        super(icon, name, sx, sy, new Integer[0]);
        this.ammoType = null;
        this.maxAmmo = 10;
        this.ammoType = a;
        this.maxAmmo = ma;
    }
    
    public ItemStack func_77659_a(final ItemStack is, final World world, final EntityPlayer player) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isServer()) {
            final boolean result = addBulletsToMagInventory(is, player);
            if (!result) {
                final IChatComponent test = (IChatComponent)new ChatComponentText("You have no bullets in your inventory.");
                player.func_145747_a(test);
            }
        }
        return is;
    }
    
    public boolean func_77648_a(final ItemStack is, final EntityPlayer player, final World world, final int par1, final int par2, final int par3, final int par4, final float par01, final float par02, final float par03) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isServer()) {
            final boolean result = addBulletsToMagInventory(is, player);
            is.field_77992_b = 0;
            if (!result) {
                final IChatComponent test = (IChatComponent)new ChatComponentText("You have no bullets in your inventory.");
                player.func_145747_a(test);
            }
        }
        return true;
    }
    
    public static boolean addBulletsToMagInventory(final ItemStack is, final EntityPlayer player) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (is != null) {
            final ItemAmmo am = ((ItemMagazine)is.func_77973_b()).ammoType;
            if (PlayerInventoryManager.hasItem(player, am)) {
                final boolean result = loadBullets(is, 1);
                if (result) {
                    player.field_70170_p.func_72956_a((Entity)player, "daym:makarov_insert_mag", 1.0f, 1.0f);
                    PlayerInventoryManager.consumeInventoryItem(player, am);
                    DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_SyncPlayerProps(0, player));
                    return true;
                }
            }
        }
        return true;
    }
    
    public boolean onEntitySwing(final EntityLivingBase ent, final ItemStack is) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        ent.field_82175_bq = false;
        ent.field_70733_aJ = 0.0f;
        ent.field_110158_av = 0;
        return true;
    }
    
    public static boolean loadBullets(final ItemStack is, final int am) {
        if (is == null) {
            return false;
        }
        NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            is.field_77990_d = new NBTTagCompound();
            tag = is.field_77990_d;
        }
        final int b = tag.func_74762_e("bullets") + am;
        if (b > ((ItemMagazine)is.func_77973_b()).maxAmmo) {
            return false;
        }
        tag.func_74768_a("bullets", b);
        return true;
    }
    
    public static int getBullets(final ItemStack is) {
        if (is == null) {
            return 0;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return 0;
        }
        final int b = tag.func_74762_e("bullets");
        return b;
    }
}
