package com.daym.items;

public class ItemClothing extends DayMItem
{
    public int clothingID;
    
    public ItemClothing(final int id, final String icon, final String name, final int sx, final int sy, final Integer... in) {
        super(icon, name, sx, sy, in);
        this.clothingID = 0;
        this.clothingID = id;
    }
}
