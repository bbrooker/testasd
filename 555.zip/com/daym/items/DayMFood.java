package com.daym.items;

import cpw.mods.fml.common.registry.*;
import net.minecraft.item.*;
import com.daym.registry.*;

public class DayMFood extends ItemFood
{
    public DayMFood(final String icon, final String name, final int healam, final float satur, final boolean forWolf) {
        super(healam, satur, forWolf);
        GameRegistry.registerItem((Item)this, name);
        this.func_111206_d(icon);
        ItemRegistry.itemList.add((Item)this);
    }
}
