package com.daym.items;

import cpw.mods.fml.common.registry.*;
import net.minecraft.item.*;
import net.minecraft.entity.*;

public class ItemDayMArmor extends ItemArmor
{
    private String textureName;
    
    public ItemDayMArmor(final String icon, final String name, final ItemArmor.ArmorMaterial material1, final int type, final String tex) {
        super(material1, 0, type);
        GameRegistry.registerItem((Item)this, name);
        this.func_111206_d(icon);
        material1.func_78044_b(type);
        this.func_77656_e(material1.func_78046_a(type));
        this.field_77777_bU = 1;
        this.textureName = tex;
    }
    
    public String getArmorTexture(final ItemStack stack, final Entity entity, final int slot, final String type) {
        return "daym:armor/" + this.textureName + "_" + ((this.field_77881_a == 2) ? "2" : "1") + ".png";
    }
}
