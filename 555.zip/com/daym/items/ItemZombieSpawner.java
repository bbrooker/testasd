package com.daym.items;

import net.minecraft.item.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.*;
import net.minecraft.util.*;
import com.daym.handlers.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.*;
import com.daym.gui.*;
import cpw.mods.fml.relauncher.*;

public class ItemZombieSpawner extends DayMItem
{
    public ItemZombieSpawner(final String icon, final String name) {
        super(icon, name, 1, 1, new Integer[0]);
    }
    
    public ItemStack func_77659_a(final ItemStack is, final World world, final EntityPlayer player) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            if (player.field_71075_bZ.field_75098_d) {
                this.doClientStuff(0);
            }
            else {
                final IChatComponent test = (IChatComponent)new ChatComponentText("You must be in creative mode to use this tool.");
                player.func_145747_a(test);
            }
        }
        return is;
    }
    
    public boolean func_77648_a(final ItemStack is, final EntityPlayer player, final World world, final int par1, final int par2, final int par3, final int par4, final float par01, final float par02, final float par03) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            if (player.field_71075_bZ.field_75098_d) {
                WorldVarHandler.daym_d968810a0 = par1;
                WorldVarHandler.daym_fbd202650 = par2;
                WorldVarHandler.daym_b8e432020 = par3;
                this.doClientStuff(WorldVarHandler.daym_6e949c730 + 1);
            }
            else {
                final IChatComponent test = (IChatComponent)new ChatComponentText("You must be in creative mode to use this tool.");
                player.func_145747_a(test);
            }
        }
        return true;
    }
    
    @SideOnly(Side.CLIENT)
    private void doClientStuff(final int c) {
        if (c == 0) {
            Minecraft.func_71410_x().func_147108_a((GuiScreen)new GuiGlobalTools());
        }
        if (c == 1) {
            Minecraft.func_71410_x().func_147108_a((GuiScreen)new GuiZombieSpawner());
        }
        if (c == 2) {
            Minecraft.func_71410_x().func_147108_a((GuiScreen)new GuiLootSpawner(0));
        }
        if (c == 3) {
            Minecraft.func_71410_x().func_147108_a((GuiScreen)new GuiPlayerSpawner());
        }
    }
}
