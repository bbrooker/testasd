package com.daym.items;

import net.minecraft.item.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.*;
import java.util.*;
import com.daym.handlers.*;
import com.daym.registry.*;
import com.daym.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.entity.*;
import cpw.mods.fml.relauncher.*;

public class ItemKey extends DayMItem
{
    public ItemKey(final String icon, final String name) {
        super(icon, name, 1, 1, new Integer[0]);
    }
    
    public ItemStack func_77659_a(final ItemStack is, final World world, final EntityPlayer player) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            return is;
        }
        final Random random = new Random();
        if (PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) == 3) {
            if (random.nextInt(80) == 64) {
                if (player.field_71071_by.func_146026_a(ItemRegistry.item_key)) {
                    DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_PlayerAnimation(player.func_70005_c_(), (byte)(-1)));
                    PlayerVarHandler.daym_b73359c80.put(player.func_70005_c_(), (byte)(-1));
                    world.func_72956_a((Entity)player, "daym:lock_click", 0.5f, 0.6f);
                }
            }
            else {
                world.func_72956_a((Entity)player, "daym:lock_click", 0.2f, 1.5f - random.nextFloat() / 2.0f);
            }
        }
        return is;
    }
    
    public boolean func_77648_a(final ItemStack is, final EntityPlayer player, final World world, final int par1, final int par2, final int par3, final int par4, final float par01, final float par02, final float par03) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            return false;
        }
        final Random random = new Random();
        if (PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) != null && PlayerVarHandler.daym_b73359c80.get(player.func_70005_c_()) == 3) {
            if (random.nextInt(80) == 64) {
                if (player.field_71071_by.func_146026_a(ItemRegistry.item_key)) {
                    DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_PlayerAnimation(player.func_70005_c_(), (byte)(-1)));
                    PlayerVarHandler.daym_b73359c80.put(player.func_70005_c_(), (byte)(-1));
                    world.func_72956_a((Entity)player, "daym:lock_click", 0.5f, 0.6f);
                }
            }
            else {
                world.func_72956_a((Entity)player, "daym:lock_click", 0.2f, 1.5f - random.nextFloat() / 2.0f);
            }
        }
        return false;
    }
}
