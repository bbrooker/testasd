package com.daym.items;

import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import cpw.mods.fml.common.*;
import com.daym.render.*;
import com.daym.misc.*;
import com.daym.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.handlers.*;
import com.daym.packet.message.*;
import com.daym.config.*;
import org.lwjgl.input.*;
import net.minecraft.client.*;
import com.daym.registry.*;
import com.daym.extended.*;
import cpw.mods.fml.relauncher.*;
import com.daym.inventory.*;
import net.minecraft.nbt.*;
import com.daym.enums.*;
import java.util.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;

public class ItemDayMGun extends DayMItem
{
    public int daym_f17829cb0;
    private boolean isAutomatic;
    private Random random;
    public ItemMagazine daym_511e1e650;
    public boolean daym_c46b8fa90;
    public boolean daym_0c2ff39f0;
    public float daym_a179deca0;
    public float daym_6d067a4e0;
    
    public ItemDayMGun(final String icon, final String name, final GunStatEnum gse, final ItemMagazine t, final int sx, final int sy, final boolean ih, final boolean ib, final float rx, final float ry) {
        super(icon, name, sx, sy, new Integer[0]);
        this.daym_f17829cb0 = 5;
        this.isAutomatic = false;
        this.random = new Random();
        this.daym_511e1e650 = null;
        this.daym_c46b8fa90 = false;
        this.daym_0c2ff39f0 = false;
        this.daym_f17829cb0 = gse.delayFireSpeed;
        this.isAutomatic = gse.isAutomatic;
        this.daym_c46b8fa90 = ih;
        this.daym_0c2ff39f0 = ib;
        ItemRegistry.gunList.add(this);
        this.daym_511e1e650 = t;
        this.daym_a179deca0 = rx;
        this.daym_6d067a4e0 = ry;
    }
    
    public void func_77615_a(final ItemStack par1ItemStack, final World par2World, final EntityPlayer par3EntityPlayer, final int par4) {
    }
    
    public void func_77663_a(final ItemStack is, final World world, final Entity ent, final int arg3, final boolean arg4) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        final int gunid = getGunID(is);
        String uuid = "";
        if (!(ent instanceof EntityPlayer)) {
            return;
        }
        checkSetOwner(is, (EntityPlayer)ent);
        uuid = ((EntityPlayer)ent).func_110124_au().toString();
        final EntityPlayer player = (EntityPlayer)ent;
        if (!DayMItem.isInHand(ent, is)) {
            if (side.isClient() && RenderSetup.daym_fdec667d0 == is.func_77977_a()) {
                GunUtils.setTimer(gunid - 2, 0);
                GunUtils.setReloading(gunid, false);
                RenderSetup.daym_8a1531e40 = -1;
                RenderSetup.daym_1bcc50820 = false;
                RenderSetup.daym_a5d853260 = 0;
            }
            return;
        }
        setCamo(is, 0);
        if (!side.isClient()) {
            return;
        }
        RenderSetup.daym_150173cf0 = getCamo(is);
        RenderSetup.daym_a13965e60 = false;
        if (RenderSetup.daym_fdec667d0 != is.func_77977_a()) {
            RenderSetup.daym_fdec667d0 = is.func_77977_a();
        }
        boolean daym_8a1531e40 = GunUtils.getReloading(gunid);
        boolean unLoading = GunUtils.getUnloading(gunid);
        boolean canShoot = false;
        final GunStatEnum gstat = GunStatEnum.getStatFromGun(is.func_77977_a());
        final int fs = gstat.delayFireSpeed;
        is.field_77992_b = 0;
        canShoot = this.testCanShoot(uuid);
        int timer = GunUtils.getTimer(gunid);
        int timer2 = GunUtils.getTimer(gunid - 1);
        int timer3 = GunUtils.getTimer(gunid - 2);
        int timer4 = GunUtils.getTimer(gunid - 3);
        final int timer5 = GunUtils.getTimer(gunid - 4);
        boolean isChambering = GunUtils.getChambering(gunid);
        if (canShoot) {
            if (this.daym_0c2ff39f0) {
                if (isChambering && timer < fs) {
                    ++timer;
                    GunUtils.setTimer(gunid, timer);
                    if (side.isClient()) {
                        RenderSetup.daym_a13965e60 = false;
                    }
                    return;
                }
            }
            else if (timer < fs) {
                ++timer;
                GunUtils.setTimer(gunid, timer);
                if (side.isClient()) {
                    RenderSetup.daym_a13965e60 = false;
                }
                return;
            }
            if ((this.daym_c46b8fa90 || this.daym_0c2ff39f0) && timer5 != 0) {
                return;
            }
            RenderSetup.daym_1bcc50820 = false;
            if (!ent.func_70051_ag() && !daym_8a1531e40) {
                timer = 0;
                GunUtils.setTimer(gunid, timer);
                GunUtils.setTimer(gunid - 1, 0);
                if (this.daym_c46b8fa90 || this.daym_0c2ff39f0) {
                    GunUtils.setTimer(gunid - 4, 1);
                }
                boolean canShoot2 = true;
                if (side.isClient()) {
                    if (!isChambered(is) && !isChambering) {
                        if (PlayerInventoryManager.hasItem(player, ((ItemMagazine)gstat.magazines[0]).ammoType) || (hasMagazine(is) && getBullets(is) > 0)) {
                            isChambering = true;
                            GunUtils.setChambering(gunid, true);
                            GunUtils.setReloading(gunid, true);
                            final int tt = gstat.reloadTime / 2 + gstat.reloadTime / 8;
                            GunUtils.setTimer(gunid - 2, tt + 3);
                            timer3 = tt + 3;
                        }
                        canShoot2 = false;
                    }
                    if (!player.field_71075_bZ.field_75098_d && canShoot2 && !isChambering && !eatBullet(is)) {
                        SoundHandlerDayM.playSound(gstat.soundLib.sounds[2].name, 1.0f, 0.9f + this.random.nextFloat() * 0.15f);
                        DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_ReloadGun(2, gstat.gunID));
                        setChambered(is, false);
                        canShoot2 = false;
                    }
                }
                if (canShoot2) {
                    final float rec = gstat.recoil * 2.0f;
                    final DayMSoundEnum dsound = gstat.soundLib.sounds[0];
                    final EntityPlayer entityPlayer = player;
                    entityPlayer.field_70125_A -= rec / 2.0f;
                    final EntityPlayer entityPlayer2 = player;
                    entityPlayer2.field_70177_z += (-1.0f + this.random.nextFloat() * 2.0f) * (rec / 2.0f) / 2.0f;
                    PlayerVarHandler.canUnclickList.put(uuid, true);
                    if (side.isClient()) {
                        final EntityPlayer entityPlayer3 = player;
                        entityPlayer3.field_70726_aT -= rec;
                        SoundHandlerDayM.playSound(dsound.name, 1.0f, 0.9f + this.random.nextFloat() * 0.15f);
                        DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_Bullet(gstat.gunID, gstat.bulletSpeed));
                        RenderSetup.daym_a13965e60 = true;
                        RenderSetup.daym_658294230 = 150;
                    }
                }
            }
        }
        else {
            if (timer2 < fs && timer2 != -1) {
                ++timer2;
                GunUtils.setTimer(gunid - 1, timer2);
                return;
            }
            if (timer2 != -1) {
                GunUtils.setTimer(gunid - 1, -1);
                GunUtils.setTimer(gunid, fs);
                if (this.daym_0c2ff39f0) {
                    System.out.println("@@@@@@@@@@@22333");
                    if (!isChambered(is) && !isChambering && (PlayerInventoryManager.hasItem(player, ((ItemMagazine)gstat.magazines[0]).ammoType) || (hasMagazine(is) && getBullets(is) > 0))) {
                        isChambering = true;
                        daym_8a1531e40 = true;
                        GunUtils.setChambering(gunid, true);
                        GunUtils.setReloading(gunid, true);
                        int tt2 = gstat.reloadTime / 2 + gstat.reloadTime / 8;
                        if (hasMagazine(is)) {
                            tt2 = gstat.reloadTime / 2 + gstat.reloadTime / 8;
                        }
                        GunUtils.setTimer(gunid - 2, tt2 + 3);
                        timer3 = tt2 + 3;
                    }
                }
            }
            if ((this.daym_c46b8fa90 || this.daym_0c2ff39f0) && timer5 != 0) {
                GunUtils.setTimer(gunid - 4, 0);
            }
            if (side.isClient()) {
                if (DayMConfig.daym_fe7a127e0) {
                    if (Mouse.isButtonDown(1) && Minecraft.func_71410_x().field_71462_r == null) {
                        if (!RenderSetup.daym_2b3b426c0) {
                            RenderSetup.mcFov = Minecraft.func_71410_x().field_71474_y.field_74334_X;
                            RenderSetup.daym_2b3b426c0 = true;
                        }
                    }
                    else {
                        RenderSetup.daym_2b3b426c0 = false;
                    }
                }
                if (KeybindRegistry.keypressed[1] && !daym_8a1531e40 && !unLoading) {
                    RenderSetup.daym_1bcc50820 = false;
                    unLoading = true;
                    GunUtils.setUnloading(gunid, unLoading);
                }
                if (unLoading) {
                    int target = gstat.unloadTime;
                    if (!hasMagazine(is) && isChambered(is)) {
                        target = gstat.reloadTime;
                    }
                    RenderSetup.daym_a5d853260 = (int)(timer4 / (target / 100.0));
                    final int tt = target / 2 + target / 8;
                    boolean unchamber = false;
                    if (hasMagazine(is)) {
                        target = tt;
                    }
                    else {
                        if (!isChambered(is)) {
                            timer4 = 0;
                            GunUtils.setTimer(gunid - 3, timer4);
                            unLoading = false;
                            GunUtils.setUnloading(gunid, unLoading);
                            return;
                        }
                        unchamber = true;
                        if (timer4 < tt) {
                            timer4 = tt + 1;
                        }
                    }
                    if (RenderSetup.daym_a5d853260 == 13 || RenderSetup.daym_a5d853260 == 14) {
                        SoundHandlerDayM.playSound(gstat.soundLib.sounds[3].name, 1.0f, 1.0f);
                    }
                    if (timer4 > 0 && timer4 < tt) {
                        if (!unchamber) {
                            RenderSetup.daym_8a1531e40 = 3;
                        }
                        else {
                            RenderSetup.daym_8a1531e40 = 0;
                        }
                    }
                    if (timer4 > tt && timer4 < target && unchamber) {
                        RenderSetup.daym_8a1531e40 = 1;
                    }
                    if (timer4 < target) {
                        ++timer4;
                        GunUtils.setTimer(gunid - 3, timer4);
                        if (timer4 > tt - 10) {
                            RenderSetup.daym_1bcc50820 = true;
                        }
                        if (timer4 == tt) {
                            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_ReloadGun(4, gstat.gunID));
                        }
                        if (unchamber && timer4 == target - 10) {
                            SoundHandlerDayM.playSound(gstat.soundLib.sounds[1].name, 1.0f, 1.0f);
                        }
                        return;
                    }
                    if (unchamber) {
                        DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_ReloadGun(5, gstat.gunID));
                    }
                    timer4 = 0;
                    GunUtils.setTimer(gunid - 3, timer4);
                    unLoading = false;
                    GunUtils.setUnloading(gunid, unLoading);
                    RenderSetup.daym_a5d853260 = (int)(timer4 / (target / 100.0));
                }
                if (KeybindRegistry.keypressed[0] && !daym_8a1531e40 && !unLoading) {
                    RenderSetup.daym_1bcc50820 = false;
                    if (getBullets(is) < ((ItemDayMGun)is.func_77973_b()).daym_511e1e650.maxAmmo) {
                        ItemStack ammo = null;
                        int bscan = 0;
                        int prevbScan = 0;
                        int slot = 0;
                        if (!hasMagazine(is)) {
                            prevbScan = -1;
                        }
                        for (int a = 0; a < 4; ++a) {
                            final ItemInventory inv = PlayerInventoryManager.getItemInventory(a, ExtendedPlayer.get(player).inventory);
                            if (inv != null) {
                                int i = 0;
                                for (final ItemStack items : inv.inventory) {
                                    if (items != null && GunStatEnum.isMagazine(gstat, items.func_77973_b())) {
                                        if (items.field_77990_d != null) {
                                            bscan = items.field_77990_d.func_74762_e("bullets");
                                        }
                                        if (bscan > prevbScan) {
                                            prevbScan = bscan;
                                            ammo = items;
                                            slot = i;
                                        }
                                    }
                                    ++i;
                                }
                            }
                        }
                        if (ammo != null) {
                            daym_8a1531e40 = true;
                            GunUtils.setReloading(gunid, daym_8a1531e40);
                        }
                    }
                }
                if (daym_8a1531e40) {
                    RenderSetup.daym_a5d853260 = (int)(timer3 / (gstat.reloadTime / 100.0));
                    int target = gstat.reloadTime;
                    final int tt = target / 2 + target / 8;
                    final int buls = getBullets(is);
                    if (isChambered(is)) {
                        target = tt;
                    }
                    if (timer3 > 0 && timer3 < tt) {
                        if (hasMagazine(is)) {
                            RenderSetup.daym_8a1531e40 = 0;
                        }
                        else {
                            RenderSetup.daym_8a1531e40 = 2;
                        }
                    }
                    int var0 = RenderSetup.daym_8a1531e40;
                    if (var0 == 0) {
                        var0 = 1;
                    }
                    if (RenderSetup.daym_a5d853260 == 13 * var0) {
                        SoundHandlerDayM.playSound(gstat.soundLib.sounds[4].name, 1.0f, 1.0f);
                    }
                    if (timer3 > tt && timer3 < target) {
                        RenderSetup.daym_8a1531e40 = 1;
                    }
                    if (timer3 < target) {
                        ++timer3;
                        GunUtils.setTimer(gunid - 2, timer3);
                        if (timer3 == tt) {
                            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_ReloadGun(0, gstat.gunID));
                            SoundHandlerDayM.playSound(gstat.soundLib.sounds[3].name, 1.0f, 1.0f);
                        }
                        if (!isChambered(is) && timer3 == target - 8) {
                            SoundHandlerDayM.playSound(gstat.soundLib.sounds[1].name, 1.0f, 1.0f);
                        }
                        return;
                    }
                    System.out.println("NEW BITCH");
                    if (isChambering) {
                        DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_ReloadGun(3, gstat.gunID));
                        isChambering = false;
                        GunUtils.setChambering(gunid, false);
                    }
                    else {
                        DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_ReloadGun(1, gstat.gunID));
                    }
                    timer3 = 0;
                    GunUtils.setTimer(gunid - 2, timer3);
                    daym_8a1531e40 = false;
                    GunUtils.setReloading(gunid, daym_8a1531e40);
                    RenderSetup.daym_a5d853260 = (int)(timer3 / (gstat.reloadTime / 100.0));
                }
                RenderSetup.daym_8a1531e40 = -1;
            }
        }
    }
    
    private boolean testCanShoot(final String uuid) {
        boolean canShoot = false;
        if (PlayerVarHandler.clickingList.containsKey(uuid)) {
            final boolean cs = PlayerVarHandler.clickingList.get(uuid);
            if (!cs) {
                if (PlayerVarHandler.canUnclickList.containsKey(uuid) && PlayerVarHandler.canUnclickList.get(uuid)) {
                    canShoot = cs;
                }
            }
            else {
                canShoot = cs;
            }
        }
        return canShoot;
    }
    
    public static void setChambered(final ItemStack is, final boolean ch) {
        if (is == null) {
            return;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return;
        }
        tag.func_74757_a("chambered", ch);
    }
    
    public static void setCamo(final ItemStack is, final int c) {
        if (is == null) {
            return;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return;
        }
        tag.func_74768_a("camo", c);
    }
    
    public static int getCamo(final ItemStack is) {
        if (is == null) {
            return 0;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return 0;
        }
        return tag.func_74762_e("camo");
    }
    
    public static GunAttachment getAttachment(final ItemStack is, final int ai) {
        if (is == null) {
            return null;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return null;
        }
        return GunAttachment.getByID(tag.func_74762_e("attachment_" + ai));
    }
    
    public static ArrayList<GunAttachment> getAttachments(final ItemStack is) {
        if (is == null) {
            return null;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return null;
        }
        final int ai = tag.func_74762_e("attachment_am");
        final ArrayList<GunAttachment> gal = new ArrayList<GunAttachment>();
        for (int i = 0; i < ai; ++i) {
            gal.add(getAttachment(is, i));
        }
        return gal;
    }
    
    public static void addAttachment(final ItemStack is, final GunAttachment ga) {
        if (is == null) {
            return;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return;
        }
        final Integer ai = tag.func_74762_e("attachment_am");
        int fai = 0;
        if (ai != null) {
            fai = ai;
        }
        else {
            tag.func_74768_a("attachment_am", 0);
        }
        tag.func_74768_a("attachment_" + (fai + 1), ga.id);
    }
    
    public static void setAttachment(final ItemStack is, final GunAttachment ga, final int id) {
        if (is == null) {
            return;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return;
        }
        final int ai = tag.func_74762_e("attachment_am");
        if (ai == 0) {
            tag.func_74768_a("attachment_am", 1);
        }
        tag.func_74768_a("attachment_" + id, ga.id);
    }
    
    public static void removeAttachment(final ItemStack is, final GunAttachment ga) {
        if (is == null) {
            return;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return;
        }
        for (int ai = tag.func_74762_e("attachment_am"), i = 0; i < ai; ++i) {
            final int ag = tag.func_74762_e("attachment_" + i);
            if (ag == ga.id) {
                tag.func_74768_a("attachment_" + i, -1);
            }
        }
    }
    
    public static boolean isChambered(final ItemStack is) {
        if (is == null) {
            return false;
        }
        final NBTTagCompound tag = is.field_77990_d;
        return tag != null && tag.func_74767_n("chambered");
    }
    
    public static void addBullets(final ItemStack is, final int am) {
        if (is == null) {
            return;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return;
        }
        final int oldB = tag.func_74762_e("mag_bullets");
        int sum = oldB + am;
        if (sum < 0) {
            sum = 0;
        }
        tag.func_74768_a("mag_bullets", sum);
    }
    
    public static boolean eatBullet(final ItemStack is) {
        if (is == null) {
            return false;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return false;
        }
        int oldB = 0;
        oldB = tag.func_74762_e("mag_bullets");
        if (oldB > 0) {
            tag.func_74768_a("mag_bullets", oldB - 1);
            return true;
        }
        return false;
    }
    
    public static int loadMagazine(final ItemStack is, ItemStack mag) {
        if (is == null || mag == null) {
            return -1;
        }
        final NBTTagCompound tag = is.field_77990_d;
        final NBTTagCompound tagmag = mag.field_77990_d;
        if (tag == null || tagmag == null) {
            return -1;
        }
        int oldB = -1;
        int ca = 0;
        if (tag.func_74767_n("hasMagazine")) {
            oldB = tag.func_74762_e("mag_bullets");
        }
        else {
            oldB = -5;
        }
        final int b = tagmag.func_74762_e("bullets");
        if (tag.func_74767_n("chambered")) {
            ca = 1;
        }
        tag.func_74768_a("mag_bullets", b + ca);
        tag.func_74757_a("hasMagazine", true);
        tagmag.func_74768_a("bullets", -1);
        mag = null;
        return oldB - ca;
    }
    
    public static int getBullets(final ItemStack is) {
        if (is == null) {
            return 0;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return 0;
        }
        final int b = tag.func_74762_e("mag_bullets");
        return b;
    }
    
    public static boolean hasMagazine(final ItemStack is) {
        if (is == null) {
            return false;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return false;
        }
        final boolean b = tag.func_74767_n("hasMagazine");
        return b;
    }
    
    public static String getMagazineUnloc(final ItemStack is) {
        if (is == null) {
            return "null";
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return "null";
        }
        return tag.func_74779_i("magazineType");
    }
    
    public static void setMagazine(final ItemStack is, final boolean b, final Item type) {
        if (is == null) {
            return;
        }
        final NBTTagCompound tag = is.field_77990_d;
        if (tag == null) {
            return;
        }
        tag.func_74757_a("hasMagazine", b);
        if (type != null) {
            tag.func_74778_a("magazineType", type.func_77658_a());
        }
        else {
            tag.func_74778_a("magazineType", "null");
        }
    }
    
    public void func_77622_d(final ItemStack itemStack, final World world, final EntityPlayer player) {
        itemStack.field_77990_d = new NBTTagCompound();
    }
    
    public static int getGunID(final ItemStack is) {
        if (is == null) {
            return 0;
        }
        if (is.field_77990_d == null) {
            is.field_77990_d = new NBTTagCompound();
            return 0;
        }
        final Integer id = is.field_77990_d.func_74762_e("gunID");
        if (id == null) {
            return 0;
        }
        return id;
    }
    
    public static void checkSetOwner(final ItemStack is, final EntityPlayer player) {
        if (is == null) {
            return;
        }
        if (is.field_77990_d == null) {
            return;
        }
        final String owner = is.field_77990_d.func_74779_i("owner");
        final String aowner = player.func_110124_au().toString();
        if (!owner.contains(aowner) || owner == null) {
            final int randomID = (int)(Math.random() * 2.147483647E9);
            final int randomID2 = (int)(Math.random() * 2.147483647E9);
            final boolean isValidID = checkRandomID(randomID);
            final int randomIDA = isValidID ? randomID : randomID2;
            is.field_77990_d.func_74778_a("owner", aowner);
            is.field_77990_d.func_74768_a("gunID", randomIDA);
            is.field_77990_d.func_74768_a("timer", 0);
            is.field_77990_d.func_74757_a("daym_8a1531e40", false);
        }
    }
    
    private static boolean checkRandomID(final int randomID) {
        boolean valid = true;
        for (final Integer id : GunUtils.daym_fdec667d0IDs) {
            if (id == randomID) {
                valid = false;
                break;
            }
        }
        return valid;
    }
    
    public ItemStack func_77659_a(final ItemStack is, final World world, final EntityPlayer player) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient() && !DayMConfig.daym_fe7a127e0) {
            RenderSetup.daym_2b3b426c0 = !RenderSetup.daym_2b3b426c0;
        }
        return is;
    }
    
    public boolean onEntitySwing(final EntityLivingBase ent, final ItemStack is) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        ent.field_82175_bq = false;
        ent.field_70733_aJ = 0.0f;
        ent.field_110158_av = 0;
        return true;
    }
    
    public EnumAction func_77661_b(final ItemStack p_77661_1_) {
        return EnumAction.bow;
    }
}
