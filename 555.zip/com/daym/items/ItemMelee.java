package com.daym.items;

import net.minecraft.item.*;
import cpw.mods.fml.common.registry.*;
import com.daym.registry.*;

public class ItemMelee extends ItemSword
{
    public int slotSizeX;
    public int slotSizeY;
    
    public ItemMelee(final Item.ToolMaterial p_i45356_1_, final String icon, final String name, final int sx, final int sy) {
        super(p_i45356_1_);
        this.slotSizeX = 1;
        this.slotSizeY = 1;
        GameRegistry.registerItem((Item)this, name);
        this.func_111206_d(icon);
        ItemRegistry.itemList.add((Item)this);
    }
}
