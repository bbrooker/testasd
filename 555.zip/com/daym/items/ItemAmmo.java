package com.daym.items;

public class ItemAmmo extends DayMItem
{
    public ItemAmmo(final String icon, final String name) {
        super(icon, name, 1, 1, new Integer[0]);
    }
}
