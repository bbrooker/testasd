package com.daym.items;

import cpw.mods.fml.common.registry.*;
import com.daym.registry.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;

public class DayMItem extends Item
{
    public int slotSizeX;
    public int slotSizeY;
    public Integer[] validslots;
    
    public DayMItem(final String icon, final String name, final int sx, final int sy, final Integer... in) {
        this.slotSizeX = 1;
        this.slotSizeY = 1;
        this.slotSizeX = sx;
        this.slotSizeY = sy;
        GameRegistry.registerItem((Item)this, name);
        this.func_111206_d(icon);
        ItemRegistry.itemList.add(this);
        if (in != null) {
            this.validslots = in;
        }
        else {
            (this.validslots = new Integer[1])[0] = -1;
        }
    }
    
    public Item func_77655_b(final String str) {
        final Item test = super.func_77655_b(str);
        return test;
    }
    
    public static boolean isInHand(final Entity ent, final ItemStack is) {
        return ent instanceof EntityPlayer && ((EntityPlayer)ent).field_71071_by.func_70448_g() == is;
    }
    
    public static boolean isInHandItem(final Entity ent, final Item i) {
        return ent instanceof EntityPlayer && ((EntityPlayer)ent).field_71071_by.func_70448_g() != null && ((EntityPlayer)ent).field_71071_by.func_70448_g().func_77973_b() == i;
    }
}
