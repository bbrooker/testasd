package com.daym.daymobjloader;

class Face
{
    int[] vertexIDs;
    int[] textureIDs;
    int[] normalIDs;
    int materialID;
    
    Face(final int[] vertIDs, final int[] txtrIDs, final int[] normIDs) {
        this.vertexIDs = new int[vertIDs.length];
        this.textureIDs = new int[vertIDs.length];
        this.normalIDs = new int[vertIDs.length];
        if (vertIDs != null) {
            System.arraycopy(vertIDs, 0, this.vertexIDs, 0, vertIDs.length);
        }
        if (txtrIDs != null) {
            System.arraycopy(txtrIDs, 0, this.textureIDs, 0, txtrIDs.length);
        }
        if (normIDs != null) {
            System.arraycopy(normIDs, 0, this.normalIDs, 0, normIDs.length);
        }
    }
    
    public int numTriangles() {
        if (this.vertexIDs == null || this.vertexIDs.length < 3) {
            return 0;
        }
        return this.vertexIDs.length - 2;
    }
}
