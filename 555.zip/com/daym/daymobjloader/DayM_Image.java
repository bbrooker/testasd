package com.daym.daymobjloader;

import javax.imageio.*;
import java.nio.*;
import java.io.*;
import java.awt.geom.*;
import java.awt.*;
import java.awt.image.*;

public class DayM_Image
{
    public int h;
    public int w;
    public ByteBuffer pixelBuffer;
    public int[] pixels;
    public int textureHandle;
    public int textureW;
    public int textureH;
    
    public DayM_Image() {
        this.h = 0;
        this.w = 0;
        this.pixelBuffer = null;
        this.pixels = null;
    }
    
    public DayM_Image(final String imgName) {
        this.h = 0;
        this.w = 0;
        this.pixelBuffer = null;
        this.pixels = null;
        final BufferedImage img = this.loadJavaImage(imgName);
        if (this.makeDayM_Image(img, true, false)) {}
    }
    
    public DayM_Image(final String imgName, final boolean flipYaxis, final boolean convertPow2) {
        this.h = 0;
        this.w = 0;
        this.pixelBuffer = null;
        this.pixels = null;
        final BufferedImage img = this.loadJavaImage(imgName);
        if (this.makeDayM_Image(img, flipYaxis, convertPow2)) {}
    }
    
    public DayM_Image(final byte[] bytes) {
        this.h = 0;
        this.w = 0;
        this.pixelBuffer = null;
        this.pixels = null;
        final BufferedImage img = this.makeBufferedImage(bytes);
        if (this.makeDayM_Image(img, true, false)) {}
    }
    
    public DayM_Image(final byte[] bytes, final boolean flipYaxis, final boolean convertPow2) {
        this.h = 0;
        this.w = 0;
        this.pixelBuffer = null;
        this.pixels = null;
        final BufferedImage img = this.makeBufferedImage(bytes);
        if (this.makeDayM_Image(img, flipYaxis, convertPow2)) {}
    }
    
    public BufferedImage makeBufferedImage(final byte[] imageFileContents) {
        BufferedImage bi = null;
        try {
            final InputStream in = new ByteArrayInputStream(imageFileContents);
            bi = ImageIO.read(in);
        }
        catch (IOException ex) {}
        return bi;
    }
    
    public DayM_Image(final ByteBuffer gl_pixels, final int w, final int h) {
        this.h = 0;
        this.w = 0;
        this.pixelBuffer = null;
        this.pixels = null;
        if (gl_pixels != null) {
            this.pixelBuffer = gl_pixels;
            this.pixels = null;
            this.h = h;
            this.w = w;
        }
    }
    
    public boolean isLoaded() {
        return this.pixelBuffer != null;
    }
    
    public void flipPixels() {
        this.pixels = flipPixels(this.pixels, this.w, this.h);
    }
    
    public boolean makeDayM_Image(BufferedImage tmpi, final boolean flipYaxis, final boolean convertToPow2) {
        if (tmpi != null) {
            if (flipYaxis) {
                tmpi = flipY(tmpi);
            }
            if (convertToPow2) {
                tmpi = convertToPowerOf2(tmpi);
            }
            this.w = tmpi.getWidth(null);
            this.h = tmpi.getHeight(null);
            this.pixels = getImagePixels(tmpi);
            this.pixelBuffer = convertImagePixelsRGBA(this.pixels, this.w, this.h, false);
            this.textureW = DayM_App.getPowerOfTwoBiggerThan(this.w);
            this.textureH = DayM_App.getPowerOfTwoBiggerThan(this.h);
            return true;
        }
        this.pixels = null;
        this.pixelBuffer = null;
        final boolean b = false;
        this.w = (b ? 1 : 0);
        this.h = (b ? 1 : 0);
        return false;
    }
    
    public BufferedImage loadJavaImage(final String imgName) {
        BufferedImage tmpi = null;
        try {
            tmpi = ImageIO.read(DayM_App.getInputStream(imgName));
        }
        catch (Exception ex) {}
        return tmpi;
    }
    
    public static int[] getImagePixels(final Image image) {
        int[] pixelsARGB = null;
        if (image != null) {
            final int imgw = image.getWidth(null);
            final int imgh = image.getHeight(null);
            pixelsARGB = new int[imgw * imgh];
            final PixelGrabber pg = new PixelGrabber(image, 0, 0, imgw, imgh, pixelsARGB, 0, imgw);
            try {
                pg.grabPixels();
            }
            catch (Exception e) {
                return null;
            }
        }
        return pixelsARGB;
    }
    
    public int[] getPixelInts() {
        return this.pixels;
    }
    
    public ByteBuffer getPixelBytes() {
        return this.pixelBuffer;
    }
    
    public static int[] flipPixels(final int[] imgPixels, final int imgw, final int imgh) {
        int[] flippedPixels = null;
        if (imgPixels != null) {
            flippedPixels = new int[imgw * imgh];
            for (int y = 0; y < imgh; ++y) {
                for (int x = 0; x < imgw; ++x) {
                    flippedPixels[(imgh - y - 1) * imgw + x] = imgPixels[y * imgw + x];
                }
            }
        }
        return flippedPixels;
    }
    
    public static ByteBuffer convertImagePixelsARGB(int[] jpixels, final int imgw, final int imgh, final boolean flipVertically) {
        if (flipVertically) {
            jpixels = flipPixels(jpixels, imgw, imgh);
        }
        final ByteBuffer bb = DayM_App.allocBytes(jpixels.length * 4);
        bb.asIntBuffer().put(jpixels);
        return bb;
    }
    
    public static ByteBuffer convertImagePixelsRGBA(int[] jpixels, final int imgw, final int imgh, final boolean flipVertically) {
        if (flipVertically) {
            jpixels = flipPixels(jpixels, imgw, imgh);
        }
        final byte[] bytes = convertARGBtoRGBA(jpixels);
        return allocBytes(bytes);
    }
    
    public static byte[] convertARGBtoRGBA(final int[] jpixels) {
        final byte[] bytes = new byte[jpixels.length * 4];
        int j = 0;
        for (int i = 0; i < jpixels.length; ++i) {
            final int p = jpixels[i];
            final int a = p >> 24 & 0xFF;
            final int r = p >> 16 & 0xFF;
            final int g = p >> 8 & 0xFF;
            final int b = p >> 0 & 0xFF;
            bytes[j + 0] = (byte)r;
            bytes[j + 1] = (byte)g;
            bytes[j + 2] = (byte)b;
            bytes[j + 3] = (byte)a;
            j += 4;
        }
        return bytes;
    }
    
    public static ByteBuffer allocBytes(final byte[] bytearray) {
        final ByteBuffer bb = ByteBuffer.allocateDirect(bytearray.length).order(ByteOrder.nativeOrder());
        bb.put(bytearray).flip();
        return bb;
    }
    
    public void convertToPowerOf2() {
        final BufferedImage image = new BufferedImage(this.w, this.h, 2);
        image.setRGB(0, 0, this.w, this.h, this.pixels, 0, this.w);
        final BufferedImage scaledImg = convertToPowerOf2(image);
        this.w = scaledImg.getWidth(null);
        this.h = scaledImg.getHeight(null);
        this.pixels = getImagePixels(scaledImg);
        this.pixelBuffer = convertImagePixelsRGBA(this.pixels, this.w, this.h, false);
        this.textureW = DayM_App.getPowerOfTwoBiggerThan(this.w);
        this.textureH = DayM_App.getPowerOfTwoBiggerThan(this.h);
    }
    
    public static void savePixelsToPNG(int[] pixels, final int width, final int height, final String imageFilename, final boolean flipY) {
        if (pixels != null && imageFilename != null) {
            if (flipY) {
                pixels = flipPixels(pixels, width, height);
            }
            try {
                final BufferedImage image = new BufferedImage(width, height, 2);
                image.setRGB(0, 0, width, height, pixels, 0, width);
                ImageIO.write(image, "png", new File(imageFilename));
            }
            catch (Exception ex) {}
        }
    }
    
    public static BufferedImage convertToPowerOf2(final BufferedImage bsrc) {
        final int newW = DayM_App.getPowerOfTwoBiggerThan(bsrc.getWidth());
        final int newH = DayM_App.getPowerOfTwoBiggerThan(bsrc.getHeight());
        if (newW == bsrc.getWidth() && newH == bsrc.getHeight()) {
            return bsrc;
        }
        final AffineTransform at = AffineTransform.getScaleInstance(newW / bsrc.getWidth(), newH / bsrc.getHeight());
        final BufferedImage bdest = new BufferedImage(newW, newH, 2);
        final Graphics2D g = bdest.createGraphics();
        g.drawRenderedImage(bsrc, at);
        return bdest;
    }
    
    public static BufferedImage scale(final BufferedImage bsrc, final int width, final int height) {
        final AffineTransform at = AffineTransform.getScaleInstance(width / bsrc.getWidth(), height / bsrc.getHeight());
        final BufferedImage bdest = new BufferedImage(width, height, 2);
        final Graphics2D g = bdest.createGraphics();
        g.drawRenderedImage(bsrc, at);
        return bdest;
    }
    
    public static BufferedImage flipY(final BufferedImage bsrc) {
        final AffineTransform tx = AffineTransform.getScaleInstance(1.0, -1.0);
        tx.translate(0.0, -bsrc.getHeight(null));
        final AffineTransformOp op = new AffineTransformOp(tx, 1);
        return op.filter(bsrc, null);
    }
}
