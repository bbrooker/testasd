package com.daym.daymobjloader;

import java.util.*;
import org.lwjgl.util.glu.*;
import java.nio.*;

public class DayM_Mesh
{
    public ArrayList vertexData;
    public ArrayList triangleData;
    public DayM_Vertex[] vertices;
    public DayM_Triangle[] triangles;
    public int numVertices;
    public int numTriangles;
    public String name;
    private float maxSmoothingAngle;
    private float cos_angle;
    public String materialLibeName;
    public DayM_Material[] materials;
    DayM_Triangle[][] groupFaces;
    String[] groupNames;
    String[] groupMaterialNames;
    int currentGroup;
    private FloatBuffer projectedVert;
    public static final int SIZE_FLOAT = 4;
    
    public DayM_Mesh() {
        this.vertexData = new ArrayList();
        this.triangleData = new ArrayList();
        this.numVertices = 0;
        this.numTriangles = 0;
        this.name = "";
        this.maxSmoothingAngle = 89.0f;
        this.cos_angle = (float)Math.cos(Math.toRadians(this.maxSmoothingAngle));
        this.materialLibeName = null;
        this.materials = null;
        this.groupFaces = new DayM_Triangle[1][];
        this.groupNames = new String[] { "default" };
        this.groupMaterialNames = new String[] { null };
        this.currentGroup = 0;
        this.projectedVert = allocFloats(16);
    }
    
    public void setSmoothingAngle(final float maxSmoothingAngle) {
        this.maxSmoothingAngle = maxSmoothingAngle;
        this.cos_angle = (float)Math.cos(Math.toRadians(maxSmoothingAngle));
    }
    
    public DayM_Vertex vertex(final int id) {
        if (this.vertexData != null) {
            return this.vertexData.get(id);
        }
        return this.vertices[id];
    }
    
    public DayM_Triangle triangle(final int id) {
        if (this.triangleData != null) {
            return this.triangleData.get(id);
        }
        return this.triangles[id];
    }
    
    public void addVertex(final DayM_Vertex newVertex) {
        newVertex.ID = this.vertexData.size();
        this.vertexData.add(newVertex);
    }
    
    public void addVertex(final float x, final float y, final float z) {
        this.addVertex(new DayM_Vertex(x, y, z));
    }
    
    public void addTriangle(final DayM_Triangle newTriangle) {
        this.triangleData.add(newTriangle);
    }
    
    public void addTriangle(final int v1, final int v2, final int v3) {
        this.addTriangle(this.vertex(v1), this.vertex(v2), this.vertex(v3));
    }
    
    public void addTriangle(final DayM_Vertex a, final DayM_Vertex b, final DayM_Vertex c) {
        this.addTriangle(new DayM_Triangle(a, b, c));
    }
    
    public void removeVertex(final DayM_Vertex v) {
        this.vertexData.remove(v);
    }
    
    public void removeTriangle(final DayM_Triangle t) {
        this.triangleData.remove(t);
    }
    
    public void removeVertexAt(final int pos) {
        this.vertexData.remove(pos);
    }
    
    public void removeTriangleAt(final int pos) {
        this.triangleData.remove(pos);
    }
    
    public void rebuild() {
        if (this.vertexData == null || this.triangleData == null) {
            System.out.println("DayM_Mesh.rebuild(): can't rebuild mesh after finalize() was run.");
            return;
        }
        this.numVertices = this.vertexData.size();
        this.vertices = new DayM_Vertex[this.numVertices];
        for (int i = 0; i < this.numVertices; ++i) {
            this.vertices[i] = this.vertex(i);
            this.vertices[i].ID = i;
            this.vertices[i].resetNeighbors();
        }
        this.numTriangles = this.triangleData.size();
        this.triangles = new DayM_Triangle[this.numTriangles];
        for (int j = 0; j < this.numTriangles; ++j) {
            final DayM_Triangle tri = this.triangles[j] = this.triangleData.get(j);
            tri.ID = j;
            tri.p1.addNeighborTri(tri);
            tri.p2.addNeighborTri(tri);
            tri.p3.addNeighborTri(tri);
        }
    }
    
    public void rebuild_OLD() {
        this.numVertices = this.vertexData.size();
        this.vertices = new DayM_Vertex[this.numVertices];
        for (int i = 0; i < this.numVertices; ++i) {
            this.vertices[i] = this.vertexData.get(i);
        }
        this.numTriangles = this.triangleData.size();
        this.triangles = new DayM_Triangle[this.numTriangles];
        for (int i = 0; i < this.numTriangles; ++i) {
            this.triangles[i] = this.triangleData.get(i);
            this.triangles[i].ID = i;
        }
        for (int i = 0; i < this.numVertices; ++i) {
            this.vertices[i].ID = i;
            this.vertices[i].resetNeighbors();
        }
        for (int i = 0; i < this.numTriangles; ++i) {
            final DayM_Triangle tri = this.triangles[i];
            tri.p1.addNeighborTri(tri);
            tri.p2.addNeighborTri(tri);
            tri.p3.addNeighborTri(tri);
        }
    }
    
    public void finalize() {
        if (this.vertexData == null || this.triangleData == null) {
            System.out.println("DayM_Mesh.finalize(): looks like finalize() was already run.");
            return;
        }
        this.vertexData.clear();
        this.triangleData.clear();
        final ArrayList list = null;
        this.triangleData = list;
        this.vertexData = list;
        for (int i = 0; i < this.vertices.length; ++i) {
            this.vertices[i].neighborTris.trimToSize();
        }
    }
    
    public void registerSmoothNeighbors(final ArrayList neighborTris, final DayM_Vertex v, final DayM_Triangle t) {
        for (int i = 0; i < v.neighborTris.size(); ++i) {
            final DayM_Triangle neighborTri = v.neighborTris.get(i);
            if (DayM_Triangle.onSameSurface(t, neighborTri, this.cos_angle) && !neighborTris.contains(neighborTri)) {
                neighborTris.add(neighborTri);
            }
        }
        if (neighborTris.size() == 0) {
            neighborTris.add(t);
        }
    }
    
    public void regenerateNormals() {
        for (int i = 0; i < this.numTriangles; ++i) {
            this.triangles[i].recalcFaceNormal();
        }
        for (int i = 0; i < this.numTriangles; ++i) {
            final DayM_Triangle tri = this.triangles[i];
            tri.resetNeighbors();
            this.registerSmoothNeighbors(tri.neighborsP1, tri.p1, tri);
            this.registerSmoothNeighbors(tri.neighborsP2, tri.p2, tri);
            this.registerSmoothNeighbors(tri.neighborsP3, tri.p3, tri);
        }
        for (int i = 0; i < this.numTriangles; ++i) {
            final DayM_Triangle tri = this.triangles[i];
            tri.norm1 = tri.recalcVertexNormal(tri.neighborsP1);
            tri.norm2 = tri.recalcVertexNormal(tri.neighborsP2);
            tri.norm3 = tri.recalcVertexNormal(tri.neighborsP3);
        }
    }
    
    public DayM_Vector min() {
        if (this.numVertices == 0) {
            return new DayM_Vector(0.0f, 0.0f, 0.0f);
        }
        float minX = this.vertices[0].pos.x;
        float minY = this.vertices[0].pos.y;
        float minZ = this.vertices[0].pos.z;
        for (int i = 0; i < this.numVertices; ++i) {
            if (this.vertices[i].pos.x < minX) {
                minX = this.vertices[i].pos.x;
            }
            if (this.vertices[i].pos.y < minY) {
                minY = this.vertices[i].pos.y;
            }
            if (this.vertices[i].pos.z < minZ) {
                minZ = this.vertices[i].pos.z;
            }
        }
        return new DayM_Vector(minX, minY, minZ);
    }
    
    public DayM_Vector max() {
        if (this.numVertices == 0) {
            return new DayM_Vector(0.0f, 0.0f, 0.0f);
        }
        float maxX = this.vertices[0].pos.x;
        float maxY = this.vertices[0].pos.y;
        float maxZ = this.vertices[0].pos.z;
        for (int i = 0; i < this.numVertices; ++i) {
            if (this.vertices[i].pos.x > maxX) {
                maxX = this.vertices[i].pos.x;
            }
            if (this.vertices[i].pos.y > maxY) {
                maxY = this.vertices[i].pos.y;
            }
            if (this.vertices[i].pos.z > maxZ) {
                maxZ = this.vertices[i].pos.z;
            }
        }
        return new DayM_Vector(maxX, maxY, maxZ);
    }
    
    public DayM_Vector getCenter() {
        final DayM_Vector max = this.max();
        final DayM_Vector min = this.min();
        return new DayM_Vector((max.x + min.x) / 2.0f, (max.y + min.y) / 2.0f, (max.z + min.z) / 2.0f);
    }
    
    public DayM_Vector getDimension() {
        final DayM_Vector max = this.max();
        final DayM_Vector min = this.min();
        return new DayM_Vector(max.x - min.x, max.y - min.y, max.z - min.z);
    }
    
    public DayM_Vertex[] getVertexArray() {
        return this.vertices;
    }
    
    public void projectVerts(final DayM_Mesh obj, final FloatBuffer modelMatrix, final FloatBuffer projectionMatrix, final IntBuffer viewport) {
        for (int i = 0; i < obj.vertices.length; ++i) {
            final DayM_Vertex v = obj.vertices[i];
            GLU.gluProject(v.pos.x, v.pos.y, v.pos.z, modelMatrix, projectionMatrix, viewport, this.projectedVert);
            v.posS.x = this.projectedVert.get(0);
            v.posS.y = this.projectedVert.get(1);
            v.posS.z = this.projectedVert.get(2);
        }
        this.calcZDepths();
    }
    
    public void calcZDepths() {
        for (int i = 0; i < this.triangles.length; ++i) {
            this.triangles[i].calcZdepth();
        }
    }
    
    public void sortTriangles() {
        if (this.triangles != null) {
            this.triangles = this.sortTriangles(this.triangles, 0, this.triangles.length - 1);
        }
    }
    
    public DayM_Triangle[] sortTriangles(final DayM_Triangle[] tri, final int L, final int R) {
        final float m = (tri[L].Zdepth + tri[R].Zdepth) / 2.0f;
        int i = L;
        int j = R;
        while (true) {
            if (tri[i].Zdepth > m) {
                ++i;
            }
            else {
                while (tri[j].Zdepth < m) {
                    --j;
                }
                if (i <= j) {
                    final DayM_Triangle temp = tri[i];
                    tri[i] = tri[j];
                    tri[j] = temp;
                    ++i;
                    --j;
                }
                if (j < i) {
                    break;
                }
                continue;
            }
        }
        if (L < j) {
            this.sortTriangles(tri, L, j);
        }
        if (R > i) {
            this.sortTriangles(tri, i, R);
        }
        return tri;
    }
    
    public DayM_Triangle getTriangle(final float x, final float y) {
        return getTriangle(x, y, this.triangles);
    }
    
    public static DayM_Triangle getTriangle(final float x, final float y, final DayM_Triangle[] _triangles) {
        final ArrayList candidates = new ArrayList();
        DayM_Triangle closestT = null;
        float minZ = 100000.0f;
        for (int i = 0; i < _triangles.length; ++i) {
            final DayM_Triangle t = _triangles[i];
            if (pointInTriangle(x, y, t.p1.posS.x, t.p1.posS.y, t.p2.posS.x, t.p2.posS.y, t.p3.posS.x, t.p3.posS.y)) {
                candidates.add(t);
            }
        }
        for (int j = 0; j < candidates.size(); ++j) {
            if (candidates.get(j).Zdepth < minZ) {
                closestT = candidates.get(j);
                minZ = closestT.Zdepth;
            }
        }
        return closestT;
    }
    
    public static boolean pointInTriangle(final float px, final float py, final float x1, final float y1, final float x2, final float y2, final float x3, final float y3) {
        final float b0 = (x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1);
        final float b2 = ((x2 - px) * (y3 - py) - (x3 - px) * (y2 - py)) / b0;
        final float b3 = ((x3 - px) * (y1 - py) - (x1 - px) * (y3 - py)) / b0;
        final float b4 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) / b0;
        return b2 > 0.0f && b3 > 0.0f && b4 > 0.0f;
    }
    
    public DayM_Mesh makeClone() {
        final DayM_Mesh clone = new DayM_Mesh();
        clone.vertexData.ensureCapacity(this.vertices.length);
        clone.triangleData.ensureCapacity(this.triangles.length);
        for (int i = 0; i < this.vertices.length; ++i) {
            clone.addVertex(this.vertices[i].makeClone());
        }
        for (int i = 0; i < this.triangles.length; ++i) {
            final DayM_Triangle ct;
            clone.addTriangle(ct = this.triangles[i].makeClone());
            ct.p1 = clone.vertex(ct.p1.ID);
            ct.p2 = clone.vertex(ct.p2.ID);
            ct.p3 = clone.vertex(ct.p3.ID);
        }
        clone.name = this.name + " [cloned]";
        clone.rebuild();
        return clone;
    }
    
    @Override
    public String toString() {
        final StringBuffer buffer = new StringBuffer();
        buffer.append("<object id=" + this.name + ">\r\n");
        for (int i = 0; i < this.numVertices; ++i) {
            buffer.append(this.vertices[i].toString());
        }
        return buffer.toString();
    }
    
    public static FloatBuffer allocFloats(final int howmany) {
        final FloatBuffer fb = ByteBuffer.allocateDirect(howmany * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        return fb;
    }
    
    public int numGroups() {
        return this.groupFaces.length;
    }
    
    public String getGroupName(final int g) {
        return this.groupNames[g];
    }
    
    public String getGroupMaterialName(final int g) {
        return this.groupMaterialNames[g];
    }
    
    public DayM_Triangle[] getGroupFaces(final int g) {
        return this.groupFaces[g];
    }
    
    public void selectGroup(int g) {
        if (g > this.groupFaces.length - 1) {
            g = this.groupFaces.length - 1;
        }
        this.currentGroup = g;
    }
    
    public void makeGroups(final int num) {
        this.groupFaces = new DayM_Triangle[num][];
        this.groupNames = new String[num];
        this.groupMaterialNames = new String[num];
    }
    
    public void initGroup(final int groupNum, final String name, final String materialName, final int numTriangles) {
        this.groupFaces[groupNum] = new DayM_Triangle[numTriangles];
        this.groupNames[groupNum] = name;
        this.groupMaterialNames[groupNum] = materialName;
        this.currentGroup = groupNum;
    }
    
    public void addTriangle(final DayM_Triangle newTriangle, final int groupNum, final int triangleNum) {
        newTriangle.ID = this.triangleData.size();
        newTriangle.groupID = groupNum;
        this.triangleData.add(newTriangle);
        this.groupFaces[groupNum][triangleNum] = newTriangle;
    }
}
