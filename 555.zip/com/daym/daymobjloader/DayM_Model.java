package com.daym.daymobjloader;

import org.lwjgl.opengl.*;
import net.minecraft.util.*;
import com.daym.registry.*;
import net.minecraft.client.*;

public class DayM_Model
{
    public static DayM_Material defaultMtl;
    public DayM_Mesh mesh;
    public int displayListID;
    public DayM_Material[] groupMaterials;
    
    public DayM_Model(final String filename) {
        this.mesh = this.loadMesh(filename);
    }
    
    public DayM_Mesh loadMesh(final String filename) {
        if (filename.toUpperCase().endsWith(".OBJ")) {
            final DayM_OBJ_Importer importer = new DayM_OBJ_Importer();
            this.mesh = importer.load(filename);
        }
        else {
            final DayM_3DS_Importer importer2 = new DayM_3DS_Importer();
            this.mesh = importer2.load(filename);
            System.out.println("GLMeshRenderer.loadMesh(): WARNING 3DS files functionality is limited");
        }
        return this.mesh;
    }
    
    public void makeDisplayList() {
        if (this.displayListID == 0) {
            GL11.glNewList(this.displayListID = GL11.glGenLists(1), 4864);
            this.render(this.mesh);
            GL11.glEndList();
        }
    }
    
    public int getDisplayListID() {
        return this.displayListID;
    }
    
    public void regenerateNormals() {
        if (this.mesh != null) {
            this.mesh.regenerateNormals();
        }
    }
    
    public void render() {
        if (this.displayListID == 0) {
            this.render(this.mesh);
        }
        else {
            GL11.glCallList(this.displayListID);
        }
    }
    
    public void renderGroup(final String groupName) {
        int GID = -1;
        for (int g = 0; g < this.mesh.numGroups(); ++g) {
            if (this.mesh.getGroupName(g).equals(groupName)) {
                GID = g;
                break;
            }
        }
        if (GID == -1) {
            return;
        }
        final DayM_Material[] materials = this.mesh.materials;
        final DayM_Triangle[] triangles = this.mesh.getGroupFaces(GID);
        int currMtl = -1;
        int i = 0;
        i = 0;
        while (i < triangles.length) {
            DayM_Triangle t = triangles[i];
            currMtl = t.materialID;
            final DayM_Material mtl = (materials != null && materials.length > 0 && currMtl >= 0) ? materials[currMtl] : DayM_Model.defaultMtl;
            mtl.apply();
            GL11.glBindTexture(3553, mtl.textureHandle);
            GL11.glBegin(4);
            while (i < triangles.length && (t = triangles[i]) != null && currMtl == t.materialID) {
                GL11.glTexCoord2f(t.uvw1.x, t.uvw1.y);
                GL11.glNormal3f(t.norm1.x, t.norm1.y, t.norm1.z);
                GL11.glVertex3f(t.p1.pos.x, t.p1.pos.y, t.p1.pos.z);
                GL11.glTexCoord2f(t.uvw2.x, t.uvw2.y);
                GL11.glNormal3f(t.norm2.x, t.norm2.y, t.norm2.z);
                GL11.glVertex3f(t.p2.pos.x, t.p2.pos.y, t.p2.pos.z);
                GL11.glTexCoord2f(t.uvw3.x, t.uvw3.y);
                GL11.glNormal3f(t.norm3.x, t.norm3.y, t.norm3.z);
                GL11.glVertex3f(t.p3.pos.x, t.p3.pos.y, t.p3.pos.z);
                ++i;
            }
            GL11.glEnd();
        }
    }
    
    public void renderTextured(final ResourceLocation textureHandle) {
        TextureRegistry.bindResource(textureHandle);
        GL11.glBegin(4);
        for (int j = 0; j < this.mesh.triangles.length; ++j) {
            final DayM_Triangle t = this.mesh.triangles[j];
            GL11.glTexCoord2f(t.uvw1.x, t.uvw1.y);
            GL11.glNormal3f(t.norm1.x, t.norm1.y, t.norm1.z);
            GL11.glVertex3f(t.p1.pos.x, t.p1.pos.y, t.p1.pos.z);
            GL11.glTexCoord2f(t.uvw2.x, t.uvw2.y);
            GL11.glNormal3f(t.norm2.x, t.norm2.y, t.norm2.z);
            GL11.glVertex3f(t.p2.pos.x, t.p2.pos.y, t.p2.pos.z);
            GL11.glTexCoord2f(t.uvw3.x, t.uvw3.y);
            GL11.glNormal3f(t.norm3.x, t.norm3.y, t.norm3.z);
            GL11.glVertex3f(t.p3.pos.x, t.p3.pos.y, t.p3.pos.z);
        }
        GL11.glEnd();
    }
    
    public void renderTextured(final int textureHandle) {
        GL11.glBindTexture(3553, textureHandle);
        GL11.glBegin(4);
        for (int j = 0; j < this.mesh.triangles.length; ++j) {
            final DayM_Triangle t = this.mesh.triangles[j];
            GL11.glTexCoord2f(t.uvw1.x, t.uvw1.y);
            GL11.glNormal3f(t.norm1.x, t.norm1.y, t.norm1.z);
            GL11.glVertex3f(t.p1.pos.x, t.p1.pos.y, t.p1.pos.z);
            GL11.glTexCoord2f(t.uvw2.x, t.uvw2.y);
            GL11.glNormal3f(t.norm2.x, t.norm2.y, t.norm2.z);
            GL11.glVertex3f(t.p2.pos.x, t.p2.pos.y, t.p2.pos.z);
            GL11.glTexCoord2f(t.uvw3.x, t.uvw3.y);
            GL11.glNormal3f(t.norm3.x, t.norm3.y, t.norm3.z);
            GL11.glVertex3f(t.p3.pos.x, t.p3.pos.y, t.p3.pos.z);
        }
        GL11.glEnd();
    }
    
    public void renderTexturedMCResource(final ResourceLocation loc) {
        Minecraft.func_71410_x().field_71446_o.func_110577_a(loc);
        GL11.glBegin(4);
        for (int j = 0; j < this.mesh.triangles.length; ++j) {
            final DayM_Triangle t = this.mesh.triangles[j];
            GL11.glTexCoord2f(t.uvw1.x, t.uvw1.y);
            GL11.glNormal3f(t.norm1.x, t.norm1.y, t.norm1.z);
            GL11.glVertex3f(t.p1.pos.x, t.p1.pos.y, t.p1.pos.z);
            GL11.glTexCoord2f(t.uvw2.x, t.uvw2.y);
            GL11.glNormal3f(t.norm2.x, t.norm2.y, t.norm2.z);
            GL11.glVertex3f(t.p2.pos.x, t.p2.pos.y, t.p2.pos.z);
            GL11.glTexCoord2f(t.uvw3.x, t.uvw3.y);
            GL11.glNormal3f(t.norm3.x, t.norm3.y, t.norm3.z);
            GL11.glVertex3f(t.p3.pos.x, t.p3.pos.y, t.p3.pos.z);
        }
        GL11.glEnd();
    }
    
    public void render(final DayM_Mesh m) {
        final DayM_Material[] materials = m.materials;
        int currMtl = -1;
        int i = 0;
        i = 0;
        while (i < m.triangles.length) {
            DayM_Triangle t = m.triangles[i];
            currMtl = t.materialID;
            final DayM_Material mtl = (materials != null && materials.length > 0 && currMtl >= 0) ? materials[currMtl] : DayM_Model.defaultMtl;
            mtl.apply();
            GL11.glBindTexture(3553, mtl.textureHandle);
            GL11.glBegin(4);
            while (i < m.triangles.length && (t = m.triangles[i]) != null && currMtl == t.materialID) {
                GL11.glTexCoord2f(t.uvw1.x, t.uvw1.y);
                GL11.glNormal3f(t.norm1.x, t.norm1.y, t.norm1.z);
                GL11.glVertex3f(t.p1.pos.x, t.p1.pos.y, t.p1.pos.z);
                GL11.glTexCoord2f(t.uvw2.x, t.uvw2.y);
                GL11.glNormal3f(t.norm2.x, t.norm2.y, t.norm2.z);
                GL11.glVertex3f(t.p2.pos.x, t.p2.pos.y, t.p2.pos.z);
                GL11.glTexCoord2f(t.uvw3.x, t.uvw3.y);
                GL11.glNormal3f(t.norm3.x, t.norm3.y, t.norm3.z);
                GL11.glVertex3f(t.p3.pos.x, t.p3.pos.y, t.p3.pos.z);
                ++i;
            }
            GL11.glEnd();
        }
    }
    
    public void renderMeshNormals() {
        GL11.glDisable(2896);
        GL11.glColor3f(0.0f, 1.0f, 0.0f);
        GL11.glBegin(1);
        for (int j = 0; j < this.mesh.triangles.length; ++j) {
            final DayM_Triangle t = this.mesh.triangles[j];
            t.norm1.normalize();
            t.norm2.normalize();
            t.norm3.normalize();
            GL11.glVertex3f(t.p1.pos.x, t.p1.pos.y, t.p1.pos.z);
            GL11.glVertex3f(t.p1.pos.x + t.norm1.x, t.p1.pos.y + t.norm1.y, t.p1.pos.z + t.norm1.z);
            GL11.glVertex3f(t.p2.pos.x, t.p2.pos.y, t.p2.pos.z);
            GL11.glVertex3f(t.p2.pos.x + t.norm2.x, t.p2.pos.y + t.norm2.y, t.p2.pos.z + t.norm2.z);
            GL11.glVertex3f(t.p3.pos.x, t.p3.pos.y, t.p3.pos.z);
            GL11.glVertex3f(t.p3.pos.x + t.norm3.x, t.p3.pos.y + t.norm3.y, t.p3.pos.z + t.norm3.z);
        }
        GL11.glEnd();
        GL11.glEnable(2896);
    }
    
    static {
        DayM_Model.defaultMtl = new DayM_Material();
    }
}
