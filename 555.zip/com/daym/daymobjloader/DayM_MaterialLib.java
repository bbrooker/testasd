package com.daym.daymobjloader;

import java.util.*;
import java.io.*;

public class DayM_MaterialLib
{
    public String filepath;
    public String filename;
    DayM_Material[] materials;
    
    public DayM_MaterialLib(final String mtlFilename) {
        this.filepath = "";
        this.filename = "";
        if (mtlFilename != null && mtlFilename.length() > 0) {
            this.materials = this.loadMaterials(mtlFilename);
        }
    }
    
    public DayM_Material[] loadMaterials(final String mtlFilename) {
        DayM_Material[] mtls = null;
        final String[] pathParts = DayM_App.getPathAndFile(mtlFilename);
        this.filepath = pathParts[0];
        this.filename = pathParts[1];
        try {
            mtls = this.loadMaterials(new BufferedReader(new InputStreamReader(DayM_App.getInputStream(mtlFilename))));
        }
        catch (Exception ex) {}
        return mtls;
    }
    
    public DayM_Material[] loadMaterials(final BufferedReader br) {
        final ArrayList mtlslist = new ArrayList();
        DayM_Material material = null;
        String line = "";
        try {
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.length() > 0) {
                    if (line.startsWith("#")) {
                        continue;
                    }
                    if (line.startsWith("newmtl")) {
                        material = new DayM_Material();
                        material.setName(line.substring(7));
                        mtlslist.add(material);
                    }
                    else if (line.startsWith("Kd")) {
                        final float[] rgb;
                        if ((rgb = this.read3Floats(line)) == null) {
                            continue;
                        }
                        material.setDiffuse(rgb);
                    }
                    else if (line.startsWith("Ka")) {
                        final float[] rgb;
                        if ((rgb = this.read3Floats(line)) == null) {
                            continue;
                        }
                        material.setAmbient(rgb);
                    }
                    else if (line.startsWith("Ks")) {
                        final float[] rgb;
                        if ((rgb = this.read3Floats(line)) == null) {
                            continue;
                        }
                        material.setSpecular(rgb);
                    }
                    else if (line.startsWith("Ns")) {
                        final float[] rgb;
                        if ((rgb = this.read3Floats(line)) == null) {
                            continue;
                        }
                        final int shininessValue = (int)(rgb[0] / 1000.0f * 127.0f);
                        material.setShininess(shininessValue);
                    }
                    else if (line.startsWith("d")) {
                        final float[] rgb;
                        if ((rgb = this.read3Floats(line)) == null) {
                            continue;
                        }
                        material.setAlpha(rgb[0]);
                    }
                    else if (line.startsWith("illum")) {
                        final float[] rgb;
                        if ((rgb = this.read3Floats(line)) != null) {
                            continue;
                        }
                        continue;
                    }
                    else {
                        if (!line.startsWith("map_Kd")) {
                            continue;
                        }
                        final String textureFile = line.substring(7);
                        if (textureFile == null || textureFile.equals("")) {
                            continue;
                        }
                        int textureHandle = 0;
                        try {
                            textureHandle = DayM_App.makeTexture(this.filepath + textureFile);
                        }
                        catch (Exception ex) {}
                        material.setTextureFile(textureFile);
                        material.setTexture(textureHandle);
                    }
                }
            }
        }
        catch (Exception ex2) {}
        final DayM_Material[] mtls = new DayM_Material[mtlslist.size()];
        mtlslist.toArray(mtls);
        return mtls;
    }
    
    private float[] read3Floats(final String line) {
        try {
            final StringTokenizer st = new StringTokenizer(line, " ");
            st.nextToken();
            if (st.countTokens() == 1) {
                return new float[] { Float.parseFloat(st.nextToken()), 0.0f, 0.0f, 0.0f };
            }
            if (st.countTokens() == 3) {
                return new float[] { Float.parseFloat(st.nextToken()), Float.parseFloat(st.nextToken()), Float.parseFloat(st.nextToken()), 1.0f };
            }
        }
        catch (Exception ex) {}
        return null;
    }
    
    public void writeLibe(final DayM_Material[] mtls, final String filename) {
        try {
            final PrintWriter mtlfile = new PrintWriter(new FileWriter(filename));
            this.writeLibe(mtls, mtlfile);
            mtlfile.close();
        }
        catch (IOException ex) {}
    }
    
    public void writeLibe(final DayM_Material[] mtls, final PrintWriter out) {
        if (out != null) {
            out.println("#");
            out.println("# Wavefront material file for use with OBJ file");
            out.println("# Created by DayM_MaterialLib.java");
            out.println("#");
            out.println("");
            for (int i = 0; i < mtls.length; ++i) {
                this.write(out, mtls[i]);
            }
        }
    }
    
    public void write(final PrintWriter out, final DayM_Material mtl) {
        if (out != null) {
            out.println("newmtl " + mtl.mtlname);
            out.println("Ka " + mtl.ambient.get(0) + " " + mtl.ambient.get(1) + " " + mtl.ambient.get(2));
            out.println("Kd " + mtl.diffuse.get(0) + " " + mtl.diffuse.get(1) + " " + mtl.diffuse.get(2));
            out.println("Ks " + mtl.specular.get(0) + " " + mtl.specular.get(1) + " " + mtl.specular.get(2));
            out.println("Ns " + mtl.shininess.get(0) / 128.0 * 1000.0);
            if (mtl.textureFile != null && !mtl.textureFile.equals("")) {
                out.println("map_Kd " + mtl.textureFile);
            }
            if (mtl.getAlpha() != 1.0f) {
                out.println("d " + mtl.getAlpha());
            }
            out.println("");
        }
    }
    
    public DayM_Material getClone(final DayM_Material mtl) {
        final DayM_Material clone = new DayM_Material();
        clone.setDiffuse(new float[] { mtl.diffuse.get(0), mtl.diffuse.get(1), mtl.diffuse.get(2), mtl.diffuse.get(3) });
        clone.setAmbient(new float[] { mtl.ambient.get(0), mtl.ambient.get(1), mtl.ambient.get(2), mtl.ambient.get(3) });
        clone.setSpecular(new float[] { mtl.specular.get(0), mtl.specular.get(1), mtl.specular.get(2), mtl.specular.get(3) });
        clone.setGlowColor(new float[] { mtl.emission.get(0), mtl.emission.get(1), mtl.emission.get(2), mtl.emission.get(3) });
        clone.setShininess(mtl.shininess.get(0));
        clone.textureFile = mtl.textureFile;
        clone.textureHandle = mtl.textureHandle;
        clone.setName(mtl.mtlname + "-copy");
        return clone;
    }
    
    public DayM_Material find(final String materialName) {
        final int mtl_idx = this.findID(materialName);
        if (mtl_idx >= 0) {
            return this.materials[mtl_idx];
        }
        return null;
    }
    
    public int findID(final String materialName) {
        if (this.materials != null && materialName != null) {
            for (int m = 0; m < this.materials.length; ++m) {
                if (this.materials[m].mtlname.equals(materialName)) {
                    return m;
                }
            }
        }
        return -1;
    }
}
