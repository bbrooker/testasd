package com.daym.daymobjloader;

public class DayM_Vector
{
    public float x;
    public float y;
    public float z;
    
    public DayM_Vector() {
        this.x = 0.0f;
        this.y = 0.0f;
        this.z = 0.0f;
    }
    
    public DayM_Vector(final float xpos, final float ypos, final float zpos) {
        this.x = 0.0f;
        this.y = 0.0f;
        this.z = 0.0f;
        this.x = xpos;
        this.y = ypos;
        this.z = zpos;
    }
    
    public DayM_Vector(final float[] float3) {
        this.x = 0.0f;
        this.y = 0.0f;
        this.z = 0.0f;
        this.x = float3[0];
        this.y = float3[1];
        this.z = float3[2];
    }
    
    public DayM_Vector(final DayM_Vector v) {
        this.x = 0.0f;
        this.y = 0.0f;
        this.z = 0.0f;
        this.x = v.x;
        this.y = v.y;
        this.z = v.z;
    }
    
    public DayM_Vector(final DayM_Vector point1, final DayM_Vector point2) {
        this.x = 0.0f;
        this.y = 0.0f;
        this.z = 0.0f;
        this.x = point1.x - point2.x;
        this.y = point1.y - point2.y;
        this.z = point1.z - point2.z;
    }
    
    public DayM_Vector add(final DayM_Vector v) {
        this.x += v.x;
        this.y += v.y;
        this.z += v.z;
        return this;
    }
    
    public DayM_Vector sub(final DayM_Vector v) {
        this.x -= v.x;
        this.y -= v.y;
        this.z -= v.z;
        return this;
    }
    
    public DayM_Vector mult(final DayM_Vector v) {
        this.x *= v.x;
        this.y *= v.y;
        this.z *= v.z;
        return this;
    }
    
    public DayM_Vector div(final DayM_Vector v) {
        this.x /= v.x;
        this.y /= v.y;
        this.z /= v.z;
        return this;
    }
    
    public DayM_Vector add(final float n) {
        this.x += n;
        this.y += n;
        this.z += n;
        return this;
    }
    
    public DayM_Vector sub(final float n) {
        this.x -= n;
        this.y -= n;
        this.z -= n;
        return this;
    }
    
    public DayM_Vector mult(final float n) {
        this.x *= n;
        this.y *= n;
        this.z *= n;
        return this;
    }
    
    public DayM_Vector div(final float n) {
        this.x /= n;
        this.y /= n;
        this.z /= n;
        return this;
    }
    
    public DayM_Vector normalize() {
        final float len = this.length();
        if (len == 0.0f) {
            return this;
        }
        final float invlen = 1.0f / len;
        this.x *= invlen;
        this.y *= invlen;
        this.z *= invlen;
        return this;
    }
    
    public DayM_Vector reverse() {
        this.x = -this.x;
        this.y = -this.y;
        this.z = -this.z;
        return this;
    }
    
    public float length() {
        return (float)Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
    }
    
    @Override
    public String toString() {
        return new String("<vector x=" + this.x + " y=" + this.y + " z=" + this.z + ">");
    }
    
    public DayM_Vector getClone() {
        return new DayM_Vector(this.x, this.y, this.z);
    }
    
    public boolean equals(final DayM_Vector v) {
        return v.x == this.x && v.y == this.y && v.z == this.z;
    }
    
    public static DayM_Vector add(final DayM_Vector a, final DayM_Vector b) {
        return new DayM_Vector(a.x + b.x, a.y + b.y, a.z + b.z);
    }
    
    public static DayM_Vector sub(final DayM_Vector a, final DayM_Vector b) {
        return new DayM_Vector(a.x - b.x, a.y - b.y, a.z - b.z);
    }
    
    public static DayM_Vector mult(final DayM_Vector a, final DayM_Vector b) {
        return new DayM_Vector(a.x * b.x, a.y * b.y, a.z * b.z);
    }
    
    public static DayM_Vector div(final DayM_Vector a, final DayM_Vector b) {
        return new DayM_Vector(a.x / b.x, a.y / b.y, a.z / b.z);
    }
    
    public static DayM_Vector multiply(final DayM_Vector v, final float r) {
        return new DayM_Vector(v.x * r, v.y * r, v.z * r);
    }
    
    public static DayM_Vector scale(final DayM_Vector a, final float f) {
        return new DayM_Vector(f * a.x, f * a.y, f * a.z);
    }
    
    public static float length(final DayM_Vector a) {
        return (float)Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z);
    }
    
    public static float dotProduct(final DayM_Vector u, final DayM_Vector v) {
        return u.x * v.x + u.y * v.y + u.z * v.z;
    }
    
    public static DayM_Vector normalize(final DayM_Vector v) {
        final float len = v.length();
        if (len == 0.0f) {
            return v;
        }
        final float invlen = 1.0f / len;
        return new DayM_Vector(v.x * invlen, v.y * invlen, v.z * invlen);
    }
    
    public static DayM_Vector crossProduct(final DayM_Vector a, final DayM_Vector b) {
        return vectorProduct(a, b).normalize();
    }
    
    public static DayM_Vector getNormal(final DayM_Vector a, final DayM_Vector b) {
        return vectorProduct(a, b).normalize();
    }
    
    public static DayM_Vector getNormal(final DayM_Vector a, final DayM_Vector b, final DayM_Vector c) {
        return vectorProduct(a, b, c).normalize();
    }
    
    public static DayM_Vector vectorProduct(final DayM_Vector a, final DayM_Vector b) {
        return new DayM_Vector(a.y * b.z - b.y * a.z, a.z * b.x - b.z * a.x, a.x * b.y - b.x * a.y);
    }
    
    public static DayM_Vector vectorProduct(final DayM_Vector a, final DayM_Vector b, final DayM_Vector c) {
        return vectorProduct(sub(b, a), sub(c, a));
    }
    
    public static float angle(final DayM_Vector a, final DayM_Vector b) {
        a.normalize();
        b.normalize();
        return a.x * b.x + a.y * b.y + a.z * b.z;
    }
    
    public static float angleXZ(final DayM_Vector a, final DayM_Vector b) {
        a.normalize();
        b.normalize();
        return (float)((Math.atan2(a.x * b.z - b.x * a.z, a.x * b.x + a.z * b.z) + 3.141592653589793) * 0.01745329238474369);
    }
    
    public static float angleXY(final DayM_Vector a, final DayM_Vector b) {
        a.normalize();
        b.normalize();
        return (float)((Math.atan2(a.x * b.y - b.x * a.y, a.x * b.x + a.y * b.y) + 3.141592653589793) * 57.295780181884766);
    }
    
    public static DayM_Vector rotationVector(final float degrees) {
        return new DayM_Vector((float)Math.sin(degrees * 0.017453292f), 0.0f, (float)Math.cos(degrees * 0.017453292f));
    }
}
