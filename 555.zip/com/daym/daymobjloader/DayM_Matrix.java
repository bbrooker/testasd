package com.daym.daymobjloader;

import java.nio.*;

public class DayM_Matrix
{
    public float m00;
    public float m01;
    public float m02;
    public float m03;
    public float m10;
    public float m11;
    public float m12;
    public float m13;
    public float m20;
    public float m21;
    public float m22;
    public float m23;
    public float m30;
    public float m31;
    public float m32;
    public float m33;
    
    public DayM_Matrix() {
        this.m00 = 1.0f;
        this.m01 = 0.0f;
        this.m02 = 0.0f;
        this.m03 = 0.0f;
        this.m10 = 0.0f;
        this.m11 = 1.0f;
        this.m12 = 0.0f;
        this.m13 = 0.0f;
        this.m20 = 0.0f;
        this.m21 = 0.0f;
        this.m22 = 1.0f;
        this.m23 = 0.0f;
        this.m30 = 0.0f;
        this.m31 = 0.0f;
        this.m32 = 0.0f;
        this.m33 = 1.0f;
    }
    
    public DayM_Matrix(final DayM_Vector right, final DayM_Vector up, final DayM_Vector forward) {
        this.m00 = 1.0f;
        this.m01 = 0.0f;
        this.m02 = 0.0f;
        this.m03 = 0.0f;
        this.m10 = 0.0f;
        this.m11 = 1.0f;
        this.m12 = 0.0f;
        this.m13 = 0.0f;
        this.m20 = 0.0f;
        this.m21 = 0.0f;
        this.m22 = 1.0f;
        this.m23 = 0.0f;
        this.m30 = 0.0f;
        this.m31 = 0.0f;
        this.m32 = 0.0f;
        this.m33 = 1.0f;
        this.m00 = right.x;
        this.m10 = right.y;
        this.m20 = right.z;
        this.m01 = up.x;
        this.m11 = up.y;
        this.m21 = up.z;
        this.m02 = forward.x;
        this.m12 = forward.y;
        this.m22 = forward.z;
    }
    
    public void importFromArray(final float[][] data) {
        if (data.length < 4) {
            return;
        }
        for (int i = 0; i < 4; ++i) {
            if (data[i].length < 4) {
                return;
            }
        }
        this.m00 = data[0][0];
        this.m01 = data[0][1];
        this.m02 = data[0][2];
        this.m03 = data[0][3];
        this.m10 = data[1][0];
        this.m11 = data[1][1];
        this.m12 = data[1][2];
        this.m13 = data[1][3];
        this.m20 = data[2][0];
        this.m21 = data[2][1];
        this.m22 = data[2][2];
        this.m23 = data[2][3];
        this.m30 = data[3][0];
        this.m31 = data[3][1];
        this.m32 = data[3][2];
        this.m33 = data[3][3];
    }
    
    public float[][] exportToArray() {
        final float[][] data = new float[4][4];
        data[0][0] = this.m00;
        data[0][1] = this.m01;
        data[0][2] = this.m02;
        data[0][3] = this.m03;
        data[1][0] = this.m10;
        data[1][1] = this.m11;
        data[1][2] = this.m12;
        data[1][3] = this.m13;
        data[2][0] = this.m20;
        data[2][1] = this.m21;
        data[2][2] = this.m22;
        data[2][3] = this.m23;
        data[3][0] = this.m30;
        data[3][1] = this.m31;
        data[3][2] = this.m32;
        data[3][3] = this.m33;
        return data;
    }
    
    public static DayM_Matrix translateMatrix(final float dx, final float dy, final float dz) {
        final DayM_Matrix m = new DayM_Matrix();
        m.m03 = dx;
        m.m13 = dy;
        m.m23 = dz;
        return m;
    }
    
    public static DayM_Matrix scaleMatrix(final float dx, final float dy, final float dz) {
        final DayM_Matrix m = new DayM_Matrix();
        m.m00 = dx;
        m.m11 = dy;
        m.m22 = dz;
        return m;
    }
    
    public static DayM_Matrix scaleMatrix(final float d) {
        return scaleMatrix(d, d, d);
    }
    
    public static DayM_Matrix rotateMatrix(final float dx, final float dy, final float dz) {
        final DayM_Matrix out = new DayM_Matrix();
        if (dx != 0.0f) {
            final DayM_Matrix m = new DayM_Matrix();
            final float SIN = (float)Math.sin(dx);
            final float COS = (float)Math.cos(dx);
            m.m11 = COS;
            m.m12 = SIN;
            m.m21 = -SIN;
            m.m22 = COS;
            out.transform(m);
        }
        if (dy != 0.0f) {
            final DayM_Matrix m = new DayM_Matrix();
            final float SIN = (float)Math.sin(dy);
            final float COS = (float)Math.cos(dy);
            m.m00 = COS;
            m.m02 = SIN;
            m.m20 = -SIN;
            m.m22 = COS;
            out.transform(m);
        }
        if (dz != 0.0f) {
            final DayM_Matrix m = new DayM_Matrix();
            final float SIN = (float)Math.sin(dz);
            final float COS = (float)Math.cos(dz);
            m.m00 = COS;
            m.m01 = SIN;
            m.m10 = -SIN;
            m.m11 = COS;
            out.transform(m);
        }
        return out;
    }
    
    public void translate(final float dx, final float dy, final float dz) {
        this.transform(translateMatrix(dx, dy, dz));
    }
    
    public void scale(final float dx, final float dy, final float dz) {
        this.transform(scaleMatrix(dx, dy, dz));
    }
    
    public void scale(final float d) {
        this.transform(scaleMatrix(d));
    }
    
    public void rotate(final float dx, final float dy, final float dz) {
        this.transform(rotateMatrix(dx, dy, dz));
    }
    
    public void scaleSelf(final float dx, final float dy, final float dz) {
        this.preTransform(scaleMatrix(dx, dy, dz));
    }
    
    public void scaleSelf(final float d) {
        this.preTransform(scaleMatrix(d));
    }
    
    public void rotateSelf(final float dx, final float dy, final float dz) {
        this.preTransform(rotateMatrix(dx, dy, dz));
    }
    
    public void reset() {
        this.m00 = 1.0f;
        this.m01 = 0.0f;
        this.m02 = 0.0f;
        this.m03 = 0.0f;
        this.m10 = 0.0f;
        this.m11 = 1.0f;
        this.m12 = 0.0f;
        this.m13 = 0.0f;
        this.m20 = 0.0f;
        this.m21 = 0.0f;
        this.m22 = 1.0f;
        this.m23 = 0.0f;
        this.m30 = 0.0f;
        this.m31 = 0.0f;
        this.m32 = 0.0f;
        this.m33 = 1.0f;
    }
    
    public DayM_Vector transform(final DayM_Vector v) {
        if (v != null) {
            final float newx = v.x * this.m00 + v.y * this.m01 + v.z * this.m02 + this.m03;
            final float newy = v.x * this.m10 + v.y * this.m11 + v.z * this.m12 + this.m13;
            final float newz = v.x * this.m20 + v.y * this.m21 + v.z * this.m22 + this.m23;
            return new DayM_Vector(newx, newy, newz);
        }
        return null;
    }
    
    public void transform(final DayM_Matrix n) {
        final DayM_Matrix m = this.getClone();
        this.m00 = n.m00 * m.m00 + n.m01 * m.m10 + n.m02 * m.m20;
        this.m01 = n.m00 * m.m01 + n.m01 * m.m11 + n.m02 * m.m21;
        this.m02 = n.m00 * m.m02 + n.m01 * m.m12 + n.m02 * m.m22;
        this.m03 = n.m00 * m.m03 + n.m01 * m.m13 + n.m02 * m.m23 + n.m03;
        this.m10 = n.m10 * m.m00 + n.m11 * m.m10 + n.m12 * m.m20;
        this.m11 = n.m10 * m.m01 + n.m11 * m.m11 + n.m12 * m.m21;
        this.m12 = n.m10 * m.m02 + n.m11 * m.m12 + n.m12 * m.m22;
        this.m13 = n.m10 * m.m03 + n.m11 * m.m13 + n.m12 * m.m23 + n.m13;
        this.m20 = n.m20 * m.m00 + n.m21 * m.m10 + n.m22 * m.m20;
        this.m21 = n.m20 * m.m01 + n.m21 * m.m11 + n.m22 * m.m21;
        this.m22 = n.m20 * m.m02 + n.m21 * m.m12 + n.m22 * m.m22;
        this.m23 = n.m20 * m.m03 + n.m21 * m.m13 + n.m22 * m.m23 + n.m23;
    }
    
    public void preTransform(final DayM_Matrix n) {
        final DayM_Matrix m = this.getClone();
        this.m00 = m.m00 * n.m00 + m.m01 * n.m10 + m.m02 * n.m20;
        this.m01 = m.m00 * n.m01 + m.m01 * n.m11 + m.m02 * n.m21;
        this.m02 = m.m00 * n.m02 + m.m01 * n.m12 + m.m02 * n.m22;
        this.m03 = m.m00 * n.m03 + m.m01 * n.m13 + m.m02 * n.m23 + m.m03;
        this.m10 = m.m10 * n.m00 + m.m11 * n.m10 + m.m12 * n.m20;
        this.m11 = m.m10 * n.m01 + m.m11 * n.m11 + m.m12 * n.m21;
        this.m12 = m.m10 * n.m02 + m.m11 * n.m12 + m.m12 * n.m22;
        this.m13 = m.m10 * n.m03 + m.m11 * n.m13 + m.m12 * n.m23 + m.m13;
        this.m20 = m.m20 * n.m00 + m.m21 * n.m10 + m.m22 * n.m20;
        this.m21 = m.m20 * n.m01 + m.m21 * n.m11 + m.m22 * n.m21;
        this.m22 = m.m20 * n.m02 + m.m21 * n.m12 + m.m22 * n.m22;
        this.m23 = m.m20 * n.m03 + m.m21 * n.m13 + m.m22 * n.m23 + m.m23;
    }
    
    public static DayM_Matrix multiply(final DayM_Matrix m1, final DayM_Matrix m2) {
        final DayM_Matrix i = new DayM_Matrix();
        i.m00 = m1.m00 * m2.m00 + m1.m01 * m2.m10 + m1.m02 * m2.m20;
        i.m01 = m1.m00 * m2.m01 + m1.m01 * m2.m11 + m1.m02 * m2.m21;
        i.m02 = m1.m00 * m2.m02 + m1.m01 * m2.m12 + m1.m02 * m2.m22;
        i.m03 = m1.m00 * m2.m03 + m1.m01 * m2.m13 + m1.m02 * m2.m23 + m1.m03;
        i.m10 = m1.m10 * m2.m00 + m1.m11 * m2.m10 + m1.m12 * m2.m20;
        i.m11 = m1.m10 * m2.m01 + m1.m11 * m2.m11 + m1.m12 * m2.m21;
        i.m12 = m1.m10 * m2.m02 + m1.m11 * m2.m12 + m1.m12 * m2.m22;
        i.m13 = m1.m10 * m2.m03 + m1.m11 * m2.m13 + m1.m12 * m2.m23 + m1.m13;
        i.m20 = m1.m20 * m2.m00 + m1.m21 * m2.m10 + m1.m22 * m2.m20;
        i.m21 = m1.m20 * m2.m01 + m1.m21 * m2.m11 + m1.m22 * m2.m21;
        i.m22 = m1.m20 * m2.m02 + m1.m21 * m2.m12 + m1.m22 * m2.m22;
        i.m23 = m1.m20 * m2.m03 + m1.m21 * m2.m13 + m1.m22 * m2.m23 + m1.m23;
        return i;
    }
    
    @Override
    public String toString() {
        final StringBuffer out = new StringBuffer("<Matrix: \r\n");
        out.append(this.m00 + "," + this.m01 + "," + this.m02 + "," + this.m03 + ",\r\n");
        out.append(this.m10 + "," + this.m11 + "," + this.m12 + "," + this.m13 + ",\r\n");
        out.append(this.m20 + "," + this.m21 + "," + this.m22 + "," + this.m23 + ",\r\n");
        out.append(this.m30 + "," + this.m31 + "," + this.m32 + "," + this.m33 + ">\r\n");
        return out.toString();
    }
    
    public DayM_Matrix getClone() {
        final DayM_Matrix m = new DayM_Matrix();
        m.m00 = this.m00;
        m.m01 = this.m01;
        m.m02 = this.m02;
        m.m03 = this.m03;
        m.m10 = this.m10;
        m.m11 = this.m11;
        m.m12 = this.m12;
        m.m13 = this.m13;
        m.m20 = this.m20;
        m.m21 = this.m21;
        m.m22 = this.m22;
        m.m23 = this.m23;
        m.m30 = this.m30;
        m.m31 = this.m31;
        m.m32 = this.m32;
        m.m33 = this.m33;
        return m;
    }
    
    public DayM_Matrix inverse() {
        final DayM_Matrix m = new DayM_Matrix();
        final float q1 = this.m12;
        final float q2 = this.m10 * this.m01;
        final float q3 = this.m10 * this.m21;
        final float q4 = this.m02;
        final float q5 = this.m20 * this.m01;
        final float q6 = this.m20 * this.m11;
        final float q7 = this.m02 * this.m21;
        final float q8 = this.m03 * this.m21;
        final float q9 = this.m01 * this.m12;
        final float q10 = this.m01 * this.m13;
        final float q11 = this.m02 * this.m11;
        final float q12 = this.m03 * this.m11;
        final float q13 = this.m10 * this.m22;
        final float q14 = this.m10 * this.m23;
        final float q15 = this.m20 * this.m12;
        final float q16 = this.m20 * this.m13;
        final float q17 = this.m00 * this.m22;
        final float q18 = this.m00 * this.m23;
        final float q19 = this.m20 * this.m02;
        final float q20 = this.m20 * this.m03;
        final float q21 = this.m00 * this.m12;
        final float q22 = this.m00 * this.m13;
        final float q23 = this.m10 * this.m02;
        final float q24 = this.m10 * this.m03;
        final float q25 = this.m00 * this.m11;
        final float q26 = this.m00 * this.m21;
        final float q27 = q25 * this.m22 - q26 * q1 - q2 * this.m22 + q3 * q4;
        final float q28 = q5 * q1 - q6 * q4;
        final float q29 = 1.0f / (q27 + q28);
        m.m00 = (this.m11 * this.m22 * this.m33 - this.m11 * this.m23 * this.m32 - this.m21 * this.m12 * this.m33 + this.m21 * this.m13 * this.m32 + this.m31 * this.m12 * this.m23 - this.m31 * this.m13 * this.m22) * q29;
        m.m01 = -(this.m01 * this.m22 * this.m33 - this.m01 * this.m23 * this.m32 - q7 * this.m33 + q8 * this.m32) * q29;
        m.m02 = (q9 * this.m33 - q10 * this.m32 - q11 * this.m33 + q12 * this.m32) * q29;
        m.m03 = -(q9 * this.m23 - q10 * this.m22 - q11 * this.m23 + q12 * this.m22 + q7 * this.m13 - q8 * this.m12) * q29;
        m.m10 = -(q13 * this.m33 - q14 * this.m32 - q15 * this.m33 + q16 * this.m32) * q29;
        m.m11 = (q17 * this.m33 - q18 * this.m32 - q19 * this.m33 + q20 * this.m32) * q29;
        m.m12 = -(q21 * this.m33 - q22 * this.m32 - q23 * this.m33 + q24 * this.m32) * q29;
        m.m13 = (q21 * this.m23 - q22 * this.m22 - q23 * this.m23 + q24 * this.m22 + q19 * this.m13 - q20 * this.m12) * q29;
        m.m20 = (q3 * this.m33 - q14 * this.m31 - q6 * this.m33 + q16 * this.m31) * q29;
        m.m21 = -(q26 * this.m33 - q18 * this.m31 - q5 * this.m33 + q20 * this.m31) * q29;
        m.m22 = (q25 * this.m33 - q22 * this.m31 - q2 * this.m33 + q24 * this.m31) * q29;
        m.m23 = -(q25 * this.m23 - q22 * this.m21 - q2 * this.m23 + q24 * this.m21 + q5 * this.m13 - q20 * this.m11) * q29;
        return m;
    }
    
    public static void createBillboardMatrix(final FloatBuffer matrix, final DayM_Vector right, final DayM_Vector up, final DayM_Vector look, final DayM_Vector pos) {
        matrix.put(0, right.x);
        matrix.put(1, right.y);
        matrix.put(2, right.z);
        matrix.put(3, 0.0f);
        matrix.put(4, up.x);
        matrix.put(5, up.y);
        matrix.put(6, up.z);
        matrix.put(7, 0.0f);
        matrix.put(8, look.x);
        matrix.put(9, look.y);
        matrix.put(10, look.z);
        matrix.put(11, 0.0f);
        matrix.put(12, pos.x);
        matrix.put(13, pos.y);
        matrix.put(14, pos.z);
        matrix.put(15, 1.0f);
    }
}
