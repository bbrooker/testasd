package com.daym.daymobjloader;

import java.util.*;

public class DayM_Triangle
{
    public DayM_Vertex p1;
    public DayM_Vertex p2;
    public DayM_Vertex p3;
    public DayM_Vector norm1;
    public DayM_Vector norm2;
    public DayM_Vector norm3;
    public DayM_Vector uvw1;
    public DayM_Vector uvw2;
    public DayM_Vector uvw3;
    public ArrayList neighborsP1;
    public ArrayList neighborsP2;
    public ArrayList neighborsP3;
    public DayM_Vector n;
    public float Zdepth;
    public int ID;
    public int groupID;
    int materialID;
    
    public DayM_Triangle(final DayM_Vertex a, final DayM_Vertex b, final DayM_Vertex c) {
        this.uvw1 = new DayM_Vector();
        this.uvw2 = new DayM_Vector();
        this.uvw3 = new DayM_Vector();
        this.neighborsP1 = new ArrayList();
        this.neighborsP2 = new ArrayList();
        this.neighborsP3 = new ArrayList();
        this.n = new DayM_Vector();
        this.Zdepth = 0.0f;
        this.ID = 0;
        this.groupID = 0;
        this.p1 = a;
        this.p2 = b;
        this.p3 = c;
    }
    
    public void recalcFaceNormal() {
        this.n = DayM_Vector.getNormal(this.p1.pos, this.p2.pos, this.p3.pos);
    }
    
    public DayM_Vector recalcVertexNormal(final ArrayList neighbors) {
        float nx = 0.0f;
        float ny = 0.0f;
        float nz = 0.0f;
        DayM_Vector wn = new DayM_Vector();
        for (int i = 0; i < neighbors.size(); ++i) {
            final DayM_Triangle tri = neighbors.get(i);
            wn = tri.getWeightedNormal();
            nx += wn.x;
            ny += wn.y;
            nz += wn.z;
        }
        final DayM_Vector vertn = new DayM_Vector(nx, ny, nz);
        vertn.normalize();
        return vertn;
    }
    
    public DayM_Vector getWeightedNormal() {
        return DayM_Vector.vectorProduct(this.p1.pos, this.p2.pos, this.p3.pos);
    }
    
    public DayM_Vector getCenter() {
        final float cx = (this.p1.pos.x + this.p2.pos.x + this.p3.pos.x) / 3.0f;
        final float cy = (this.p1.pos.y + this.p2.pos.y + this.p3.pos.y) / 3.0f;
        final float cz = (this.p1.pos.z + this.p2.pos.z + this.p3.pos.z) / 3.0f;
        return new DayM_Vector(cx, cy, cz);
    }
    
    public void resetNeighbors() {
        this.neighborsP1.clear();
        this.neighborsP2.clear();
        this.neighborsP3.clear();
    }
    
    public void calcZdepth() {
        this.Zdepth = (this.p1.posS.z + this.p2.posS.z + this.p3.posS.z) / 3.0f;
    }
    
    public static boolean onSameSurface(final DayM_Triangle t1, final DayM_Triangle t2, final float cos_angle) {
        final float dot = DayM_Vector.dotProduct(t1.n, t2.n);
        return dot > cos_angle;
    }
    
    public DayM_Triangle makeClone() {
        final DayM_Triangle clone = new DayM_Triangle(this.p1.makeClone(), this.p2.makeClone(), this.p3.makeClone());
        clone.norm1 = this.norm1.getClone();
        clone.norm2 = this.norm2.getClone();
        clone.norm3 = this.norm3.getClone();
        clone.uvw1 = this.uvw1.getClone();
        clone.uvw2 = this.uvw2.getClone();
        clone.uvw3 = this.uvw3.getClone();
        clone.neighborsP1 = (ArrayList)this.neighborsP1.clone();
        clone.neighborsP2 = (ArrayList)this.neighborsP2.clone();
        clone.neighborsP3 = (ArrayList)this.neighborsP3.clone();
        return clone;
    }
}
