package com.daym.daymobjloader;

import java.util.*;
import java.io.*;

public class DayM_3DS_Reader
{
    public ArrayList vertices;
    public ArrayList normals;
    public ArrayList textureCoords;
    public ArrayList faces;
    private int currentId;
    private int nextOffset;
    private String currentObjectName;
    private boolean endOfStream;
    
    public DayM_3DS_Reader() {
        this.vertices = new ArrayList();
        this.normals = new ArrayList();
        this.textureCoords = new ArrayList();
        this.faces = new ArrayList();
        this.currentObjectName = null;
        this.endOfStream = false;
    }
    
    public DayM_3DS_Reader(final String filename) {
        this.vertices = new ArrayList();
        this.normals = new ArrayList();
        this.textureCoords = new ArrayList();
        this.faces = new ArrayList();
        this.currentObjectName = null;
        this.endOfStream = false;
        this.loadobject(filename);
    }
    
    public void loadobject(final String filename) {
        try {
            this.load3DSFromStream(DayM_App.getInputStream(filename));
        }
        catch (Exception e) {
            System.out.println("DayM_3DS_Reader.loadobject(): Exception when reading file: " + filename + " " + e);
        }
    }
    
    public boolean load3DSFromStream(final InputStream inStream) {
        System.out.println(">> Importing from 3DS stream ...");
        final BufferedInputStream in = new BufferedInputStream(inStream);
        try {
            this.readHeader(in);
            if (this.currentId != 19789) {
                System.out.println("Error: This is not a valid 3ds file.");
                return false;
            }
            while (!this.endOfStream) {
                this.readNext(in);
            }
        }
        catch (Throwable t) {}
        return true;
    }
    
    private String readString(final InputStream in) throws IOException {
        String result = new String();
        byte inByte;
        while ((inByte = (byte)in.read()) != 0) {
            result += (char)inByte;
        }
        return result;
    }
    
    private int readInt(final InputStream in) throws IOException {
        return in.read() | in.read() << 8 | in.read() << 16 | in.read() << 24;
    }
    
    private int readShort(final InputStream in) throws IOException {
        return in.read() | in.read() << 8;
    }
    
    private float readFloat(final InputStream in) throws IOException {
        return Float.intBitsToFloat(this.readInt(in));
    }
    
    private void readHeader(final InputStream in) throws IOException {
        this.currentId = this.readShort(in);
        this.nextOffset = this.readInt(in);
        this.endOfStream = (this.currentId < 0);
    }
    
    private void readNext(final InputStream in) throws IOException {
        this.readHeader(in);
        if (this.currentId == 15677) {
            return;
        }
        if (this.currentId == 16384) {
            this.currentObjectName = this.readString(in);
            System.out.println("DayM_3DS_Reader: " + this.currentObjectName);
            return;
        }
        if (this.currentId == 16640) {
            System.out.println("DayM_3DS_Reader: start mesh object");
            return;
        }
        if (this.currentId == 16656) {
            System.out.println("DayM_3DS_Reader: read vertex list");
            this.readVertexList(in);
            return;
        }
        if (this.currentId == 16672) {
            System.out.println("DayM_3DS_Reader: read triangle list");
            this.readPointList(in);
            return;
        }
        if (this.currentId == 16704) {
            System.out.println("DayM_3DS_Reader: read mapping coords");
            this.readMappingCoordinates(in);
            return;
        }
        this.skip(in);
    }
    
    private void skip(final InputStream in) throws IOException, OutOfMemoryError {
        for (int i = 0; i < this.nextOffset - 6 && !this.endOfStream; ++i) {
            this.endOfStream = (in.read() < 0);
        }
    }
    
    private void readVertexList(final InputStream in) throws IOException {
        for (int numVertices = this.readShort(in), i = 0; i < numVertices; ++i) {
            final float x = this.readFloat(in);
            float y = this.readFloat(in);
            float z = this.readFloat(in);
            final float tmpy = y;
            y = z;
            z = -tmpy;
            this.vertices.add(new float[] { x, y, z });
        }
    }
    
    private void readPointList(final InputStream in) throws IOException {
        for (int triangles = this.readShort(in), i = 0; i < triangles; ++i) {
            final int[] vertexIDs = { this.readShort(in), this.readShort(in), this.readShort(in) };
            this.readShort(in);
            this.faces.add(new Face(vertexIDs, vertexIDs, null));
        }
    }
    
    private void readMappingCoordinates(final InputStream in) throws IOException {
        for (int numVertices = this.readShort(in), i = 0; i < numVertices; ++i) {
            final float[] uvw = { this.readFloat(in), this.readFloat(in), 0.0f };
            this.textureCoords.add(uvw);
        }
    }
}
