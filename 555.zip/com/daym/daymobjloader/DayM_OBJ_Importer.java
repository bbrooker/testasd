package com.daym.daymobjloader;

import java.io.*;
import java.util.*;

public class DayM_OBJ_Importer
{
    private DayM_OBJ_Reader reader;
    private DayM_Mesh mesh;
    
    public DayM_OBJ_Importer() {
        this.reader = null;
        this.mesh = null;
    }
    
    public DayM_Mesh load(final String filename) {
        this.reader = new DayM_OBJ_Reader(filename);
        return this.makeMeshObject(this.reader);
    }
    
    public DayM_Mesh importFromStream(final InputStream inStream) {
        this.reader = new DayM_OBJ_Reader(inStream);
        return this.makeMeshObject(this.reader);
    }
    
    public DayM_Mesh makeMeshObject(final DayM_OBJ_Reader objData) {
        final ArrayList verts = objData.vertices;
        final ArrayList txtrs = objData.textureCoords;
        final ArrayList norms = objData.normals;
        ArrayList faces = objData.faces;
        this.mesh = new DayM_Mesh();
        this.mesh.name = objData.filename;
        this.mesh.materialLibeName = objData.materialLibeName;
        this.mesh.materials = (DayM_Material[])((objData.materialLib != null) ? objData.materialLib.materials : null);
        for (int i = 0; i < verts.size(); ++i) {
            final float[] coords = verts.get(i);
            this.mesh.addVertex(coords[0], coords[1], coords[2]);
        }
        this.mesh.makeGroups(objData.numGroups());
        for (int g = 0; g < objData.numGroups(); ++g) {
            this.mesh.initGroup(g, objData.getGroupName(g), objData.getGroupMaterialName(g), objData.getGroupTriangleCount(g));
        }
        for (int g = 0; g < objData.numGroups(); ++g) {
            int triCount = 0;
            faces = objData.getGroupFaces(g);
            for (int j = 0; j < faces.size(); ++j) {
                final Face face = faces.get(j);
                if (face.vertexIDs.length == 3) {
                    this.addTriangle(this.mesh, g, triCount, face, txtrs, norms, 0, 1, 2, face.materialID);
                    ++triCount;
                }
                else if (face.vertexIDs.length == 4) {
                    this.addTriangle(this.mesh, g, triCount, face, txtrs, norms, 0, 1, 2, face.materialID);
                    ++triCount;
                    this.addTriangle(this.mesh, g, triCount, face, txtrs, norms, 0, 2, 3, face.materialID);
                    ++triCount;
                }
                else {
                    for (int n = 0; n < face.vertexIDs.length - 2; ++n) {
                        this.addTriangle(this.mesh, g, triCount, face, txtrs, norms, 0, n + 1, n + 2, face.materialID);
                        ++triCount;
                    }
                }
            }
        }
        this.mesh.rebuild();
        if (norms.size() == 0) {
            this.mesh.regenerateNormals();
        }
        return this.mesh;
    }
    
    public DayM_Triangle addTriangle(final DayM_Mesh obj, final int groupNum, final int triNum, final Face face, final ArrayList txtrs, final ArrayList norms, final int v1, final int v2, final int v3, final int mtlID) {
        final DayM_Triangle t = new DayM_Triangle(obj.vertex(face.vertexIDs[v1]), obj.vertex(face.vertexIDs[v2]), obj.vertex(face.vertexIDs[v3]));
        if (txtrs.size() > 0) {
            float[] uvw = txtrs.get(face.textureIDs[v1]);
            t.uvw1 = new DayM_Vector(uvw[0], uvw[1], uvw[2]);
            uvw = txtrs.get(face.textureIDs[v2]);
            t.uvw2 = new DayM_Vector(uvw[0], uvw[1], uvw[2]);
            uvw = txtrs.get(face.textureIDs[v3]);
            t.uvw3 = new DayM_Vector(uvw[0], uvw[1], uvw[2]);
        }
        if (norms.size() > 0) {
            float[] norm = norms.get(face.normalIDs[v1]);
            t.norm1 = new DayM_Vector(norm[0], norm[1], norm[2]);
            norm = norms.get(face.normalIDs[v2]);
            t.norm2 = new DayM_Vector(norm[0], norm[1], norm[2]);
            norm = norms.get(face.normalIDs[v3]);
            t.norm3 = new DayM_Vector(norm[0], norm[1], norm[2]);
        }
        t.materialID = mtlID;
        obj.addTriangle(t, groupNum, triNum);
        return t;
    }
}
