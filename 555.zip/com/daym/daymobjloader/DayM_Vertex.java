package com.daym.daymobjloader;

import java.util.*;

public class DayM_Vertex
{
    public DayM_Vector pos;
    public DayM_Vector posS;
    public int ID;
    public ArrayList neighborTris;
    
    public DayM_Vertex() {
        this.pos = new DayM_Vector();
        this.posS = new DayM_Vector();
        this.neighborTris = new ArrayList();
        this.pos = new DayM_Vector(0.0f, 0.0f, 0.0f);
    }
    
    public DayM_Vertex(final float xpos, final float ypos, final float zpos) {
        this.pos = new DayM_Vector();
        this.posS = new DayM_Vector();
        this.neighborTris = new ArrayList();
        this.pos = new DayM_Vector(xpos, ypos, zpos);
    }
    
    public DayM_Vertex(final float xpos, final float ypos, final float zpos, final float u, final float v) {
        this.pos = new DayM_Vector();
        this.posS = new DayM_Vector();
        this.neighborTris = new ArrayList();
        this.pos = new DayM_Vector(xpos, ypos, zpos);
    }
    
    public DayM_Vertex(final DayM_Vector ppos) {
        this.pos = new DayM_Vector();
        this.posS = new DayM_Vector();
        this.neighborTris = new ArrayList();
        this.pos = ppos.getClone();
    }
    
    void addNeighborTri(final DayM_Triangle triangle) {
        if (!this.neighborTris.contains(triangle)) {
            this.neighborTris.add(triangle);
        }
    }
    
    void resetNeighbors() {
        this.neighborTris.clear();
    }
    
    public DayM_Vertex makeClone() {
        final DayM_Vertex newVertex = new DayM_Vertex();
        newVertex.pos = this.pos.getClone();
        newVertex.posS = this.posS.getClone();
        newVertex.ID = this.ID;
        return newVertex;
    }
    
    @Override
    public String toString() {
        return new String("<vertex  x=" + this.pos.x + " y=" + this.pos.y + " z=" + this.pos.z + ">\r\n");
    }
}
