package com.daym.daymobjloader;

import java.util.*;

class Group
{
    String name;
    String materialname;
    int materialID;
    int numTriangles;
    ArrayList faces;
    
    public void Group_(final ArrayList faces, final String name, final String materialname) {
        this.name = name;
        this.materialname = materialname;
        this.faces = faces;
    }
    
    public Group(final String name) {
        this.name = name;
        this.materialname = "";
        this.faces = new ArrayList();
    }
}
