package com.daym.daymobjloader;

import java.io.*;
import java.util.*;

public class DayM_3DS_Importer
{
    private DayM_3DS_Reader reader;
    private DayM_Mesh mesh;
    
    public DayM_3DS_Importer() {
        this.reader = new DayM_3DS_Reader();
        this.mesh = new DayM_Mesh();
    }
    
    public DayM_Mesh load(final String filename) {
        System.out.println("DayM_3DS_Importer.import(): Load object from " + filename);
        this.reader = new DayM_3DS_Reader(filename);
        System.out.println("DayM_3DS_Importer.importFromStream(): model has " + this.reader.faces.size() + " faces and " + this.reader.vertices.size() + " vertices. ");
        return this.makeMeshObject(this.reader.vertices, this.reader.textureCoords, this.reader.normals, this.reader.faces);
    }
    
    public DayM_Mesh importFromStream(final InputStream inStream) {
        System.out.println("importFromStream(): Load object from stream...");
        this.reader.load3DSFromStream(inStream);
        System.out.println("importFromStream(): model has " + this.reader.faces.size() + " faces and " + this.reader.vertices.size() + " vertices and " + this.reader.textureCoords.size() + " txtrcoords.");
        return this.makeMeshObject(this.reader.vertices, this.reader.textureCoords, this.reader.normals, this.reader.faces);
    }
    
    public DayM_Mesh makeMeshObject(final ArrayList verts, final ArrayList txtrs, final ArrayList norms, final ArrayList faces) {
        this.mesh = new DayM_Mesh();
        this.mesh.name = "3DS";
        for (int i = 0; i < verts.size(); ++i) {
            final float[] coords = verts.get(i);
            this.mesh.addVertex(coords[0], coords[1], coords[2]);
        }
        for (int i = 0; i < faces.size(); ++i) {
            final Face face = faces.get(i);
            this.addTriangle(this.mesh, face, txtrs, norms);
        }
        this.mesh.rebuild();
        if (norms.size() == 0) {
            this.mesh.regenerateNormals();
        }
        return this.mesh;
    }
    
    public DayM_Triangle addTriangle(final DayM_Mesh obj, final Face face, final ArrayList txtrs, final ArrayList norms) {
        final DayM_Triangle t = new DayM_Triangle(obj.vertex(face.vertexIDs[0]), obj.vertex(face.vertexIDs[1]), obj.vertex(face.vertexIDs[2]));
        if (txtrs.size() > 0) {
            float[] uvw = txtrs.get(face.textureIDs[0]);
            t.uvw1 = new DayM_Vector(uvw[0], uvw[1], uvw[2]);
            uvw = txtrs.get(face.textureIDs[1]);
            t.uvw2 = new DayM_Vector(uvw[0], uvw[1], uvw[2]);
            uvw = txtrs.get(face.textureIDs[2]);
            t.uvw3 = new DayM_Vector(uvw[0], uvw[1], uvw[2]);
        }
        if (norms.size() > 0) {
            float[] norm = norms.get(face.normalIDs[0]);
            t.norm1 = new DayM_Vector(norm[0], norm[1], norm[2]);
            norm = norms.get(face.normalIDs[1]);
            t.norm2 = new DayM_Vector(norm[0], norm[1], norm[2]);
            norm = norms.get(face.normalIDs[2]);
            t.norm3 = new DayM_Vector(norm[0], norm[1], norm[2]);
        }
        this.mesh.addTriangle(t);
        return t;
    }
}
