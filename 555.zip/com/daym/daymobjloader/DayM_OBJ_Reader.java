package com.daym.daymobjloader;

import java.io.*;
import java.util.*;

public class DayM_OBJ_Reader
{
    public ArrayList vertices;
    public ArrayList normals;
    public ArrayList textureCoords;
    public ArrayList faces;
    public ArrayList groups;
    public String materialLibeName;
    public DayM_MaterialLib materialLib;
    public String filepath;
    public String filename;
    public float leftpoint;
    public float rightpoint;
    public float bottompoint;
    public float toppoint;
    public float farpoint;
    public float nearpoint;
    
    public DayM_OBJ_Reader(final String objfilename) {
        this.vertices = new ArrayList();
        this.normals = new ArrayList();
        this.textureCoords = new ArrayList();
        this.faces = new ArrayList();
        this.groups = new ArrayList();
        this.materialLibeName = null;
        this.filepath = "";
        this.filename = "";
        this.leftpoint = 0.0f;
        this.rightpoint = 0.0f;
        this.bottompoint = 0.0f;
        this.toppoint = 0.0f;
        this.farpoint = 0.0f;
        this.nearpoint = 0.0f;
        this.loadobject(objfilename);
    }
    
    public DayM_OBJ_Reader(final InputStream in) {
        this.vertices = new ArrayList();
        this.normals = new ArrayList();
        this.textureCoords = new ArrayList();
        this.faces = new ArrayList();
        this.groups = new ArrayList();
        this.materialLibeName = null;
        this.filepath = "";
        this.filename = "";
        this.leftpoint = 0.0f;
        this.rightpoint = 0.0f;
        this.bottompoint = 0.0f;
        this.toppoint = 0.0f;
        this.farpoint = 0.0f;
        this.nearpoint = 0.0f;
        this.loadobject(in);
    }
    
    public void loadobject(final String objfilename) {
        if (objfilename != null && objfilename.length() > 0) {
            final String[] pathParts = DayM_App.getPathAndFile(objfilename);
            this.filepath = pathParts[0];
            this.filename = pathParts[1];
            try {
                this.loadobject(DayM_App.getInputStream(objfilename));
            }
            catch (Exception ex) {}
        }
    }
    
    public void loadobject(final InputStream in) {
        if (in != null) {
            final BufferedReader br = new BufferedReader(new InputStreamReader(in));
            this.loadobject(br);
        }
    }
    
    public void loadobject(final BufferedReader br) {
        String line = "";
        String materialName = "";
        int materialID = -1;
        Group group = new Group("default");
        this.groups.add(group);
        try {
            while ((line = br.readLine()) != null) {
                line = line.trim();
                line = line.replaceAll("  ", " ");
                if (line.length() > 0) {
                    if (line.startsWith("v ")) {
                        this.vertices.add(this.read3Floats(line));
                    }
                    else if (line.startsWith("vt")) {
                        this.textureCoords.add(this.read3Floats(line));
                    }
                    else if (line.startsWith("vn")) {
                        this.normals.add(this.read3Floats(line));
                    }
                    else if (line.startsWith("f ")) {
                        final Face f = this.readFace(line);
                        f.materialID = materialID;
                        this.faces.add(f);
                        group.faces.add(f);
                        final Group group2 = group;
                        group2.numTriangles += f.numTriangles();
                    }
                    else if (line.startsWith("g ")) {
                        final String groupname = (line.length() > 1) ? line.substring(2).trim() : "";
                        group = this.findGroup(groupname);
                        if (group != null) {
                            continue;
                        }
                        group = new Group(groupname);
                        group.materialname = materialName;
                        group.materialID = materialID;
                        this.groups.add(group);
                    }
                    else if (line.startsWith("usemtl")) {
                        materialName = line.substring(7).trim();
                        materialID = ((this.materialLib == null) ? -1 : this.materialLib.findID(materialName));
                        group.materialname = materialName;
                        group.materialID = materialID;
                    }
                    else {
                        if (!line.startsWith("mtllib")) {
                            continue;
                        }
                        this.materialLibeName = line.substring(7).trim();
                        if (this.materialLibeName.startsWith("./")) {
                            this.materialLibeName = this.materialLibeName.substring(2);
                        }
                        this.materialLib = new DayM_MaterialLib(this.filepath + this.materialLibeName);
                    }
                }
            }
        }
        catch (Exception ex) {}
        for (int g = this.groups.size() - 1; g >= 0; --g) {
            if (this.getGroupFaces(g).size() <= 0) {
                this.groups.remove(g);
            }
        }
        this.calcDimensions();
        for (int i = 0; i < this.groups.size(); ++i) {}
    }
    
    private float[] read3Floats(final String line) {
        try {
            final StringTokenizer st = new StringTokenizer(line, " ");
            st.nextToken();
            if (st.countTokens() == 2) {
                return new float[] { Float.parseFloat(st.nextToken()), Float.parseFloat(st.nextToken()), 0.0f };
            }
            return new float[] { Float.parseFloat(st.nextToken()), Float.parseFloat(st.nextToken()), Float.parseFloat(st.nextToken()) };
        }
        catch (Exception e) {
            return null;
        }
    }
    
    public Group findGroup(final String name) {
        for (int i = 0; i < this.groups.size(); ++i) {
            if (this.groups.get(i).name.equals(name)) {
                return this.groups.get(i);
            }
        }
        return null;
    }
    
    private Face readFace(final String line) {
        final String[] triplets = line.substring(2).split(" ");
        final int[] v = new int[triplets.length];
        final int[] vt = new int[triplets.length];
        final int[] vn = new int[triplets.length];
        for (int i = 0; i < triplets.length; ++i) {
            final String[] vertTxtrNorm = triplets[i].replaceAll("//", "/0/").split("/");
            if (vertTxtrNorm.length > 0) {
                v[i] = this.convertIndex(vertTxtrNorm[0], this.vertices.size());
            }
            if (vertTxtrNorm.length > 1) {
                vt[i] = this.convertIndex(vertTxtrNorm[1], this.textureCoords.size());
            }
            if (vertTxtrNorm.length > 2) {
                vn[i] = this.convertIndex(vertTxtrNorm[2], this.normals.size());
            }
        }
        return new Face(v, vt, vn);
    }
    
    public int convertIndex(final String token, final int numVerts) {
        int idx = Integer.valueOf(token);
        idx = ((idx < 0) ? (numVerts + idx) : (idx - 1));
        return idx;
    }
    
    public void calcDimensions() {
        final float n = 0.0f;
        this.rightpoint = n;
        this.leftpoint = n;
        final float n2 = 0.0f;
        this.toppoint = n2;
        this.bottompoint = n2;
        final float n3 = 0.0f;
        this.nearpoint = n3;
        this.farpoint = n3;
        for (int g = 0; g < this.groups.size(); ++g) {
            final ArrayList faces = this.groups.get(g).faces;
            for (int f = 0; f < faces.size(); ++f) {
                final Face face = faces.get(f);
                final int[] vertIDs = face.vertexIDs;
                for (int v = 0; v < vertIDs.length; ++v) {
                    final float[] vertex = this.vertices.get(vertIDs[v]);
                    if (vertex[0] > this.rightpoint) {
                        this.rightpoint = vertex[0];
                    }
                    if (vertex[0] < this.leftpoint) {
                        this.leftpoint = vertex[0];
                    }
                    if (vertex[1] > this.toppoint) {
                        this.toppoint = vertex[1];
                    }
                    if (vertex[1] < this.bottompoint) {
                        this.bottompoint = vertex[1];
                    }
                    if (vertex[2] > this.nearpoint) {
                        this.nearpoint = vertex[2];
                    }
                    if (vertex[2] < this.farpoint) {
                        this.farpoint = vertex[2];
                    }
                }
            }
        }
    }
    
    public float getXWidth() {
        return this.rightpoint - this.leftpoint;
    }
    
    public float getYHeight() {
        return this.toppoint - this.bottompoint;
    }
    
    public float getZDepth() {
        return this.nearpoint - this.farpoint;
    }
    
    public int numpolygons() {
        int number = 0;
        for (int i = 0; i < this.groups.size(); ++i) {
            number += this.groups.get(i).faces.size();
        }
        return number;
    }
    
    public int numGroups() {
        return this.groups.size();
    }
    
    public String getGroupName(final int g) {
        return this.groups.get(g).name;
    }
    
    public ArrayList getGroupFaces(final int g) {
        return this.groups.get(g).faces;
    }
    
    public String getGroupMaterialName(final int g) {
        return this.groups.get(g).materialname;
    }
    
    public int getGroupTriangleCount(final int g) {
        return this.groups.get(g).numTriangles;
    }
    
    class Group
    {
        String name;
        String materialname;
        int materialID;
        int numTriangles;
        ArrayList faces;
        
        public void Group_(final ArrayList faces, final String name, final String materialname) {
            this.name = name;
            this.materialname = materialname;
            this.faces = faces;
        }
        
        public Group(final String name) {
            this.name = name;
            this.materialname = "";
            this.faces = new ArrayList();
        }
    }
}
