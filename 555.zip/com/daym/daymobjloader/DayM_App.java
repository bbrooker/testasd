package com.daym.daymobjloader;

import java.net.*;
import org.lwjgl.*;
import org.lwjgl.input.*;
import org.lwjgl.util.glu.*;
import org.lwjgl.opengl.*;
import java.nio.*;
import java.io.*;
import java.util.regex.*;
import java.util.*;
import java.lang.reflect.*;

public class DayM_App
{
    public static final String GLAPP_VERSION = ".5";
    public static final int SIZE_DOUBLE = 8;
    public static final int SIZE_FLOAT = 4;
    public static final int SIZE_INT = 4;
    public static final int SIZE_BYTE = 1;
    public static int finishedKey;
    public static String window_title;
    public static String configFilename;
    public static boolean hideNativeCursor;
    public static boolean disableNativeCursor;
    public static boolean VSyncEnabled;
    public static boolean useCurrentDisplay;
    public static boolean fullScreen;
    public static boolean showMessages;
    public static float aspectRatio;
    public static int displayWidth;
    public static int displayHeight;
    public static int displayColorBits;
    public static int displayFrequency;
    public static int depthBufferBits;
    public static int viewportX;
    public static int viewportY;
    public static int viewportW;
    public static int viewportH;
    public static DisplayMode DM;
    public static DisplayMode origDM;
    public static DisplayMode displayMode;
    public static Properties settings;
    public static boolean finished;
    public static int cursorX;
    public static int cursorY;
    public static double daym_f54ccc6f0Time;
    public static double secondsSinceLastFrame;
    public static long ticksPerSecond;
    public static int frameCount;
    public static int screenTextureSize;
    public static IntBuffer bufferViewport;
    public static FloatBuffer bufferModelviewMatrix;
    public static FloatBuffer bufferProjectionMatrix;
    public static FloatBuffer tmpResult;
    public static FloatBuffer tmpFloats;
    public static ByteBuffer tmpFloat;
    public static IntBuffer tmpInts;
    public static ByteBuffer tmpByte;
    public static ByteBuffer tmpInt;
    public static FloatBuffer mtldiffuse;
    public static FloatBuffer mtlambient;
    public static FloatBuffer mtlspecular;
    public static FloatBuffer mtlemissive;
    public static FloatBuffer mtlshininess;
    public static float rotation;
    public static final float PIOVER180 = 0.017453292f;
    public static final float PIUNDER180 = 57.29578f;
    static Hashtable OpenGLextensions;
    static double avgSecsPerFrame;
    public static final float[] colorClear;
    public static final float[] colorBlack;
    public static final float[] colorWhite;
    public static final float[] colorGray;
    public static final float[] colorRed;
    public static final float[] colorGreen;
    public static final float[] colorBlue;
    static int fontListBase;
    static int fontTextureHandle;
    public static ArrayList displayLists;
    public static URL appletBaseURL;
    public static Class rootClass;
    
    public void init() {
        this.loadSettings(DayM_App.configFilename);
        this.initDisplay();
        this.initInput();
        this.initGL();
        this.setup();
        updateTimer();
    }
    
    public void handleEvents() {
        final int mouseDX = Mouse.getDX();
        final int mouseDY = Mouse.getDY();
        final int mouseDW = Mouse.getDWheel();
        if (mouseDX != 0 || mouseDY != 0 || mouseDW != 0) {
            DayM_App.cursorX += mouseDX;
            DayM_App.cursorY += mouseDY;
            if (DayM_App.cursorX < 0) {
                DayM_App.cursorX = 0;
            }
            else if (DayM_App.cursorX > DayM_App.displayMode.getWidth()) {
                DayM_App.cursorX = DayM_App.displayMode.getWidth();
            }
            if (DayM_App.cursorY < 0) {
                DayM_App.cursorY = 0;
            }
            else if (DayM_App.cursorY > DayM_App.displayMode.getHeight()) {
                DayM_App.cursorY = DayM_App.displayMode.getHeight();
            }
            this.mouseMove(DayM_App.cursorX, DayM_App.cursorY);
        }
        if (mouseDW != 0) {
            this.mouseWheel(mouseDW);
        }
        while (Mouse.next()) {
            if (Mouse.getEventButton() == 0 && Mouse.getEventButtonState()) {
                this.mouseDown(DayM_App.cursorX, DayM_App.cursorY);
            }
            if (Mouse.getEventButton() == 0 && !Mouse.getEventButtonState()) {
                this.mouseUp(DayM_App.cursorX, DayM_App.cursorY);
            }
            if (Mouse.getEventButton() == 1 && Mouse.getEventButtonState()) {
                this.mouseDown(DayM_App.cursorX, DayM_App.cursorY);
            }
            if (Mouse.getEventButton() == 1 && !Mouse.getEventButtonState()) {
                this.mouseUp(DayM_App.cursorX, DayM_App.cursorY);
            }
        }
        while (Keyboard.next()) {
            if (Keyboard.getEventKey() == DayM_App.finishedKey) {
                DayM_App.finished = true;
            }
            if (Keyboard.getEventKeyState()) {
                this.keyDown(Keyboard.getEventKey());
            }
            else {
                this.keyUp(Keyboard.getEventKey());
            }
        }
        ++DayM_App.frameCount;
        if (Sys.getTime() - DayM_App.daym_f54ccc6f0Time > DayM_App.ticksPerSecond) {
            DayM_App.frameCount = 0;
        }
    }
    
    public void loadSettings(final String configFilename) {
        if (configFilename == null || configFilename.equals("")) {
            return;
        }
        final InputStream configFileIn = getInputStream(configFilename);
        DayM_App.settings = new Properties();
        if (configFileIn == null) {
            return;
        }
        try {
            DayM_App.settings.load(configFileIn);
        }
        catch (Exception e) {
            return;
        }
        DayM_App.settings.list(System.out);
        if (DayM_App.settings.getProperty("displayWidth") != null) {
            DayM_App.displayWidth = Integer.parseInt(DayM_App.settings.getProperty("displayWidth"));
        }
        if (DayM_App.settings.getProperty("displayHeight") != null) {
            DayM_App.displayHeight = Integer.parseInt(DayM_App.settings.getProperty("displayHeight"));
        }
        if (DayM_App.settings.getProperty("displayColorBits") != null) {
            DayM_App.displayColorBits = Integer.parseInt(DayM_App.settings.getProperty("displayColorBits"));
        }
        if (DayM_App.settings.getProperty("displayFrequency") != null) {
            DayM_App.displayFrequency = Integer.parseInt(DayM_App.settings.getProperty("displayFrequency"));
        }
        if (DayM_App.settings.getProperty("depthBufferBits") != null) {
            DayM_App.depthBufferBits = Integer.parseInt(DayM_App.settings.getProperty("depthBufferBits"));
        }
        if (DayM_App.settings.getProperty("aspectRatio") != null) {
            DayM_App.aspectRatio = Float.parseFloat(DayM_App.settings.getProperty("aspectRatio"));
        }
        if (DayM_App.settings.getProperty("fullScreen") != null) {
            DayM_App.fullScreen = DayM_App.settings.getProperty("fullScreen").toUpperCase().equals("YES");
        }
        if (DayM_App.settings.getProperty("useCurrentDisplay") != null) {
            DayM_App.useCurrentDisplay = DayM_App.settings.getProperty("useCurrentDisplay").toUpperCase().equals("YES");
        }
        if (DayM_App.settings.getProperty("finishedKey") != null) {
            DayM_App.finishedKey = Integer.parseInt(DayM_App.settings.getProperty("finishedKey"));
        }
        if (DayM_App.settings.getProperty("window_title") != null) {
            DayM_App.window_title = DayM_App.settings.getProperty("window_title");
        }
        if (DayM_App.settings.getProperty("VSyncEnabled") != null) {
            DayM_App.VSyncEnabled = DayM_App.settings.getProperty("VSyncEnabled").toUpperCase().equals("YES");
        }
    }
    
    public boolean initDisplay() {
        DayM_App.origDM = Display.getDisplayMode();
        msg("DayM_App.initDisplay(): Current display mode is " + DayM_App.origDM);
        if (DayM_App.displayHeight == -1) {
            DayM_App.displayHeight = DayM_App.origDM.getHeight();
        }
        if (DayM_App.displayWidth == -1) {
            DayM_App.displayWidth = DayM_App.origDM.getWidth();
        }
        if (DayM_App.displayColorBits == -1) {
            DayM_App.displayColorBits = DayM_App.origDM.getBitsPerPixel();
        }
        if (DayM_App.displayFrequency == -1) {
            DayM_App.displayFrequency = DayM_App.origDM.getFrequency();
        }
        try {
            if (DayM_App.useCurrentDisplay) {
                DayM_App.DM = DayM_App.origDM;
            }
            else if ((DayM_App.DM = getDisplayMode(DayM_App.displayWidth, DayM_App.displayHeight, DayM_App.displayColorBits, DayM_App.displayFrequency)) != null || (DayM_App.DM = getDisplayMode(1024, 768, 32, 60)) != null || (DayM_App.DM = getDisplayMode(1024, 768, 16, 60)) != null || (DayM_App.DM = getDisplayMode(DayM_App.origDM.getWidth(), DayM_App.origDM.getHeight(), DayM_App.origDM.getBitsPerPixel(), DayM_App.origDM.getFrequency())) == null) {}
            msg("DayM_App.initDisplay(): Setting display mode to " + DayM_App.DM + " with pixel depth = " + DayM_App.depthBufferBits);
            Display.setDisplayMode(DayM_App.DM);
            DayM_App.displayMode = DayM_App.DM;
            DayM_App.displayWidth = DayM_App.DM.getWidth();
            DayM_App.displayHeight = DayM_App.DM.getHeight();
            DayM_App.displayColorBits = DayM_App.DM.getBitsPerPixel();
            DayM_App.displayFrequency = DayM_App.DM.getFrequency();
        }
        catch (Exception exception) {
            System.exit(1);
        }
        try {
            Display.create(new PixelFormat(0, DayM_App.depthBufferBits, 8));
            Display.setTitle(DayM_App.window_title);
            Display.setFullscreen(DayM_App.fullScreen);
            Display.setVSyncEnabled(DayM_App.VSyncEnabled);
        }
        catch (Exception exception2) {
            System.exit(1);
        }
        if (DayM_App.aspectRatio == 0.0f) {
            DayM_App.aspectRatio = DayM_App.DM.getWidth() / DayM_App.DM.getHeight();
        }
        DayM_App.viewportH = DayM_App.DM.getHeight();
        DayM_App.viewportW = (int)(DayM_App.DM.getHeight() * DayM_App.aspectRatio);
        if (DayM_App.viewportW > DayM_App.DM.getWidth()) {
            DayM_App.viewportW = DayM_App.DM.getWidth();
            DayM_App.viewportH = (int)(DayM_App.DM.getWidth() * (1.0f / DayM_App.aspectRatio));
        }
        DayM_App.viewportX = (DayM_App.DM.getWidth() - DayM_App.viewportW) / 2;
        DayM_App.viewportY = (DayM_App.DM.getHeight() - DayM_App.viewportH) / 2;
        return true;
    }
    
    public static DisplayMode getDisplayMode(final int w, final int h, final int colorBits, final int freq) {
        try {
            final DisplayMode[] allDisplayModes = Display.getAvailableDisplayModes();
            DisplayMode dm = null;
            for (int j = 0; j < allDisplayModes.length; ++j) {
                dm = allDisplayModes[j];
                if (dm.getWidth() == w && dm.getHeight() == h && dm.getBitsPerPixel() == colorBits && dm.getFrequency() == freq) {
                    return dm;
                }
            }
        }
        catch (LWJGLException ex) {}
        return null;
    }
    
    public void initInput() {
        try {
            Keyboard.create();
            if (DayM_App.disableNativeCursor) {
                disableNativeCursor(true);
                DayM_App.cursorX = DayM_App.DM.getWidth() / 2;
                DayM_App.cursorY = DayM_App.DM.getHeight() / 2;
            }
            if (DayM_App.hideNativeCursor) {
                hideNativeCursor(true);
            }
            DayM_App.ticksPerSecond = Sys.getTimerResolution();
        }
        catch (Exception ex) {}
    }
    
    public void initGL() {
        try {
            GL11.glEnable(2929);
            GL11.glDepthFunc(515);
            GL11.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            GL11.glEnable(2977);
            GL11.glEnable(2884);
            GL11.glEnable(3553);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glEnable(3008);
            GL11.glAlphaFunc(516, 0.0f);
            GL11.glLightModeli(33272, 33274);
            GL11.glHint(3152, 4354);
            GL11.glViewport(DayM_App.viewportX, DayM_App.viewportY, DayM_App.viewportW, DayM_App.viewportH);
            setPerspective();
            GL11.glMatrixMode(5888);
            GL11.glLoadIdentity();
        }
        catch (Exception ex) {}
    }
    
    public void setup() {
    }
    
    public void update() {
    }
    
    public void draw() {
        this.render();
    }
    
    public void render() {
        DayM_App.rotation += (float)(DayM_App.secondsSinceLastFrame * 90.0);
        GL11.glClear(16640);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        GLU.gluLookAt(0.0f, 0.0f, 10.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);
        GL11.glPushMatrix();
        GL11.glRotatef(DayM_App.rotation, 0.0f, 1.0f, 0.0f);
        GL11.glColor4f(0.0f, 0.5f, 1.0f, 1.0f);
        renderCube();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glRotatef(DayM_App.rotation, 1.0f, 1.0f, 1.0f);
        GL11.glColor4f(0.7f, 0.5f, 0.0f, 1.0f);
        renderCube();
        GL11.glPopMatrix();
    }
    
    public void cleanup() {
        destroyFont();
        destroyDisplayLists();
        Keyboard.destroy();
        Display.destroy();
    }
    
    public void exit() {
        DayM_App.finished = true;
    }
    
    public void mouseMove(final int x, final int y) {
    }
    
    public void mouseDown(final int x, final int y) {
    }
    
    public void mouseUp(final int x, final int y) {
    }
    
    public void mouseWheel(final int wheelMoved) {
    }
    
    public boolean mouseButtonDown(final int whichButton) {
        return Mouse.isButtonDown(whichButton);
    }
    
    public void keyDown(final int keycode) {
    }
    
    public void keyUp(final int keycode) {
    }
    
    public char keyChar() {
        return Keyboard.getEventCharacter();
    }
    
    public static Properties loadPropertiesFile(final String configFilename) {
        final Properties props = new Properties();
        try {
            DayM_App.settings.load(getInputStream(configFilename));
        }
        catch (Exception e) {
            return null;
        }
        return props;
    }
    
    public static String getProperty(final Properties props, final String propName) {
        String s = null;
        if (propName != null && propName.length() > 0) {
            s = props.getProperty(propName);
        }
        return s;
    }
    
    public static int getPropertyInt(final Properties props, final String propName) {
        final String s = getProperty(props, propName);
        int v = -1;
        if (s != null) {
            v = Integer.parseInt(s);
        }
        return v;
    }
    
    public static float getPropertyFloat(final Properties props, final String propName) {
        final String s = getProperty(props, propName);
        float v = -1.0f;
        if (s != null) {
            v = Float.parseFloat(s);
        }
        return v;
    }
    
    public static boolean getPropertyBool(final Properties props, final String propName) {
        final String s = getProperty(props, propName);
        boolean v = false;
        if (s != null) {
            v = (s.toUpperCase().equals("YES") || s.toUpperCase().equals("TRUE") || s.equals("1"));
        }
        return v;
    }
    
    public static String getProperty(final String propertyName) {
        return DayM_App.settings.getProperty(propertyName);
    }
    
    public static int getWidth() {
        return DayM_App.viewportW;
    }
    
    public static int getHeight() {
        return DayM_App.viewportH;
    }
    
    public static int getWidthWindow() {
        return DayM_App.displayWidth;
    }
    
    public static int getHeightWindow() {
        return DayM_App.displayHeight;
    }
    
    public static void setBackgroundColor(final float R, final float G, final float B) {
        GL11.glClearColor(R, G, B, 1.0f);
    }
    
    public static void disableNativeCursor(final boolean off) {
        Mouse.setGrabbed(DayM_App.disableNativeCursor = off);
    }
    
    public static void hideNativeCursor(final boolean hide) {
        DayM_App.hideNativeCursor = hide;
        if ((Cursor.getCapabilities() & 0x1) == 0x0) {
            return;
        }
        try {
            if (hide) {
                Cursor cursor = null;
                final int cursorImageCount = 1;
                final int cursorHeight;
                final int cursorWidth = cursorHeight = Cursor.getMaxCursorSize();
                final IntBuffer cursorDelays = null;
                final IntBuffer cursorImages = ByteBuffer.allocateDirect(cursorWidth * cursorHeight * cursorImageCount * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
                for (int j = 0; j < cursorWidth; ++j) {
                    for (int l = 0; l < cursorHeight; ++l) {
                        cursorImages.put(0);
                    }
                }
                cursorImages.flip();
                cursor = new Cursor(Cursor.getMaxCursorSize(), Cursor.getMaxCursorSize(), Cursor.getMaxCursorSize() / 2, Cursor.getMaxCursorSize() / 2, cursorImageCount, cursorImages, cursorDelays);
                Mouse.setNativeCursor(cursor);
            }
            else {
                Mouse.setNativeCursor((Cursor)null);
            }
        }
        catch (Exception ex) {}
    }
    
    public static void setCursorPosition(final int screenX, final int screenY) {
        Mouse.setCursorPosition(screenX, screenY);
        DayM_App.cursorX = screenX;
        DayM_App.cursorY = screenY;
    }
    
    public static int getSettingInt(final int whichSetting) {
        DayM_App.tmpInts.clear();
        GL11.glGetInteger(whichSetting, DayM_App.tmpInts);
        return DayM_App.tmpInt.get(0);
    }
    
    public static FloatBuffer getModelviewMatrix() {
        DayM_App.bufferModelviewMatrix.clear();
        GL11.glGetFloat(2982, DayM_App.bufferModelviewMatrix);
        return DayM_App.bufferModelviewMatrix;
    }
    
    public static FloatBuffer getProjectionMatrix() {
        DayM_App.bufferProjectionMatrix.clear();
        GL11.glGetFloat(2983, DayM_App.bufferProjectionMatrix);
        return DayM_App.bufferProjectionMatrix;
    }
    
    public static IntBuffer getViewport() {
        DayM_App.bufferViewport.clear();
        GL11.glGetInteger(2978, DayM_App.bufferViewport);
        return DayM_App.bufferViewport;
    }
    
    public static float[][] getMatrixAsArray(final FloatBuffer fb) {
        final float[][] fa = new float[4][4];
        fa[0][0] = fb.get();
        fa[0][1] = fb.get();
        fa[0][2] = fb.get();
        fa[0][3] = fb.get();
        fa[1][0] = fb.get();
        fa[1][1] = fb.get();
        fa[1][2] = fb.get();
        fa[1][3] = fb.get();
        fa[2][0] = fb.get();
        fa[2][1] = fb.get();
        fa[2][2] = fb.get();
        fa[2][3] = fb.get();
        fa[3][0] = fb.get();
        fa[3][1] = fb.get();
        fa[3][2] = fb.get();
        fa[3][3] = fb.get();
        return fa;
    }
    
    public static float getZDepth(final int x, final int y) {
        DayM_App.tmpFloat.clear();
        GL11.glReadPixels(x, y, 1, 1, 6402, 5126, DayM_App.tmpFloat);
        return DayM_App.tmpFloat.getFloat(0);
    }
    
    public static float getZDepthAtOrigin() {
        final float[] resultf = new float[3];
        project(0.0f, 0.0f, 0.0f, resultf);
        return (int)(resultf[2] * 10000.0f) / 10000.0f;
    }
    
    public static void project(final float x, final float y, final float z, final float[] resultf) {
        GLU.gluProject(x, y, z, getModelviewMatrix(), getProjectionMatrix(), getViewport(), DayM_App.tmpResult);
        resultf[0] = DayM_App.tmpResult.get(0);
        resultf[1] = DayM_App.tmpResult.get(1);
        resultf[2] = DayM_App.tmpResult.get(2);
    }
    
    public static void unProject(final float x, final float y, final float z, final float[] resultf) {
        GLU.gluUnProject(x, y, z, getModelviewMatrix(), getProjectionMatrix(), getViewport(), DayM_App.tmpResult);
        resultf[0] = DayM_App.tmpResult.get(0);
        resultf[1] = DayM_App.tmpResult.get(1);
        resultf[2] = DayM_App.tmpResult.get(2);
    }
    
    public static float[] getWorldCoordsAtScreen(final int x, final int y) {
        final float z = getZDepthAtOrigin();
        final float[] resultf = new float[3];
        unProject(x, y, z, resultf);
        return resultf;
    }
    
    public static float[] getWorldCoordsAtScreen(final int x, final int y, final float z) {
        final float[] resultf = new float[3];
        unProject(x, y, z, resultf);
        return resultf;
    }
    
    public static int allocateTexture() {
        final IntBuffer textureHandle = allocInts(1);
        GL11.glGenTextures(textureHandle);
        return textureHandle.get(0);
    }
    
    public static void activateTexture(final int textureHandle) {
        GL11.glBindTexture(3553, textureHandle);
    }
    
    public static int makeTexture(final String textureImagePath) {
        int textureHandle = 0;
        final DayM_Image textureImg = loadImage(textureImagePath);
        if (textureImg != null) {
            textureHandle = makeTexture(textureImg);
            makeTextureMipMap(textureHandle, textureImg);
        }
        return textureHandle;
    }
    
    public static int makeTexture(final String textureImagePath, final boolean mipmap, final boolean anisotropic) {
        int textureHandle = 0;
        final DayM_Image textureImg = loadImage(textureImagePath);
        if (textureImg != null) {
            textureHandle = makeTexture(textureImg.pixelBuffer, textureImg.w, textureImg.h, anisotropic);
            if (mipmap) {
                makeTextureMipMap(textureHandle, textureImg);
            }
        }
        return textureHandle;
    }
    
    public static int makeTexture(final DayM_Image textureImg) {
        if (textureImg == null) {
            return 0;
        }
        if (isPowerOf2(textureImg.w) && isPowerOf2(textureImg.h)) {
            return makeTexture(textureImg.pixelBuffer, textureImg.w, textureImg.h, false);
        }
        msg("DayM_App.makeTexture(DayM_Image) Warning: not a power of two: " + textureImg.w + "," + textureImg.h);
        textureImg.convertToPowerOf2();
        return makeTexture(textureImg.pixelBuffer, textureImg.w, textureImg.h, false);
    }
    
    public static void deleteTexture(final int textureHandle) {
        final IntBuffer bufferTxtr = allocInts(1).put(textureHandle);
        GL11.glDeleteTextures(bufferTxtr);
    }
    
    public static boolean isPowerOf2(final int n) {
        return n != 0 && (n & n - 1) == 0x0;
    }
    
    public static int makeTexture(final int w) {
        final ByteBuffer pixels = allocBytes(w * w * 4);
        return makeTexture(pixels, w, w, false);
    }
    
    public static int makeTexture(final int[] pixelsARGB, final int w, final int h, final boolean anisotropic) {
        if (pixelsARGB != null) {
            final ByteBuffer pixelsRGBA = DayM_Image.convertImagePixelsRGBA(pixelsARGB, w, h, true);
            return makeTexture(pixelsRGBA, w, h, anisotropic);
        }
        return 0;
    }
    
    public static int makeTexture(final ByteBuffer pixels, final int w, final int h, final boolean anisotropic) {
        final int textureHandle = allocateTexture();
        GL11.glPushAttrib(262144);
        GL11.glBindTexture(3553, textureHandle);
        GL11.glTexParameteri(3553, 10242, 10497);
        GL11.glTexParameteri(3553, 10243, 10497);
        GL11.glTexParameteri(3553, 10240, 9729);
        GL11.glTexParameteri(3553, 10241, 9729);
        if (anisotropic && extensionExists("GL_EXT_texture_filter_anisotropic")) {
            final FloatBuffer max_a = allocFloats(16);
            GL11.glGetFloat(34047, max_a);
            GL11.glTexParameterf(3553, 34046, max_a.get(0));
        }
        GL11.glTexImage2D(3553, 0, 32856, w, h, 0, 6408, 5121, pixels);
        GL11.glPopAttrib();
        return textureHandle;
    }
    
    public static int makeTextureARGB(final ByteBuffer pixels, final int w, final int h) {
        final int pixel_byte_order = (pixels.order() == ByteOrder.BIG_ENDIAN) ? 32821 : 33639;
        final int textureHandle = allocateTexture();
        GL11.glBindTexture(3553, textureHandle);
        GL11.glTexParameteri(3553, 10242, 10497);
        GL11.glTexParameteri(3553, 10243, 10497);
        GL11.glTexParameteri(3553, 10240, 9729);
        GL11.glTexParameteri(3553, 10241, 9729);
        GL11.glTexImage2D(3553, 0, 32856, w, h, 0, 32993, pixel_byte_order, pixels);
        return textureHandle;
    }
    
    public static int makeTextureMipMap(final int textureHandle, final DayM_Image textureImg) {
        int ret = 0;
        if (textureImg != null && textureImg.isLoaded()) {
            GL11.glBindTexture(3553, textureHandle);
            ret = GLU.gluBuild2DMipmaps(3553, 32856, textureImg.w, textureImg.h, 6408, 5121, textureImg.getPixelBytes());
            if (ret != 0) {}
            GL11.glTexParameteri(3553, 10241, 9985);
            GL11.glTexEnvf(8960, 8704, 8448.0f);
        }
        return ret;
    }
    
    public static int makeTextureForScreen(final int screenSize) {
        DayM_App.screenTextureSize = getPowerOfTwoBiggerThan(screenSize);
        msg("DayM_App.makeTextureForScreen(): made texture for screen with size " + DayM_App.screenTextureSize);
        final int textureHandle = allocateTexture();
        final ByteBuffer pixels = allocBytes(DayM_App.screenTextureSize * DayM_App.screenTextureSize * 4);
        GL11.glBindTexture(3553, textureHandle);
        GL11.glTexParameteri(3553, 10242, 10497);
        GL11.glTexParameteri(3553, 10243, 10497);
        GL11.glTexParameteri(3553, 10240, 9728);
        GL11.glTexParameteri(3553, 10241, 9728);
        GL11.glTexImage2D(3553, 0, 32856, DayM_App.screenTextureSize, DayM_App.screenTextureSize, 0, 6408, 5121, pixels);
        return textureHandle;
    }
    
    public static int getPowerOfTwoBiggerThan(int n) {
        if (n < 0) {
            return 0;
        }
        n = (--n | n >> 1);
        n |= n >> 2;
        n |= n >> 4;
        n |= n >> 8;
        n |= n >> 16;
        return n + 1;
    }
    
    public static void copyPixelsToTexture(final ByteBuffer bb, final int w, final int h, final int textureHandle) {
        final int pixel_byte_order = (bb.order() == ByteOrder.BIG_ENDIAN) ? 32821 : 33639;
        GL11.glBindTexture(3553, textureHandle);
        GL11.glTexSubImage2D(3553, 0, 0, 0, w, h, 32993, pixel_byte_order, bb);
    }
    
    public static void copyImageToTexture(final DayM_Image img, final int textureHandle) {
        copyPixelsToTexture(img.pixelBuffer, img.w, img.h, textureHandle);
    }
    
    public static void setPerspective() {
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GLU.gluPerspective(40.0f, DayM_App.aspectRatio, 1.0f, 1000.0f);
        GL11.glMatrixMode(5888);
    }
    
    public static void setOrtho() {
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0, (double)DayM_App.viewportW, 0.0, (double)DayM_App.viewportH, -500.0, 500.0);
        GL11.glMatrixMode(5888);
    }
    
    public static void setOrtho(final int width, final int height) {
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0, (double)width, 0.0, (double)height, -500.0, 500.0);
        GL11.glMatrixMode(5888);
    }
    
    public static void setOrthoOn() {
        GL11.glMatrixMode(5889);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0, (double)DayM_App.viewportW, 0.0, (double)DayM_App.viewportH, -500.0, 500.0);
        GL11.glMatrixMode(5888);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glDisable(2929);
    }
    
    public static void setOrthoOff() {
        GL11.glMatrixMode(5889);
        GL11.glPopMatrix();
        GL11.glMatrixMode(5888);
        GL11.glPopMatrix();
        GL11.glEnable(2929);
    }
    
    public static void setViewport(final int x, final int y, final int width, final int height) {
        DayM_App.viewportX = x;
        DayM_App.viewportY = y;
        DayM_App.viewportW = width;
        DayM_App.viewportH = height;
        DayM_App.aspectRatio = width / height;
        GL11.glViewport(x, y, width, height);
    }
    
    public static void resetViewport() {
        setViewport(0, 0, DayM_App.displayWidth, DayM_App.displayHeight);
    }
    
    public static void lookAt(final float lookatX, final float lookatY, final float lookatZ, final float distance) {
        GLU.gluLookAt(lookatX, lookatY, lookatZ + distance, lookatX, lookatY, lookatZ, 0.0f, 1.0f, 0.0f);
    }
    
    public static void pushAttrib() {
        GL11.glPushAttrib(1048575);
    }
    
    public static void pushAttrib(final int attribute_bits) {
        GL11.glPushAttrib(attribute_bits);
    }
    
    public static void pushAttribOrtho() {
        GL11.glPushAttrib(278848);
    }
    
    public static void pushAttribViewport() {
        GL11.glPushAttrib(2048);
    }
    
    public static void popAttrib() {
        GL11.glPopAttrib();
    }
    
    public static void setLight(final int GLLightHandle, final float[] diffuseLightColor, final float[] ambientLightColor, final float[] specularLightColor, final float[] position) {
        final FloatBuffer ltDiffuse = allocFloats(diffuseLightColor);
        final FloatBuffer ltAmbient = allocFloats(ambientLightColor);
        final FloatBuffer ltSpecular = allocFloats(specularLightColor);
        final FloatBuffer ltPosition = allocFloats(position);
        GL11.glLight(GLLightHandle, 4609, ltDiffuse);
        GL11.glLight(GLLightHandle, 4610, ltSpecular);
        GL11.glLight(GLLightHandle, 4608, ltAmbient);
        GL11.glLight(GLLightHandle, 4611, ltPosition);
        GL11.glEnable(GLLightHandle);
    }
    
    public static void setSpotLight(final int GLLightHandle, final float[] diffuseLightColor, final float[] ambientLightColor, final float[] position, final float[] direction, final float cutoffAngle) {
        final FloatBuffer ltDirection = allocFloats(direction);
        setLight(GLLightHandle, diffuseLightColor, ambientLightColor, diffuseLightColor, position);
        GL11.glLightf(GLLightHandle, 4614, cutoffAngle);
        GL11.glLight(GLLightHandle, 4612, ltDirection);
        GL11.glLightf(GLLightHandle, 4615, 2.0f);
    }
    
    public static void setAmbientLight(final float[] ambientLightColor) {
        put(DayM_App.tmpFloats, ambientLightColor);
        GL11.glLightModel(2899, DayM_App.tmpFloats);
    }
    
    public static void setLightPosition(final int GLLightHandle, final float x, final float y, final float z) {
        put(DayM_App.tmpFloats, new float[] { x, y, z, 1.0f });
        GL11.glLight(GLLightHandle, 4611, DayM_App.tmpFloats);
    }
    
    public static void setLightPosition(final int GLLightHandle, final float[] position) {
        put(DayM_App.tmpFloats, position);
        GL11.glLight(GLLightHandle, 4611, DayM_App.tmpFloats);
    }
    
    public static void setLight(final int GLLightHandle, final boolean on) {
        if (on) {
            GL11.glEnable(GLLightHandle);
        }
        else {
            GL11.glDisable(GLLightHandle);
        }
    }
    
    public static void setLighting(final boolean on) {
        if (on) {
            GL11.glEnable(2896);
        }
        else {
            GL11.glDisable(2896);
        }
    }
    
    public static void setMaterial(final float[] surfaceColor, final float shiny) {
        final float[] reflect = { shiny, shiny, shiny, 1.0f };
        final float[] ambient = { surfaceColor[0] * 0.5f, surfaceColor[1] * 0.5f, surfaceColor[2] * 0.5f, 1.0f };
        DayM_App.mtldiffuse.put(surfaceColor).flip();
        DayM_App.mtlambient.put(ambient).flip();
        DayM_App.mtlspecular.put(reflect).flip();
        DayM_App.mtlemissive.put(DayM_App.colorBlack).flip();
        final int openglShininess = (int)(shiny * 127.0f);
        if (openglShininess >= 0 && openglShininess <= 127) {
            DayM_App.mtlshininess.put(new float[] { openglShininess, 0.0f, 0.0f, 0.0f }).flip();
        }
        applyMaterial();
    }
    
    public static void setMaterial(final float[] diffuseColor, final float[] ambientColor, final float[] specularColor, final float[] emissiveColor, final float shininess) {
        DayM_App.mtldiffuse.put(diffuseColor).flip();
        DayM_App.mtlambient.put(ambientColor).flip();
        DayM_App.mtlspecular.put(specularColor).flip();
        DayM_App.mtlemissive.put(emissiveColor).flip();
        if (shininess >= 0.0f && shininess <= 127.0f) {
            DayM_App.mtlshininess.put(new float[] { shininess, 0.0f, 0.0f, 0.0f }).flip();
        }
        applyMaterial();
    }
    
    public static void setMaterialAlpha(float alpha) {
        if (alpha < 0.0f) {
            alpha = 0.0f;
        }
        if (alpha > 1.0f) {
            alpha = 1.0f;
        }
        DayM_App.mtldiffuse.put(3, alpha).flip();
        applyMaterial();
    }
    
    public static void applyMaterial() {
        GL11.glMaterial(1028, 4609, DayM_App.mtldiffuse);
        GL11.glMaterial(1028, 4608, DayM_App.mtlambient);
        GL11.glMaterial(1028, 4610, DayM_App.mtlspecular);
        GL11.glMaterial(1028, 5632, DayM_App.mtlemissive);
        GL11.glMaterial(1028, 5633, DayM_App.mtlshininess);
    }
    
    public static void setFog(final float[] fogColor, final float fogdensity) {
        put(DayM_App.tmpFloats, fogColor);
        GL11.glEnable(2912);
        GL11.glFogi(2917, 2049);
        GL11.glFog(2918, DayM_App.tmpFloats);
        GL11.glFogf(2914, fogdensity);
        GL11.glHint(3156, 4354);
    }
    
    public static void setFog(final boolean on) {
        if (on) {
            GL11.glEnable(2912);
        }
        else {
            GL11.glDisable(2912);
        }
    }
    
    public static double getTimeInSeconds() {
        if (DayM_App.ticksPerSecond == 0L) {
            DayM_App.ticksPerSecond = Sys.getTimerResolution();
        }
        return Sys.getTime() / DayM_App.ticksPerSecond;
    }
    
    public static double getTimeInMillis() {
        if (DayM_App.ticksPerSecond == 0L) {
            DayM_App.ticksPerSecond = Sys.getTimerResolution();
        }
        return Sys.getTime() / DayM_App.ticksPerSecond * 1000.0;
    }
    
    public static void updateTimer() {
        final double numToAvg = 50.0;
        DayM_App.secondsSinceLastFrame = (Sys.getTime() - DayM_App.daym_f54ccc6f0Time) / DayM_App.ticksPerSecond;
        DayM_App.daym_f54ccc6f0Time = Sys.getTime();
        if (DayM_App.secondsSinceLastFrame < 1.0) {
            DayM_App.avgSecsPerFrame = (DayM_App.avgSecsPerFrame * numToAvg + DayM_App.secondsSinceLastFrame) / (numToAvg + 1.0);
        }
    }
    
    public static double getSecondsPerFrame() {
        return DayM_App.avgSecsPerFrame;
    }
    
    public static double getFramesPerSecond() {
        return 1.0 / DayM_App.avgSecsPerFrame;
    }
    
    public static DayM_Image makeImage(final int w, final int h) {
        final ByteBuffer pixels = allocBytes(w * h * 4);
        return new DayM_Image(pixels, w, h);
    }
    
    public static DayM_Image loadImage(final String imgFilename) {
        final DayM_Image img = new DayM_Image(imgFilename);
        if (img.isLoaded()) {
            return img;
        }
        return null;
    }
    
    public static ByteBuffer loadImagePixels(final String imgFilename) {
        final DayM_Image img = new DayM_Image(imgFilename);
        return img.pixelBuffer;
    }
    
    public static void drawCursor(final int cursorTextureHandle) {
        GL11.glMatrixMode(5889);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0, (double)DayM_App.displayWidth, 0.0, (double)DayM_App.displayHeight, -1.0, 1.0);
        GL11.glMatrixMode(5888);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glPushAttrib(280640);
        GL11.glViewport(0, 0, DayM_App.displayWidth, DayM_App.displayHeight);
        GL11.glEnable(3553);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        drawQuadZ(cursorTextureHandle, DayM_App.cursorX - 15, DayM_App.cursorY - 15, 0.0f, 32.0f, 32.0f);
        GL11.glPopAttrib();
        GL11.glMatrixMode(5889);
        GL11.glPopMatrix();
        GL11.glMatrixMode(5888);
        GL11.glPopMatrix();
    }
    
    public static void drawCursorOLD(final int cursorTextureHandle) {
        setOrthoOn();
        GL11.glPushAttrib(278592);
        GL11.glEnable(3553);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        drawQuad(cursorTextureHandle, DayM_App.cursorX - 15, DayM_App.cursorY - 15, 32.0f, 32.0f);
        GL11.glPopAttrib();
        setOrthoOff();
    }
    
    public static void drawImageFullScreen(final DayM_Image img) {
        if (img == null || !img.isLoaded()) {
            return;
        }
        if (img.textureHandle <= 0) {
            img.textureHandle = makeTexture(img);
        }
        final float maxU = img.w / img.textureW;
        final float maxV = img.h / img.textureH;
        pushAttribOrtho();
        setOrthoOn();
        GL11.glEnable(3553);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glBindTexture(3553, img.textureHandle);
        GL11.glBegin(7);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f(0.0f, 0.0f, 0.0f);
        GL11.glTexCoord2f(maxU, 0.0f);
        GL11.glVertex3f((float)getWidth(), 0.0f, 0.0f);
        GL11.glTexCoord2f(maxU, maxV);
        GL11.glVertex3f((float)getWidth(), (float)getHeight(), 0.0f);
        GL11.glTexCoord2f(0.0f, maxV);
        GL11.glVertex3f(0.0f, (float)getHeight(), 0.0f);
        GL11.glEnd();
        setOrthoOff();
        popAttrib();
    }
    
    public static void drawImage(final DayM_Image img, final int x, final int y, final float w, final float h) {
        if (img.textureHandle <= 0) {
            img.textureHandle = makeTexture(img);
        }
        pushAttribOrtho();
        GL11.glBindTexture(3553, img.textureHandle);
        GL11.glNormal3f(0.0f, 0.0f, 1.0f);
        GL11.glBegin(7);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f((float)x, (float)y, 0.0f);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex3f(x + w, (float)y, 0.0f);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex3f(x + w, y + h, 0.0f);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex3f((float)x, y + h, 0.0f);
        GL11.glEnd();
        popAttrib();
    }
    
    public static void drawQuad(final int textureHandle, final int x, final int y, final float w, final float h) {
        GL11.glBindTexture(3553, textureHandle);
        setOrthoOn();
        GL11.glNormal3f(0.0f, 0.0f, 1.0f);
        GL11.glBegin(7);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f((float)x, (float)y, 0.0f);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex3f(x + w, (float)y, 0.0f);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex3f(x + w, y + h, 0.0f);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex3f((float)x, y + h, 0.0f);
        GL11.glEnd();
        setOrthoOff();
    }
    
    public static void drawQuadZ(final int textureHandle, final float x, final float y, final float z, final float w, final float h) {
        GL11.glBindTexture(3553, textureHandle);
        GL11.glNormal3f(0.0f, 0.0f, 1.0f);
        GL11.glBegin(7);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f(x, y, z);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex3f(x + w, y, z);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex3f(x + w, y + h, z);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex3f(x, y + h, z);
        GL11.glEnd();
    }
    
    public static ByteBuffer framePixels() {
        return framePixels(0, 0, DayM_App.displayMode.getWidth(), DayM_App.displayMode.getHeight());
    }
    
    public static ByteBuffer framePixels(final int x, final int y, final int w, final int h) {
        final ByteBuffer pixels = allocBytes(w * h * 4);
        GL11.glReadPixels(x, y, w, h, 32993, 33639, pixels);
        return pixels;
    }
    
    public static int[] framePixelsInt(final int x, final int y, final int w, final int h) {
        final int[] pixels = new int[w * h];
        final ByteBuffer pixelsBB = framePixels(x, y, w, h);
        get(pixelsBB, pixels);
        return pixels;
    }
    
    public static byte[] getPixelColor(final int x, final int y) {
        DayM_App.tmpInt.clear();
        GL11.glReadPixels(x, y, 1, 1, 6407, 5121, DayM_App.tmpInt);
        final byte[] rgb = { DayM_App.tmpInt.get(0), DayM_App.tmpInt.get(1), DayM_App.tmpInt.get(2) };
        return rgb;
    }
    
    public static float getPixelDepth(final int x, final int y) {
        return getZDepth(x, y);
    }
    
    public static int getPixelStencil(final int x, final int y) {
        return getMaskValue(x, y);
    }
    
    public static void frameCopy(final int txtrHandle) {
        frameCopy(txtrHandle, 0, 0, DayM_App.DM.getWidth(), DayM_App.DM.getHeight());
    }
    
    public static void frameCopy(final int txtrHandle, final int x, final int y, final int w, final int h) {
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glReadBuffer(1029);
        GL11.glBindTexture(3553, txtrHandle);
        GL11.glCopyTexSubImage2D(3553, 0, 0, 0, x, y, w, h);
    }
    
    public static void frameDraw(final int txtrHandle) {
        GL11.glDisable(3042);
        GL11.glViewport(0, 0, DayM_App.DM.getWidth(), DayM_App.DM.getHeight());
        drawQuad(txtrHandle, 0, 0, DayM_App.screenTextureSize, DayM_App.screenTextureSize);
        GL11.glViewport(DayM_App.viewportX, DayM_App.viewportY, DayM_App.viewportW, DayM_App.viewportH);
    }
    
    public static void frameSave() {
        screenShot();
    }
    
    public static void drawRect(final int x, final int y, final float w, final float h) {
        setOrthoOn();
        drawRectZ(x, y, 0, w, h);
        setOrthoOff();
    }
    
    public static void drawRectZ(final int x, final int y, final int z, final float w, final float h) {
        GL11.glPushAttrib(262208);
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        GL11.glBegin(3);
        GL11.glVertex3f((float)x, (float)y, (float)z);
        GL11.glVertex3f(x + w, (float)y, (float)z);
        GL11.glVertex3f(x + w, y + h, (float)z);
        GL11.glVertex3f((float)x, y + h, (float)z);
        GL11.glVertex3f((float)x, (float)y, (float)z);
        GL11.glEnd();
        GL11.glBegin(0);
        GL11.glVertex3f((float)x, (float)y, (float)z);
        GL11.glVertex3f(x + w, (float)y, (float)z);
        GL11.glVertex3f(x + w, y + h, (float)z);
        GL11.glVertex3f((float)x, y + h, (float)z);
        GL11.glEnd();
        popAttrib();
    }
    
    public static void drawCircle(final int x, final int y, final int radius, final int linewidth) {
        setOrthoOn();
        GL11.glPushMatrix();
        GL11.glTranslatef((float)x, (float)y, 0.0f);
        drawCircle(radius - linewidth, radius, 180);
        GL11.glPopMatrix();
        setOrthoOff();
    }
    
    public static void drawCircleZ(final int x, final int y, final int z, final int radius, final int linewidth) {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)x, (float)y, (float)z);
        drawCircle(radius - linewidth, radius, 180);
        GL11.glPopMatrix();
    }
    
    public static void drawCircle(final float innerRadius, final float outerRadius, final int numSegments) {
        int s = 0;
        final int e = 360;
        final int stepSize = 360 / numSegments;
        GL11.glBegin(8);
        float ts = (float)Math.sin(Math.toRadians(s));
        float tc = (float)Math.cos(Math.toRadians(s));
        GL11.glVertex2f(tc * innerRadius, ts * innerRadius);
        GL11.glVertex2f(tc * outerRadius, ts * outerRadius);
        while ((s = (s + stepSize) / stepSize * stepSize) < e) {
            ts = (float)Math.sin(Math.toRadians(s));
            tc = (float)Math.cos(Math.toRadians(s));
            GL11.glVertex2f(tc * innerRadius, ts * innerRadius);
            GL11.glVertex2f(tc * outerRadius, ts * outerRadius);
        }
        ts = (float)Math.sin(Math.toRadians(e));
        tc = (float)Math.cos(Math.toRadians(e));
        GL11.glVertex2f(tc * innerRadius, ts * innerRadius);
        GL11.glVertex2f(tc * outerRadius, ts * outerRadius);
        GL11.glEnd();
    }
    
    public static void renderCube() {
        GL11.glBegin(7);
        GL11.glNormal3f(0.0f, 0.0f, 1.0f);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f(-1.0f, -1.0f, 1.0f);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex3f(1.0f, -1.0f, 1.0f);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex3f(1.0f, 1.0f, 1.0f);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex3f(-1.0f, 1.0f, 1.0f);
        GL11.glNormal3f(0.0f, 0.0f, -1.0f);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex3f(-1.0f, -1.0f, -1.0f);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex3f(-1.0f, 1.0f, -1.0f);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex3f(1.0f, 1.0f, -1.0f);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f(1.0f, -1.0f, -1.0f);
        GL11.glNormal3f(0.0f, 1.0f, 0.0f);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex3f(-1.0f, 1.0f, -1.0f);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f(-1.0f, 1.0f, 1.0f);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex3f(1.0f, 1.0f, 1.0f);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex3f(1.0f, 1.0f, -1.0f);
        GL11.glNormal3f(0.0f, -1.0f, 0.0f);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex3f(-1.0f, -1.0f, -1.0f);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex3f(1.0f, -1.0f, -1.0f);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f(1.0f, -1.0f, 1.0f);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex3f(-1.0f, -1.0f, 1.0f);
        GL11.glNormal3f(1.0f, 0.0f, 0.0f);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex3f(1.0f, -1.0f, -1.0f);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex3f(1.0f, 1.0f, -1.0f);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex3f(1.0f, 1.0f, 1.0f);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f(1.0f, -1.0f, 1.0f);
        GL11.glNormal3f(-1.0f, 0.0f, 0.0f);
        GL11.glTexCoord2f(0.0f, 0.0f);
        GL11.glVertex3f(-1.0f, -1.0f, -1.0f);
        GL11.glTexCoord2f(1.0f, 0.0f);
        GL11.glVertex3f(-1.0f, -1.0f, 1.0f);
        GL11.glTexCoord2f(1.0f, 1.0f);
        GL11.glVertex3f(-1.0f, 1.0f, 1.0f);
        GL11.glTexCoord2f(0.0f, 1.0f);
        GL11.glVertex3f(-1.0f, 1.0f, -1.0f);
        GL11.glEnd();
    }
    
    public static void renderCube(final float size, final int segments) {
        final float halfsize = size / 2.0f;
        GL11.glPushMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(0.0f, 0.0f, halfsize);
        renderPlane(size, segments);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
        GL11.glTranslatef(0.0f, 0.0f, halfsize);
        renderPlane(size, segments);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
        GL11.glTranslatef(0.0f, 0.0f, halfsize);
        renderPlane(size, segments);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glRotatef(270.0f, 0.0f, 1.0f, 0.0f);
        GL11.glTranslatef(0.0f, 0.0f, halfsize);
        renderPlane(size, segments);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
        GL11.glTranslatef(0.0f, 0.0f, halfsize);
        renderPlane(size, segments);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        GL11.glTranslatef(0.0f, 0.0f, halfsize);
        renderPlane(size, segments);
        GL11.glPopMatrix();
        GL11.glPopMatrix();
    }
    
    public static void renderPlane(final float size, final int segments) {
        renderPlane(size, size, segments, segments);
    }
    
    public static void renderPlane(final float length, final float height, final int length_segments, final int height_segments) {
        renderPlane(length, height, length_segments, height_segments, 1.0f, 1.0f);
    }
    
    public static void renderPlane(final float length, final float height, final int length_segments, final int height_segments, final float tilefactorU, final float tilefactorV) {
        float xpos = -length / 2.0f;
        float ypos = -height / 2.0f;
        final float segsizeL = length / length_segments;
        final float segsizeH = height / height_segments;
        final float maxDimension = (length > height) ? length : height;
        final float uvsegsizeL = length / maxDimension / length_segments;
        final float uvsegsizeH = height / maxDimension / height_segments;
        GL11.glBegin(7);
        GL11.glNormal3f(0.0f, 0.0f, 1.0f);
        for (int x = 0; x < length_segments; ++x, xpos += segsizeL) {
            for (int y = 0; y < height_segments; ++y, ypos += segsizeH) {
                GL11.glTexCoord2f(x * uvsegsizeL * tilefactorU, y * uvsegsizeH * tilefactorV);
                GL11.glVertex3f(xpos, ypos, 0.0f);
                GL11.glTexCoord2f((x * uvsegsizeL + uvsegsizeL) * tilefactorU, y * uvsegsizeH * tilefactorV);
                GL11.glVertex3f(xpos + segsizeL, ypos, 0.0f);
                GL11.glTexCoord2f((x * uvsegsizeL + uvsegsizeL) * tilefactorU, (y * uvsegsizeH + uvsegsizeH) * tilefactorV);
                GL11.glVertex3f(xpos + segsizeL, ypos + segsizeH, 0.0f);
                GL11.glTexCoord2f(x * uvsegsizeL * tilefactorU, (y * uvsegsizeH + uvsegsizeH) * tilefactorV);
                GL11.glVertex3f(xpos, ypos + segsizeH, 0.0f);
            }
            ypos = -height / 2.0f;
        }
        GL11.glEnd();
    }
    
    public static void renderPlaneORIG(final float length, final float height, final int length_segments, final int height_segments) {
        float xpos = -length / 2.0f;
        float ypos = -height / 2.0f;
        final float segsizeL = length / length_segments;
        final float segsizeH = height / height_segments;
        final float maxDimension = (length > height) ? length : height;
        final float uvsegsizeL = length / maxDimension / length_segments;
        final float uvsegsizeH = height / maxDimension / height_segments;
        GL11.glBegin(7);
        GL11.glNormal3f(0.0f, 0.0f, 1.0f);
        for (int x = 0; x < length_segments; ++x, xpos += segsizeL) {
            for (int y = 0; y < height_segments; ++y, ypos += segsizeH) {
                GL11.glTexCoord2f(x * uvsegsizeL, y * uvsegsizeH);
                GL11.glVertex3f(xpos, ypos, 0.0f);
                GL11.glTexCoord2f(x * uvsegsizeL + uvsegsizeL, y * uvsegsizeH);
                GL11.glVertex3f(xpos + segsizeL, ypos, 0.0f);
                GL11.glTexCoord2f(x * uvsegsizeL + uvsegsizeL, y * uvsegsizeH + uvsegsizeH);
                GL11.glVertex3f(xpos + segsizeL, ypos + segsizeH, 0.0f);
                GL11.glTexCoord2f(x * uvsegsizeL, y * uvsegsizeH + uvsegsizeH);
                GL11.glVertex3f(xpos, ypos + segsizeH, 0.0f);
            }
            ypos = -height / 2.0f;
        }
        GL11.glEnd();
    }
    
    public static void renderSphere(final int facets) {
        final Sphere s = new Sphere();
        s.setOrientation(100020);
        s.setTextureFlag(true);
        GL11.glPushMatrix();
        GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        s.draw(1.0f, facets, facets);
        GL11.glPopMatrix();
    }
    
    public static void renderSphere() {
        renderSphere(48);
    }
    
    public static void setLineWidth(final int width) {
        GL11.glLineWidth((float)width);
        GL11.glPointSize((float)width);
    }
    
    public static void setColor(final float R, final float G, final float B, final float A) {
        GL11.glColor4f(R, G, B, A);
    }
    
    public static void setColorB(final int R, final int G, final int B, final int A) {
        GL11.glColor4ub((byte)R, (byte)G, (byte)B, (byte)A);
    }
    
    public static void setColor(final float[] rgba) {
        if (rgba != null) {
            if (rgba.length == 4) {
                GL11.glColor4f(rgba[0], rgba[1], rgba[2], rgba[3]);
            }
            else if (rgba.length == 3) {
                GL11.glColor4f(rgba[0], rgba[1], rgba[2], 1.0f);
            }
        }
    }
    
    public static void setColorMaterial(final boolean on) {
        if (on) {
            GL11.glColorMaterial(1028, 5634);
            GL11.glEnable(2903);
        }
        else {
            GL11.glDisable(2903);
        }
    }
    
    public static boolean buildFont(final String charSetImage, final int fontWidth) {
        final DayM_Image textureImg = loadImage(charSetImage);
        if (textureImg == null) {
            return false;
        }
        buildFont(DayM_App.fontTextureHandle = makeTexture(textureImg), fontWidth);
        return true;
    }
    
    public static void buildFont(final int fontTxtrHandle, final int fontWidth) {
        final float factor = 0.0625f;
        DayM_App.fontListBase = GL11.glGenLists(256);
        for (int i = 0; i < 256; ++i) {
            final float cx = i % 16 / 16.0f;
            final float cy = i / 16 / 16.0f;
            GL11.glNewList(DayM_App.fontListBase + i, 4864);
            GL11.glBegin(7);
            GL11.glTexCoord2f(cx, 1.0f - cy - factor);
            GL11.glVertex2i(0, 0);
            GL11.glTexCoord2f(cx + factor, 1.0f - cy - factor);
            GL11.glVertex2i(16, 0);
            GL11.glTexCoord2f(cx + factor, 1.0f - cy);
            GL11.glVertex2i(16, 16);
            GL11.glTexCoord2f(cx, 1.0f - cy);
            GL11.glVertex2i(0, 16);
            GL11.glEnd();
            GL11.glTranslatef((float)fontWidth, 0.0f, 0.0f);
            GL11.glEndList();
        }
    }
    
    public static void destroyFont() {
        if (DayM_App.fontListBase != -1) {
            GL11.glDeleteLists(DayM_App.fontListBase, 256);
            DayM_App.fontListBase = -1;
        }
    }
    
    public static void print(final int x, final int y, final String msg) {
        print(x, y, msg, 0);
    }
    
    public static void print(final int x, final int y, final String msg, final int set) {
        if ((DayM_App.fontListBase == -1 || DayM_App.fontTextureHandle == -1) && !buildFont("images/font_tahoma.png", 12)) {
            return;
        }
        if (msg != null) {
            final int offset = DayM_App.fontListBase - 32 + 128 * set;
            pushAttribOrtho();
            GL11.glDisable(2896);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glBindTexture(3553, DayM_App.fontTextureHandle);
            setOrthoOn();
            GL11.glTranslatef((float)x, (float)y, 0.0f);
            for (int i = 0; i < msg.length(); ++i) {
                GL11.glCallList(offset + msg.charAt(i));
            }
            setOrthoOff();
            popAttrib();
        }
    }
    
    public static void printZ(final float x, final float y, final float z, final int set, final float scale, final String msg) {
        if ((DayM_App.fontListBase == -1 || DayM_App.fontTextureHandle == -1) && !buildFont("images/font_tahoma.png", 12)) {
            return;
        }
        final int offset = DayM_App.fontListBase - 32 + 128 * set;
        if (msg != null) {
            GL11.glBindTexture(3553, DayM_App.fontTextureHandle);
            GL11.glPushMatrix();
            GL11.glTranslatef(x, y, z);
            GL11.glScalef(scale, scale, scale);
            for (int i = 0; i < msg.length(); ++i) {
                GL11.glCallList(offset + msg.charAt(i));
            }
            GL11.glPopMatrix();
        }
    }
    
    public static Pbuffer makePbuffer(final int width, final int height) {
        Pbuffer pbuffer = null;
        try {
            pbuffer = new Pbuffer(width, height, new PixelFormat(24, 8, 24, 8, 0), (RenderTexture)null, (Drawable)null);
        }
        catch (LWJGLException ex) {}
        return pbuffer;
    }
    
    public static Pbuffer selectPbuffer(Pbuffer pb) {
        if (pb != null) {
            try {
                if (pb.isBufferLost()) {
                    final int w = pb.getWidth();
                    final int h = pb.getHeight();
                    msg("DayM_App.selectPbuffer(): Buffer contents lost - recreating the pbuffer");
                    pb.destroy();
                    pb = makePbuffer(w, h);
                }
                pb.makeCurrent();
            }
            catch (LWJGLException ex) {}
        }
        return pb;
    }
    
    public static void selectDisplay() {
        try {
            Display.makeCurrent();
        }
        catch (LWJGLException ex) {}
    }
    
    public static void frameCopy(final Pbuffer pbuff, final int textureHandle) {
        GL11.glBindTexture(3553, textureHandle);
        GL11.glCopyTexImage2D(3553, 0, 6407, 0, 0, pbuff.getWidth(), pbuff.getHeight(), 0);
    }
    
    public static void screenShot() {
        screenShot(0, 0, DayM_App.displayMode.getWidth(), DayM_App.displayMode.getHeight(), DayM_App.rootClass.getName() + "-" + makeTimestamp() + ".png");
    }
    
    public static void screenShot(final String imageFilename) {
        screenShot(0, 0, DayM_App.displayMode.getWidth(), DayM_App.displayMode.getHeight(), imageFilename);
    }
    
    public static void screenShot(final Pbuffer pb) {
        screenShot(0, 0, pb.getWidth(), pb.getHeight(), DayM_App.rootClass.getName() + "_" + makeTimestamp() + ".png");
    }
    
    public static void screenShot(final int x, final int y, final int width, final int height, final String imageFilename) {
        ByteBuffer framebytes = allocBytes(width * height * 4);
        final int[] pixels = new int[width * height];
        GL11.glReadPixels(x, y, width, height, 32993, 33639, framebytes);
        framebytes.asIntBuffer().get(pixels, 0, pixels.length);
        framebytes = null;
        DayM_Image.savePixelsToPNG(pixels, width, height, imageFilename, true);
    }
    
    public static void savePixelsToPNG(final ByteBuffer framebytes, final int width, final int height, final String imageFilename, final boolean flipY) {
        if (framebytes != null && imageFilename != null) {
            final int[] pixels = new int[width * height];
            framebytes.asIntBuffer().get(pixels, 0, pixels.length);
            DayM_Image.savePixelsToPNG(pixels, width, height, imageFilename, flipY);
        }
    }
    
    public static void screenShotRGB(final int width, final int height, final String saveFilename) {
        ByteBuffer framebytes = allocBytes(width * height * 3);
        final int[] pixels = new int[width * height];
        GL11.glReadPixels(0, 0, width, height, 6407, 5121, framebytes);
        for (int i = 0; i < pixels.length; ++i) {
            final int bindex = i * 3;
            pixels[i] = (0xFF000000 | (framebytes.get(bindex) & 0xFF) << 16 | (framebytes.get(bindex + 1) & 0xFF) << 8 | (framebytes.get(bindex + 2) & 0xFF) << 0);
        }
        framebytes = null;
        DayM_Image.savePixelsToPNG(pixels, width, height, saveFilename, true);
    }
    
    public static void clearMask() {
        GL11.glClear(1024);
    }
    
    public static void beginMask(final int maskvalue) {
        GL11.glColorMask(false, false, false, false);
        GL11.glDepthMask(false);
        GL11.glEnable(2960);
        GL11.glStencilFunc(519, maskvalue, -1);
        GL11.glStencilOp(7681, 7681, 7681);
    }
    
    public static void endMask() {
        GL11.glStencilOp(7680, 7680, 7680);
        GL11.glColorMask(true, true, true, true);
        GL11.glDepthMask(true);
    }
    
    public static void activateMask(final int maskvalue) {
        GL11.glEnable(2960);
        GL11.glStencilFunc(514, maskvalue, -1);
    }
    
    public static void disableMask() {
        GL11.glDisable(2960);
    }
    
    public static int getMaskValue(final int x, final int y) {
        DayM_App.tmpByte.clear();
        GL11.glReadPixels(x, y, 1, 1, 6401, 5121, DayM_App.tmpByte);
        return DayM_App.tmpByte.get(0);
    }
    
    public static int beginDisplayList() {
        final int DL_ID = GL11.glGenLists(1);
        GL11.glNewList(DL_ID, 4864);
        DayM_App.displayLists.add(new Integer(DL_ID));
        return DL_ID;
    }
    
    public static void endDisplayList() {
        GL11.glEndList();
    }
    
    public static void callDisplayList(final int displayListID) {
        GL11.glCallList(displayListID);
    }
    
    public static void destroyDisplayList(final int DL_ID) {
        GL11.glDeleteLists(DL_ID, 1);
    }
    
    public static void destroyDisplayLists() {
        while (DayM_App.displayLists.size() > 0) {
            final int displaylistID = DayM_App.displayLists.get(0);
            GL11.glDeleteLists(displaylistID, 1);
            DayM_App.displayLists.remove(0);
        }
    }
    
    public static ByteBuffer allocBytes(final int howmany) {
        return ByteBuffer.allocateDirect(howmany * 1).order(ByteOrder.nativeOrder());
    }
    
    public static IntBuffer allocInts(final int howmany) {
        return ByteBuffer.allocateDirect(howmany * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
    }
    
    public static FloatBuffer allocFloats(final int howmany) {
        return ByteBuffer.allocateDirect(howmany * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    }
    
    public static DoubleBuffer allocDoubles(final int howmany) {
        return ByteBuffer.allocateDirect(howmany * 8).order(ByteOrder.nativeOrder()).asDoubleBuffer();
    }
    
    public static ByteBuffer allocBytes(final byte[] bytearray) {
        final ByteBuffer bb = ByteBuffer.allocateDirect(bytearray.length * 1).order(ByteOrder.nativeOrder());
        bb.put(bytearray).flip();
        return bb;
    }
    
    public static IntBuffer allocInts(final int[] intarray) {
        final IntBuffer ib = ByteBuffer.allocateDirect(intarray.length * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
        ib.put(intarray).flip();
        return ib;
    }
    
    public static FloatBuffer allocFloats(final float[] floatarray) {
        final FloatBuffer fb = ByteBuffer.allocateDirect(floatarray.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        fb.put(floatarray).flip();
        return fb;
    }
    
    public static DoubleBuffer allocDoubles(final double[] darray) {
        final DoubleBuffer fb = ByteBuffer.allocateDirect(darray.length * 8).order(ByteOrder.nativeOrder()).asDoubleBuffer();
        fb.put(darray).flip();
        return fb;
    }
    
    public static void put(final ByteBuffer b, final byte[] values) {
        b.clear();
        b.put(values).flip();
    }
    
    public static void put(final IntBuffer b, final int[] values) {
        b.clear();
        b.put(values).flip();
    }
    
    public static void put(final FloatBuffer b, final float[] values) {
        b.clear();
        b.put(values).flip();
    }
    
    public static void put(final DoubleBuffer b, final double[] values) {
        b.clear();
        b.put(values).flip();
    }
    
    public static void get(final ByteBuffer b, final int[] values) {
        b.asIntBuffer().get(values, 0, values.length);
    }
    
    public static void get(final IntBuffer b, final int[] values) {
        b.get(values, 0, values.length);
    }
    
    public static int[] getInts(final ByteBuffer b) {
        final int[] values = new int[b.capacity() / 4];
        b.asIntBuffer().get(values, 0, values.length);
        return values;
    }
    
    public static InputStream getInputStream(String filename) {
        InputStream in = null;
        try {
            in = new FileInputStream(filename);
        }
        catch (IOException ioe) {}
        catch (Exception e) {
            msg("DayM_App.getInputStream (" + filename + "): " + e);
        }
        if (in == null && DayM_App.rootClass != null) {
            URL u = null;
            if (filename.startsWith(".")) {
                filename = filename.substring(1);
            }
            try {
                u = DayM_App.rootClass.getResource(filename);
            }
            catch (Exception ue) {
                msg("DayM_App.getInputStream(): Can't find resource: " + ue);
            }
            if (u != null) {
                try {
                    in = u.openStream();
                }
                catch (Exception e2) {
                    msg("DayM_App.getInputStream (" + filename + "): Can't load from jar: " + e2);
                }
            }
            if (in == null && DayM_App.appletBaseURL != null) {
                try {
                    u = new URL(DayM_App.appletBaseURL, filename);
                }
                catch (Exception ue) {
                    msg("DayM_App.getInputStream(): Can't make applet base url: " + ue);
                }
                try {
                    in = u.openStream();
                }
                catch (Exception e2) {
                    msg("DayM_App.getInputStream (" + filename + "): Can't load from applet base URL: " + e2);
                }
            }
        }
        return in;
    }
    
    public static byte[] getBytesFromStream(final InputStream is) {
        final int chunkSize = 1024;
        int totalRead = 0;
        int num = 0;
        byte[] bytes = new byte[chunkSize];
        final ArrayList byteChunks = new ArrayList();
        try {
            while ((num = is.read(bytes)) >= 0) {
                byteChunks.add(bytes);
                bytes = new byte[chunkSize];
                totalRead += num;
            }
        }
        catch (IOException ex) {}
        int numCopied = 0;
        bytes = new byte[totalRead];
        while (byteChunks.size() > 0) {
            final byte[] byteChunk = byteChunks.get(0);
            final int copylen = (totalRead - numCopied > chunkSize) ? chunkSize : (totalRead - numCopied);
            System.arraycopy(byteChunk, 0, bytes, numCopied, copylen);
            byteChunks.remove(0);
            numCopied += copylen;
        }
        msg("getBytesFromStream() read " + numCopied + " bytes.");
        return bytes;
    }
    
    public static byte[] getBytesFromFile(final String filename) {
        final InputStream is = getInputStream(filename);
        final byte[] bytes = getBytesFromStream(is);
        try {
            is.close();
        }
        catch (IOException ex) {}
        return bytes;
    }
    
    public static String[] getPathAndFile(final String filename) {
        final String[] pathAndFile = new String[2];
        final Matcher matcher = Pattern.compile("^.*/").matcher(filename);
        if (matcher.find()) {
            pathAndFile[0] = matcher.group();
            pathAndFile[1] = filename.substring(matcher.end());
        }
        else {
            pathAndFile[0] = "";
            pathAndFile[1] = filename;
        }
        return pathAndFile;
    }
    
    public void setRootClass() {
        DayM_App.rootClass = this.getClass();
    }
    
    public static String makeTimestamp() {
        final Calendar now = Calendar.getInstance();
        final int year = now.get(1);
        final int month = now.get(2) + 1;
        final int day = now.get(5);
        final int hours = now.get(11);
        final int minutes = now.get(12);
        final int seconds = now.get(13);
        final String datetime = "" + year + ((month < 10) ? "0" : "") + month + ((day < 10) ? "0" : "") + day + "-" + ((hours < 10) ? "0" : "") + hours + ((minutes < 10) ? "0" : "") + minutes + ((seconds < 10) ? "0" : "") + seconds;
        return datetime;
    }
    
    public static float random() {
        return (float)Math.random();
    }
    
    public static float random(final float upperbound) {
        return (float)(Math.random() * upperbound);
    }
    
    public static int random(final int upperbound) {
        return (int)(Math.random() * upperbound);
    }
    
    public static int round(final float f) {
        return Math.round(f);
    }
    
    public static boolean extensionExists(final String extensionName) {
        if (DayM_App.OpenGLextensions == null) {
            final String[] GLExtensions = GL11.glGetString(7939).split(" ");
            DayM_App.OpenGLextensions = new Hashtable();
            for (int i = 0; i < GLExtensions.length; ++i) {
                DayM_App.OpenGLextensions.put(GLExtensions[i].toUpperCase(), "");
            }
        }
        return DayM_App.OpenGLextensions.get(extensionName.toUpperCase()) != null;
    }
    
    public static void msg(final String text) {
        if (DayM_App.showMessages) {
            System.out.println(text);
        }
    }
    
    public static void err(final String text) {
        System.out.println(text);
    }
    
    public static Method method(final Object object, final String methodName) {
        Method M = null;
        try {
            M = object.getClass().getMethod(methodName, (Class<?>[])null);
        }
        catch (Exception ex) {}
        return M;
    }
    
    public Method method(final String methodName) {
        return method(this, methodName);
    }
    
    public static void invoke(final Object object, final Method method) {
        if (object != null && method != null) {
            try {
                method.invoke(object, (Object[])null);
            }
            catch (Exception ex) {}
        }
    }
    
    public void invoke(final Method method) {
        if (method != null) {
            try {
                method.invoke(this, (Object[])null);
            }
            catch (Exception ex) {}
        }
    }
    
    static {
        DayM_App.finishedKey = 1;
        DayM_App.window_title = "OpenGL Window";
        DayM_App.configFilename = "DayM_App.cfg";
        DayM_App.hideNativeCursor = false;
        DayM_App.disableNativeCursor = false;
        DayM_App.VSyncEnabled = true;
        DayM_App.useCurrentDisplay = false;
        DayM_App.fullScreen = false;
        DayM_App.showMessages = true;
        DayM_App.aspectRatio = 0.0f;
        DayM_App.displayWidth = -1;
        DayM_App.displayHeight = -1;
        DayM_App.displayColorBits = -1;
        DayM_App.displayFrequency = -1;
        DayM_App.depthBufferBits = 24;
        DayM_App.settings = new Properties();
        DayM_App.daym_f54ccc6f0Time = 0.0;
        DayM_App.secondsSinceLastFrame = 0.0;
        DayM_App.ticksPerSecond = 0L;
        DayM_App.frameCount = 0;
        DayM_App.screenTextureSize = 1024;
        DayM_App.bufferViewport = allocInts(16);
        DayM_App.bufferModelviewMatrix = allocFloats(16);
        DayM_App.bufferProjectionMatrix = allocFloats(16);
        DayM_App.tmpResult = allocFloats(16);
        DayM_App.tmpFloats = allocFloats(4);
        DayM_App.tmpFloat = allocBytes(4);
        DayM_App.tmpInts = allocInts(16);
        DayM_App.tmpByte = allocBytes(1);
        DayM_App.tmpInt = allocBytes(4);
        DayM_App.mtldiffuse = allocFloats(4);
        DayM_App.mtlambient = allocFloats(4);
        DayM_App.mtlspecular = allocFloats(4);
        DayM_App.mtlemissive = allocFloats(4);
        DayM_App.mtlshininess = allocFloats(4);
        DayM_App.rotation = 0.0f;
        DayM_App.avgSecsPerFrame = 0.01;
        colorClear = new float[] { 0.0f, 0.0f, 0.0f, 0.0f };
        colorBlack = new float[] { 0.0f, 0.0f, 0.0f, 1.0f };
        colorWhite = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
        colorGray = new float[] { 0.5f, 0.5f, 0.5f, 1.0f };
        colorRed = new float[] { 1.0f, 0.0f, 0.0f, 1.0f };
        colorGreen = new float[] { 0.0f, 1.0f, 0.0f, 1.0f };
        colorBlue = new float[] { 0.0f, 0.0f, 1.0f, 1.0f };
        DayM_App.fontListBase = -1;
        DayM_App.fontTextureHandle = -1;
        DayM_App.displayLists = new ArrayList();
        DayM_App.appletBaseURL = null;
        DayM_App.rootClass = DayM_App.class;
    }
}
