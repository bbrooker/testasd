package com.daym.gui;

import cpw.mods.fml.relauncher.*;
import com.daym.registry.*;
import net.minecraft.item.*;
import com.daym.handlers.*;
import net.minecraft.client.gui.*;
import com.daym.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.util.*;
import java.util.*;
import java.net.*;
import net.minecraft.world.storage.*;
import org.lwjgl.input.*;

@SideOnly(Side.CLIENT)
public class GuiLootSpawner extends GuiScreen implements GuiYesNoCallback
{
    Random random;
    private StringTranslate stringTranslate;
    private boolean usedButton;
    private int scrollbar;
    private boolean dragging;
    private int calculatedPercentage;
    
    public GuiLootSpawner(final int s) {
        this.random = new Random();
        this.usedButton = false;
        this.scrollbar = 0;
        this.stringTranslate = new StringTranslate();
        this.scrollbar = s;
    }
    
    public void func_73876_c() {
        if (this.usedButton) {
            for (final Object button : this.field_146292_n) {
                if (button instanceof GuiDayMSlider) {
                    final GuiDayMSlider slider = (GuiDayMSlider)button;
                    final int id = slider.field_146127_k;
                    final float val = slider.sliderValue;
                    if (id == 1) {
                        WorldVarHandler.daym_6176e9ba0id = (int)(val / 100.0f) / 30;
                        slider.field_146126_j = "loot table: " + ItemRegistry.lootTablesNames[WorldVarHandler.daym_6176e9ba0id];
                    }
                    if (id == 2) {
                        WorldVarHandler.daym_fd6bdaa50 = (int)(val / 1200.0f);
                        slider.field_146126_j = "loot radius: " + WorldVarHandler.daym_fd6bdaa50;
                    }
                    if (id == 3) {
                        WorldVarHandler.daym_55512bc80 = (int)(val / 100.0f);
                        slider.field_146126_j = "loot spawnChance: %" + WorldVarHandler.daym_55512bc80;
                    }
                    if (id > 3 + ItemRegistry.lootTable.size()) {
                        slider.field_146126_j = "chance: %" + (int)val;
                        try {
                            WorldVarHandler.daym_4f999ab20.set(id - (ItemRegistry.lootTable.size() + 4), (int)val);
                        }
                        catch (Exception ex) {}
                    }
                }
                if (button instanceof GuiDayMButton && !(button instanceof GuiDayMSlider)) {
                    final GuiDayMButton button2 = (GuiDayMButton)button;
                    final int id = button2.field_146127_k;
                    final int var4 = (int)(this.field_146295_m / 2 - this.field_146295_m / 2.5) - this.scrollbar * ItemRegistry.lootTable.size() / (this.field_146295_m / 24);
                    if (id > 3 && id != 500 && id != 501 && id != 502) {
                        button2.field_146129_i = var4 + 24 * (id - 4);
                    }
                }
                if (button instanceof GuiDayMSlider) {
                    final GuiDayMButton button2 = (GuiDayMButton)button;
                    final int id = button2.field_146127_k;
                    final int var4 = (int)(this.field_146295_m / 2 - this.field_146295_m / 2.5) - this.scrollbar * ItemRegistry.lootTable.size() / (this.field_146295_m / 24);
                    if (id <= 3) {
                        continue;
                    }
                    button2.field_146129_i = var4 + 24 * (id - (ItemRegistry.lootTable.size() + 4));
                }
            }
        }
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    protected void func_73869_a(final char par1, final int par2) {
    }
    
    public void func_73866_w_() {
        final int var4 = (int)(this.field_146295_m / 2 - this.field_146295_m / 2.5);
        final int var5 = 20;
        final int var6 = 106;
        final int var7 = this.field_146294_l / 2;
        final int yOffset = 0;
        final int xOffset = -90;
        this.field_146292_n.add(new GuiDayMButton(0, 0, "center", var5, this.field_146294_l / 2 - var6, var4 + 24, 20, "Close"));
        this.field_146292_n.add(new GuiDayMButton(501, 0, "left", var5, this.field_146294_l / 2 - var6 + 23, var4 + 24, 20, "Reset Loot Table"));
        this.field_146292_n.add(new GuiDayMButton(502, 0, "right", var5, this.field_146294_l / 2 - var6 - 23, var4 + 24, 20, "Add Table (id)"));
        final GuiDayMSlider slider = new GuiDayMSlider(1, var7 - var6 * 2, var4 + 48, "loot table: " + ItemRegistry.lootTablesNames[WorldVarHandler.daym_6176e9ba0id], WorldVarHandler.daym_6176e9ba0id * 100 * 30);
        slider.field_146124_l = true;
        this.field_146292_n.add(slider);
        this.field_146292_n.add(new GuiDayMSlider(2, var7 - var6 * 2, var4 + 72, "loot radius: " + WorldVarHandler.daym_fd6bdaa50, WorldVarHandler.daym_fd6bdaa50 * 1200));
        this.field_146292_n.add(new GuiDayMSlider(3, var7 - var6 * 2, var4 + 96, "loot spawnChance: " + WorldVarHandler.daym_55512bc80, WorldVarHandler.daym_55512bc80 * 100));
        boolean addAll = false;
        boolean addAll2 = false;
        if (WorldVarHandler.daym_4f999ab20.isEmpty()) {
            addAll = true;
        }
        if (WorldVarHandler.daym_6176e9ba0.isEmpty()) {
            addAll2 = true;
        }
        for (int i = 0; i < ItemRegistry.lootTable.size(); ++i) {
            String varstr = "Add";
            if (WorldVarHandler.daym_6176e9ba0.contains(i)) {
                varstr = "Remove";
            }
            this.field_146292_n.add(new GuiDayMButton(4 + i, var7 - var6 / 24, var4 + 24 * i, 144, 20, varstr + " " + LanguageHandler.translate(ItemRegistry.lootTable.get(i).func_77658_a() + ".name")));
            if (addAll2) {
                WorldVarHandler.daym_6176e9ba0.add(-1);
            }
            if (addAll) {
                WorldVarHandler.daym_4f999ab20.add(50);
            }
            try {
                this.field_146292_n.add(new GuiDayMSlider(4 + ItemRegistry.lootTable.size() + i, var7 + var6 / 24 + 97 + 40, var4 + 24 * i, 60, 20, "chance: %" + WorldVarHandler.daym_4f999ab20.get(i), 100.0f, WorldVarHandler.daym_4f999ab20.get(i)));
            }
            catch (Exception e) {
                final GuiDayMSlider sld = new GuiDayMSlider(4 + ItemRegistry.lootTable.size() + i, var7 + var6 / 24 + 97 + 40, var4 + 24 * i, 60, 20, "chance: %50", 100.0f, 50.0f);
                sld.field_146124_l = false;
                this.field_146292_n.add(sld);
            }
        }
        String s = "Apply";
        if (WorldVarHandler.daym_6176e9ba0.isEmpty()) {
            s = "Apply (No Items Selected)";
        }
        final GuiDayMButton button = new GuiDayMButton(500, 0, "center", var5, this.field_146294_l / 2 - var6, var4 + 120, 20, s);
        if (WorldVarHandler.daym_6176e9ba0.isEmpty()) {
            button.field_146124_l = false;
        }
        this.field_146292_n.add(button);
        if (this.scrollbar != 0) {
            this.usedButton = true;
        }
    }
    
    protected void func_146284_a(final GuiButton par1GuiButton) {
        if (par1GuiButton.field_146127_k == 0) {
            this.field_146297_k.field_71462_r = null;
            this.field_146297_k.func_71381_h();
        }
        this.usedButton = true;
        if (par1GuiButton.field_146127_k > 3 && !(par1GuiButton instanceof GuiDayMSlider)) {
            final int id = par1GuiButton.field_146127_k - 4;
            if (!WorldVarHandler.daym_6176e9ba0.contains(id)) {
                if (id < WorldVarHandler.daym_6176e9ba0.size()) {
                    WorldVarHandler.daym_6176e9ba0.set(id, id);
                }
            }
            else {
                WorldVarHandler.daym_6176e9ba0.remove((Object)id);
            }
            this.field_146297_k.func_147108_a((GuiScreen)new GuiLootSpawner(this.scrollbar));
        }
        if (par1GuiButton.field_146127_k == 500) {
            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_LootSpawner(0, WorldVarHandler.daym_6176e9ba0, WorldVarHandler.daym_4f999ab20, WorldVarHandler.daym_6176e9ba0.size(), WorldVarHandler.daym_4f999ab20.size(), WorldVarHandler.daym_6176e9ba0id, WorldVarHandler.daym_fd6bdaa50, WorldVarHandler.daym_55512bc80, WorldVarHandler.daym_d968810a0, WorldVarHandler.daym_fbd202650, WorldVarHandler.daym_b8e432020));
            final IChatComponent test = (IChatComponent)new ChatComponentText("Added Loot Spawner at: " + WorldVarHandler.daym_d968810a0 + ", " + WorldVarHandler.daym_fbd202650 + ", " + WorldVarHandler.daym_b8e432020);
            this.field_146297_k.field_71439_g.func_145747_a(test);
            this.field_146297_k.field_71462_r = null;
            this.field_146297_k.func_71381_h();
        }
        if (par1GuiButton.field_146127_k == 501) {
            WorldVarHandler.daym_6176e9ba0.clear();
            WorldVarHandler.daym_4f999ab20.clear();
            this.field_146297_k.func_147108_a((GuiScreen)new GuiLootSpawner(this.scrollbar));
        }
        if (par1GuiButton.field_146127_k == 502) {
            final ArrayList<Item> test2 = (ArrayList<Item>)ItemRegistry.lootTables[WorldVarHandler.daym_6176e9ba0id];
            final ArrayList<Integer> test3 = (ArrayList<Integer>)ItemRegistry.lootTablesChance[WorldVarHandler.daym_6176e9ba0id];
            int i = 0;
            int a = 0;
            for (final Item it : ItemRegistry.lootTable) {
                if (test2.contains(it)) {
                    try {
                        WorldVarHandler.daym_6176e9ba0.set(i, i);
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (i < ItemRegistry.lootTable.size()) {
                        try {
                            WorldVarHandler.daym_4f999ab20.set(i, test3.get(a));
                        }
                        catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    ++a;
                }
                ++i;
            }
            this.field_146297_k.func_147108_a((GuiScreen)new GuiLootSpawner(this.scrollbar));
        }
    }
    
    public void func_73878_a(final boolean par1, final int par2) {
        if (par1 && par2 == 12) {
            final ISaveFormat var6 = this.field_146297_k.func_71359_d();
            var6.func_75800_d();
            var6.func_75802_e("Demo_World");
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
        else if (par2 == 13) {
            if (par1) {
                try {
                    final Class var7 = Class.forName("java.awt.Desktop");
                    final Object var8 = var7.getMethod("getDesktop", (Class[])new Class[0]).invoke(null, new Object[0]);
                    var7.getMethod("browse", URI.class).invoke(var8, new URI("http://tinyurl.com/javappc"));
                }
                catch (Throwable var9) {
                    var9.printStackTrace();
                }
            }
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        if (this.scrollbar != 0) {
            this.usedButton = true;
        }
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, -2130706433, 16777215);
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, 0, Integer.MIN_VALUE);
        final int var4 = (int)(this.field_146295_m / 2 - this.field_146295_m / 2.5);
        final int var5 = 20;
        final int var6 = 100;
        final int var7 = this.field_146294_l / 2;
        func_73734_a(var7 - var6 / 24 - 4, 0, var7 + var6 / 3 + 91 + 60 + 28, this.field_146295_m, Integer.MIN_VALUE);
        final int ws = var7 + var6 / 3 + 91 + 60 + 20;
        final int we = var7 + var6 / 3 + 91 + 60 + 28;
        int hs = 0 + this.scrollbar;
        int he = 32 + this.scrollbar;
        if (hs < 0) {
            this.scrollbar = 0;
        }
        if (he > this.field_146295_m) {
            this.scrollbar = this.field_146295_m - 32;
        }
        func_73734_a(ws, 0, we, this.field_146295_m, Integer.MIN_VALUE);
        func_73734_a(ws, hs, we, he, Integer.MAX_VALUE);
        boolean mouseOver = false;
        if (par1 > ws && par1 < we && par2 > hs && par2 < he) {
            mouseOver = true;
            if (Mouse.isButtonDown(0)) {
                this.dragging = true;
            }
        }
        else if (!Mouse.isButtonDown(0)) {
            this.dragging = false;
        }
        if ((mouseOver && this.dragging) || this.dragging) {
            if (hs > -1 && he < this.field_146295_m + 1) {
                this.scrollbar = par2 + (hs - he) / 2;
                hs = 0 + this.scrollbar;
                he = 32 + this.scrollbar;
                if (hs < 0) {
                    this.scrollbar = 0;
                }
                if (he > this.field_146295_m) {
                    this.scrollbar = this.field_146295_m - 32;
                }
            }
            this.usedButton = true;
        }
        else {
            this.dragging = false;
        }
        final int mmi = Mouse.getDWheel();
        hs = 0 + this.scrollbar;
        he = 32 + this.scrollbar;
        if (hs > -1 && he < this.field_146295_m + 1) {
            if (mmi > 0) {
                this.usedButton = true;
                this.scrollbar -= 5;
            }
            if (mmi < 0) {
                this.usedButton = true;
                this.scrollbar += 5;
            }
        }
        hs = 0 + this.scrollbar;
        he = 32 + this.scrollbar;
        if (hs < 0) {
            this.scrollbar = 0;
        }
        if (he > this.field_146295_m) {
            this.scrollbar = this.field_146295_m - 32;
        }
        this.calculatedPercentage = hs / (Math.max(1, this.field_146295_m - 32) / 100);
        if (16 - this.scrollbar * 3 > 0) {
            String s = "Loot table";
            this.func_73731_b(this.field_146289_q, s, this.field_146294_l / 2 + 104 - this.field_146289_q.func_78256_a(s) / 2, 4 - this.scrollbar * 3, 16777215);
            s = "Apply to save changes.";
            this.func_73731_b(this.field_146289_q, s, this.field_146294_l / 2 + 104 - this.field_146289_q.func_78256_a(s) / 2, 12 - this.scrollbar * 3, 16777215);
        }
        final int size = 105;
        final int size2 = 45;
        final int offset = 48;
        final String var8 = "2.1.4_beta";
        final String var9 = "Minecraft 1.7.10 | Copyright Mojang AB. Do not distribute!";
        this.func_73731_b(this.field_146289_q, var9, this.field_146294_l - this.field_146289_q.func_78256_a(var9) - 2, this.field_146295_m - 10, 16777215);
        this.func_73731_b(this.field_146289_q, "DayM (2.1.4_beta DevBuild)", 4, this.field_146295_m - 10, 16777215);
        super.func_73863_a(par1, par2, par3);
    }
}
