package com.daym.gui;

import net.minecraft.client.resources.*;
import com.daym.config.*;
import net.minecraft.client.gui.*;

public class GuiDayMOptions extends GuiScreen
{
    private GuiScreen parent;
    
    public GuiDayMOptions(final GuiScreen p) {
        this.parent = p;
    }
    
    public void func_73866_w_() {
        this.field_146292_n.clear();
        final byte b0 = -16;
        final boolean flag = true;
        this.field_146292_n.add(new GuiDayMButton(0, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 24 + b0, I18n.func_135052_a("menu.returnToGame", new Object[0])));
        this.field_146292_n.add(new GuiDayMButton(1, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 48 + b0, 98, 20, "RenderHD: " + DayMConfig.daym_8fd972390));
        this.field_146292_n.add(new GuiDayMButton(4, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 48 + b0 + 24, 98, 20, "RenderHDGroundItems: " + DayMConfig.daym_8fd972390GroundItem));
        this.field_146292_n.add(new GuiDayMButton(2, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 48 + b0 + 48, 98, 20, "Hold to Zoom: " + DayMConfig.daym_fe7a127e0));
        this.field_146292_n.add(new GuiDayMButton(3, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 48 + b0 + 72, 98, 20, "Render FP Body: " + DayMConfig.renderBody));
    }
    
    protected void func_146284_a(final GuiButton b) {
        boolean refreshScreen = false;
        if (b.field_146127_k == 1) {
            DayMConfig.daym_8fd972390 = !DayMConfig.daym_8fd972390;
            DayMConfig.saveProp(DayMConfig.props, DayMConfig.daym_8fd972390, "HDModels");
            refreshScreen = true;
        }
        if (b.field_146127_k == 2) {
            DayMConfig.daym_fe7a127e0 = !DayMConfig.daym_fe7a127e0;
            DayMConfig.saveProp(DayMConfig.props, DayMConfig.daym_fe7a127e0, "AutoUnzoom");
            refreshScreen = true;
        }
        if (b.field_146127_k == 3) {
            DayMConfig.renderBody = !DayMConfig.renderBody;
            DayMConfig.saveProp(DayMConfig.props, DayMConfig.renderBody, "renderBody");
            refreshScreen = true;
        }
        if (b.field_146127_k == 4) {
            DayMConfig.daym_8fd972390GroundItem = !DayMConfig.daym_8fd972390GroundItem;
            DayMConfig.saveProp(DayMConfig.props, DayMConfig.daym_8fd972390GroundItem, "HDGroundItem");
            refreshScreen = true;
        }
        DayMConfig.daym_c651688a0(DayMConfig.cfgdir, DayMConfig.cfgfile, DayMConfig.props);
        if (b.field_146127_k == 0) {
            this.field_146297_k.func_147108_a(this.parent);
        }
        if (refreshScreen) {
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
    }
    
    public void func_73876_c() {
        super.func_73876_c();
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        this.func_146276_q_();
        this.func_73732_a(this.field_146289_q, I18n.func_135052_a("daym.gui.ingame.options", new Object[0]), this.field_146294_l / 2, 40, 16777215);
        super.func_73863_a(par1, par2, par3);
    }
}
