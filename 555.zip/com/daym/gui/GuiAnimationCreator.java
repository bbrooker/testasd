package com.daym.gui;

import cpw.mods.fml.relauncher.*;
import net.minecraft.util.*;
import java.text.*;
import com.daym.render.*;
import java.util.*;
import net.minecraft.client.gui.*;
import java.awt.*;
import java.io.*;
import java.awt.datatransfer.*;
import java.net.*;
import net.minecraft.world.storage.*;
import net.minecraft.client.renderer.*;

@SideOnly(Side.CLIENT)
public class GuiAnimationCreator extends GuiScreen implements GuiYesNoCallback
{
    Random random;
    private StringTranslate stringTranslate;
    private boolean usedButton;
    
    public GuiAnimationCreator() {
        this.random = new Random();
        this.usedButton = false;
        this.stringTranslate = new StringTranslate();
    }
    
    public void func_73876_c() {
        if (this.usedButton) {
            for (final Object button : this.field_146292_n) {
                if (button instanceof GuiDayMSlider) {
                    final GuiDayMSlider slider = (GuiDayMSlider)button;
                    final int id = slider.field_146127_k;
                    final float val = slider.sliderValue - 5000.0f;
                    final DecimalFormat df = new DecimalFormat();
                    df.setMaximumFractionDigits(3);
                    if (id == 2) {
                        RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug] = val / (2500.0f * RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug]);
                        slider.field_146126_j = "X | " + df.format(RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 3) {
                        RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug] = val / (2500.0f * RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug]);
                        slider.field_146126_j = "Y | " + df.format(RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 4) {
                        RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug] = val / (2500.0f * RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug]);
                        slider.field_146126_j = "Z | " + df.format(RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 5) {
                        RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug] = val / (80.0f * RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug]);
                        slider.field_146126_j = "RX | " + df.format(RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 6) {
                        RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug] = val / (80.0f * RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug]);
                        slider.field_146126_j = "RY | " + df.format(RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 7) {
                        RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug] = val / (80.0f * RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug]);
                        slider.field_146126_j = "RZ | " + df.format(RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 8) {
                        df.setMaximumFractionDigits(5);
                        RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug] = val / 2500000.0f;
                        slider.field_146126_j = "SP | " + df.format(RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id != 9) {
                        continue;
                    }
                    float fval = (val + 5000.0f) / 5000.0f * 2.0f;
                    if (fval == 0.0f) {
                        fval = 0.001f;
                    }
                    RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug] = fval;
                    slider.field_146126_j = "Slider Sensitivity | " + RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug];
                }
            }
        }
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    protected void func_73869_a(final char par1, final int par2) {
    }
    
    public void func_73866_w_() {
        final int var4 = 8;
        final int var5 = 22;
        final int var6 = 50;
        final int var7 = var6 + 4;
        final int yOffset = 0;
        final int xOffset = -90;
        this.field_146292_n.add(new GuiDayMButton(25, 0, "left", var5, 253, var4, 20, "AnimPart: " + this.getAnimpart(RenderSetup.daym_6b1c3e8e0Debug)));
        this.field_146292_n.add(new GuiDayMButton(24, 0, "center", var5, 223, var4, 20, "Paste animkey"));
        this.field_146292_n.add(new GuiDayMButton(23, 0, "center", var5, 164, var4, 20, "Copy animkey"));
        this.field_146292_n.add(new GuiDayMButton(22, 0, "center", var5, 121, var4, 20, "Setup"));
        this.field_146292_n.add(new GuiDayMButton(21, 0, "center", var5, 94, var4, 20, "Play"));
        this.field_146292_n.add(new GuiDayMButton(20, 0, "center", var5, 71, var4, 20, "Add"));
        this.field_146292_n.add(new GuiDayMButton(0, 0, "center", var5, 45, var4, 20, "Reset"));
        this.field_146292_n.add(new GuiDayMButton(1, 0, "center", var5, 16, var4, 20, "Close"));
        this.field_146292_n.add(new GuiDayMSlider(2, var7 - var6, var4 + 24, "X | " + RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug], 5000.0f));
        this.field_146292_n.add(new GuiDayMSlider(3, var7 - var6, var4 + 24 + 24, "Y | " + RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug], 5000.0f));
        this.field_146292_n.add(new GuiDayMSlider(4, var7 - var6, var4 + 24 + 48, "Z | " + RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug], 5000.0f));
        this.field_146292_n.add(new GuiDayMSlider(5, var7 - var6, var4 + 24 + 72, "RX | " + RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug], 5000.0f));
        this.field_146292_n.add(new GuiDayMSlider(6, var7 - var6, var4 + 24 + 96, "RY | " + RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug], 5000.0f));
        this.field_146292_n.add(new GuiDayMSlider(7, var7 - var6, var4 + 24 + 120, "RZ | " + RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug], 5000.0f));
        this.field_146292_n.add(new GuiDayMSlider(8, var7 - var6, var4 + 24 + 144, "SP | " + RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug], 5045.0f));
        this.field_146292_n.add(new GuiDayMSlider(9, var7 - var6, var4 + 24 + 168, "ACS | " + RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug], 5000.0f));
        for (int i = 0; i < 8; ++i) {
            this.field_146292_n.add(new GuiDayMButton(102 + i, 0, "left", var5, 205, var4 + 24 * (i + 1), 20, "R"));
        }
        for (final Object button : this.field_146292_n) {
            if (button instanceof GuiDayMSlider) {
                final GuiDayMSlider slider = (GuiDayMSlider)button;
                if (slider.field_146127_k == 2) {
                    slider.sliderValue = RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug] * 2500.0f * 2.0f + 5000.0f;
                }
                if (slider.field_146127_k == 3) {
                    slider.sliderValue = RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug] * 2500.0f * 2.0f + 5000.0f;
                }
                if (slider.field_146127_k == 4) {
                    slider.sliderValue = RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug] * 2500.0f * 2.0f + 5000.0f;
                }
                if (slider.field_146127_k == 5) {
                    slider.sliderValue = RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug] * 80.0f * 2.0f + 5000.0f;
                }
                if (slider.field_146127_k == 6) {
                    slider.sliderValue = RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug] * 80.0f * 2.0f + 5000.0f;
                }
                if (slider.field_146127_k == 7) {
                    slider.sliderValue = RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug] * 80.0f * 2.0f + 5000.0f;
                }
                if (slider.field_146127_k != 8) {
                    continue;
                }
                slider.sliderValue = (RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug] * 45000.0f * 2.0f + 5000.0f) * 2.0f;
            }
        }
    }
    
    private String getAnimpart(final int daym_6b1c3e8e0Debug) {
        if (daym_6b1c3e8e0Debug == 0) {
            return "weapon";
        }
        if (daym_6b1c3e8e0Debug == 1) {
            return "left hand";
        }
        if (daym_6b1c3e8e0Debug == 2) {
            return "right hand";
        }
        return "error";
    }
    
    protected void func_146284_a(final GuiButton par1GuiButton) {
        if (par1GuiButton.field_146127_k == 1) {
            this.field_146297_k.field_71462_r = null;
            this.field_146297_k.func_71381_h();
        }
        if (par1GuiButton.field_146127_k == 0) {
            RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
            RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
            RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
            RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
            RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
            RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
            RenderSetup.r0[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
            RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug] = 0.001f;
            RenderSetup.daym_b73359c80.clear();
            RenderSetup.daym_8ff2912f0.setupAnims();
            RenderSetup.daym_8ff2912f0.doAnimation("reset");
            this.field_146297_k.func_147108_a((GuiScreen)new GuiAnimationCreator());
        }
        if (par1GuiButton.field_146127_k == 102) {
            RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
        }
        if (par1GuiButton.field_146127_k == 103) {
            RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
        }
        if (par1GuiButton.field_146127_k == 104) {
            RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
        }
        if (par1GuiButton.field_146127_k == 105) {
            RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
        }
        if (par1GuiButton.field_146127_k == 106) {
            RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
        }
        if (par1GuiButton.field_146127_k == 107) {
            RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
        }
        if (par1GuiButton.field_146127_k == 108) {
            RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug] = 0.001f;
        }
        if (par1GuiButton.field_146127_k == 109) {
            RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug] = 2.0f;
        }
        if (par1GuiButton.field_146127_k > 101 && par1GuiButton.field_146127_k < 110) {
            for (final Object button : this.field_146292_n) {
                if (button instanceof GuiDayMSlider) {
                    final GuiDayMSlider slider = (GuiDayMSlider)button;
                    if (slider.field_146127_k != par1GuiButton.field_146127_k - 100) {
                        continue;
                    }
                    final int id = slider.field_146127_k;
                    final DecimalFormat df = new DecimalFormat();
                    df.setMaximumFractionDigits(3);
                    if (id == 2) {
                        RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
                        slider.field_146126_j = "X | " + df.format(RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 3) {
                        RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
                        slider.field_146126_j = "Y | " + df.format(RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 4) {
                        RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
                        slider.field_146126_j = "Z | " + df.format(RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 5) {
                        RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
                        slider.field_146126_j = "RX | " + df.format(RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 6) {
                        RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
                        slider.field_146126_j = "RY | " + df.format(RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 7) {
                        RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug] = 0.0f;
                        slider.field_146126_j = "RZ | " + df.format(RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 8) {
                        df.setMaximumFractionDigits(5);
                        RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug] = 0.001f;
                        slider.field_146126_j = "SP | " + df.format(RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug]);
                    }
                    if (id == 9) {
                        RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug] = 2.0f;
                        slider.field_146126_j = "Slider Sensitivity | " + RenderSetup.animSensitivity[RenderSetup.daym_6b1c3e8e0Debug];
                    }
                    if (slider.field_146127_k == 2) {
                        slider.sliderValue = RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug] * 2500.0f * 2.0f + 5000.0f;
                    }
                    if (slider.field_146127_k == 3) {
                        slider.sliderValue = RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug] * 2500.0f * 2.0f + 5000.0f;
                    }
                    if (slider.field_146127_k == 4) {
                        slider.sliderValue = RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug] * 2500.0f * 2.0f + 5000.0f;
                    }
                    if (slider.field_146127_k == 5) {
                        slider.sliderValue = RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug] * 80.0f * 2.0f + 5000.0f;
                    }
                    if (slider.field_146127_k == 6) {
                        slider.sliderValue = RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug] * 80.0f * 2.0f + 5000.0f;
                    }
                    if (slider.field_146127_k == 7) {
                        slider.sliderValue = RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug] * 80.0f * 2.0f + 5000.0f;
                    }
                    if (slider.field_146127_k != 8) {
                        continue;
                    }
                    slider.sliderValue = (RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug] * 45000.0f * 2.0f + 5000.0f) * 2.0f;
                }
            }
        }
        if (par1GuiButton.field_146127_k == 20) {
            RenderSetup.daym_b73359c80.add(RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug] + "|" + RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug] + "|" + RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug] + "|" + RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug] + "|" + RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug] + "|" + RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug] + "|" + RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug]);
            this.field_146297_k.func_147108_a((GuiScreen)new GuiAnimationCreator());
        }
        if (par1GuiButton.field_146127_k == 21) {
            RenderSetup.daym_8ff2912f0.doAnimation("reset");
            RenderSetup.daym_8ff2912f0.setAnimationFrame(0);
        }
        if (par1GuiButton.field_146127_k == 22) {
            RenderSetup.daym_8ff2912f0.setupAnims();
        }
        if (par1GuiButton.field_146127_k == 23) {
            final String animkey = RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug] + "f," + RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug] + "f," + RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug] + "f,0f," + RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug] + "f," + RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug] + "f," + RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug] + "f," + RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug] + "f";
            final StringSelection stringSelection = new StringSelection(animkey);
            final Clipboard clpbrd = Toolkit.getDefaultToolkit().getSystemClipboard();
            clpbrd.setContents(stringSelection, null);
        }
        if (par1GuiButton.field_146127_k == 24) {
            final Clipboard clpbrd2 = Toolkit.getDefaultToolkit().getSystemClipboard();
            final Transferable contents = clpbrd2.getContents(null);
            String result = "";
            if (contents != null) {
                try {
                    result = (String)contents.getTransferData(DataFlavor.stringFlavor);
                }
                catch (UnsupportedFlavorException e) {
                    e.printStackTrace();
                }
                catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
            if (result != "") {
                this.decodeDebugAnimsFP(result);
            }
        }
        if (par1GuiButton.field_146127_k == 25) {
            if (RenderSetup.daym_6b1c3e8e0Debug < 2) {
                ++RenderSetup.daym_6b1c3e8e0Debug;
            }
            else {
                RenderSetup.daym_6b1c3e8e0Debug = 0;
            }
            this.field_146297_k.func_147108_a((GuiScreen)new GuiAnimationCreator());
        }
        this.usedButton = true;
    }
    
    private void decodeDebugAnimsFP(final String result) {
        final String[] data = result.split("\\,");
        try {
            RenderSetup.lx[RenderSetup.daym_6b1c3e8e0Debug] = Float.parseFloat(data[0]);
            RenderSetup.ly[RenderSetup.daym_6b1c3e8e0Debug] = Float.parseFloat(data[1]);
            RenderSetup.lz[RenderSetup.daym_6b1c3e8e0Debug] = Float.parseFloat(data[2]);
            RenderSetup.r0[RenderSetup.daym_6b1c3e8e0Debug] = Float.parseFloat(data[3]);
            RenderSetup.rx[RenderSetup.daym_6b1c3e8e0Debug] = Float.parseFloat(data[4]);
            RenderSetup.ry[RenderSetup.daym_6b1c3e8e0Debug] = Float.parseFloat(data[5]);
            RenderSetup.rz[RenderSetup.daym_6b1c3e8e0Debug] = Float.parseFloat(data[6]);
            RenderSetup.speed[RenderSetup.daym_6b1c3e8e0Debug] = Float.parseFloat(data[7]);
            this.field_146297_k.func_147108_a((GuiScreen)new GuiAnimationCreator());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void func_73878_a(final boolean par1, final int par2) {
        if (par1 && par2 == 12) {
            final ISaveFormat var6 = this.field_146297_k.func_71359_d();
            var6.func_75800_d();
            var6.func_75802_e("Demo_World");
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
        else if (par2 == 13) {
            if (par1) {
                try {
                    final Class var7 = Class.forName("java.awt.Desktop");
                    final Object var8 = var7.getMethod("getDesktop", (Class[])new Class[0]).invoke(null, new Object[0]);
                    var7.getMethod("browse", URI.class).invoke(var8, new URI("http://tinyurl.com/javappc"));
                }
                catch (Throwable var9) {
                    var9.printStackTrace();
                }
            }
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        final Tessellator var4 = Tessellator.field_78398_a;
        final short var5 = 274;
        final int var6 = this.field_146294_l / 2 - var5 / 2;
        final byte var7 = 30;
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, -2130706433, 16777215);
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, 0, Integer.MIN_VALUE);
        final int size = 105;
        final int size2 = 45;
        final int offset = 48;
        final String var8 = "2.1.4_beta";
        final String var9 = "Minecraft 1.7.10 | Copyright Mojang AB. Do not distribute!";
        this.func_73731_b(this.field_146289_q, var9, this.field_146294_l - this.field_146289_q.func_78256_a(var9) - 2, this.field_146295_m - 10, 16777215);
        this.func_73731_b(this.field_146289_q, "DayM (2.1.4_beta DevBuild)", 4, this.field_146295_m - 10, 16777215);
        super.func_73863_a(par1, par2, par3);
    }
}
