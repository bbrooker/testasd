package com.daym.gui;

import cpw.mods.fml.relauncher.*;
import java.util.*;
import net.minecraft.util.*;
import com.daym.*;
import com.daym.config.*;
import com.daym.handlers.*;
import net.minecraft.client.gui.*;
import org.lwjgl.opengl.*;
import com.daym.registry.*;
import net.minecraft.client.renderer.*;
import com.daym.render.*;
import java.awt.*;

@SideOnly(Side.CLIENT)
public class GuiCustomizeCharacter extends GuiScreen implements GuiYesNoCallback
{
    Random random;
    private StringTranslate stringTranslate;
    
    public GuiCustomizeCharacter() {
        this.random = new Random();
        this.stringTranslate = new StringTranslate();
    }
    
    public void func_73876_c() {
        if (DayM.daym_e1d8ee710.mtcm_posX < 10.0f) {
            final GuiVarHandler daym_e1d8ee710 = DayM.daym_e1d8ee710;
            daym_e1d8ee710.mtcm_posX += 0.8f;
        }
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    protected void func_73869_a(final char par1, final int par2) {
    }
    
    public void func_73866_w_() {
        final int var4 = this.field_146295_m / 4 + 14;
        final int var5 = 22;
        final int yOffset = 0;
        final int xOffset = -90;
        final String daym_d836addc0Text = this.getSkinType(DayMConfig.daym_d836addc0);
        final String genderText = DayMConfig.daym_8eb8ec9d0 ? "daym.gui.character.female" : "daym.gui.character.male";
        this.field_146292_n.add(new GuiDayMButton(1, 1, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.character.gender") + " : " + LanguageHandler.translate(genderText)));
        this.field_146292_n.add(new GuiDayMButton(2, 2, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.character.currentskin") + " : " + daym_d836addc0Text));
        this.field_146292_n.add(new GuiDayMButton(3, 3, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.character.currentshirt") + " : " + (DayMConfig.daym_bed00c4b0 - 2)));
        this.field_146292_n.add(new GuiDayMButton(4, 4, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.character.currentpants") + " : " + DayMConfig.daym_94a3461e0));
        this.field_146292_n.add(new GuiDayMButton(0, 5, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.back")));
    }
    
    private String getSkinType(final int daym_d836addc0) {
        if (daym_d836addc0 == 6) {
            return "Your Skin";
        }
        return "Skin " + daym_d836addc0;
    }
    
    protected void func_146284_a(final GuiButton par1GuiButton) {
        boolean refreshScreen = false;
        if (par1GuiButton.field_146127_k == 1) {
            DayMConfig.daym_8eb8ec9d0 = !DayMConfig.daym_8eb8ec9d0;
            DayMConfig.saveProp(DayMConfig.props, DayMConfig.daym_8eb8ec9d0, "daym_8eb8ec9d0");
            refreshScreen = true;
        }
        if (par1GuiButton.field_146127_k == 2) {
            if (DayMConfig.daym_d836addc0 < 4) {
                ++DayMConfig.daym_d836addc0;
            }
            else {
                DayMConfig.daym_d836addc0 = 0;
            }
            DayMConfig.saveProp(DayMConfig.props, DayMConfig.daym_d836addc0, "playerSkin");
            refreshScreen = true;
        }
        if (par1GuiButton.field_146127_k == 3) {
            if (DayMConfig.daym_bed00c4b0 < 8) {
                ++DayMConfig.daym_bed00c4b0;
            }
            else {
                DayMConfig.daym_bed00c4b0 = 2;
            }
            DayMConfig.saveProp(DayMConfig.props, DayMConfig.daym_bed00c4b0, "playerSkinShirt");
            refreshScreen = true;
        }
        if (par1GuiButton.field_146127_k == 4) {
            if (DayMConfig.daym_94a3461e0 < 3) {
                ++DayMConfig.daym_94a3461e0;
            }
            else {
                DayMConfig.daym_94a3461e0 = 0;
            }
            DayMConfig.saveProp(DayMConfig.props, DayMConfig.daym_94a3461e0, "playerSkinPants");
            refreshScreen = true;
        }
        DayMConfig.daym_c651688a0(DayMConfig.cfgdir, DayMConfig.cfgfile, DayMConfig.props);
        if (par1GuiButton.field_146127_k == 0) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiDaymMainMenu());
        }
        if (refreshScreen) {
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
    }
    
    public void func_73878_a(final boolean par1, final int par2) {
    }
    
    private void drawDayMLogo() {
        GL11.glPushMatrix();
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(3008);
        GL11.glEnable(3042);
        TextureRegistry.bindResource(TextureRegistry.mainmenu_logoTexture);
        final Tessellator var3 = Tessellator.field_78398_a;
        var3.func_78382_b();
        final int size = 105 + this.field_146294_l / 24;
        final int size2 = 45 + this.field_146295_m / 24;
        final int offset = 32 + this.field_146295_m / 24;
        final float var4 = RenderSetup.getTime() / 512.0f;
        var3.func_78374_a((double)(this.field_146294_l / 2 - size), (double)(offset + size2 + 2), -90.0, 0.0, 1.0);
        var3.func_78374_a((double)(this.field_146294_l / 2 + size), (double)(offset + size2 + 2), -90.0, 1.0, 1.0);
        var3.func_78374_a((double)(this.field_146294_l / 2 + size), (double)(offset + -size2 + 2), -90.0, 1.0, 0.0);
        var3.func_78374_a((double)(this.field_146294_l / 2 - size), (double)(offset + -size2 + 2), -90.0, 0.0, 0.0);
        var3.func_78381_a();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glEnable(3008);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    public boolean isMouseOver(final int par1, final int par2, final int x, final int y, final int xx, final int yy) {
        return par1 > x && par1 < xx && par2 > y && par2 < yy;
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        RenderSetup.renderBackgroundAndPlayer(this.field_146294_l, this.field_146295_m, par1, par2, par3);
        final Tessellator var4 = Tessellator.field_78398_a;
        final short var5 = 274;
        final int var6 = this.field_146294_l / 2 - var5 / 2;
        final byte var7 = 30;
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, -2130706433, 16777215);
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, 0, Integer.MIN_VALUE);
        final int size = 105;
        final int size2 = 45;
        final int offset = 48;
        final String textDaym = "Playing as " + this.field_146297_k.func_110432_I().func_111285_a();
        func_73734_a(1, 1, this.field_146289_q.func_78256_a(textDaym) + 5, 12, Integer.MIN_VALUE);
        this.field_146289_q.func_78261_a(textDaym, 3, 2, Color.white.getRGB());
        final String s = "Character Customization";
        func_73734_a(this.field_146294_l / 2 - this.field_146289_q.func_78256_a(s) - 16, this.field_146295_m / 6, this.field_146294_l / 2 + this.field_146289_q.func_78256_a(s) + 16, this.field_146295_m / 6 + 18, Integer.MIN_VALUE);
        GL11.glPushMatrix();
        GL11.glScalef(2.0f, 2.0f, 2.0f);
        this.field_146289_q.func_78261_a(s, (this.field_146294_l / 2 - this.field_146289_q.func_78256_a(s)) / 2, this.field_146295_m / 6 / 2, Color.white.getRGB());
        GL11.glPopMatrix();
        final String var8 = "2.1.4_beta";
        final String var9 = "Minecraft 1.7.10 | Copyright Mojang AB. Do not distribute!";
        final String var10 = "Resource pack made from: Faithful 32x32";
        final Color color1 = new Color(100, 125, 255);
        this.func_73731_b(this.field_146289_q, var9, this.field_146294_l - this.field_146289_q.func_78256_a(var9) - 2, this.field_146295_m - 10, 16777215);
        this.func_73731_b(this.field_146289_q, "DayM (2.1.4_beta DevBuild)", 4, this.field_146295_m - 10, 16777215);
        this.func_73731_b(this.field_146289_q, var10, this.field_146294_l - this.field_146289_q.func_78256_a(var10) - 2, this.field_146295_m - 18, color1.getRGB());
        super.func_73863_a(par1, par2, par3);
    }
}
