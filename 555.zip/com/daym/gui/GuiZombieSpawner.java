package com.daym.gui;

import cpw.mods.fml.relauncher.*;
import com.daym.handlers.*;
import java.util.*;
import net.minecraft.client.gui.*;
import com.daym.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.util.*;
import java.net.*;
import net.minecraft.world.storage.*;
import net.minecraft.client.renderer.*;

@SideOnly(Side.CLIENT)
public class GuiZombieSpawner extends GuiScreen implements GuiYesNoCallback
{
    Random random;
    private StringTranslate stringTranslate;
    private boolean usedButton;
    
    public GuiZombieSpawner() {
        this.random = new Random();
        this.usedButton = false;
        this.stringTranslate = new StringTranslate();
    }
    
    public void func_73876_c() {
        if (this.usedButton) {
            for (final Object button : this.field_146292_n) {
                if (button instanceof GuiDayMSlider) {
                    final GuiDayMSlider slider = (GuiDayMSlider)button;
                    final int id = slider.field_146127_k;
                    final float val = slider.sliderValue;
                    if (id == 2) {
                        WorldVarHandler.daym_91c21be00 = (int)(val / 51.0f) / 100;
                        slider.field_146126_j = "zs type: " + WorldVarHandler.daym_91c21be00;
                    }
                    if (id == 3) {
                        WorldVarHandler.daym_7b9f69410 = (int)(val / 100.0f);
                        slider.field_146126_j = "zs spawnChance: %" + WorldVarHandler.daym_7b9f69410;
                    }
                    if (id == 4) {
                        WorldVarHandler.daym_82c209f00 = (int)(val / 4.0f / 100.0f) + 1;
                        slider.field_146126_j = "zs spawnRadius: " + WorldVarHandler.daym_82c209f00 + " blocks";
                    }
                    if (id == 5) {
                        WorldVarHandler.daym_47241d9f0 = (int)(val / 5.0f) / 100;
                        slider.field_146126_j = "zs amountSpawn: " + WorldVarHandler.daym_47241d9f0;
                    }
                    if (id != 6) {
                        continue;
                    }
                    WorldVarHandler.daym_fc4e31e70 = (int)(val / 51.0f) / 100;
                    slider.field_146126_j = "zs randAmount: " + WorldVarHandler.daym_fc4e31e70;
                }
            }
        }
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    protected void func_73869_a(final char par1, final int par2) {
    }
    
    public void func_73866_w_() {
        final int var4 = (int)(this.field_146295_m / 2 - this.field_146295_m / 2.5);
        final int var5 = 20;
        final int var6 = 100;
        final int var7 = this.field_146294_l / 2;
        final int yOffset = 0;
        final int xOffset = -90;
        this.field_146292_n.add(new GuiDayMButton(1, 0, "center", var5, this.field_146294_l / 2, var4, 20, "Close"));
        final GuiDayMSlider slider = new GuiDayMSlider(2, var7 - var6, var4 + 24, "zs type: " + WorldVarHandler.daym_91c21be00, WorldVarHandler.daym_91c21be00 * 51.0f * 100.0f);
        slider.field_146124_l = false;
        this.field_146292_n.add(slider);
        this.field_146292_n.add(new GuiDayMSlider(3, var7 - var6, var4 + 72, "zs spawnChance: " + WorldVarHandler.daym_7b9f69410, WorldVarHandler.daym_7b9f69410 * 100));
        this.field_146292_n.add(new GuiDayMSlider(4, var7 - var6, var4 + 96, "zs spawnRadius: " + WorldVarHandler.daym_82c209f00, WorldVarHandler.daym_82c209f00 * 4.0f * 100.0f));
        this.field_146292_n.add(new GuiDayMSlider(5, var7 - var6, var4 + 48, "zs amountSpawn: " + WorldVarHandler.daym_47241d9f0, WorldVarHandler.daym_47241d9f0 * 5.0f * 100.0f));
        this.field_146292_n.add(new GuiDayMSlider(6, var7 - var6, var4 + 120, "zs randAmount: " + WorldVarHandler.daym_fc4e31e70, WorldVarHandler.daym_fc4e31e70 * 51.0f * 100.0f));
        this.field_146292_n.add(new GuiDayMButton(0, 0, "center", var5, this.field_146294_l / 2, var4 + 144, 20, "Apply"));
    }
    
    protected void func_146284_a(final GuiButton par1GuiButton) {
        if (par1GuiButton.field_146127_k == 1) {
            this.field_146297_k.field_71462_r = null;
            this.field_146297_k.func_71381_h();
        }
        this.usedButton = true;
        if (par1GuiButton.field_146127_k == 0) {
            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_ZombieSpawner(0, WorldVarHandler.daym_91c21be00, WorldVarHandler.daym_7b9f69410, WorldVarHandler.daym_82c209f00, WorldVarHandler.daym_47241d9f0, WorldVarHandler.daym_fc4e31e70, WorldVarHandler.daym_d968810a0, WorldVarHandler.daym_fbd202650, WorldVarHandler.daym_b8e432020));
            final IChatComponent test = (IChatComponent)new ChatComponentText("Added Zombie Spawner at: " + WorldVarHandler.daym_d968810a0 + ", " + WorldVarHandler.daym_fbd202650 + ", " + WorldVarHandler.daym_b8e432020);
            this.field_146297_k.field_71439_g.func_145747_a(test);
            this.field_146297_k.field_71462_r = null;
            this.field_146297_k.func_71381_h();
        }
    }
    
    public void func_73878_a(final boolean par1, final int par2) {
        if (par1 && par2 == 12) {
            final ISaveFormat var6 = this.field_146297_k.func_71359_d();
            var6.func_75800_d();
            var6.func_75802_e("Demo_World");
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
        else if (par2 == 13) {
            if (par1) {
                try {
                    final Class var7 = Class.forName("java.awt.Desktop");
                    final Object var8 = var7.getMethod("getDesktop", (Class[])new Class[0]).invoke(null, new Object[0]);
                    var7.getMethod("browse", URI.class).invoke(var8, new URI("http://tinyurl.com/javappc"));
                }
                catch (Throwable var9) {
                    var9.printStackTrace();
                }
            }
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        final Tessellator var4 = Tessellator.field_78398_a;
        final short var5 = 274;
        final int var6 = this.field_146294_l / 2 - var5 / 2;
        final byte var7 = 30;
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, -2130706433, 16777215);
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, 0, Integer.MIN_VALUE);
        final int size = 105;
        final int size2 = 45;
        final int offset = 48;
        final String var8 = "2.1.4_beta";
        final String var9 = "Minecraft 1.7.10 | Copyright Mojang AB. Do not distribute!";
        this.func_73731_b(this.field_146289_q, var9, this.field_146294_l - this.field_146289_q.func_78256_a(var9) - 2, this.field_146295_m - 10, 16777215);
        this.func_73731_b(this.field_146289_q, "DayM (2.1.4_beta DevBuild)", 4, this.field_146295_m - 10, 16777215);
        super.func_73863_a(par1, par2, par3);
    }
}
