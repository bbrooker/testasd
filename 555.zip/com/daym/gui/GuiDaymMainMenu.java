package com.daym.gui;

import cpw.mods.fml.relauncher.*;
import net.minecraft.util.*;
import com.daym.threads.*;
import net.minecraft.client.*;
import com.daym.*;
import com.daym.clientproxy.*;
import cpw.mods.fml.common.*;
import java.util.*;
import com.daym.handlers.*;
import net.minecraft.client.gui.*;
import cpw.mods.fml.client.*;
import java.net.*;
import net.minecraft.world.storage.*;
import org.lwjgl.opengl.*;
import com.daym.registry.*;
import net.minecraft.client.renderer.*;
import com.daym.render.*;
import java.awt.*;
import org.lwjgl.input.*;

@SideOnly(Side.CLIENT)
public class GuiDaymMainMenu extends GuiScreen implements GuiYesNoCallback
{
    Random random;
    private StringTranslate stringTranslate;
    private float logoRotation;
    private boolean daym_908ef7fc0;
    private boolean mousePressed;
    private int randomClothing;
    private OfficialSLThread daym_98717f180;
    private float timer;
    private int daym_ce8384310;
    public static boolean daym_f8098c6c0;
    public boolean daym_ae5230ec0;
    
    public GuiDaymMainMenu() {
        this.random = new Random();
        this.logoRotation = 0.0f;
        this.daym_908ef7fc0 = true;
        this.mousePressed = false;
        this.daym_ae5230ec0 = true;
        this.field_146297_k = Minecraft.func_71410_x();
        this.stringTranslate = new StringTranslate();
        (this.daym_98717f180 = new OfficialSLThread(DayM.daym_1a33edfd0 + "data/version.daym", "version")).start();
        DayM.forceUnicode();
        if (ClientProxy.daym_b7fb94700 == null) {
            ClientProxy.daym_b7fb94700 = SoundHandlerDayM.playSoundLoop("ambient_forest", 0.25f, 1.0f, "forest", false);
        }
        if (DayM.daym_5aeef7d50 == 203L) {
            DayM.daym_5aeef7d50 = this.hashCode();
        }
        if (Minecraft.func_71410_x().field_71474_y.field_74335_Z == 1) {
            Minecraft.func_71410_x().field_71474_y.field_74335_Z = 2;
        }
        WorldHandler.daym_3bb3f01c0.clear();
        for (final ModContainer mc : Loader.instance().getActiveModList()) {
            if (mc != null && !mc.getModId().toLowerCase().contains("daym") && !mc.getModId().toLowerCase().contains("optifine") && !mc.getModId().toLowerCase().contains("mcp") && !mc.getModId().toLowerCase().contains("fml") && !mc.getModId().toLowerCase().contains("forge")) {
                this.daym_ae5230ec0 = false;
            }
        }
    }
    
    public void func_73876_c() {
        if (this.daym_ce8384310 < 40) {
            ++this.daym_ce8384310;
        }
        if (DayM.daym_e1d8ee710.mtcm_posX > 0.0f) {
            final GuiVarHandler daym_e1d8ee710 = DayM.daym_e1d8ee710;
            daym_e1d8ee710.mtcm_posX -= 0.8f;
        }
        if (this.daym_98717f180 != null && this.daym_98717f180.daym_28f500420) {
            this.daym_98717f180 = null;
        }
    }
    
    public void func_146281_b() {
        super.func_146281_b();
        this.daym_ce8384310 = 0;
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    protected void func_73869_a(final char par1, final int par2) {
    }
    
    public void func_73866_w_() {
        final int var4 = this.field_146295_m / 4 + 14;
        final int var5 = 22;
        final int yOffset = 0;
        final int xOffset = -90;
        if (GuiDaymMainMenu.daym_f8098c6c0 && DayM.daym_a252379c0) {
            this.field_146292_n.add(new GuiDayMButton(1, 1, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.solo")));
            this.field_146292_n.add(new GuiDayMButton(2, 2, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.servers")));
            this.field_146292_n.add(new GuiDayMButton(7, 2, "left", var5, this.field_146294_l / 2 + xOffset + this.field_146297_k.field_71466_p.func_78256_a(LanguageHandler.translate("daym.gui.servers")) + 12, var4 + yOffset, 20, "$mcico"));
            this.field_146292_n.add(new GuiDayMButton(9, 3, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.customizechar")));
            this.field_146292_n.add(new GuiDayMButton(0, 4, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, this.stringTranslate.func_74805_b("menu.options")));
            this.field_146292_n.add(new GuiDayMButton(6, 5, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.addons")));
            this.field_146292_n.add(new GuiDayMButton(4, 6, "left", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, this.stringTranslate.func_74805_b("menu.quit")));
        }
        else {
            String varc = "Continue";
            if (!DayM.daym_a252379c0) {
                varc = "Quit";
            }
            this.field_146292_n.add(new GuiDayMButton(8, 5, "left", var5, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(varc) / 2, var4 + yOffset + 16, 20, varc));
        }
    }
    
    protected void func_146284_a(final GuiButton par1GuiButton) {
        if (par1GuiButton.field_146127_k == 0) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiOptions((GuiScreen)this, this.field_146297_k.field_71474_y));
        }
        if (par1GuiButton.field_146127_k == 5) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiLanguage((GuiScreen)this, this.field_146297_k.field_71474_y, this.field_146297_k.func_135016_M()));
        }
        if (par1GuiButton.field_146127_k == 1) {
            final GuiScreen scr = (GuiScreen)new GuiMainMenu();
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, 6));
        }
        if (par1GuiButton.field_146127_k == 8) {
            if (DayM.daym_a252379c0) {
                GuiDaymMainMenu.daym_f8098c6c0 = true;
                this.field_146297_k.func_147108_a((GuiScreen)new GuiDaymMainMenu());
            }
            else {
                this.field_146297_k.func_71400_g();
            }
        }
        if (par1GuiButton.field_146127_k == 7) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerMC(this));
        }
        if (par1GuiButton.field_146127_k == 2) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayer((GuiScreen)this));
        }
        if (par1GuiButton.field_146127_k == 3) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiScreenResourcePacks((GuiScreen)this));
        }
        if (par1GuiButton.field_146127_k == 4) {
            this.field_146297_k.func_71400_g();
        }
        if (par1GuiButton.field_146127_k == 6) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiModList((GuiScreen)this));
        }
        if (par1GuiButton.field_146127_k == 9) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiCustomizeCharacter());
        }
    }
    
    public void func_73878_a(final boolean par1, final int par2) {
        if (par1 && par2 == 12) {
            final ISaveFormat var6 = this.field_146297_k.func_71359_d();
            var6.func_75800_d();
            var6.func_75802_e("Demo_World");
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
        else if (par2 == 13) {
            if (par1) {
                try {
                    final Class var7 = Class.forName("java.awt.Desktop");
                    final Object var8 = var7.getMethod("getDesktop", (Class[])new Class[0]).invoke(null, new Object[0]);
                    var7.getMethod("browse", URI.class).invoke(var8, new URI("http://tinyurl.com/javappc"));
                }
                catch (Throwable var9) {
                    var9.printStackTrace();
                }
            }
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
    }
    
    private void drawDayMLogo() {
        GL11.glPushMatrix();
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(3008);
        GL11.glEnable(3042);
        TextureRegistry.bindResource(TextureRegistry.mainmenu_logoTexture);
        final Tessellator var3 = Tessellator.field_78398_a;
        var3.func_78382_b();
        final int size = 105 + this.field_146294_l / 24;
        final int size2 = 45 + this.field_146295_m / 24;
        final int offset = 32 + this.field_146295_m / 24;
        final float var4 = RenderSetup.getTime() / 512.0f;
        var3.func_78374_a((double)(this.field_146294_l / 2 - size), (double)(offset + size2 + 2), -90.0, 0.0, 1.0);
        var3.func_78374_a((double)(this.field_146294_l / 2 + size), (double)(offset + size2 + 2), -90.0, 1.0, 1.0);
        var3.func_78374_a((double)(this.field_146294_l / 2 + size), (double)(offset + -size2 + 2), -90.0, 1.0, 0.0);
        var3.func_78374_a((double)(this.field_146294_l / 2 - size), (double)(offset + -size2 + 2), -90.0, 0.0, 0.0);
        var3.func_78381_a();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glEnable(3008);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    public boolean isMouseOver(final int par1, final int par2, final int x, final int y, final int xx, final int yy) {
        return par1 > x && par1 < xx && par2 > y && par2 < yy;
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        RenderSetup.renderBackgroundAndPlayer(this.field_146294_l, this.field_146295_m, par1, par2, par3);
        final Tessellator var4 = Tessellator.field_78398_a;
        final short var5 = 274;
        final int var6 = this.field_146294_l / 2 - var5 / 2;
        final byte var7 = 30;
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, -2130706433, 16777215);
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, 0, Integer.MIN_VALUE);
        this.drawDayMLogo();
        final int size = 105;
        final int size2 = 45;
        final int offset = 48;
        final String textDaym = "Playing as " + this.field_146297_k.func_110432_I().func_111285_a();
        func_73734_a(1, 1, this.field_146289_q.func_78256_a(textDaym) + 5, 12, Integer.MIN_VALUE);
        this.field_146289_q.func_78261_a(textDaym, 3, 2, Color.white.getRGB());
        if (!GuiDaymMainMenu.daym_f8098c6c0 || !DayM.daym_a252379c0 || !this.daym_ae5230ec0) {
            if (!this.daym_ae5230ec0) {
                this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, Integer.MIN_VALUE, Integer.MIN_VALUE);
                this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, Integer.MIN_VALUE, Integer.MIN_VALUE);
                String var8 = "Sorry, you're running mods that DayM doesn't support. (This version supports none)";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2 - 24, 16777215);
                var8 = "This will be changed in a later release, however currently to prevent hacks and...";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2 - 12, 16777215);
                var8 = "other mods like mini-maps which reveal player locations... for now only a handfull of mods will be whitelisted.";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2, 16777215);
                var8 = "Next release should have more whitelisted mods. Thanks for understanding.";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2 + 12, 16777215);
            }
            else if (DayM.daym_a252379c0) {
                this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, Integer.MIN_VALUE, Integer.MIN_VALUE);
                this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, Integer.MIN_VALUE, Integer.MIN_VALUE);
                String var8 = "Note: This release of DayM is in early beta, meaning its a unfinished version";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2 - 24, 16777215);
                var8 = "So keep in mind that what you see is not the final mod, but rather a unpolished release.";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2 - 12, 16777215);
                var8 = "Make sure to check out the tutorial in the escape menu when you play.";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2, 16777215);
                var8 = "We recommend to play on the server, for the full experience. Feel free to donate to keep our servers running.";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2 + 12, 16777215);
                var8 = "That is all, have fun playing the mod! :D";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2 + 24, 16777215);
            }
            else {
                this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, Integer.MIN_VALUE, Integer.MIN_VALUE);
                this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, Integer.MIN_VALUE, Integer.MIN_VALUE);
                String var8 = "You're running either a newer or older version of java which is unsupported for DayM.";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2 - 24, 16777215);
                var8 = "Please download Java 7 and uninstall your current version of java.";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2 - 12, 16777215);
                var8 = "@ at java.com/download | Make sure you download java 7. Thanks";
                this.func_73731_b(this.field_146289_q, var8, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var8) / 2, this.field_146295_m / 2, 16777215);
            }
        }
        final String var9 = "2.1.4_beta";
        final String var10 = "Minecraft 1.7.10 | Copyright Mojang AB. Do not distribute!";
        final String var11 = "Resource pack made from: Faithful 32x32";
        final Color color1 = new Color(100, 125, 255);
        this.func_73731_b(this.field_146289_q, var10, this.field_146294_l - this.field_146289_q.func_78256_a(var10) - 2, this.field_146295_m - 10, 16777215);
        this.func_73731_b(this.field_146289_q, "DayM (2.1.4_beta DevBuild)", 4, this.field_146295_m - 10, 16777215);
        this.func_73731_b(this.field_146289_q, var11, this.field_146294_l - this.field_146289_q.func_78256_a(var11) - 2, this.field_146295_m - 18, color1.getRGB());
        final String var12 = "New version of DayM is out! (" + DayM.daym_8907e7060 + ")";
        if (GuiDaymMainMenu.daym_f8098c6c0 && DayM.daym_a252379c0) {
            int col = 16777215;
            if (!DayM.daym_8907e7060.contains("2.1.4_beta") && DayM.daym_8907e7060 != "-1") {
                if (Mouse.isButtonDown(0) && this.mousePressed) {
                    this.mousePressed = false;
                }
                if (this.isMouseOver(par1, par2, 0, this.field_146295_m - 22, this.field_146289_q.func_78256_a(var12), this.field_146295_m - 12)) {
                    col = Color.red.getRGB();
                    if (this.mousePressed) {
                        try {
                            final Class var13 = Class.forName("java.awt.Desktop");
                            final Object var14 = var13.getMethod("getDesktop", (Class[])new Class[0]).invoke(null, new Object[0]);
                            var13.getMethod("browse", URI.class).invoke(var14, new URI(DayM.daym_1a33edfd0 + "/downloads/"));
                        }
                        catch (Throwable var15) {
                            var15.printStackTrace();
                        }
                    }
                }
                if (Mouse.isButtonDown(0) && !this.mousePressed) {
                    this.mousePressed = true;
                }
                else {
                    this.mousePressed = false;
                }
                if (this.isMouseOver(par1, par2, 0, this.field_146295_m - 22, this.field_146289_q.func_78256_a(var12), this.field_146295_m - 12) && this.mousePressed) {
                    col = Color.black.getRGB();
                }
                this.func_73731_b(this.field_146289_q, var12, 4, this.field_146295_m - 22, col);
            }
            if (DayM.daym_8907e7060.contains("2.1.4_beta") && DayM.daym_8907e7060 != "-1" && DayM.daym_a252379c0 && DayM.daym_9b02c5b00.startsWith("1.8.")) {
                this.func_73731_b(this.field_146289_q, "Running on Java 8, (Which has not been tested fully.)", 4, this.field_146295_m - 22, col);
            }
        }
        if (GuiDaymMainMenu.daym_f8098c6c0 && DayM.daym_a252379c0) {
            if (this.isMouseOver(par1, par2, this.field_146294_l / 2 + this.field_146294_l / 18, this.field_146295_m / 3 + this.field_146295_m / 18, this.field_146294_l / 2 + this.field_146294_l / 8, this.field_146295_m / 2 + this.field_146295_m / 3) && !this.isMouseOver(par1, par2, this.field_146294_l / 2 + this.field_146294_l / 14, (int)(this.field_146295_m / 2.35) + this.field_146295_m / 14, this.field_146294_l / 2 + this.field_146294_l / 4, this.field_146295_m / 2 + this.field_146295_m / 11) && DayM.daym_70a7d6d00) {
                final String varmo = LanguageHandler.translate("daym.gui.customizechar");
                int color2 = 16777215;
                if (Mouse.isButtonDown(0) && this.mousePressed) {
                    this.mousePressed = false;
                }
                if (this.mousePressed) {
                    boolean finished = false;
                    if (!finished) {
                        this.field_146297_k.func_147108_a((GuiScreen)new GuiCustomizeCharacter());
                        finished = true;
                    }
                }
                if (Mouse.isButtonDown(0) && !this.mousePressed) {
                    this.mousePressed = true;
                }
                else {
                    this.mousePressed = false;
                }
                if (this.mousePressed) {
                    color2 = Color.red.getRGB();
                }
                this.func_73731_b(this.field_146289_q, varmo, par1 - this.field_146289_q.func_78256_a(varmo) / 2 - 2, par2 - 10, color2);
            }
            else if (this.isMouseOver(par1, par2, this.field_146294_l / 2 + this.field_146294_l / 14, (int)(this.field_146295_m / 2.35) + this.field_146295_m / 14, this.field_146294_l / 2 + this.field_146294_l / 4, this.field_146295_m / 2 + this.field_146295_m / 11) && DayM.daym_70a7d6d00) {
                final String varmo = "Customize Gun (debug testing)";
                if (Mouse.isButtonDown(0) && this.mousePressed) {
                    this.mousePressed = false;
                }
                if (this.mousePressed) {
                    boolean finished2 = false;
                    if (!finished2) {
                        finished2 = true;
                    }
                }
                if (Mouse.isButtonDown(0) && !this.mousePressed) {
                    this.mousePressed = true;
                }
                else {
                    this.mousePressed = false;
                }
                this.func_73731_b(this.field_146289_q, varmo, par1 - this.field_146289_q.func_78256_a(varmo) / 2 - 2, par2 - 10, Color.orange.getRGB());
            }
            else if (this.isMouseOver(par1, par2, this.field_146294_l - this.field_146289_q.func_78256_a(var11) - 2, this.field_146295_m - 18, this.field_146294_l, this.field_146295_m - 10)) {
                final String varmo = "Visit page";
                int color2 = 16777215;
                if (Mouse.isButtonDown(0) && this.mousePressed) {
                    this.mousePressed = false;
                }
                if (this.mousePressed) {
                    boolean finished = false;
                    if (!finished && this.daym_ce8384310 > 19) {
                        try {
                            final Class var16 = Class.forName("java.awt.Desktop");
                            final Object var17 = var16.getMethod("getDesktop", (Class[])new Class[0]).invoke(null, new Object[0]);
                            var16.getMethod("browse", URI.class).invoke(var17, new URI("http://www.minecraftforum.net/forums/mapping-and-modding/resource-packs/1223254-faithful-32x32-pack-update-red-cat-clay-1-8"));
                        }
                        catch (Throwable var18) {
                            var18.printStackTrace();
                        }
                        finished = true;
                    }
                }
                if (Mouse.isButtonDown(0) && !this.mousePressed) {
                    this.mousePressed = true;
                }
                else {
                    this.mousePressed = false;
                }
                if (this.mousePressed) {
                    color2 = Color.blue.getRGB();
                }
                this.func_73731_b(this.field_146289_q, varmo, par1 - this.field_146289_q.func_78256_a(varmo) / 2 - 2, par2 - 10, color2);
            }
            else if (!this.isMouseOver(par1, par2, 0, this.field_146295_m - 22, this.field_146289_q.func_78256_a(var12), this.field_146295_m - 12)) {
                this.mousePressed = false;
            }
        }
        super.func_73863_a(par1, par2, par3);
    }
    
    private void changeClothing() {
        final int temp = 0;
        if (this.randomClothing == 0) {}
        if (this.randomClothing == 1) {}
        if (this.randomClothing == 2) {}
        if (this.randomClothing == 3) {}
    }
    
    static {
        GuiDaymMainMenu.daym_f8098c6c0 = false;
    }
}
