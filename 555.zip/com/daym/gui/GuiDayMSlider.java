package com.daym.gui;

import net.minecraft.client.*;
import org.lwjgl.opengl.*;

public class GuiDayMSlider extends GuiDayMButton
{
    public float sliderValue;
    public boolean dragging;
    public float maxSlider;
    
    public GuiDayMSlider(final int id, final int x, final int y, final String label, final float startingValue) {
        super(id, x, y, 200, 20, label);
        this.sliderValue = 5000.0f;
        this.dragging = false;
        this.maxSlider = 10000.0f;
        this.sliderValue = startingValue;
        this.func_146119_b(Minecraft.func_71410_x(), this.field_146120_f / 2, 0);
    }
    
    public GuiDayMSlider(final int id, final int x, final int y, final int w, final int h, final String label, final float ms, final float startingValue) {
        super(id, x, y, w, h, label);
        this.sliderValue = 5000.0f;
        this.dragging = false;
        this.maxSlider = 10000.0f;
        this.sliderValue = startingValue;
        this.maxSlider = ms;
        this.func_146119_b(Minecraft.func_71410_x(), this.field_146120_f / 2, 0);
    }
    
    protected void func_146119_b(final Minecraft par1Minecraft, final int par2, final int par3) {
        if (this.field_146125_m) {
            if (this.dragging) {
                this.sliderValue = (par2 - (this.field_146128_h + 4)) / (this.field_146120_f - 8) * this.maxSlider;
                if (this.sliderValue < 0.0f) {
                    this.sliderValue = 0.0f;
                }
                if (this.sliderValue > this.maxSlider) {
                    this.sliderValue = this.maxSlider;
                }
            }
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            final int posX = this.field_146128_h + (int)(this.sliderValue / this.maxSlider * (this.field_146120_f - 8)) + 4;
            func_73734_a(posX - this.field_146120_f / 2 / 12 / 2, this.field_146129_i, posX + this.field_146120_f / 2 / 12 / 2, this.field_146129_i + this.field_146121_g, Integer.MIN_VALUE);
        }
    }
    
    public boolean func_146116_c(final Minecraft par1Minecraft, final int par2, final int par3) {
        return super.func_146116_c(par1Minecraft, par2, par3) && (this.dragging = true);
    }
    
    public void func_146118_a(final int par1, final int par2) {
        this.dragging = false;
    }
}
