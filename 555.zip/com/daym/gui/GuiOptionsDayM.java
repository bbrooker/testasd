package com.daym.gui;

import cpw.mods.fml.relauncher.*;
import net.minecraft.client.settings.*;
import net.minecraft.client.resources.*;
import java.util.*;
import com.daym.render.*;
import net.minecraft.client.gui.*;

@SideOnly(Side.CLIENT)
public class GuiOptionsDayM extends GuiOptions
{
    GuiScreen parent;
    private float timer;
    
    public GuiOptionsDayM(final GuiScreen p_i1046_1_, final GameSettings p_i1046_2_) {
        super(p_i1046_1_, p_i1046_2_);
        this.parent = null;
        this.timer = 0.0f;
        this.parent = p_i1046_1_;
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
        final byte b0 = -16;
        final ArrayList<Object> bl = new ArrayList<Object>();
        for (final Object o : this.field_146292_n) {
            if (o instanceof GuiButton && !(o instanceof GuiOptionSlider) && !(o instanceof GuiOptionButton) && !(o instanceof GuiOptions)) {
                final GuiButton b2 = (GuiButton)o;
                bl.add(GuiDayMButton.copyButton(b2));
                if (b2.field_146127_k == 7) {}
            }
            else {
                bl.add(o);
            }
        }
        this.field_146292_n.clear();
        this.field_146292_n.add(new GuiDayMButton(50, this.field_146294_l / 2 - 155, this.field_146295_m / 6 + 48 - 6, 150, 20, I18n.func_135052_a("daym.gui.ingame.options", new Object[0])));
        this.field_146292_n.addAll(bl);
    }
    
    protected void func_146284_a(final GuiButton b) {
        super.func_146284_a(b);
        if (b.field_146127_k == 50) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiDayMOptions(this.parent));
        }
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        this.func_146276_q_();
        this.func_73732_a(this.field_146289_q, this.field_146442_a, this.field_146294_l / 2, 15, 16777215);
        if (this.parent instanceof GuiMainMenu) {
            RenderSetup.renderBackgroundAndPlayer(this.field_146294_l, this.field_146295_m, par1, par2, par3);
            this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, -2130706433, 16777215);
            this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, 0, Integer.MIN_VALUE);
        }
        for (int k = 0; k < this.field_146292_n.size(); ++k) {
            this.field_146292_n.get(k).func_146112_a(this.field_146297_k, par1, par2);
        }
        for (int k = 0; k < this.field_146293_o.size(); ++k) {
            this.field_146293_o.get(k).func_146159_a(this.field_146297_k, par1, par2);
        }
    }
}
