package com.daym.gui;

import com.daym.render.*;
import net.minecraft.client.resources.*;
import net.minecraft.client.gui.*;
import com.daym.config.*;
import com.daym.registry.*;

public class GuiDayMTutorial extends GuiScreen
{
    private GuiScreen parent;
    
    public GuiDayMTutorial(final GuiScreen p) {
        this.parent = p;
        RenderSetup.tutorialID = 0;
    }
    
    public void func_73866_w_() {
        this.field_146292_n.clear();
        final byte b0 = -16;
        final boolean flag = true;
        this.field_146292_n.add(new GuiDayMButton(0, this.field_146294_l / 2 - 49, 10, 98, 20, I18n.func_135052_a("menu.returnToGame", new Object[0])));
        this.field_146292_n.add(new GuiDayMButton(1, this.field_146294_l / 2 - 200, this.field_146295_m - 24, 98, 20, "<- Previous"));
        this.field_146292_n.add(new GuiDayMButton(2, this.field_146294_l / 2 + 102, this.field_146295_m - 24, 98, 20, "Next ->"));
    }
    
    protected void func_146284_a(final GuiButton b) {
        if (b.field_146127_k == 1 && RenderSetup.tutorialID > 0) {
            --RenderSetup.tutorialID;
        }
        if (b.field_146127_k == 2 && RenderSetup.tutorialID < 9) {
            ++RenderSetup.tutorialID;
        }
        if (b.field_146127_k == 0) {
            this.field_146297_k.func_147108_a(this.parent);
        }
    }
    
    public void func_146281_b() {
        DayMConfig.didTutorial = true;
        DayMConfig.saveProp(DayMConfig.props, DayMConfig.didTutorial, "finishedTutorial");
        DayMConfig.daym_c651688a0(DayMConfig.cfgdir, DayMConfig.cfgfile, DayMConfig.props);
    }
    
    public void func_73876_c() {
        super.func_73876_c();
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        this.func_146276_q_();
        RenderSetup.drawTexture(0.0, 0.0, 0.0, 0.0, this.field_146294_l, this.field_146295_m, 1.0f, TextureRegistry.tutorial[RenderSetup.tutorialID]);
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, Integer.MIN_VALUE, Integer.MIN_VALUE);
        this.func_73732_a(this.field_146289_q, I18n.func_135052_a("daym.gui.tutorial", new Object[0]) + " " + (RenderSetup.tutorialID + 1) + " / 10", this.field_146294_l / 2, 1, 16777215);
        if (RenderSetup.tutorialID != 0) {
            final String str1 = I18n.func_135052_a("daym.gui.tutorial_" + RenderSetup.tutorialID + "_0", new Object[0]);
            final String str2 = I18n.func_135052_a("daym.gui.tutorial_" + RenderSetup.tutorialID + "_1", new Object[0]);
            func_73734_a(this.field_146294_l / 2 - this.field_146289_q.func_78256_a(str1) / 2 - 4, 46, this.field_146294_l / 2 + this.field_146289_q.func_78256_a(str1) / 2 + 4, 59, Integer.MIN_VALUE);
            func_73734_a(this.field_146294_l / 2 - this.field_146289_q.func_78256_a(str2) / 2 - 4, this.field_146295_m - 48 - 2, this.field_146294_l / 2 + this.field_146289_q.func_78256_a(str2) / 2 + 4, this.field_146295_m - 48 + 11, Integer.MIN_VALUE);
            this.func_73732_a(this.field_146289_q, str1, this.field_146294_l / 2, 48, 16777215);
            this.func_73732_a(this.field_146289_q, str2, this.field_146294_l / 2, this.field_146295_m - 48, 16777215);
        }
        else {
            final String str1 = I18n.func_135052_a("daym.gui.tutorial_" + RenderSetup.tutorialID + "_0", new Object[0]);
            final String str2 = I18n.func_135052_a("daym.gui.tutorial_" + RenderSetup.tutorialID + "_1", new Object[0]);
            final String str3 = I18n.func_135052_a("daym.gui.tutorial_" + RenderSetup.tutorialID + "_2", new Object[0]);
            final String str4 = I18n.func_135052_a("daym.gui.tutorial_" + RenderSetup.tutorialID + "_3", new Object[0]);
            func_73734_a(this.field_146294_l / 2 - this.field_146289_q.func_78256_a(str1) / 2 - 4, 46, this.field_146294_l / 2 + this.field_146289_q.func_78256_a(str1) / 2 + 4, 59, Integer.MIN_VALUE);
            func_73734_a(this.field_146294_l / 2 - this.field_146289_q.func_78256_a(str2) / 2 - 4, 94, this.field_146294_l / 2 + this.field_146289_q.func_78256_a(str2) / 2 + 4, 107, Integer.MIN_VALUE);
            func_73734_a(this.field_146294_l / 2 - this.field_146289_q.func_78256_a(str3) / 2 - 4, 142, this.field_146294_l / 2 + this.field_146289_q.func_78256_a(str3) / 2 + 4, 155, Integer.MIN_VALUE);
            func_73734_a(this.field_146294_l / 2 - this.field_146289_q.func_78256_a(str4) / 2 - 4, this.field_146295_m - 48 - 2, this.field_146294_l / 2 + this.field_146289_q.func_78256_a(str4) / 2 + 4, this.field_146295_m - 48 + 11, Integer.MIN_VALUE);
            this.func_73732_a(this.field_146289_q, str1, this.field_146294_l / 2, 48, 16777215);
            this.func_73732_a(this.field_146289_q, str2, this.field_146294_l / 2, 96, 16777215);
            this.func_73732_a(this.field_146289_q, str3, this.field_146294_l / 2, 144, 16777215);
            this.func_73732_a(this.field_146289_q, str4, this.field_146294_l / 2, this.field_146295_m - 48, 16777215);
        }
        super.func_73863_a(par1, par2, par3);
    }
}
