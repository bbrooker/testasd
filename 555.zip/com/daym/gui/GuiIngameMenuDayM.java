package com.daym.gui;

import cpw.mods.fml.relauncher.*;
import net.minecraft.client.resources.*;
import java.util.*;
import net.minecraft.client.gui.*;
import com.daym.registry.*;
import com.daym.items.*;
import com.daym.render.*;
import net.minecraft.item.*;
import net.minecraft.util.*;

@SideOnly(Side.CLIENT)
public class GuiIngameMenuDayM extends GuiIngameMenu
{
    public void func_73866_w_() {
        super.func_73866_w_();
        final byte b0 = -16;
        final ArrayList<GuiDayMButton> bl = new ArrayList<GuiDayMButton>();
        for (final Object o : this.field_146292_n) {
            if (o instanceof GuiButton) {
                final GuiButton b2 = (GuiButton)o;
                if (b2.field_146127_k != 7) {
                    bl.add(GuiDayMButton.copyButton(b2));
                }
                if (b2.field_146127_k != 7) {
                    continue;
                }
                final GuiButton guibutton = new GuiDayMButton(7, this.field_146294_l / 2 + 2, this.field_146295_m / 4 + 72 + b0, 98, 20, I18n.func_135052_a("menu.shareToLan", new Object[0]));
                guibutton.field_146124_l = (this.field_146297_k.func_71356_B() && !this.field_146297_k.func_71401_C().func_71344_c());
                bl.add(GuiDayMButton.copyButton(guibutton));
            }
        }
        this.field_146292_n.clear();
        this.field_146292_n.add(new GuiDayMButton(13, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 72 + b0, 98, 20, I18n.func_135052_a("daym.gui.ingame.options", new Object[0])));
        this.field_146292_n.add(new GuiDayMButton(14, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 168 - 24 + b0, 98, 20, I18n.func_135052_a("daym.gui.ingamemenu.suicide", new Object[0])));
        this.field_146292_n.add(new GuiDayMButton(15, this.field_146294_l / 2 + 2, this.field_146295_m / 4 + 168 - 24 + b0, 98, 20, I18n.func_135052_a("daym.gui.tutorial", new Object[0])));
        this.field_146292_n.addAll(bl);
    }
    
    protected void func_146284_a(final GuiButton b) {
        super.func_146284_a(b);
        if (b.field_146127_k == 13) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiDayMOptions((GuiScreen)this));
        }
        if (b.field_146127_k == 15) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiDayMTutorial((GuiScreen)this));
        }
        if (b.field_146127_k == 14) {
            this.field_146297_k.func_147108_a((GuiScreen)null);
            this.field_146297_k.func_71381_h();
            if (this.field_146297_k.field_71439_g != null) {
                boolean hasGun = false;
                boolean hasAmmo = false;
                boolean hasWeapon = false;
                for (final ItemStack is : this.field_146297_k.field_71439_g.field_71071_by.field_70462_a) {
                    if (is != null && is.func_77973_b() == ItemRegistry.item_axe) {
                        hasWeapon = true;
                    }
                    if (is != null && ItemRegistry.gunList.contains(is.func_77973_b())) {
                        hasGun = true;
                        if (ItemDayMGun.getBullets(is) > 0) {
                            hasAmmo = true;
                            break;
                        }
                    }
                }
                if (hasGun || hasWeapon) {
                    if (hasAmmo || hasWeapon) {
                        RenderSetup.daym_839b70940 = 50;
                    }
                    else {
                        final IChatComponent test = (IChatComponent)new ChatComponentText("Couldn't suicide, your gun doesn't have ammo.");
                        this.field_146297_k.field_71439_g.func_145747_a(test);
                    }
                }
                else {
                    final IChatComponent test = (IChatComponent)new ChatComponentText("Couldn't suicide, no weapon in your hotbar.");
                    this.field_146297_k.field_71439_g.func_145747_a(test);
                }
            }
        }
    }
    
    public void func_73863_a(final int p_73863_1_, final int p_73863_2_, final float p_73863_3_) {
        super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
    }
}
