package com.daym.gui.inventory;

import cpw.mods.fml.relauncher.*;
import net.minecraft.inventory.*;
import org.lwjgl.opengl.*;
import net.minecraft.potion.*;
import net.minecraft.client.resources.*;
import java.util.*;

@SideOnly(Side.CLIENT)
public abstract class InventoryEffectRendererDayM extends GuiContainerDayM
{
    private boolean field_147045_u;
    private static final String __OBFID = "CL_00000755";
    
    public InventoryEffectRendererDayM(final Container p_i1089_1_) {
        super(p_i1089_1_);
    }
    
    @Override
    public void func_73866_w_() {
        super.func_73866_w_();
        if (!this.field_146297_k.field_71439_g.func_70651_bq().isEmpty()) {
            this.guiLeft = 160 + (this.field_146294_l - this.xSize - 200) / 2;
            this.field_147045_u = true;
        }
    }
    
    @Override
    public void func_73863_a(final int p_73863_1_, final int p_73863_2_, final float p_73863_3_) {
        super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
        if (this.field_147045_u) {
            this.func_147044_g();
        }
    }
    
    private void func_147044_g() {
        final int i = this.guiLeft - 124;
        int j = this.guiTop;
        final boolean flag = true;
        final Collection collection = this.field_146297_k.field_71439_g.func_70651_bq();
        if (!collection.isEmpty()) {
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glDisable(2896);
            int k = 33;
            if (collection.size() > 5) {
                k = 132 / (collection.size() - 1);
            }
            for (final PotionEffect potioneffect : this.field_146297_k.field_71439_g.func_70651_bq()) {
                final Potion potion = Potion.field_76425_a[potioneffect.func_76456_a()];
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                this.field_146297_k.func_110434_K().func_110577_a(InventoryEffectRendererDayM.field_147001_a);
                this.func_73729_b(i, j, 0, 166, 140, 32);
                if (potion.func_76400_d()) {
                    final int l = potion.func_76392_e();
                    this.func_73729_b(i + 6, j + 7, 0 + l % 8 * 18, 198 + l / 8 * 18, 18, 18);
                }
                potion.renderInventoryEffect(i, j, potioneffect, this.field_146297_k);
                if (potion.shouldRenderInvText(potioneffect)) {
                    String s1 = I18n.func_135052_a(potion.func_76393_a(), new Object[0]);
                    if (potioneffect.func_76458_c() == 1) {
                        s1 = s1 + " " + I18n.func_135052_a("enchantment.level.2", new Object[0]);
                    }
                    else if (potioneffect.func_76458_c() == 2) {
                        s1 = s1 + " " + I18n.func_135052_a("enchantment.level.3", new Object[0]);
                    }
                    else if (potioneffect.func_76458_c() == 3) {
                        s1 = s1 + " " + I18n.func_135052_a("enchantment.level.4", new Object[0]);
                    }
                    this.field_146289_q.func_78261_a(s1, i + 10 + 18, j + 6, 16777215);
                    final String s2 = Potion.func_76389_a(potioneffect);
                    this.field_146289_q.func_78261_a(s2, i + 10 + 18, j + 6 + 10, 8355711);
                }
                j += k;
            }
        }
    }
}
