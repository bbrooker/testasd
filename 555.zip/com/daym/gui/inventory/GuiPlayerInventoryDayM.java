package com.daym.gui.inventory;

import net.minecraft.inventory.*;
import net.minecraft.item.*;
import net.minecraft.client.*;
import net.minecraft.entity.player.*;
import com.daym.clientproxy.*;
import com.daym.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import com.daym.render.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import java.util.*;
import com.daym.gui.inventory.slot.*;
import com.daym.packet.message.*;
import com.daym.handlers.*;
import net.minecraft.entity.item.*;
import net.minecraft.client.resources.*;
import com.daym.inventory.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.texture.*;
import com.daym.registry.*;
import com.daym.items.*;
import net.minecraft.util.*;
import org.lwjgl.input.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;

public class GuiPlayerInventoryDayM extends GuiScreen
{
    public float xSize_lo;
    public float ySize_lo;
    private static final ResourceLocation iconLocation;
    private final PlayerInventoryDayM inventory;
    protected int xSize;
    protected int ySize;
    public Container inventorySlots;
    protected int guiLeft;
    protected int guiTop;
    private Slot theSlot;
    private Slot clickedSlot;
    private boolean isRightMouseClick;
    private ItemStack draggedStack;
    private int field_147011_y;
    private int field_147010_z;
    private Slot returningStackDestSlot;
    private long returningStackTime;
    private ItemStack returningStack;
    private Slot field_146985_D;
    private long field_146986_E;
    protected final Set field_147008_s;
    protected boolean field_147007_t;
    private int field_146987_F;
    private int field_146988_G;
    private boolean field_146995_H;
    private int field_146996_I;
    private long field_146997_J;
    private Slot field_146998_K;
    private int field_146992_L;
    private boolean field_146993_M;
    private ItemStack field_146994_N;
    private static final String __OBFID = "CL_00000737";
    Minecraft field_146297_k;
    public boolean reloadScreen;
    InventoryPlayer inventoryPlayer;
    public int lastClick;
    public int scrollbarLoc;
    public int scrollbarLoc2;
    private ItemStack checkForReload;
    private boolean draggingMouse;
    private boolean draggingMouse2;
    private boolean didSuperCheck;
    
    public GuiPlayerInventoryDayM(final EntityPlayer player, final InventoryPlayer ip, final PlayerInventoryDayM inventoryCustom, final boolean setCon) {
        this.xSize = 176;
        this.ySize = 166;
        this.field_147008_s = new HashSet();
        this.field_146297_k = Minecraft.func_71410_x();
        this.reloadScreen = false;
        this.inventoryPlayer = null;
        this.lastClick = 0;
        this.scrollbarLoc = 0;
        this.scrollbarLoc2 = 0;
        this.didSuperCheck = false;
        this.field_146995_H = false;
        if (setCon) {
            this.inventorySlots = (Container)new PlayerContainerDayM(player, ip, inventoryCustom);
        }
        this.inventory = inventoryCustom;
        this.inventoryPlayer = ip;
        ClientProxy.daym_4fa0d23c0 = false;
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
        this.field_146297_k.field_71439_g.field_71070_bA = this.inventorySlots;
        this.guiLeft = (this.field_146294_l - this.xSize) / 2;
        this.guiTop = (this.field_146295_m - this.ySize) / 2;
        Mouse.setCursorPosition(ClientProxy.mouseX * 2, -ClientProxy.mouseY * 2 + this.field_146295_m * 2);
    }
    
    public void func_73863_a(final int par1, final int par2, final float p_73863_3_) {
        this.xSize_lo = par1;
        this.ySize_lo = par2;
        ClientProxy.mouseX = par1;
        ClientProxy.mouseY = par2;
        if (this.lastClick > 0) {
            --this.lastClick;
        }
        else {
            this.lastClick = 0;
        }
        if (this.reloadScreen && this.lastClick == 0) {
            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_OpenGui(1, DayM.GUI_CUSTOM_INV));
        }
        if (this.checkForReload != null && this.inventoryPlayer != null) {
            final ItemStack itemstack = (this.draggedStack == null) ? this.inventoryPlayer.func_70445_o() : this.draggedStack;
            if (itemstack != this.checkForReload) {
                this.reloadScreen = true;
            }
        }
        if (RenderSetup.daym_8a1531e40 != -1) {
            this.field_146297_k.func_147108_a((GuiScreen)null);
        }
        if (this.inventorySlots == null) {
            return;
        }
        if (ClientProxy.daym_4fa0d23c0) {
            this.reloadScreen = true;
        }
        final int k = this.guiLeft;
        final int l = this.guiTop;
        this.drawGuiContainerBackgroundLayer(p_73863_3_, par1, par2);
        GL11.glDisable(32826);
        RenderHelper.func_74518_a();
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        super.func_73863_a(par1, par2, p_73863_3_);
        RenderHelper.func_74520_c();
        GL11.glPushMatrix();
        GL11.glTranslatef((float)k, (float)l, 0.0f);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glEnable(32826);
        this.theSlot = null;
        final short short1 = 240;
        final short short2 = 240;
        OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, short1 / 1.0f, short2 / 1.0f);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        for (int i1 = 0; i1 < this.inventorySlots.field_75151_b.size(); ++i1) {
            final Slot slot = this.inventorySlots.field_75151_b.get(i1);
            this.func_146977_a(slot);
            if (this.isMouseOverSlot(slot, par1, par2) && slot.func_111238_b()) {
                this.theSlot = slot;
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                if (slot instanceof SlotSized) {
                    int sc = this.scrollbarLoc;
                    if (slot.field_75223_e < this.field_146294_l / 2 - this.guiLeft) {
                        sc = this.scrollbarLoc2;
                    }
                    slot.field_75221_f = ((SlotSized)slot).actualPosy - sc * 2;
                }
                if (slot instanceof SlotItemPickup) {
                    slot.field_75221_f = ((SlotItemPickup)slot).actualPosy - this.scrollbarLoc2 * 2;
                }
                final int j1 = slot.field_75223_e;
                final int k2 = slot.field_75221_f;
                boolean renderDefault = false;
                if (slot instanceof SlotSized) {
                    final SlotSized ss = (SlotSized)slot;
                    if (ss.parent != null && ss.checkOccupied() && ss.parent.func_75216_d()) {
                        if (ss.parent.func_75211_c().func_77973_b() instanceof DayMItem) {
                            final DayMItem daymitem = (DayMItem)ss.parent.func_75211_c().func_77973_b();
                            GL11.glColorMask(true, true, true, false);
                            this.func_73733_a(ss.parent.field_75223_e, ss.parent.field_75221_f, ss.parent.field_75223_e + daymitem.slotSizeX * 17, ss.parent.field_75221_f + daymitem.slotSizeY * 17, -2130706433, -2130706433);
                            GL11.glColorMask(true, true, true, true);
                            GL11.glEnable(2896);
                            GL11.glEnable(2929);
                        }
                    }
                    else {
                        final InventoryPlayer inventoryplayer = this.field_146297_k.field_71439_g.field_71071_by;
                        final ItemStack itemstack2 = (this.draggedStack == null) ? inventoryplayer.func_70445_o() : this.draggedStack;
                        if (itemstack2 != null) {
                            if (itemstack2.func_77973_b() instanceof DayMItem) {
                                final DayMItem daymitem2 = (DayMItem)itemstack2.func_77973_b();
                                GL11.glColorMask(true, true, true, false);
                                this.func_73733_a(j1, k2, j1 + daymitem2.slotSizeX * 17, k2 + daymitem2.slotSizeY * 17, -2130706433, -2130706433);
                                this.func_73733_a(j1, k2, j1 + 16, k2 + 16, Integer.MIN_VALUE, Integer.MIN_VALUE);
                                GL11.glColorMask(true, true, true, true);
                                GL11.glEnable(2896);
                                GL11.glEnable(2929);
                            }
                            else {
                                renderDefault = true;
                            }
                        }
                        else if (ss.func_75216_d()) {
                            if (ss.func_75211_c().func_77973_b() instanceof DayMItem) {
                                final DayMItem daymitem2 = (DayMItem)ss.func_75211_c().func_77973_b();
                                GL11.glColorMask(true, true, true, false);
                                this.func_73733_a(j1, k2, j1 + daymitem2.slotSizeX * 17, k2 + daymitem2.slotSizeY * 17, -2130706433, -2130706433);
                                GL11.glColorMask(true, true, true, true);
                                GL11.glEnable(2896);
                                GL11.glEnable(2929);
                            }
                            else {
                                renderDefault = true;
                            }
                        }
                        else {
                            renderDefault = true;
                        }
                    }
                }
                else {
                    renderDefault = true;
                }
                if (renderDefault) {
                    GL11.glColorMask(true, true, true, false);
                    this.func_73733_a(j1, k2, j1 + 16, k2 + 16, -2130706433, -2130706433);
                    GL11.glColorMask(true, true, true, true);
                    GL11.glEnable(2896);
                    GL11.glEnable(2929);
                }
            }
        }
        GL11.glDisable(2896);
        this.drawGuiContainerForegroundLayer(par1, par2);
        GL11.glEnable(2896);
        final InventoryPlayer inventoryplayer2 = this.field_146297_k.field_71439_g.field_71071_by;
        ItemStack itemstack3 = (this.draggedStack == null) ? inventoryplayer2.func_70445_o() : this.draggedStack;
        if (itemstack3 != null) {
            final byte b0 = 8;
            final int k2 = (this.draggedStack == null) ? 8 : 16;
            String s = null;
            if (this.draggedStack != null && this.isRightMouseClick) {
                itemstack3 = itemstack3.func_77946_l();
                itemstack3.field_77994_a = MathHelper.func_76123_f(itemstack3.field_77994_a / 2.0f);
            }
            else if (this.field_147007_t && this.field_147008_s.size() > 1) {
                itemstack3 = itemstack3.func_77946_l();
                itemstack3.field_77994_a = this.field_146996_I;
                if (itemstack3.field_77994_a == 0) {
                    s = "" + EnumChatFormatting.YELLOW + "0";
                }
            }
            this.drawItemStack(itemstack3, par1 - k - b0, par2 - l - k2, s);
        }
        if (this.returningStack != null) {
            float f1 = (Minecraft.func_71386_F() - this.returningStackTime) / 100.0f;
            if (f1 >= 1.0f) {
                f1 = 1.0f;
                this.returningStack = null;
            }
            final int k2 = this.returningStackDestSlot.field_75223_e - this.field_147011_y;
            final int j2 = this.returningStackDestSlot.field_75221_f - this.field_147010_z;
            final int l2 = this.field_147011_y + (int)(k2 * f1);
            final int i2 = this.field_147010_z + (int)(j2 * f1);
            this.drawItemStack(this.returningStack, l2, i2, null);
        }
        GL11.glPopMatrix();
        if (inventoryplayer2.func_70445_o() == null && this.theSlot != null && this.theSlot.func_75216_d()) {
            final ItemStack itemstack4 = this.theSlot.func_75211_c();
            this.func_146285_a(itemstack4, par1, par2);
        }
        GL11.glEnable(2896);
        GL11.glEnable(2929);
        RenderHelper.func_74519_b();
        if (!this.didSuperCheck) {
            this.didSuperCheck = true;
            this.checkAllOccItems();
        }
    }
    
    private void checkAllOccItems() {
        for (int i1 = 0; i1 < this.inventorySlots.field_75151_b.size(); ++i1) {
            final Slot slot = this.inventorySlots.field_75151_b.get(i1);
            if (slot instanceof SlotSized) {
                final ItemStack itemstack = slot.func_75211_c();
                if (itemstack != null) {
                    if (itemstack.func_77973_b() instanceof DayMItem) {
                        final int mouseX = slot.field_75223_e + this.guiLeft;
                        final int mouseY = slot.field_75221_f + this.guiTop;
                        final DayMItem daymitem = (DayMItem)itemstack.func_77973_b();
                        final ArrayList<SlotSized> slotsneedupdate = new ArrayList<SlotSized>();
                        for (int j = 0; j < daymitem.slotSizeX; ++j) {
                            for (int k = 0; k < daymitem.slotSizeY; ++k) {
                                final Slot slot2 = this.getSlotAtPosition(mouseX + 18 * j, mouseY + 18 * k);
                                if (slot2 != null && slot2 instanceof SlotSized) {
                                    final SlotSized ss = (SlotSized)slot2;
                                    if (!ss.checkOccupied() && !ss.func_75216_d()) {
                                        ss.setOccupied(slot, true);
                                    }
                                }
                            }
                        }
                        for (final SlotSized sss : slotsneedupdate) {
                            sss.setOccupied(slot, true);
                        }
                    }
                    else {
                        for (int i2 = 0; i2 < this.inventorySlots.field_75151_b.size(); ++i2) {
                            final Slot slot3 = this.inventorySlots.field_75151_b.get(i2);
                            if (slot3 instanceof SlotSized && ((SlotSized)slot3).parent == slot) {
                                ((SlotSized)slot3).setOccupied(null, false);
                            }
                        }
                    }
                }
            }
        }
    }
    
    protected void func_146273_a(final int p_146273_1_, final int p_146273_2_, final int p_146273_3_, final long p_146273_4_) {
        final Slot slot = this.getSlotAtPosition(p_146273_1_, p_146273_2_);
        final ItemStack itemstack = this.field_146297_k.field_71439_g.field_71071_by.func_70445_o();
        if (this.clickedSlot != null && this.field_146297_k.field_71474_y.field_85185_A) {
            if (p_146273_3_ == 0 || p_146273_3_ == 1) {
                if (this.draggedStack == null) {
                    if (slot != this.clickedSlot) {
                        this.draggedStack = this.clickedSlot.func_75211_c().func_77946_l();
                    }
                }
                else if (this.draggedStack.field_77994_a > 1 && slot != null && Container.func_94527_a(slot, this.draggedStack, false)) {
                    final long i1 = Minecraft.func_71386_F();
                    if (this.field_146985_D == slot) {
                        if (i1 - this.field_146986_E > 500L) {
                            this.handleMouseClick(this.clickedSlot, this.clickedSlot.field_75222_d, 0, 0);
                            this.handleMouseClick(slot, slot.field_75222_d, 1, 0);
                            this.handleMouseClick(this.clickedSlot, this.clickedSlot.field_75222_d, 0, 0);
                            this.field_146986_E = i1 + 750L;
                            final ItemStack draggedStack = this.draggedStack;
                            --draggedStack.field_77994_a;
                        }
                    }
                    else {
                        this.field_146985_D = slot;
                        this.field_146986_E = i1;
                    }
                }
            }
        }
        else if (this.field_147007_t && slot != null && itemstack != null && itemstack.field_77994_a > this.field_147008_s.size() && Container.func_94527_a(slot, itemstack, true) && slot.func_75214_a(itemstack) && this.inventorySlots.func_94531_b(slot)) {
            this.field_147008_s.add(slot);
            this.func_146980_g();
        }
    }
    
    protected void handleMouseClick(final Slot p_146984_1_, int p_146984_2_, final int p_146984_3_, final int p_146984_4_) {
        if (this.lastClick != 0) {
            return;
        }
        this.lastClick = 0;
        final int mouseX = (int)this.xSize_lo;
        final int mouseY = (int)this.ySize_lo;
        boolean pullofreload = false;
        if (p_146984_1_ != null) {
            p_146984_2_ = p_146984_1_.field_75222_d;
            if (p_146984_1_ instanceof SlotClothing && (p_146984_1_.field_75222_d == 5 || p_146984_1_.field_75222_d == 6 || p_146984_1_.field_75222_d == 1 || p_146984_1_.field_75222_d == 2) && p_146984_1_.func_75216_d() && this.inventoryPlayer != null) {
                final ItemStack itemstack = (this.draggedStack == null) ? this.inventoryPlayer.func_70445_o() : this.draggedStack;
                if (itemstack == null && p_146984_1_.func_75211_c().func_77973_b() instanceof ItemWithInventory) {
                    this.checkForReload = p_146984_1_.func_75211_c();
                }
                else if (p_146984_1_.func_75214_a(itemstack)) {
                    this.checkForReload = p_146984_1_.func_75211_c();
                }
            }
            if (p_146984_1_ instanceof SlotItemPickup) {
                if (!p_146984_1_.func_75216_d()) {
                    return;
                }
                if (this.inventoryPlayer != null) {
                    final ItemStack itemstack = (this.draggedStack == null) ? this.inventoryPlayer.func_70445_o() : this.draggedStack;
                    if (itemstack != null) {
                        return;
                    }
                    if (itemstack == null) {
                        this.checkForReload = p_146984_1_.func_75211_c();
                        DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_ItemPickup(this.checkForReload));
                        ArrayList<EntityItem> al = null;
                        if (WorldHandler.daym_e3864ff00.containsKey(this.field_146297_k.field_71439_g.func_110124_au().toString())) {
                            al = WorldHandler.daym_e3864ff00.get(this.field_146297_k.field_71439_g.func_110124_au().toString());
                        }
                        final ItemStack is = this.checkForReload;
                        if (al != null && is != null) {
                            al.remove(is);
                        }
                    }
                }
            }
            if (!p_146984_1_.func_75216_d()) {
                if (p_146984_1_ instanceof SlotSized) {
                    final SlotSized ss = (SlotSized)p_146984_1_;
                    if (ss.checkOccupied()) {
                        return;
                    }
                }
                if (p_146984_1_ instanceof SlotClothing && (p_146984_1_.field_75222_d == 5 || p_146984_1_.field_75222_d == 6 || p_146984_1_.field_75222_d == 1 || p_146984_1_.field_75222_d == 2) && this.inventoryPlayer != null) {
                    final ItemStack itemstack = (this.draggedStack == null) ? this.inventoryPlayer.func_70445_o() : this.draggedStack;
                    if (itemstack != null && itemstack.func_77973_b() instanceof ItemWithInventory) {
                        if (!p_146984_1_.func_75214_a(itemstack)) {
                            return;
                        }
                        pullofreload = true;
                    }
                }
                if (this.inventoryPlayer != null) {
                    final ItemStack itemstack = (this.draggedStack == null) ? this.inventoryPlayer.func_70445_o() : this.draggedStack;
                    if (itemstack != null && itemstack.func_77973_b() instanceof DayMItem) {
                        final DayMItem daymitem = (DayMItem)itemstack.func_77973_b();
                        final ArrayList<SlotSized> slotsneedupdate = new ArrayList<SlotSized>();
                        for (int i = 0; i < daymitem.slotSizeX; ++i) {
                            for (int j = 0; j < daymitem.slotSizeY; ++j) {
                                final Slot slot2 = this.getSlotAtPosition(mouseX + 18 * i, mouseY + 18 * j);
                                final Slot slotleft = this.getSlotAtPosition(mouseX + 18 * i - 18, mouseY + 18 * j);
                                final Slot slotright = this.getSlotAtPosition(mouseX + 18 * i + 18, mouseY + 18 * j);
                                final Slot slotup = this.getSlotAtPosition(mouseX + 18 * i, mouseY + 18 * j - 18);
                                final Slot slotdown = this.getSlotAtPosition(mouseX + 18 * i, mouseY + 18 * j + 18);
                                if (slot2 != p_146984_1_) {
                                    if (slot2 != null && slot2 instanceof SlotSized) {
                                        final SlotSized ss2 = (SlotSized)slot2;
                                        if (ss2.checkOccupied() || ss2.func_75216_d()) {
                                            return;
                                        }
                                        slotsneedupdate.add(ss2);
                                    }
                                    if (slot2 == null) {
                                        if (slotleft == null && slotright == null && slotup == null && slotdown == null) {
                                            return;
                                        }
                                        if ((slotleft != null && slotleft instanceof SlotSized) || (slotright != null && slotright instanceof SlotSized) || (slotup != null && slotup instanceof SlotSized) || (slotdown != null && slotdown instanceof SlotSized)) {
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                        for (final SlotSized sss : slotsneedupdate) {
                            sss.setOccupied(p_146984_1_, true);
                        }
                    }
                }
            }
            else {
                if (this.inventoryPlayer != null) {
                    final ItemStack itemstack = (this.draggedStack == null) ? this.inventoryPlayer.func_70445_o() : this.draggedStack;
                    if (itemstack != null && itemstack.func_77973_b() instanceof DayMItem) {
                        final DayMItem daymitem = (DayMItem)itemstack.func_77973_b();
                        final ArrayList<SlotSized> slotsneedupdate = new ArrayList<SlotSized>();
                        for (int i = 0; i < daymitem.slotSizeX; ++i) {
                            for (int j = 0; j < daymitem.slotSizeY; ++j) {
                                final Slot slot2 = this.getSlotAtPosition(mouseX + 18 * i, mouseY + 18 * j);
                                final Slot slotleft = this.getSlotAtPosition(mouseX + 18 * i - 18, mouseY + 18 * j);
                                final Slot slotright = this.getSlotAtPosition(mouseX + 18 * i + 18, mouseY + 18 * j);
                                final Slot slotup = this.getSlotAtPosition(mouseX + 18 * i, mouseY + 18 * j - 18);
                                final Slot slotdown = this.getSlotAtPosition(mouseX + 18 * i, mouseY + 18 * j + 18);
                                if (slot2 != p_146984_1_) {
                                    if (slot2 != null && slot2 instanceof SlotSized) {
                                        final SlotSized ss2 = (SlotSized)slot2;
                                        if (ss2.checkOccupied() || ss2.func_75216_d()) {
                                            return;
                                        }
                                        slotsneedupdate.add(ss2);
                                    }
                                    if (slot2 == null) {
                                        if (slotleft == null && slotright == null && slotup == null && slotdown == null) {
                                            return;
                                        }
                                        if ((slotleft != null && slotleft instanceof SlotSized) || (slotright != null && slotright instanceof SlotSized) || (slotup != null && slotup instanceof SlotSized) || (slotdown != null && slotdown instanceof SlotSized)) {
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                        for (final SlotSized sss : slotsneedupdate) {
                            sss.setOccupied(p_146984_1_, true);
                        }
                    }
                }
                ItemStack itemstack = p_146984_1_.func_75211_c();
                if (itemstack.func_77973_b() instanceof DayMItem) {
                    final DayMItem daymitem = (DayMItem)itemstack.func_77973_b();
                    for (int k = 0; k < daymitem.slotSizeX; ++k) {
                        for (int l = 0; l < daymitem.slotSizeY; ++l) {
                            final Slot slot3 = this.getSlotAtPosition(mouseX + 18 * k, mouseY + 18 * l);
                            if (slot3 != p_146984_1_ && slot3 != null && slot3 instanceof SlotSized) {
                                final SlotSized ss3 = (SlotSized)slot3;
                                ss3.setOccupied(p_146984_1_, false);
                            }
                        }
                    }
                }
                if (this.inventoryPlayer != null) {
                    itemstack = ((this.draggedStack == null) ? this.inventoryPlayer.func_70445_o() : this.draggedStack);
                    if (itemstack != null && itemstack.func_77973_b() instanceof DayMItem) {
                        final DayMItem daymitem = (DayMItem)itemstack.func_77973_b();
                        final ArrayList<SlotSized> slotsneedupdate = new ArrayList<SlotSized>();
                        for (int i = 0; i < daymitem.slotSizeX; ++i) {
                            for (int j = 0; j < daymitem.slotSizeY; ++j) {
                                final Slot slot2 = this.getSlotAtPosition(mouseX + 18 * i, mouseY + 18 * j);
                                if (slot2 != p_146984_1_) {
                                    if (slot2 != null && slot2 instanceof SlotSized) {
                                        final SlotSized ss4 = (SlotSized)slot2;
                                        if (ss4.checkOccupied() || ss4.func_75216_d()) {
                                            this.didSuperCheck = false;
                                            return;
                                        }
                                        slotsneedupdate.add(ss4);
                                    }
                                    if (slot2 == null && slot2 instanceof SlotSized) {
                                        return;
                                    }
                                }
                            }
                        }
                        for (final SlotSized sss : slotsneedupdate) {
                            sss.setOccupied(p_146984_1_, true);
                        }
                    }
                }
            }
        }
        if (pullofreload) {
            this.reloadScreen = true;
        }
        ItemStack itemstack = (this.draggedStack == null) ? this.inventoryPlayer.func_70445_o() : this.draggedStack;
        if (itemstack != null && itemstack.func_77973_b() instanceof ItemWithInventory) {
            final DayMItem daymitem = (ItemWithInventory)itemstack.func_77973_b();
        }
        this.field_146297_k.field_71442_b.func_78753_a(this.inventorySlots.field_75152_c, p_146984_2_, p_146984_3_, p_146984_4_, (EntityPlayer)this.field_146297_k.field_71439_g);
        this.didSuperCheck = false;
    }
    
    private Slot getSlotAtPosition(final int p_146975_1_, final int p_146975_2_) {
        for (int k = 0; k < this.inventorySlots.field_75151_b.size(); ++k) {
            final Slot slot = this.inventorySlots.field_75151_b.get(k);
            if (this.isMouseOverSlot(slot, p_146975_1_, p_146975_2_)) {
                return slot;
            }
        }
        return null;
    }
    
    public void func_146281_b() {
        KeybindRegistry.isKeyDown = false;
        if (!this.reloadScreen) {
            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_OpenGui(1, DayM.GUI_CUSTOM_INV));
        }
        else {
            DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_OpenGui(0, DayM.GUI_CUSTOM_INV));
        }
    }
    
    protected void drawGuiContainerForegroundLayer(final int par1, final int par2) {
        String s = I18n.func_135052_a("daym.gui.inventory.hotbar", new Object[0]);
        this.field_146289_q.func_78276_b(s, this.xSize / 2 - this.field_146289_q.func_78256_a(s) / 2, this.ySize / 2 + this.ySize / 5 + 21, Integer.MAX_VALUE);
        s = I18n.func_135052_a("daym.gui.inventory.player", new Object[0]);
        this.field_146289_q.func_78276_b(s, this.xSize / 2 - this.field_146289_q.func_78256_a(s) / 2, -(this.ySize / 6), Integer.MAX_VALUE);
        s = I18n.func_135052_a("container.crafting", new Object[0]);
        this.field_146289_q.func_78276_b(s, this.xSize / 2 - this.field_146289_q.func_78256_a(s) / 2, this.ySize / 2 + this.ySize / 14, Integer.MAX_VALUE);
        s = I18n.func_135052_a("daym.gui.inventory.vicinity", new Object[0]) + " ( Disabled )";
        this.field_146289_q.func_78276_b(s, -(this.xSize / 16) - this.field_146289_q.func_78256_a(s) / 2, -(this.ySize / 6), Integer.MAX_VALUE);
        s = I18n.func_135052_a("container.inventory", new Object[0]);
        this.field_146289_q.func_78276_b(s, this.xSize + this.xSize / 16 - this.field_146289_q.func_78256_a(s) / 2, -(this.ySize / 6), Integer.MAX_VALUE);
        final int iia2 = 0;
        final int iia3 = 0;
        for (int max1 = ((PlayerContainerDayM)this.inventorySlots).daym_a58cb7bc0, iia4 = 0; iia4 < max1; ++iia4) {
            if (((PlayerContainerDayM)this.inventorySlots).daym_c8ee2c4b0[iia4] != null) {
                final ItemInventory inv = ((PlayerContainerDayM)this.inventorySlots).daym_c8ee2c4b0[iia4];
                s = I18n.func_135052_a(inv.func_145825_b(), new Object[0]) + " (" + (inv.func_70302_i_() - 1) + ")";
                final int offsety1 = ((PlayerContainerDayM)this.inventorySlots).inventoryGuiOffset[iia4] - this.scrollbarLoc * 2;
                if (offsety1 > -4 && offsety1 < 172) {
                    func_73734_a(this.xSize + this.xSize / 16 - this.field_146289_q.func_78256_a(s) / 2 - 2, -(this.ySize / 6) + 13 + offsety1, this.xSize + this.xSize / 16 + this.field_146289_q.func_78256_a(s) / 2 + 2, -(this.ySize / 6) + 22 + offsety1, Integer.MIN_VALUE);
                    this.field_146289_q.func_78276_b(s, this.xSize + this.xSize / 16 - this.field_146289_q.func_78256_a(s) / 2, -(this.ySize / 6) + 13 + offsety1, Integer.MAX_VALUE);
                }
            }
        }
    }
    
    private void drawItemStack(final ItemStack p_146982_1_, final int p_146982_2_, final int p_146982_3_, final String p_146982_4_) {
        GL11.glTranslatef(0.0f, 0.0f, 32.0f);
        if (p_146982_1_ != null && p_146982_1_.func_77973_b() instanceof DayMItem) {
            final DayMItem daymitem = (DayMItem)p_146982_1_.func_77973_b();
            GL11.glTranslatef((float)(-p_146982_2_ * daymitem.slotSizeX), (float)(-p_146982_3_ * daymitem.slotSizeY), 0.0f);
            GL11.glTranslatef((float)p_146982_2_, (float)p_146982_3_, 0.0f);
            GL11.glScalef((float)daymitem.slotSizeX, (float)daymitem.slotSizeY, 1.0f);
        }
        this.field_73735_i = 200.0f;
        GuiPlayerInventoryDayM.field_146296_j.field_77023_b = 200.0f;
        FontRenderer font = null;
        if (p_146982_1_ != null) {
            font = p_146982_1_.func_77973_b().getFontRenderer(p_146982_1_);
        }
        if (font == null) {
            font = this.field_146289_q;
        }
        GuiPlayerInventoryDayM.field_146296_j.func_82406_b(font, this.field_146297_k.func_110434_K(), p_146982_1_, p_146982_2_, p_146982_3_);
        GuiPlayerInventoryDayM.field_146296_j.func_94148_a(font, this.field_146297_k.func_110434_K(), p_146982_1_, p_146982_2_, p_146982_3_ - ((this.draggedStack == null) ? 0 : 8), p_146982_4_);
        this.field_73735_i = 0.0f;
        GuiPlayerInventoryDayM.field_146296_j.field_77023_b = 0.0f;
    }
    
    private void func_146977_a(final Slot p_146977_1_) {
        boolean renderItem = true;
        if (p_146977_1_ instanceof SlotSized) {
            int sc = this.scrollbarLoc;
            if (p_146977_1_.field_75223_e < this.field_146294_l / 2 - this.guiLeft) {
                sc = this.scrollbarLoc2;
            }
            p_146977_1_.field_75221_f = ((SlotSized)p_146977_1_).actualPosy - sc * 2;
            if (p_146977_1_.field_75221_f < -16 || p_146977_1_.field_75221_f > 148) {
                return;
            }
            int ydis = 0;
            if (p_146977_1_.func_75216_d() && p_146977_1_.func_75211_c().func_77973_b() instanceof DayMItem) {
                final DayMItem daymitem = (DayMItem)p_146977_1_.func_75211_c().func_77973_b();
                ydis = p_146977_1_.field_75221_f + daymitem.slotSizeY * 8 + 2;
            }
            if (ydis > 148) {
                renderItem = false;
            }
        }
        if (p_146977_1_ instanceof SlotItemPickup) {
            p_146977_1_.field_75221_f = ((SlotItemPickup)p_146977_1_).actualPosy - this.scrollbarLoc2 * 2;
            if (p_146977_1_.field_75221_f < -16 || p_146977_1_.field_75221_f > 148) {
                return;
            }
        }
        final int i = p_146977_1_.field_75223_e;
        final int j = p_146977_1_.field_75221_f;
        ItemStack itemstack = p_146977_1_.func_75211_c();
        boolean flag = false;
        boolean flag2 = p_146977_1_ == this.clickedSlot && this.draggedStack != null && !this.isRightMouseClick;
        final ItemStack itemstack2 = this.field_146297_k.field_71439_g.field_71071_by.func_70445_o();
        String s = null;
        if (p_146977_1_ == this.clickedSlot && this.draggedStack != null && this.isRightMouseClick && itemstack != null) {
            final ItemStack func_77946_l;
            itemstack = (func_77946_l = itemstack.func_77946_l());
            func_77946_l.field_77994_a /= 2;
        }
        else if (this.field_147007_t && this.field_147008_s.contains(p_146977_1_) && itemstack2 != null) {
            if (this.field_147008_s.size() == 1) {
                return;
            }
            if (Container.func_94527_a(p_146977_1_, itemstack2, true) && this.inventorySlots.func_94531_b(p_146977_1_)) {
                itemstack = itemstack2.func_77946_l();
                flag = true;
                Container.func_94525_a(this.field_147008_s, this.field_146987_F, itemstack, (p_146977_1_.func_75211_c() == null) ? 0 : p_146977_1_.func_75211_c().field_77994_a);
                if (itemstack.field_77994_a > itemstack.func_77976_d()) {
                    s = EnumChatFormatting.YELLOW + "" + itemstack.func_77976_d();
                    itemstack.field_77994_a = itemstack.func_77976_d();
                }
                if (itemstack.field_77994_a > p_146977_1_.func_75219_a()) {
                    s = EnumChatFormatting.YELLOW + "" + p_146977_1_.func_75219_a();
                    itemstack.field_77994_a = p_146977_1_.func_75219_a();
                }
            }
            else {
                this.field_147008_s.remove(p_146977_1_);
                this.func_146980_g();
            }
        }
        this.field_73735_i = 100.0f;
        GuiPlayerInventoryDayM.field_146296_j.field_77023_b = 100.0f;
        if (itemstack == null) {
            final IIcon iicon = p_146977_1_.func_75212_b();
            if (iicon != null) {
                GL11.glDisable(2896);
                GL11.glEnable(3008);
                this.field_146297_k.func_110434_K().func_110577_a(TextureMap.field_110576_c);
                this.func_94065_a(i, j, iicon, 16, 16);
                GL11.glDisable(3008);
                GL11.glEnable(2896);
                flag2 = true;
            }
        }
        if (!flag2) {
            if (flag) {
                func_73734_a(i, j, i + 16, j + 16, -2130706433);
            }
            GL11.glEnable(2929);
            GL11.glPushMatrix();
            if (itemstack != null && p_146977_1_ instanceof SlotSized && itemstack.func_77973_b() instanceof DayMItem) {
                final DayMItem daymitem2 = (DayMItem)itemstack.func_77973_b();
                if (renderItem) {
                    GL11.glTranslatef((float)(-i * daymitem2.slotSizeX), (float)(-j * daymitem2.slotSizeY), 0.0f);
                    GL11.glTranslatef((float)i, (float)j, 0.0f);
                    GL11.glScalef((float)daymitem2.slotSizeX, (float)daymitem2.slotSizeY, 1.0f);
                }
                else {
                    GL11.glTranslatef((float)(-i * daymitem2.slotSizeX), (float)(-j * daymitem2.slotSizeY), 0.0f);
                    GL11.glTranslatef((float)i, (float)(j * 2), 0.0f);
                    GL11.glScalef((float)daymitem2.slotSizeX, 1.0f, 1.0f);
                }
            }
            if (p_146977_1_ != null && p_146977_1_ instanceof SlotClothing) {
                GL11.glDisable(2896);
                RenderSetup.drawTexture(i, j, 0.0, 0.0, 16.0, 16.0, 0.45f, TextureRegistry.gui_playerinv_slots[p_146977_1_.field_75222_d]);
            }
            GuiPlayerInventoryDayM.field_146296_j.func_82406_b(this.field_146289_q, this.field_146297_k.func_110434_K(), itemstack, i, j);
            GuiPlayerInventoryDayM.field_146296_j.func_94148_a(this.field_146289_q, this.field_146297_k.func_110434_K(), itemstack, i, j, s);
            GL11.glPopMatrix();
        }
        int test = Integer.MIN_VALUE;
        if (p_146977_1_ != null && p_146977_1_.func_75216_d()) {
            test = 536870911;
        }
        if (p_146977_1_ != null && p_146977_1_ instanceof SlotSized) {
            final SlotSized ss = (SlotSized)p_146977_1_;
            if (!ss.checkOccupied()) {
                if (itemstack != null && itemstack.func_77973_b() instanceof DayMItem) {
                    final DayMItem daymitem3 = (DayMItem)itemstack.func_77973_b();
                    if ((daymitem3.slotSizeX > 1 || daymitem3.slotSizeY > 1) && renderItem) {
                        func_73734_a(i, j, i + (16 + daymitem3.slotSizeX / 2) * daymitem3.slotSizeX + 1, j + (16 + daymitem3.slotSizeY / 2) * daymitem3.slotSizeY, test);
                    }
                }
            }
            else {
                test = 536870911;
            }
        }
        func_73734_a(i, j, i + 16, j + 16, test);
        GuiPlayerInventoryDayM.field_146296_j.field_77023_b = 0.0f;
        this.field_73735_i = 0.0f;
        if (itemstack != null && itemstack.func_77973_b() instanceof ItemMagazine) {
            final DayMItem daymitem4 = (DayMItem)itemstack.func_77973_b();
            final int bul = ItemMagazine.getBullets(itemstack);
            if (bul != 0) {
                final String text = "" + bul;
                int yyo = j + 9 + 16 * (daymitem4.slotSizeY - 1);
                int yof2 = 0;
                if (!(p_146977_1_ instanceof SlotSized)) {
                    yyo = j + 9;
                }
                if (!renderItem) {
                    yof2 = -16;
                }
                GL11.glPushMatrix();
                GL11.glTranslatef(0.0f, 0.0f, 200.0f);
                this.field_146289_q.func_78261_a(text, i + 16 - this.field_146289_q.func_78256_a(text), yyo + yof2, Integer.MAX_VALUE);
                GL11.glPopMatrix();
            }
        }
    }
    
    private void func_146980_g() {
        final ItemStack itemstack = this.field_146297_k.field_71439_g.field_71071_by.func_70445_o();
        if (itemstack != null && this.field_147007_t) {
            this.field_146996_I = itemstack.field_77994_a;
            for (final Slot slot : this.field_147008_s) {
                final ItemStack itemstack2 = itemstack.func_77946_l();
                final int i = (slot.func_75211_c() == null) ? 0 : slot.func_75211_c().field_77994_a;
                Container.func_94525_a(this.field_147008_s, this.field_146987_F, itemstack2, i);
                if (itemstack2.field_77994_a > itemstack2.func_77976_d()) {
                    itemstack2.field_77994_a = itemstack2.func_77976_d();
                }
                if (itemstack2.field_77994_a > slot.func_75219_a()) {
                    itemstack2.field_77994_a = slot.func_75219_a();
                }
                this.field_146996_I -= itemstack2.field_77994_a - i;
            }
        }
    }
    
    protected void func_73864_a(final int p_73864_1_, final int p_73864_2_, final int p_73864_3_) {
        super.func_73864_a(p_73864_1_, p_73864_2_, p_73864_3_);
        final boolean flag = p_73864_3_ == this.field_146297_k.field_71474_y.field_74322_I.func_151463_i() + 100;
        final Slot slot = this.getSlotAtPosition(p_73864_1_, p_73864_2_);
        final long l = Minecraft.func_71386_F();
        this.field_146993_M = (this.field_146998_K == slot && l - this.field_146997_J < 250L && this.field_146992_L == p_73864_3_);
        this.field_146995_H = false;
        if (p_73864_3_ == 0 || p_73864_3_ == 1 || flag) {
            final int i1 = this.guiLeft;
            final int j1 = this.guiTop;
            final boolean flag2 = false;
            int k1 = -1;
            if (slot != null) {
                k1 = slot.field_75222_d;
            }
            if (flag2) {
                k1 = -999;
            }
            if (this.field_146297_k.field_71474_y.field_85185_A && flag2 && this.field_146297_k.field_71439_g.field_71071_by.func_70445_o() == null) {
                this.field_146297_k.func_147108_a((GuiScreen)null);
                return;
            }
            if (k1 != -1) {
                if (this.field_146297_k.field_71474_y.field_85185_A) {
                    if (slot != null && slot.func_75216_d()) {
                        this.clickedSlot = slot;
                        this.draggedStack = null;
                        this.isRightMouseClick = (p_73864_3_ == 1);
                    }
                    else {
                        this.clickedSlot = null;
                    }
                }
                else if (!this.field_147007_t) {
                    if (this.field_146297_k.field_71439_g.field_71071_by.func_70445_o() == null) {
                        if (p_73864_3_ == this.field_146297_k.field_71474_y.field_74322_I.func_151463_i() + 100) {
                            this.handleMouseClick(slot, k1, p_73864_3_, 3);
                        }
                        else {
                            final boolean flag3 = k1 != -999 && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));
                            byte b0 = 0;
                            if (flag3) {
                                this.field_146994_N = ((slot != null && slot.func_75216_d()) ? slot.func_75211_c() : null);
                                b0 = 1;
                            }
                            else if (k1 == -999) {
                                b0 = 4;
                            }
                            this.handleMouseClick(slot, k1, p_73864_3_, b0);
                        }
                        this.field_146995_H = true;
                    }
                    else {
                        this.field_147007_t = true;
                        this.field_146988_G = p_73864_3_;
                        this.field_147008_s.clear();
                        if (p_73864_3_ == 0) {
                            this.field_146987_F = 0;
                        }
                        else if (p_73864_3_ == 1) {
                            this.field_146987_F = 1;
                        }
                    }
                }
            }
        }
        this.field_146998_K = slot;
        this.field_146997_J = l;
        this.field_146992_L = p_73864_3_;
    }
    
    protected void func_73869_a(final char p_73869_1_, final int p_73869_2_) {
        if (p_73869_2_ == 1 || p_73869_2_ == this.field_146297_k.field_71474_y.field_151445_Q.func_151463_i()) {
            this.field_146297_k.field_71439_g.func_71053_j();
        }
        this.checkHotbarKeys(p_73869_2_);
        if (this.theSlot != null && this.theSlot.func_75216_d()) {
            if (p_73869_2_ == this.field_146297_k.field_71474_y.field_74322_I.func_151463_i()) {
                this.handleMouseClick(this.theSlot, this.theSlot.field_75222_d, 0, 3);
            }
            else if (p_73869_2_ == this.field_146297_k.field_71474_y.field_74316_C.func_151463_i()) {
                this.handleMouseClick(this.theSlot, this.theSlot.field_75222_d, func_146271_m() ? 1 : 0, 4);
            }
        }
    }
    
    protected boolean checkHotbarKeys(final int p_146983_1_) {
        if (this.field_146297_k.field_71439_g.field_71071_by.func_70445_o() == null && this.theSlot != null) {
            for (int j = 0; j < 9; ++j) {
                if (p_146983_1_ == this.field_146297_k.field_71474_y.field_151456_ac[j].func_151463_i()) {
                    this.handleMouseClick(this.theSlot, this.theSlot.field_75222_d, j, 2);
                    return true;
                }
            }
        }
        return false;
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    public void func_73876_c() {
        super.func_73876_c();
        if (!this.field_146297_k.field_71439_g.func_70089_S() || this.field_146297_k.field_71439_g.field_70128_L) {
            this.field_146297_k.field_71439_g.func_71053_j();
        }
    }
    
    private boolean isMouseOverSlot(final Slot p_146981_1_, final int p_146981_2_, final int p_146981_3_) {
        return (!(p_146981_1_ instanceof SlotSized) || (p_146981_3_ - this.guiTop >= -12 && p_146981_3_ - this.guiTop <= 160)) && this.func_146978_c(p_146981_1_.field_75223_e, p_146981_1_.field_75221_f, 16, 16, p_146981_2_, p_146981_3_);
    }
    
    protected boolean func_146978_c(final int p_146978_1_, final int p_146978_2_, final int p_146978_3_, final int p_146978_4_, int p_146978_5_, int p_146978_6_) {
        final int k1 = this.guiLeft;
        final int l1 = this.guiTop;
        p_146978_5_ -= k1;
        p_146978_6_ -= l1;
        final boolean result = p_146978_5_ >= p_146978_1_ - 1 && p_146978_5_ < p_146978_1_ + p_146978_3_ + 1 && p_146978_6_ >= p_146978_2_ - 1 && p_146978_6_ < p_146978_2_ + p_146978_4_ + 1;
        return result;
    }
    
    protected void drawGuiContainerBackgroundLayer(final float par1, final int par2, final int par3) {
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, -2130706433, 16777215);
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, 0, Integer.MIN_VALUE);
        final int x = this.field_146294_l / 2;
        final int y = this.field_146295_m / 2;
        int xoffs = 0;
        int yoffs = -53;
        int sizeX = 96;
        int sizeY = 122;
        func_73734_a(x + xoffs - sizeX / 2, y + yoffs - sizeY / 2, x + xoffs + sizeX - sizeX / 2, y + yoffs + sizeY - sizeY / 2, Integer.MIN_VALUE);
        xoffs = 0;
        yoffs = 34;
        sizeX = 96;
        sizeY = 50;
        func_73734_a(x + xoffs - sizeX / 2, y + yoffs - sizeY / 2, x + xoffs + sizeX - sizeX / 2, y + yoffs + sizeY - sizeY / 2, Integer.MIN_VALUE);
        xoffs = 0;
        yoffs = 72;
        sizeX = 96;
        sizeY = 24;
        func_73734_a(x + xoffs - sizeX / 2, y + yoffs - sizeY / 2, x + xoffs + sizeX - sizeX / 2, y + yoffs + sizeY - sizeY / 2, Integer.MIN_VALUE);
        xoffs = -97;
        yoffs = -15;
        sizeX = 96;
        sizeY = 198;
        func_73734_a(x + xoffs - sizeX / 2, y + yoffs - sizeY / 2, x + xoffs + sizeX - sizeX / 2, y + yoffs + sizeY - sizeY / 2, Integer.MIN_VALUE);
        xoffs = 97;
        yoffs = -15;
        sizeX = 96;
        sizeY = 198;
        func_73734_a(x + xoffs - sizeX / 2, y + yoffs - sizeY / 2, x + xoffs + sizeX - sizeX / 2, y + yoffs + sizeY - sizeY / 2, Integer.MIN_VALUE);
        drawPlayerModel(x, y, 50, x - this.xSize_lo, -10.0f, (EntityLivingBase)this.field_146297_k.field_71439_g);
        xoffs = 150;
        yoffs = -15;
        sizeX = 8;
        sizeY = 198;
        func_73734_a(x + xoffs - sizeX / 2, y + yoffs - sizeY / 2, x + xoffs + sizeX - sizeX / 2, y + yoffs + sizeY - sizeY / 2, Integer.MIN_VALUE);
        xoffs = -150;
        yoffs = -15;
        sizeX = 8;
        sizeY = 198;
        func_73734_a(x + xoffs - sizeX / 2, y + yoffs - sizeY / 2, x + xoffs + sizeX - sizeX / 2, y + yoffs + sizeY - sizeY / 2, Integer.MIN_VALUE);
        xoffs = 150;
        yoffs = -89 + this.scrollbarLoc;
        sizeX = 8;
        sizeY = 50;
        boolean mouseOver = par2 > x + xoffs - sizeX / 2 && par2 < x + xoffs + sizeX - sizeX / 2 && par3 > y + yoffs - sizeY / 2 && par3 < y + yoffs + sizeY - sizeY / 2;
        int color = Integer.MAX_VALUE;
        final int color2 = Integer.MAX_VALUE;
        if ((mouseOver || this.draggingMouse) && Mouse.isButtonDown(0)) {
            this.draggingMouse = true;
            this.didSuperCheck = false;
            this.scrollbarLoc = par3 - (this.guiTop - 38) - sizeY / 2;
            if (this.scrollbarLoc < 0) {
                this.scrollbarLoc = 0;
            }
            if (this.scrollbarLoc > 148) {
                this.scrollbarLoc = 148;
            }
            color = Integer.MIN_VALUE;
        }
        else {
            this.draggingMouse = false;
        }
        final int d = Mouse.getDWheel();
        if (par2 > this.field_146294_l / 2) {
            if (d > 0) {
                this.didSuperCheck = false;
                this.scrollbarLoc -= 9;
            }
            if (d < 0) {
                this.didSuperCheck = false;
                this.scrollbarLoc += 9;
            }
            if (this.scrollbarLoc < 0) {
                this.scrollbarLoc = 0;
            }
            if (this.scrollbarLoc > 148) {
                this.scrollbarLoc = 148;
            }
        }
        else {
            if (d > 0) {
                this.scrollbarLoc2 -= 9;
            }
            if (d < 0) {
                this.scrollbarLoc2 += 9;
            }
            if (this.scrollbarLoc2 < 0) {
                this.scrollbarLoc2 = 0;
            }
            if (this.scrollbarLoc2 > 148) {
                this.scrollbarLoc2 = 148;
            }
        }
        func_73734_a(x + xoffs - sizeX / 2, y + yoffs - sizeY / 2, x + xoffs + sizeX - sizeX / 2, y + yoffs + sizeY - sizeY / 2, color);
        xoffs = -150;
        yoffs = -89 + this.scrollbarLoc2;
        sizeX = 8;
        sizeY = 50;
        mouseOver = (par2 > x + xoffs - sizeX / 2 && par2 < x + xoffs + sizeX - sizeX / 2 && par3 > y + yoffs - sizeY / 2 && par3 < y + yoffs + sizeY - sizeY / 2);
        if ((mouseOver || this.draggingMouse2) && Mouse.isButtonDown(0)) {
            this.draggingMouse2 = true;
            this.scrollbarLoc2 = par3 - (this.guiTop - 38) - sizeY / 2;
            if (this.scrollbarLoc2 < 0) {
                this.scrollbarLoc2 = 0;
            }
            if (this.scrollbarLoc2 > 148) {
                this.scrollbarLoc2 = 148;
            }
            color = Integer.MIN_VALUE;
        }
        else {
            this.draggingMouse2 = false;
        }
        func_73734_a(x + xoffs - sizeX / 2, y + yoffs - sizeY / 2, x + xoffs + sizeX - sizeX / 2, y + yoffs + sizeY - sizeY / 2, color2);
    }
    
    protected void func_146286_b(final int p_146286_1_, final int p_146286_2_, final int p_146286_3_) {
        super.func_146286_b(p_146286_1_, p_146286_2_, p_146286_3_);
        final Slot slot = this.getSlotAtPosition(p_146286_1_, p_146286_2_);
        final int l = this.guiLeft;
        final int i1 = this.guiTop;
        final boolean flag = p_146286_1_ < l || p_146286_2_ < i1 || p_146286_1_ >= l + this.xSize || p_146286_2_ >= i1 + this.ySize;
        int j1 = -1;
        if (slot != null) {
            j1 = slot.field_75222_d;
        }
        if (flag) {
            j1 = -999;
        }
        if (this.field_146993_M && slot != null && p_146286_3_ == 0 && this.inventorySlots.func_94530_a((ItemStack)null, slot)) {
            if (func_146272_n()) {
                if (slot != null && slot.field_75224_c != null && this.field_146994_N != null) {
                    for (final Slot slot2 : this.inventorySlots.field_75151_b) {
                        if (slot2 != null && slot2.func_82869_a((EntityPlayer)this.field_146297_k.field_71439_g) && slot2.func_75216_d() && slot2.field_75224_c == slot.field_75224_c && Container.func_94527_a(slot2, this.field_146994_N, true)) {
                            this.handleMouseClick(slot2, slot2.field_75222_d, p_146286_3_, 1);
                        }
                    }
                }
            }
            else {
                this.handleMouseClick(slot, j1, p_146286_3_, 6);
            }
            this.field_146993_M = false;
            this.field_146997_J = 0L;
        }
        else {
            if (this.field_147007_t && this.field_146988_G != p_146286_3_) {
                this.field_147007_t = false;
                this.field_147008_s.clear();
                this.field_146995_H = true;
                return;
            }
            if (this.field_146995_H) {
                this.field_146995_H = false;
                return;
            }
            if (this.clickedSlot != null && this.field_146297_k.field_71474_y.field_85185_A) {
                if (p_146286_3_ == 0 || p_146286_3_ == 1) {
                    if (this.draggedStack == null && slot != this.clickedSlot) {
                        this.draggedStack = this.clickedSlot.func_75211_c();
                    }
                    final boolean flag2 = Container.func_94527_a(slot, this.draggedStack, false);
                    if (j1 != -1 && this.draggedStack != null && flag2) {
                        this.handleMouseClick(this.clickedSlot, this.clickedSlot.field_75222_d, p_146286_3_, 0);
                        this.handleMouseClick(slot, j1, 0, 0);
                        if (this.field_146297_k.field_71439_g.field_71071_by.func_70445_o() != null) {
                            this.handleMouseClick(this.clickedSlot, this.clickedSlot.field_75222_d, p_146286_3_, 0);
                            this.field_147011_y = p_146286_1_ - l;
                            this.field_147010_z = p_146286_2_ - i1;
                            this.returningStackDestSlot = this.clickedSlot;
                            this.returningStack = this.draggedStack;
                        }
                        else {
                            this.returningStack = null;
                        }
                    }
                    else if (this.draggedStack != null) {
                        this.field_147011_y = p_146286_1_ - l;
                        this.field_147010_z = p_146286_2_ - i1;
                        this.returningStackDestSlot = this.clickedSlot;
                        this.returningStack = this.draggedStack;
                        this.returningStackTime = Minecraft.func_71386_F();
                    }
                    this.draggedStack = null;
                    this.clickedSlot = null;
                }
            }
            else if (this.field_147007_t && !this.field_147008_s.isEmpty()) {
                this.handleMouseClick(null, -999, Container.func_94534_d(0, this.field_146987_F), 5);
                for (final Slot slot2 : this.field_147008_s) {
                    this.handleMouseClick(slot2, slot2.field_75222_d, Container.func_94534_d(1, this.field_146987_F), 5);
                }
                this.handleMouseClick(null, -999, Container.func_94534_d(2, this.field_146987_F), 5);
            }
            else if (this.field_146297_k.field_71439_g.field_71071_by.func_70445_o() != null) {
                if (p_146286_3_ == this.field_146297_k.field_71474_y.field_74322_I.func_151463_i() + 100) {
                    this.handleMouseClick(slot, j1, p_146286_3_, 3);
                }
                else {
                    final boolean flag2 = j1 != -999 && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));
                    if (flag2) {
                        this.field_146994_N = ((slot != null && slot.func_75216_d()) ? slot.func_75211_c() : null);
                    }
                    this.handleMouseClick(slot, j1, p_146286_3_, flag2 ? 1 : 0);
                }
            }
        }
        if (this.field_146297_k.field_71439_g.field_71071_by.func_70445_o() == null) {
            this.field_146997_J = 0L;
        }
        this.field_147007_t = false;
    }
    
    public static void drawPlayerModel(final int x, final int y, final int scale, final float yaw, final float pitch, final EntityLivingBase entity) {
        GL11.glEnable(2903);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)x, (float)y, 50.0f);
        GL11.glScalef((float)(-scale), (float)scale, (float)scale);
        GL11.glRotatef(180.0f, 0.0f, 0.0f, 1.0f);
        final float f2 = entity.field_70761_aq;
        final float f3 = entity.field_70177_z;
        final float f4 = entity.field_70125_A;
        final float f5 = entity.field_70758_at;
        final float f6 = entity.field_70759_as;
        GL11.glRotatef(135.0f, 0.0f, 1.0f, 0.0f);
        RenderHelper.func_74519_b();
        GL11.glRotatef(-135.0f, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(-(float)Math.atan(pitch / 40.0f) * 20.0f, 1.0f, 0.0f, 0.0f);
        entity.field_70761_aq = (float)Math.atan(yaw / 40.0f) * 20.0f;
        entity.field_70177_z = (float)Math.atan(yaw / 40.0f) * 40.0f;
        entity.field_70125_A = -(float)Math.atan(pitch / 40.0f) * 20.0f;
        entity.field_70759_as = entity.field_70177_z;
        entity.field_70758_at = entity.field_70177_z;
        GL11.glTranslatef(0.0f, entity.field_70129_M, 0.0f);
        RenderManager.field_78727_a.field_78735_i = 180.0f;
        RenderManager.field_78727_a.func_147940_a((Entity)entity, 0.0, 0.0, 0.0, 0.0f, 1.0f);
        entity.field_70761_aq = f2;
        entity.field_70177_z = f3;
        entity.field_70125_A = f4;
        entity.field_70758_at = f5;
        entity.field_70759_as = f6;
        GL11.glPopMatrix();
        RenderHelper.func_74518_a();
        GL11.glDisable(32826);
        OpenGlHelper.func_77473_a(OpenGlHelper.field_77476_b);
        GL11.glDisable(3553);
        OpenGlHelper.func_77473_a(OpenGlHelper.field_77478_a);
    }
    
    static {
        iconLocation = new ResourceLocation("tutorial:textures/gui/custom_inventory.png");
    }
}
