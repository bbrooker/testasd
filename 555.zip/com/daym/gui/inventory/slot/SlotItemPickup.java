package com.daym.gui.inventory.slot;

import net.minecraft.inventory.*;
import net.minecraft.item.*;

public class SlotItemPickup extends Slot
{
    public int actualPosy;
    
    public SlotItemPickup(final IInventory inventory, final int slotIndex, final int x, final int y) {
        super(inventory, slotIndex, x, y);
        this.actualPosy = y;
    }
    
    public boolean func_75214_a(final ItemStack itemstack) {
        return true;
    }
}
