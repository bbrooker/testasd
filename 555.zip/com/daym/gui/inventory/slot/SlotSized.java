package com.daym.gui.inventory.slot;

import net.minecraft.inventory.*;
import net.minecraft.item.*;
import com.daym.items.*;
import com.daym.registry.*;

public class SlotSized extends Slot
{
    private boolean occupied;
    public SlotSized parent;
    public int actualPosy;
    
    public SlotSized(final IInventory arg0, final int arg1, final int arg2, final int arg3) {
        super(arg0, arg1, arg2, arg3);
        this.occupied = false;
        this.actualPosy = arg3;
    }
    
    public boolean checkOccupied() {
        if (this.parent != null) {
            if (!this.parent.func_75216_d()) {
                this.occupied = false;
            }
        }
        else {
            this.occupied = false;
        }
        return this.occupied;
    }
    
    public void setOccupied(final Slot p, final boolean oc) {
        if (p instanceof SlotSized) {
            this.parent = (SlotSized)p;
        }
        if (!this.func_75216_d() && this.parent.func_75216_d() && this.parent.func_75211_c().func_77973_b() instanceof DayMItem) {
            this.occupied = oc;
        }
    }
    
    public boolean func_75214_a(final ItemStack itemstack) {
        return itemstack == null || (!(itemstack.func_77973_b() instanceof ItemWithInventory) && itemstack.func_77973_b() != ItemRegistry.item_ak47 && itemstack.func_77973_b() != ItemRegistry.item_rem700 && itemstack.func_77973_b() != ItemRegistry.item_axe);
    }
}
