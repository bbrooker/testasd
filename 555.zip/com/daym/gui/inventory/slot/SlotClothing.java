package com.daym.gui.inventory.slot;

import net.minecraft.inventory.*;
import net.minecraft.item.*;
import com.daym.items.*;

public class SlotClothing extends Slot
{
    public SlotClothing(final IInventory inventory, final int slotIndex, final int x, final int y) {
        super(inventory, slotIndex, x, y);
    }
    
    public boolean func_75214_a(final ItemStack itemstack) {
        if (itemstack != null) {
            if (itemstack.func_77973_b() instanceof DayMItem) {
                final DayMItem daymitem = (DayMItem)itemstack.func_77973_b();
                for (final Integer i : daymitem.validslots) {
                    if (this.field_75222_d == i) {
                        return true;
                    }
                }
            }
            if (itemstack.func_77973_b() instanceof ItemWithInventory) {
                final ItemWithInventory daymitem2 = (ItemWithInventory)itemstack.func_77973_b();
                for (final Integer i : daymitem2.validslots) {
                    if (this.field_75222_d == i) {
                        return true;
                    }
                }
            }
            if (itemstack.func_77973_b() instanceof ItemClothing) {
                final ItemClothing daymitem3 = (ItemClothing)itemstack.func_77973_b();
                for (final Integer i : daymitem3.validslots) {
                    if (this.field_75222_d == i) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
