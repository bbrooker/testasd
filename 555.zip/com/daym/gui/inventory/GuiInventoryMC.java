package com.daym.gui.inventory;

import cpw.mods.fml.relauncher.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.resources.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.achievement.*;

@SideOnly(Side.CLIENT)
public class GuiInventoryMC extends InventoryEffectRenderer
{
    private float xSizeFloat;
    private float ySizeFloat;
    
    public GuiInventoryMC(final EntityPlayer p_i1094_1_) {
        super(p_i1094_1_.field_71069_bz);
        this.field_146291_p = true;
    }
    
    public void func_73876_c() {
        if (this.field_146297_k.field_71442_b.func_78758_h()) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiContainerCreativeMC((EntityPlayer)this.field_146297_k.field_71439_g));
        }
    }
    
    public void func_73866_w_() {
        this.field_146292_n.clear();
        if (this.field_146297_k.field_71442_b.func_78758_h()) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiContainerCreativeMC((EntityPlayer)this.field_146297_k.field_71439_g));
        }
        else {
            super.func_73866_w_();
        }
    }
    
    protected void func_146979_b(final int p_drawGuiContainerForegroundLayer_1_, final int p_drawGuiContainerForegroundLayer_2_) {
        this.field_146289_q.func_78276_b(I18n.func_135052_a("container.crafting", new Object[0]), 86, 16, 4210752);
    }
    
    public void func_73863_a(final int p_drawScreen_1_, final int p_drawScreen_2_, final float p_drawScreen_3_) {
        super.func_73863_a(p_drawScreen_1_, p_drawScreen_2_, p_drawScreen_3_);
        this.xSizeFloat = p_drawScreen_1_;
        this.ySizeFloat = p_drawScreen_2_;
    }
    
    protected void func_146976_a(final float p_drawGuiContainerBackgroundLayer_1_, final int p_drawGuiContainerBackgroundLayer_2_, final int p_drawGuiContainerBackgroundLayer_3_) {
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.field_146297_k.func_110434_K().func_110577_a(GuiInventoryMC.field_147001_a);
        final int i = this.field_147003_i;
        final int j = this.field_147009_r;
        this.func_73729_b(i, j, 0, 0, this.field_146999_f, this.field_147000_g);
        func_147046_a(i + 51, j + 75, 30, i + 51 - this.xSizeFloat, j + 75 - 50 - this.ySizeFloat, (EntityLivingBase)this.field_146297_k.field_71439_g);
    }
    
    public static void func_147046_a(final int p_147046_0_, final int p_147046_1_, final int p_147046_2_, final float p_147046_3_, final float p_147046_4_, final EntityLivingBase p_147046_5_) {
        GL11.glEnable(2903);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)p_147046_0_, (float)p_147046_1_, 50.0f);
        GL11.glScalef((float)(-p_147046_2_), (float)p_147046_2_, (float)p_147046_2_);
        GL11.glRotatef(180.0f, 0.0f, 0.0f, 1.0f);
        final float f1 = p_147046_5_.field_70761_aq;
        final float f2 = p_147046_5_.field_70177_z;
        final float f3 = p_147046_5_.field_70125_A;
        final float f4 = p_147046_5_.field_70758_at;
        final float f5 = p_147046_5_.field_70759_as;
        GL11.glRotatef(135.0f, 0.0f, 1.0f, 0.0f);
        RenderHelper.func_74519_b();
        GL11.glRotatef(-135.0f, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(-(float)Math.atan(p_147046_4_ / 40.0f) * 20.0f, 1.0f, 0.0f, 0.0f);
        p_147046_5_.field_70761_aq = (float)Math.atan(p_147046_3_ / 40.0f) * 20.0f;
        p_147046_5_.field_70177_z = (float)Math.atan(p_147046_3_ / 40.0f) * 40.0f;
        p_147046_5_.field_70125_A = -(float)Math.atan(p_147046_4_ / 40.0f) * 20.0f;
        p_147046_5_.field_70759_as = p_147046_5_.field_70177_z;
        p_147046_5_.field_70758_at = p_147046_5_.field_70177_z;
        GL11.glTranslatef(0.0f, p_147046_5_.field_70129_M, 0.0f);
        RenderManager.field_78727_a.field_78735_i = 180.0f;
        RenderManager.field_78727_a.func_147940_a((Entity)p_147046_5_, 0.0, 0.0, 0.0, 0.0f, 1.0f);
        p_147046_5_.field_70761_aq = f1;
        p_147046_5_.field_70177_z = f2;
        p_147046_5_.field_70125_A = f3;
        p_147046_5_.field_70758_at = f4;
        p_147046_5_.field_70759_as = f5;
        GL11.glPopMatrix();
        RenderHelper.func_74518_a();
        GL11.glDisable(32826);
        OpenGlHelper.func_77473_a(OpenGlHelper.field_77476_b);
        GL11.glDisable(3553);
        OpenGlHelper.func_77473_a(OpenGlHelper.field_77478_a);
    }
    
    protected void func_146284_a(final GuiButton p_actionPerformed_1_) {
        if (p_actionPerformed_1_.field_146127_k == 0) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiAchievements((GuiScreen)this, this.field_146297_k.field_71439_g.func_146107_m()));
        }
        if (p_actionPerformed_1_.field_146127_k == 1) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiStats((GuiScreen)this, this.field_146297_k.field_71439_g.func_146107_m()));
        }
    }
}
