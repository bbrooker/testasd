package com.daym.gui.inventory;

import net.minecraft.client.gui.inventory.*;
import net.minecraft.entity.player.*;
import com.daym.registry.*;
import com.daym.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;

public class GuiContainerCreativeMC extends GuiContainerCreative
{
    public GuiContainerCreativeMC(final EntityPlayer arg0) {
        super(arg0);
    }
    
    public void func_146281_b() {
        super.func_146281_b();
        KeybindRegistry.isKeyDown = false;
        DayM.daym_6cbaa18a0.sendToServer((IMessage)new MSG_OpenGui(1, DayM.GUI_CUSTOM_INV));
    }
}
