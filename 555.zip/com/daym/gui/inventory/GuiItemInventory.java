package com.daym.gui.inventory;

import net.minecraft.client.gui.inventory.*;
import net.minecraft.util.*;
import com.daym.inventory.*;
import net.minecraft.inventory.*;
import net.minecraft.client.resources.*;
import org.lwjgl.opengl.*;

public class GuiItemInventory extends GuiContainer
{
    private float xSize_lo;
    private float ySize_lo;
    private static final ResourceLocation iconLocation;
    private final ItemInventory inventory;
    private int inventoryRows;
    
    public GuiItemInventory(final ContainerItem containerItem) {
        super((Container)containerItem);
        this.inventory = containerItem.inventory;
        this.inventoryRows = 1;
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        super.func_73863_a(par1, par2, par3);
        this.xSize_lo = par1;
        this.ySize_lo = par2;
    }
    
    protected void func_146979_b(final int par1, final int par2) {
        final String s = this.inventory.func_145825_b();
        this.field_146289_q.func_78276_b(s, 8, 58, Integer.MAX_VALUE);
        this.field_146289_q.func_78276_b(I18n.func_135052_a("Hotbar", new Object[0]), 8, this.field_147000_g - 96 + 58, Integer.MAX_VALUE);
    }
    
    protected void func_146976_a(final float par1, final int par2, final int par3) {
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.field_146297_k.func_110434_K().func_110577_a(GuiItemInventory.iconLocation);
        final int i = (this.field_146294_l - this.field_146999_f) / 2;
        final int j = (this.field_146295_m - this.field_147000_g) / 2;
        func_73734_a(i, (int)(j + 56.8), i + 9 * this.inventory.func_70302_i_() * 2 + 14, (int)(j + 56.8 + this.inventoryRows * 18 + 17.0 + 5.0), Integer.MIN_VALUE);
        func_73734_a(i, j + 142 - 17, i + 162 + 14, j + 142 + 18 + 8, Integer.MIN_VALUE);
        for (int a = 0; a < this.inventory.func_70302_i_(); ++a) {
            func_73734_a(i + 8 + a * 18, (int)(j + 56.8 + 18.0), i + 8 + a * 18 + 16, (int)(j + 56.8 + 18.0) + 16, -1073741824);
        }
        for (int a = 0; a < 9; ++a) {
            func_73734_a(i + 8 + a * 18, j + 142, i + 8 + a * 18 + 16, j + 142 + 16, -1073741824);
        }
    }
    
    static {
        iconLocation = new ResourceLocation("textures/gui/container/generic_54.png");
    }
}
