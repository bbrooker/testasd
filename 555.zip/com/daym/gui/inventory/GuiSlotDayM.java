package com.daym.gui.inventory;

import net.minecraft.inventory.*;
import net.minecraft.util.*;
import cpw.mods.fml.relauncher.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.renderer.texture.*;

public class GuiSlotDayM
{
    private final int slotIndex;
    public final IInventory inventory;
    public int slotNumber;
    public int xDisplayPosition;
    public int yDisplayPosition;
    private static final String __OBFID = "CL_00001762";
    protected IIcon backgroundIcon;
    @SideOnly(Side.CLIENT)
    protected ResourceLocation texture;
    
    public GuiSlotDayM(final IInventory p_i1824_1_, final int p_i1824_2_, final int p_i1824_3_, final int p_i1824_4_) {
        this.backgroundIcon = null;
        this.inventory = p_i1824_1_;
        this.slotIndex = p_i1824_2_;
        this.xDisplayPosition = p_i1824_3_;
        this.yDisplayPosition = p_i1824_4_;
    }
    
    public void onSlotChange(final ItemStack p_75220_1_, final ItemStack p_75220_2_) {
        if (p_75220_1_ != null && p_75220_2_ != null && p_75220_1_.func_77973_b() == p_75220_2_.func_77973_b()) {
            final int i = p_75220_2_.field_77994_a - p_75220_1_.field_77994_a;
            if (i > 0) {
                this.onCrafting(p_75220_1_, i);
            }
        }
    }
    
    protected void onCrafting(final ItemStack p_75210_1_, final int p_75210_2_) {
    }
    
    protected void onCrafting(final ItemStack p_75208_1_) {
    }
    
    public void onPickupFromSlot(final EntityPlayer p_82870_1_, final ItemStack p_82870_2_) {
        this.onSlotChanged();
    }
    
    public boolean isItemValid(final ItemStack p_75214_1_) {
        return true;
    }
    
    public ItemStack getStack() {
        return this.inventory.func_70301_a(this.slotIndex);
    }
    
    public boolean getHasStack() {
        return this.getStack() != null;
    }
    
    public void putStack(final ItemStack p_75215_1_) {
        this.inventory.func_70299_a(this.slotIndex, p_75215_1_);
        this.onSlotChanged();
    }
    
    public void onSlotChanged() {
        this.inventory.func_70296_d();
    }
    
    public int getSlotStackLimit() {
        return this.inventory.func_70297_j_();
    }
    
    public ItemStack decrStackSize(final int p_75209_1_) {
        return this.inventory.func_70298_a(this.slotIndex, p_75209_1_);
    }
    
    public boolean isSlotInInventory(final IInventory p_75217_1_, final int p_75217_2_) {
        return p_75217_1_ == this.inventory && p_75217_2_ == this.slotIndex;
    }
    
    public boolean canTakeStack(final EntityPlayer p_82869_1_) {
        return true;
    }
    
    @SideOnly(Side.CLIENT)
    public IIcon getBackgroundIconIndex() {
        return this.backgroundIcon;
    }
    
    @SideOnly(Side.CLIENT)
    public boolean func_111238_b() {
        return true;
    }
    
    @SideOnly(Side.CLIENT)
    public ResourceLocation getBackgroundIconTexture() {
        return (this.texture == null) ? TextureMap.field_110576_c : this.texture;
    }
    
    public void setBackgroundIcon(final IIcon icon) {
        this.backgroundIcon = icon;
    }
    
    @SideOnly(Side.CLIENT)
    public void setBackgroundIconTexture(final ResourceLocation texture) {
        this.texture = texture;
    }
    
    public int getSlotIndex() {
        return this.slotIndex;
    }
}
