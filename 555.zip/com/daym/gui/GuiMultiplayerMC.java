package com.daym.gui;

import net.minecraft.client.gui.*;

public class GuiMultiplayerMC extends GuiMultiplayer
{
    public GuiMultiplayerMC(final GuiScreen arg0) {
        super(arg0);
    }
    
    protected void func_146284_a(final GuiButton p_146284_1_) {
        super.func_146284_a(p_146284_1_);
        if (p_146284_1_.field_146124_l && p_146284_1_.field_146127_k == 8) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerMC(new GuiDaymMainMenu()));
        }
    }
}
