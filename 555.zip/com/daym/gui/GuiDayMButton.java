package com.daym.gui;

import net.minecraft.client.multiplayer.*;
import com.daym.threads.*;
import com.daym.handlers.*;
import net.minecraft.client.*;
import com.daym.clientproxy.*;
import org.lwjgl.opengl.*;
import java.awt.*;
import com.daym.registry.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.gui.*;
import net.minecraft.util.*;
import net.minecraft.client.audio.*;

public class GuiDayMButton extends GuiButton implements Comparable
{
    public int strwidth;
    private boolean invert;
    public String serverIp;
    public String serverVersion;
    public String serverMOTD;
    public String serverPort;
    public ServerData serverData;
    public String currentString;
    GuiMultiplayerDayM parent;
    PingServerDayMThread thread;
    private boolean isRefresh;
    private boolean needsServerSelected;
    private boolean failedtoload;
    private int timer;
    
    public GuiDayMButton(final int arg0, final int arg1, final int arg2, final int arg3, final int arg4, final String arg5) {
        super(arg0, arg1, arg2, arg3, arg4, arg5);
        this.invert = false;
        this.serverIp = "127.0.0.1";
        this.serverVersion = "-1";
        this.serverMOTD = "Error";
        this.serverPort = "25565";
        this.serverData = null;
        this.currentString = "ERROR";
        this.parent = null;
        this.thread = null;
        this.isRefresh = false;
        this.needsServerSelected = false;
        this.failedtoload = false;
        this.timer = 0;
    }
    
    public GuiDayMButton(final int bid, final int cr, final String format, final int yoffset, final int xx, final int yy, final int height, String text) {
        super(bid, xx, yy + yoffset * cr, 0, height, text);
        this.invert = false;
        this.serverIp = "127.0.0.1";
        this.serverVersion = "-1";
        this.serverMOTD = "Error";
        this.serverPort = "25565";
        this.serverData = null;
        this.currentString = "ERROR";
        this.parent = null;
        this.thread = null;
        this.isRefresh = false;
        this.needsServerSelected = false;
        this.failedtoload = false;
        this.timer = 0;
        if (text == "daym.gui.server.refresh") {
            this.isRefresh = true;
            this.field_146126_j = LanguageHandler.translate(text);
            text = this.field_146126_j;
            this.strwidth = Minecraft.func_71410_x().field_71466_p.func_78256_a(text) + 16;
        }
        else {
            this.strwidth = Minecraft.func_71410_x().field_71466_p.func_78256_a(text) + 10;
        }
        this.field_146128_h = getPosFormat(format, xx, this.strwidth);
        this.field_146120_f = this.strwidth;
        if (text == "$mcico") {
            this.field_146120_f = 20;
        }
    }
    
    public GuiDayMButton(final int bid, final int cr, final String format, final int yoffset, final int xx, final int yy, final int height, final String text, final boolean sp) {
        super(bid, xx, yy + yoffset * cr, height * 2, height, text);
        this.invert = false;
        this.serverIp = "127.0.0.1";
        this.serverVersion = "-1";
        this.serverMOTD = "Error";
        this.serverPort = "25565";
        this.serverData = null;
        this.currentString = "ERROR";
        this.parent = null;
        this.thread = null;
        this.isRefresh = false;
        this.needsServerSelected = false;
        this.failedtoload = false;
        this.timer = 0;
        this.strwidth = Minecraft.func_71410_x().field_71466_p.func_78256_a(text) + 10;
        this.needsServerSelected = sp;
        this.field_146128_h = getPosFormat(format, xx, this.strwidth);
        this.field_146120_f = this.strwidth;
    }
    
    public GuiDayMButton(final int bid, final int cr, final String format, final int yoffset, final int xx, final int yy, final int height, final String text, final boolean horizontal, final int widt) {
        super(bid, xx, yy, height * 2, height, text);
        this.invert = false;
        this.serverIp = "127.0.0.1";
        this.serverVersion = "-1";
        this.serverMOTD = "Error";
        this.serverPort = "25565";
        this.serverData = null;
        this.currentString = "ERROR";
        this.parent = null;
        this.thread = null;
        this.isRefresh = false;
        this.needsServerSelected = false;
        this.failedtoload = false;
        this.timer = 0;
        this.strwidth = Minecraft.func_71410_x().field_71466_p.func_78256_a(text) + 10;
        if (!horizontal) {
            this.field_146128_h = getPosFormat(format, xx, this.strwidth);
            this.field_146129_i = yy + yoffset * cr;
        }
        else {
            this.field_146128_h = getPosFormat(format, xx, this.strwidth) + widt;
        }
        this.field_146120_f = this.strwidth;
    }
    
    public GuiDayMButton(final int bid, final int cr, final String format, final int yoffset, final int xx, final int yy, final int height, final String text, final int wid) {
        super(bid, xx, yy + yoffset * cr, height * 2, height, text);
        this.invert = false;
        this.serverIp = "127.0.0.1";
        this.serverVersion = "-1";
        this.serverMOTD = "Error";
        this.serverPort = "25565";
        this.serverData = null;
        this.currentString = "ERROR";
        this.parent = null;
        this.thread = null;
        this.isRefresh = false;
        this.needsServerSelected = false;
        this.failedtoload = false;
        this.timer = 0;
        this.field_146128_h = xx;
        this.field_146120_f = wid;
        this.invert = true;
    }
    
    public GuiDayMButton(final int bid, final int cr, final String format, final int yoffset, final int xx, final int yy, final int height, final String text, final int wid, final String ip, final String port, final String ver, final String name, final ServerData sd, final GuiMultiplayerDayM d, final PingServerDayMThread th) {
        super(bid, xx, yy + yoffset * cr, height * 2, height, text);
        this.invert = false;
        this.serverIp = "127.0.0.1";
        this.serverVersion = "-1";
        this.serverMOTD = "Error";
        this.serverPort = "25565";
        this.serverData = null;
        this.currentString = "ERROR";
        this.parent = null;
        this.thread = null;
        this.isRefresh = false;
        this.needsServerSelected = false;
        this.failedtoload = false;
        this.timer = 0;
        this.field_146128_h = xx;
        this.field_146120_f = wid;
        this.invert = true;
        this.currentString = text;
        this.serverIp = ip;
        this.serverPort = port;
        this.serverVersion = ver;
        this.serverMOTD = name;
        this.serverData = sd;
        this.parent = d;
        if (th != null) {
            (this.thread = th).start();
        }
    }
    
    public static GuiDayMButton copyButton(final GuiButton b) {
        final GuiDayMButton daymb = new GuiDayMButton(b.field_146127_k, b.field_146128_h, b.field_146129_i, b.field_146120_f, b.field_146121_g, b.field_146126_j);
        daymb.field_146124_l = b.field_146124_l;
        return daymb;
    }
    
    private static int getPosFormat(final String format, final int xx, final int strw) {
        if (format.toLowerCase().contains("right")) {
            return xx - strw;
        }
        if (format.toLowerCase().contains("left")) {
            return xx;
        }
        if (format.toLowerCase().contains("center")) {
            return xx - strw / 2;
        }
        return xx;
    }
    
    public GuiDayMButton(final int i, final int j, final int par1, final String translateKey) {
        super(i, j, par1, translateKey);
        this.invert = false;
        this.serverIp = "127.0.0.1";
        this.serverVersion = "-1";
        this.serverMOTD = "Error";
        this.serverPort = "25565";
        this.serverData = null;
        this.currentString = "ERROR";
        this.parent = null;
        this.thread = null;
        this.isRefresh = false;
        this.needsServerSelected = false;
        this.failedtoload = false;
        this.timer = 0;
    }
    
    public void func_146112_a(final Minecraft p_146112_1_, final int p_146112_2_, final int p_146112_3_) {
        if (this.needsServerSelected && this.field_146124_l != ClientProxy.daym_72efc9900) {
            this.field_146124_l = ClientProxy.daym_72efc9900;
        }
        int textOffsetY = 0;
        if (this.field_146121_g < 10) {
            textOffsetY = 1;
        }
        if (this.thread != null) {
            if (this.thread != null && this.thread.daym_28f500420 == 2) {
                this.serverData = this.thread.server;
                this.thread.stop();
                this.thread = null;
            }
            if (this.thread != null && this.thread.daym_28f500420 == 1) {
                this.failedtoload = true;
                this.thread.stop();
                this.thread = null;
            }
        }
        else if (this.serverMOTD != "Error") {
            if (this.timer > 230) {
                this.failedtoload = true;
                if (this.thread != null) {
                    this.thread.stop();
                    this.thread = null;
                }
            }
            else {
                ++this.timer;
            }
        }
        else {
            this.timer = 0;
        }
        int offsetY = 0;
        final int posX = this.field_146129_i;
        int test = 10000;
        int test2 = -1000;
        if (this.parent != null) {
            test = this.parent.field_146295_m / 4 + 14 - 52 + 26 + 180 - 12;
            test2 = this.parent.field_146295_m / 4 + 14 - 36;
        }
        if (this.parent != null) {
            final int top = this.parent.field_146295_m / 4 + 14 - 37;
            offsetY = (int)(-(top - this.parent.scrollBarY) * this.parent.currentButtonList.size() / 8.866666666666667) / 12 * 12;
        }
        this.field_146129_i -= offsetY;
        if (this.field_146125_m && this.field_146129_i > test2 && this.field_146129_i < test) {
            final FontRenderer fontrenderer = p_146112_1_.field_71466_p;
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            this.field_146123_n = (p_146112_2_ >= this.field_146128_h && p_146112_3_ >= this.field_146129_i && p_146112_2_ < this.field_146128_h + this.field_146120_f && p_146112_3_ < this.field_146129_i + this.field_146121_g);
            final int k = this.func_146114_a(this.field_146123_n);
            GL11.glEnable(3042);
            OpenGlHelper.func_148821_a(770, 771, 1, 0);
            GL11.glBlendFunc(770, 771);
            int var0 = 1;
            if (k > 1) {
                var0 = 2;
            }
            this.func_73733_a(this.field_146128_h, this.field_146129_i, this.field_146128_h + this.field_146120_f, this.field_146129_i + this.field_146121_g, Integer.MIN_VALUE / var0, Integer.MIN_VALUE / var0);
            this.func_146119_b(p_146112_1_, p_146112_2_, p_146112_3_);
            int l = Color.white.getRGB();
            if (k > 1) {
                l = Color.red.getRGB();
            }
            if (!this.field_146124_l) {
                l = Color.gray.getRGB();
            }
            if (this.serverMOTD == "Error") {
                String texttr = this.field_146126_j;
                if (this.isRefresh && ClientProxy.daym_1227f65d0 > 0) {
                    texttr = this.field_146126_j + " (" + ClientProxy.daym_1227f65d0 / 20 + ")";
                }
                if (!this.invert) {
                    if (!texttr.contains("$mcico")) {
                        this.func_73732_a(fontrenderer, texttr, this.field_146128_h - 1 + this.field_146120_f / 2, this.field_146129_i + 1 - textOffsetY + (this.field_146121_g - 8) / 2, Color.black.getRGB());
                        this.func_73732_a(fontrenderer, texttr, this.field_146128_h + this.field_146120_f / 2, this.field_146129_i - textOffsetY + (this.field_146121_g - 8) / 2, l);
                    }
                    else {
                        if (this.field_146120_f != 20) {
                            this.field_146120_f = 20;
                        }
                        GL11.glPushMatrix();
                        GL11.glDisable(2929);
                        GL11.glDepthMask(false);
                        GL11.glBlendFunc(770, 771);
                        if (k > 1) {
                            GL11.glColor4f(0.5f, 0.5f, 0.5f, 1.0f);
                        }
                        else {
                            GL11.glColor4f(0.8f, 0.8f, 0.8f, 1.0f);
                        }
                        GL11.glDisable(3008);
                        GL11.glEnable(3042);
                        TextureRegistry.bindResource(TextureRegistry.gui_mcicon);
                        final Tessellator var2 = Tessellator.field_78398_a;
                        var2.func_78382_b();
                        var2.func_78374_a(this.field_146128_h - this.field_146120_f / 2.5 + this.field_146120_f / 2, this.field_146129_i + this.field_146121_g / 2.5 + this.field_146121_g / 2, -90.0, 0.0, 1.0);
                        var2.func_78374_a(this.field_146128_h + this.field_146120_f / 2.5 + this.field_146120_f / 2, this.field_146129_i + this.field_146121_g / 2.5 + this.field_146121_g / 2, -90.0, 1.0, 1.0);
                        var2.func_78374_a(this.field_146128_h + this.field_146120_f / 2.5 + this.field_146120_f / 2, this.field_146129_i - this.field_146121_g / 2.5 + this.field_146121_g / 2, -90.0, 1.0, 0.0);
                        var2.func_78374_a(this.field_146128_h - this.field_146120_f / 2.5 + this.field_146120_f / 2, this.field_146129_i - this.field_146121_g / 2.5 + this.field_146121_g / 2, -90.0, 0.0, 0.0);
                        var2.func_78381_a();
                        GL11.glDepthMask(true);
                        GL11.glEnable(2929);
                        GL11.glEnable(3008);
                        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                        GL11.glPopMatrix();
                    }
                }
                else {
                    this.func_73732_a(fontrenderer, texttr, this.field_146128_h - 1 + fontrenderer.func_78256_a(texttr) / 2 + 2, this.field_146129_i + 1 + (this.field_146121_g - 8) / 2, Color.black.getRGB());
                    this.func_73732_a(fontrenderer, texttr, this.field_146128_h + fontrenderer.func_78256_a(texttr) / 2 + 2, this.field_146129_i + (this.field_146121_g - 8) / 2, l);
                }
            }
            else {
                if (this.parent != null && this.serverIp == this.parent.serverIp && this.serverMOTD == this.parent.serverMOTD && this.serverVersion == this.parent.serverVersion && this.serverPort == this.parent.serverPort) {
                    this.func_73733_a(this.field_146128_h, this.field_146129_i, this.field_146128_h + this.field_146120_f, this.field_146129_i + this.field_146121_g, Integer.MIN_VALUE / var0 / 4, Integer.MIN_VALUE / var0 / 4);
                }
                String errormsg = EnumChatFormatting.GOLD.toString() + "Loading...";
                if (this.failedtoload) {
                    errormsg = EnumChatFormatting.YELLOW.toString() + "Timed out. " + EnumChatFormatting.GRAY.toString() + " (Server might be local or packet returned empty. Try refreshing.)";
                }
                if (this.serverData != null) {
                    if (this.serverData.field_78846_c != null) {
                        final String players = "[" + StringUtils.func_76338_a(this.serverData.field_78846_c) + "]";
                        String name = StringUtils.func_76338_a(this.serverMOTD).replace("*?*", "#").replace("*!*", " ");
                        String version = "[" + this.serverVersion + "]";
                        String ping = "(" + this.serverData.field_78844_e + ")";
                        final int len = 76;
                        if (name.length() > len) {
                            name = this.serverMOTD.substring(0, Math.min(this.serverMOTD.length(), len)) + "...";
                        }
                        this.func_73732_a(fontrenderer, name, this.field_146128_h - 1 + fontrenderer.func_78256_a(name) / 2 + 2, this.field_146129_i + 1 + (this.field_146121_g - 8) / 2, Color.black.getRGB());
                        this.func_73732_a(fontrenderer, name, this.field_146128_h + fontrenderer.func_78256_a(name) / 2 + 2, this.field_146129_i + (this.field_146121_g - 8) / 2, l);
                        this.func_73732_a(fontrenderer, version, this.field_146128_h - 1 + this.field_146120_f - fontrenderer.func_78256_a(version) / 2 - 22, this.field_146129_i + 1 + (this.field_146121_g - 8) / 2, Color.black.getRGB());
                        if ("2.1.4_beta".contains(this.serverVersion)) {
                            version = EnumChatFormatting.GREEN.toString() + version;
                        }
                        else {
                            version = EnumChatFormatting.GOLD.toString() + version;
                        }
                        this.func_73732_a(fontrenderer, version, this.field_146128_h + this.field_146120_f - fontrenderer.func_78256_a(version) / 2 - 22, this.field_146129_i + (this.field_146121_g - 8) / 2, l);
                        this.func_73732_a(fontrenderer, ping, this.field_146128_h + this.field_146120_f - fontrenderer.func_78256_a(ping) / 2 - 2, this.field_146129_i + (this.field_146121_g - 8) / 2, Color.black.getRGB());
                        ping = this.colorPing(this.serverData.field_78844_e) + ping;
                        this.func_73732_a(fontrenderer, ping, this.field_146128_h + this.field_146120_f - fontrenderer.func_78256_a(ping) / 2 - 2, this.field_146129_i + (this.field_146121_g - 8) / 2, l);
                        this.func_73732_a(fontrenderer, players, this.field_146128_h - 1 + this.field_146120_f - fontrenderer.func_78256_a(players) / 2 - 64, this.field_146129_i + 1 + (this.field_146121_g - 8) / 2, Color.black.getRGB());
                        this.func_73732_a(fontrenderer, players, this.field_146128_h + this.field_146120_f - fontrenderer.func_78256_a(players) / 2 - 64, this.field_146129_i + (this.field_146121_g - 8) / 2, l);
                    }
                    else {
                        final String str = errormsg;
                        this.func_73732_a(fontrenderer, str, this.field_146128_h + fontrenderer.func_78256_a(str) / 2 + 2, this.field_146129_i + (this.field_146121_g - 8) / 2, l);
                    }
                }
                else {
                    final String str = errormsg;
                    this.func_73732_a(fontrenderer, str, this.field_146128_h + fontrenderer.func_78256_a(str) / 2 + 2, this.field_146129_i + (this.field_146121_g - 8) / 2, l);
                }
            }
        }
        this.field_146129_i = posX;
    }
    
    private String colorPing(final long pingToServer) {
        if (pingToServer < 50L) {
            return EnumChatFormatting.GREEN.toString();
        }
        if (pingToServer < 100L) {
            return EnumChatFormatting.DARK_GREEN.toString();
        }
        if (pingToServer < 200L) {
            return EnumChatFormatting.YELLOW.toString();
        }
        if (pingToServer < 300L) {
            return EnumChatFormatting.GOLD.toString();
        }
        if (pingToServer < 400L) {
            return EnumChatFormatting.RED.toString();
        }
        return EnumChatFormatting.DARK_RED.toString();
    }
    
    public void func_146113_a(final SoundHandler p_146113_1_) {
        p_146113_1_.func_147682_a((ISound)PositionedSoundRecord.func_147674_a(new ResourceLocation("gui.button.press"), 1.0f));
    }
    
    public int compareTo(final Object o) {
        return this.field_146126_j.compareTo(((GuiDayMButton)o).field_146126_j);
    }
}
