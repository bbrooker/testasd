package com.daym.gui;

import cpw.mods.fml.relauncher.*;
import java.util.*;
import net.minecraft.client.gui.*;
import com.daym.handlers.*;
import net.minecraft.util.*;
import java.net.*;
import net.minecraft.world.storage.*;
import net.minecraft.client.renderer.*;

@SideOnly(Side.CLIENT)
public class GuiGlobalTools extends GuiScreen implements GuiYesNoCallback
{
    Random random;
    private StringTranslate stringTranslate;
    
    public GuiGlobalTools() {
        this.random = new Random();
        this.stringTranslate = new StringTranslate();
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    protected void func_73869_a(final char par1, final int par2) {
    }
    
    public void func_73866_w_() {
        final int var4 = (int)(this.field_146295_m / 2 - this.field_146295_m / 2.5);
        final int var5 = 20;
        final int var6 = 50;
        final int var7 = this.field_146294_l / 2;
        final int yOffset = 0;
        final int xOffset = -90;
        this.field_146292_n.add(new GuiDayMButton(0, 0, "center", var5, this.field_146294_l / 2, var4, 20, "Close"));
        this.field_146292_n.add(new GuiDayMButton(1, 0, "center", var5, this.field_146294_l / 2, var4 + 24, 20, "Zombie Spawn Creator"));
        this.field_146292_n.add(new GuiDayMButton(2, 0, "center", var5, this.field_146294_l / 2, var4 + 48, 20, "Loot Spawn Creator"));
        this.field_146292_n.add(new GuiDayMButton(3, 0, "center", var5, this.field_146294_l / 2, var4 + 72, 20, "Player Spawn Placer"));
    }
    
    protected void func_146284_a(final GuiButton b) {
        if (b.field_146127_k == 0) {
            this.field_146297_k.field_71462_r = null;
            this.field_146297_k.func_71381_h();
        }
        if (b.field_146127_k == 1 || b.field_146127_k == 2 || b.field_146127_k == 3) {
            String type = "Zombie Spawn Creator";
            if (b.field_146127_k == 1) {
                type = "Zombie Spawn Creator";
                WorldVarHandler.daym_6e949c730 = 0;
            }
            if (b.field_146127_k == 2) {
                type = "Loot Spawn Creator";
                WorldVarHandler.daym_6e949c730 = 1;
            }
            if (b.field_146127_k == 3) {
                type = "Player Spawn Placer";
                WorldVarHandler.daym_6e949c730 = 2;
            }
            final IChatComponent test = (IChatComponent)new ChatComponentText("\"" + type + "\" tool selected.");
            this.field_146297_k.field_71439_g.func_145747_a(test);
            this.field_146297_k.field_71462_r = null;
            this.field_146297_k.func_71381_h();
        }
    }
    
    public void func_73878_a(final boolean par1, final int par2) {
        if (par1 && par2 == 12) {
            final ISaveFormat var6 = this.field_146297_k.func_71359_d();
            var6.func_75800_d();
            var6.func_75802_e("Demo_World");
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
        else if (par2 == 13) {
            if (par1) {
                try {
                    final Class var7 = Class.forName("java.awt.Desktop");
                    final Object var8 = var7.getMethod("getDesktop", (Class[])new Class[0]).invoke(null, new Object[0]);
                    var7.getMethod("browse", URI.class).invoke(var8, new URI("http://tinyurl.com/javappc"));
                }
                catch (Throwable var9) {
                    var9.printStackTrace();
                }
            }
            this.field_146297_k.func_147108_a((GuiScreen)this);
        }
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        final Tessellator var4 = Tessellator.field_78398_a;
        final short var5 = 274;
        final int var6 = this.field_146294_l / 2 - var5 / 2;
        final byte var7 = 30;
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, -2130706433, 16777215);
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, 0, Integer.MIN_VALUE);
        final int size = 105;
        final int size2 = 45;
        final int offset = 48;
        final String var8 = "2.1.4_beta";
        final String var9 = "Minecraft 1.7.10 | Copyright Mojang AB. Do not distribute!";
        this.func_73731_b(this.field_146289_q, var9, this.field_146294_l - this.field_146289_q.func_78256_a(var9) - 2, this.field_146295_m - 10, 16777215);
        this.func_73731_b(this.field_146289_q, "DayM (2.1.4_beta DevBuild)", 4, this.field_146295_m - 10, 16777215);
        super.func_73863_a(par1, par2, par3);
    }
}
