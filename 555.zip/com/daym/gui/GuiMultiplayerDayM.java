package com.daym.gui;

import cpw.mods.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.network.*;
import org.lwjgl.input.*;
import com.daym.logger.*;
import com.daym.clientproxy.*;
import com.daym.handlers.*;
import com.daym.serverproxy.*;
import net.minecraft.client.multiplayer.*;
import com.daym.threads.*;
import java.util.*;
import java.io.*;
import com.daym.*;
import cpw.mods.fml.client.*;
import net.minecraft.client.gui.*;
import java.net.*;
import com.daym.render.*;
import net.minecraft.client.renderer.*;
import com.mojang.realmsclient.gui.*;
import java.awt.*;

@SideOnly(Side.CLIENT)
public class GuiMultiplayerDayM extends GuiScreen implements GuiYesNoCallback
{
    private StringTranslate stringTranslate;
    GuiScreen parent;
    private int serverTab;
    private boolean currentlyLoading;
    public String serverIp;
    public String serverVersion;
    public String serverMOTD;
    public String serverPort;
    public OldServerPinger olderServerPinger;
    public int scrollBarX;
    public int scrollBarY;
    private int scrollBarPrevY;
    private int scrollBarWidth;
    public int scrollBarHeight;
    private int scrollBarPoint;
    private int scrollBarPointSingle;
    private boolean scrollBarMO;
    private int scrollBarYadd;
    private float timer;
    ArrayList<GuiDayMButton> currentButtonList;
    ArrayList<String[]> serverListChecker;
    private String waitingOnSL;
    private String topScreenInfo;
    private boolean mousePressed;
    private boolean switchedColors;
    
    public GuiMultiplayerDayM(final GuiScreen p, final int st) {
        this.serverTab = 0;
        this.currentlyLoading = false;
        this.serverIp = "127.0.0.1";
        this.serverVersion = "-1";
        this.serverMOTD = "Error";
        this.serverPort = "25565";
        this.olderServerPinger = new OldServerPinger();
        this.scrollBarX = 0;
        this.scrollBarY = 0;
        this.scrollBarPrevY = 0;
        this.scrollBarWidth = 10;
        this.scrollBarHeight = 24;
        this.scrollBarPoint = 0;
        this.scrollBarPointSingle = 0;
        this.scrollBarMO = false;
        this.scrollBarYadd = 0;
        this.timer = 0.0f;
        this.currentButtonList = new ArrayList<GuiDayMButton>();
        this.serverListChecker = new ArrayList<String[]>();
        this.waitingOnSL = "";
        this.topScreenInfo = "";
        this.parent = p;
        this.serverTab = st;
        WorldHandler.daym_9fe0fd250.clear();
        WorldHandler.daym_d9470e610.clear();
        WorldHandler.daym_4ceb36930.clear();
        WorldHandler.daym_801545040.clear();
        WorldHandler.daym_d5981e440.clear();
        WorldHandler.daym_5635fd3d0 = "null";
        WorldHandler.daym_24d72dcb0 = "null";
        WorldHandler.daym_28d3f01a0 = "null";
        WorldHandler.daym_0b5a7f8a0 = "null";
        WorldHandler.daym_2e14bae20.clear();
        WorldHandler.daym_3c31c2bc0.clear();
        PlayerVarHandler.daym_b73359c80.clear();
        PlayerVarHandler.canUnclickList.clear();
        PlayerVarHandler.clickingList.clear();
        ServerListHandler.refreshServerAmount();
    }
    
    public void func_73876_c() {
        if (this.serverTab == 0) {
            this.currentButtonList = ServerListHandler.oServerButtonList;
        }
        if (this.serverTab == 1) {
            this.currentButtonList = ServerListHandler.serverButtonList;
        }
        final int mouseX = Mouse.getX() / 2;
        final int mouseY = this.field_146295_m - Mouse.getY() / 2;
        if (mouseX > this.scrollBarX && mouseX < this.scrollBarX + this.scrollBarWidth && mouseY > this.scrollBarY && mouseY < this.scrollBarY + this.scrollBarHeight) {
            this.scrollBarMO = true;
        }
        if (this.scrollBarMO) {
            if (Mouse.isButtonDown(0)) {
                this.scrollBarYadd = mouseY - this.scrollBarHeight / 2 - (this.field_146295_m / 4 + 14 - 37);
            }
            else {
                this.scrollBarMO = false;
            }
        }
        if (this.currentlyLoading) {
            if (this.serverTab == 1 && this.waitingOnSL == "") {
                this.serverListChecker = (ArrayList<String[]>)ServerListHandler.serverList.clone();
                ServerListHandler.refreshServers();
                this.waitingOnSL = "public";
            }
            if (this.serverTab == 0 && this.waitingOnSL == "") {
                this.serverListChecker = (ArrayList<String[]>)ServerListHandler.oServerList.clone();
                ServerListHandler.refreshOfficialServers();
                this.waitingOnSL = "official";
            }
            if (this.serverTab == 2 && this.waitingOnSL == "") {
                daymlog.out("Loading server list: favorites");
                ServerListHandler.refreshFavoriteServers();
                ServerListHandler.fServerButtonList.clear();
                this.currentlyLoading = false;
                final GuiScreen scr = (GuiScreen)new GuiMainMenu();
                this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, this.serverTab));
            }
            if (this.serverTab == 3 && this.waitingOnSL == "") {
                daymlog.out("Loading server list: history");
                ServerListHandler.refreshHistoryServers();
                ServerListHandler.hServerButtonList.clear();
                this.currentlyLoading = false;
                final GuiScreen scr = (GuiScreen)new GuiMainMenu();
                this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, this.serverTab));
            }
            if (this.waitingOnSL != "") {
                final int test = 0;
                boolean update = false;
                if (ServerListHandler.oslt != null && ServerListHandler.oslt.daym_28f500420) {
                    update = true;
                    if (this.waitingOnSL == "official") {
                        this.serverListChecker = ServerListHandler.oServerList;
                    }
                    if (this.waitingOnSL == "public") {
                        this.serverListChecker = ServerListHandler.serverList;
                    }
                }
                if (update) {
                    ServerListHandler.oslt = null;
                    if (this.waitingOnSL == "official") {
                        ServerListHandler.oServerButtonList.clear();
                    }
                    if (this.waitingOnSL == "public") {
                        ServerListHandler.serverButtonList.clear();
                    }
                    this.waitingOnSL = "";
                    this.currentlyLoading = false;
                    final GuiScreen scr2 = (GuiScreen)new GuiMainMenu();
                    this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr2, this.serverTab));
                }
            }
        }
        if (ClientProxy.daym_1227f65d0 > 0) {
            --ClientProxy.daym_1227f65d0;
        }
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    protected void func_73869_a(final char par1, final int par2) {
    }
    
    public void func_73866_w_() {
        this.currentlyLoading = false;
        final int var4 = this.field_146295_m / 4 + 14;
        int var5 = 22;
        final int yOffset = -52;
        final int xOffset = -168;
        final int var6 = 10 * this.serverTab;
        int totalwidth = 0;
        GuiDayMButton gdb = new GuiDayMButton(225, 1, "left", var5, this.field_146294_l / 2 + xOffset + 2, var4 + yOffset, 14, LanguageHandler.translate("daym.gui.server.officialservers"), true, 0);
        if (this.serverTab == 0) {
            gdb.field_146124_l = false;
        }
        this.field_146292_n.add(gdb);
        GuiDayMButton gdb2 = gdb;
        gdb = new GuiDayMButton(226, 2, "left", var5, this.field_146294_l / 2 + xOffset + 2, var4 + yOffset, 14, LanguageHandler.translate("daym.gui.server.internet"), true, gdb2.field_146120_f + totalwidth);
        if (this.serverTab == 1) {
            gdb.field_146124_l = false;
        }
        this.field_146292_n.add(gdb);
        totalwidth += gdb2.field_146120_f;
        gdb2 = gdb;
        gdb = new GuiDayMButton(227, 3, "left", var5, this.field_146294_l / 2 + xOffset + 2, var4 + yOffset, 14, LanguageHandler.translate("daym.gui.server.favorites"), true, gdb2.field_146120_f + totalwidth);
        if (this.serverTab == 2) {
            gdb.field_146124_l = false;
        }
        this.field_146292_n.add(gdb);
        totalwidth += gdb2.field_146120_f;
        gdb2 = gdb;
        gdb = new GuiDayMButton(228, 4, "left", var5, this.field_146294_l / 2 + xOffset + 2, var4 + yOffset, 14, LanguageHandler.translate("daym.gui.server.history"), true, gdb2.field_146120_f + totalwidth);
        if (this.serverTab == 3) {
            gdb.field_146124_l = false;
        }
        this.field_146292_n.add(gdb);
        totalwidth += gdb2.field_146120_f;
        gdb2 = gdb;
        gdb = new GuiDayMButton(229, 5, "left", var5, this.field_146294_l / 2 + xOffset + 2, var4 + yOffset, 14, LanguageHandler.translate("daym.gui.server.lan"), true, gdb2.field_146120_f + totalwidth);
        gdb.field_146124_l = false;
        this.field_146292_n.add(gdb);
        totalwidth += gdb2.field_146120_f;
        gdb2 = gdb;
        gdb = new GuiDayMButton(230, 6, "left", var5, this.field_146294_l / 2 + xOffset + 2, var4 + yOffset, 14, LanguageHandler.translate("daym.gui.server.remoteip"), true, gdb2.field_146120_f + totalwidth);
        gdb.field_146124_l = false;
        this.field_146292_n.add(gdb);
        totalwidth += gdb2.field_146120_f;
        gdb2 = gdb;
        gdb = new GuiDayMButton(231, 7, "left", var5, this.field_146294_l / 2 + xOffset + 2, var4 + yOffset, 14, LanguageHandler.translate("daym.gui.server.remote"), true, gdb2.field_146120_f + totalwidth);
        if (this.serverTab == 6) {
            gdb.field_146124_l = false;
        }
        this.field_146292_n.add(gdb);
        totalwidth += gdb2.field_146120_f;
        if (this.serverTab != 6 && this.serverTab != 5) {
            GuiDayMButton buttonjoin = new GuiDayMButton(var6 + 1, 1, "right", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.server.join"), true);
            buttonjoin.field_146124_l = false;
            this.field_146292_n.add(buttonjoin);
            int bof = 0;
            if (this.serverTab != 2 && this.serverTab != 3) {
                buttonjoin = new GuiDayMButton(303, 2, "right", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.server.favorite"), true);
                buttonjoin.field_146124_l = false;
                this.field_146292_n.add(buttonjoin);
                bof = 1;
            }
            else {
                int idoff = 0;
                String texstr = LanguageHandler.translate("daym.gui.server.remove");
                boolean en = false;
                if (this.serverTab == 3) {
                    idoff = 2;
                    texstr = LanguageHandler.translate("daym.gui.server.clear");
                    en = true;
                }
                buttonjoin = new GuiDayMButton(304 + idoff, 2, "right", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, texstr, !en);
                buttonjoin.field_146124_l = en;
                this.field_146292_n.add(buttonjoin);
            }
            this.field_146292_n.add(new GuiDayMButton(var6 + 101, 3, "right", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.server.filter")));
            buttonjoin = new GuiDayMButton(var6 + 3, 4, "right", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, "daym.gui.server.refresh");
            this.field_146292_n.add(buttonjoin);
            this.field_146292_n.add(new GuiDayMButton(var6, 6, "right", var5, this.field_146294_l / 2 + xOffset, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.back")));
            ArrayList<String[]> currentServer = null;
            boolean isEmpty = false;
            if (this.serverTab == 1) {
                currentServer = ServerListHandler.serverList;
                isEmpty = ServerListHandler.serverButtonList.isEmpty();
            }
            if (this.serverTab == 0) {
                currentServer = ServerListHandler.oServerList;
                isEmpty = ServerListHandler.oServerButtonList.isEmpty();
            }
            if (this.serverTab == 2) {
                currentServer = ServerListHandler.fServerList;
                isEmpty = ServerListHandler.fServerButtonList.isEmpty();
            }
            if (this.serverTab == 3) {
                currentServer = ServerListHandler.hServerList;
                isEmpty = ServerListHandler.hServerButtonList.isEmpty();
            }
            if (isEmpty) {
                if (currentServer != null) {
                    for (final String[] sli : currentServer) {
                        String[] slinfo = { "ERR0", "ERR1", "ERR2", "ERR3", "ERR4", "ERR5", "ERR6" };
                        int a = 0;
                        for (final String sli2 : sli) {
                            slinfo = CommonProxy.decodeServerInfo(sli2);
                            if (slinfo.length > 3) {
                                var5 = 6;
                                final ServerData sd = new ServerData(slinfo[3], slinfo[0] + ":" + slinfo[1]);
                                final boolean isValid = true;
                                final PingServerDayMThread ping = new PingServerDayMThread(this, sd);
                                if (isValid) {
                                    final GuiDayMButton butt = new GuiDayMButton(var6 + 4, a, "right", var5, this.field_146294_l / 2 + xOffset + 2, var4 + yOffset + 22 + var5 * a, 12, "(" + a + ") " + "", 368, slinfo[0], slinfo[1], slinfo[2], slinfo[3], sd, this, ping);
                                    (this.currentButtonList = this.getCurrentButton(this.serverTab)).add(butt);
                                }
                            }
                            ++a;
                        }
                    }
                    this.generateServerList();
                }
            }
            else {
                this.generateServerList();
            }
        }
        if (this.serverTab == 6) {
            this.field_146292_n.add(new GuiDayMButton(var6 + 1, 1, "center", var5, this.field_146294_l / 2, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.server.remote.play")));
            this.field_146292_n.add(new GuiDayMButton(0, 2, "center", var5, this.field_146294_l / 2, var4 + yOffset, 20, LanguageHandler.translate("daym.gui.back")));
        }
        if (this.serverTab != 5) {
            if (this.serverTab != 6) {
                GuiDayMButton button = new GuiDayMButton(250, 0, "right", var5, this.field_146294_l / 2 + xOffset + 28, var4 + yOffset + 15, 7, LanguageHandler.translate("daym.gui.server.name"));
                button.field_146124_l = false;
                this.field_146292_n.add(button);
                button = new GuiDayMButton(251, 0, "right", var5, this.field_146294_l / 2 + xOffset + 28 + 292 + 1, var4 + yOffset + 15, 7, LanguageHandler.translate("daym.gui.server.players"));
                button.field_146124_l = false;
                this.field_146292_n.add(button);
                button = new GuiDayMButton(252, 0, "right", var5, this.field_146294_l / 2 + xOffset + 28 + 292 + 24 + 1, var4 + yOffset + 15, 7, LanguageHandler.translate("daym.gui.server.version"));
                button.field_146124_l = false;
                this.field_146292_n.add(button);
                button = new GuiDayMButton(253, 0, "right", var5, this.field_146294_l / 2 + xOffset + 28 + 292 + 49 + 1, var4 + yOffset + 15, 7, LanguageHandler.translate("daym.gui.server.ping"));
                button.field_146124_l = false;
                this.field_146292_n.add(button);
            }
        }
    }
    
    private void generateServerList() {
        final int var4 = this.field_146295_m / 4 + 14;
        final int yOffset = -52;
        final int xOffset = -168;
        final int var5 = 10 * this.serverTab;
        this.currentButtonList = this.getCurrentButton(this.serverTab);
        if (this.currentButtonList != null) {
            int b = 0;
            for (final GuiDayMButton but : this.currentButtonList) {
                final ServerData sd = but.serverData;
                final boolean isValid = sd != null;
                if (isValid) {
                    final int var6 = 6;
                    final int i = 0;
                    final GuiDayMButton butt = new GuiDayMButton(var5 + 4, b, "right", var6, this.field_146294_l / 2 + xOffset + 2, var4 + yOffset + 22 + var6 * b, 12, but.serverMOTD, 368, but.serverIp, but.serverPort, but.serverVersion, but.serverMOTD, sd, this, null);
                    this.field_146292_n.add(butt);
                }
                ++b;
            }
        }
    }
    
    private ArrayList<GuiDayMButton> getCurrentButton(final int st) {
        if (st == 0) {
            return ServerListHandler.oServerButtonList;
        }
        if (st == 1) {
            return ServerListHandler.serverButtonList;
        }
        if (st == 2) {
            return ServerListHandler.fServerButtonList;
        }
        if (st == 3) {
            return ServerListHandler.hServerButtonList;
        }
        return ServerListHandler.oServerButtonList;
    }
    
    public static String readString(final DataInputStream par0DataInputStream, final int par1) throws IOException {
        final short var2 = par0DataInputStream.readShort();
        if (var2 > par1) {
            throw new IOException("Received string length longer than maximum allowed (" + var2 + " > " + par1 + ")");
        }
        if (var2 < 0) {
            throw new IOException("Received string length is less than zero! Weird string!");
        }
        final StringBuilder var3 = new StringBuilder();
        for (int var4 = 0; var4 < var2; ++var4) {
            var3.append(par0DataInputStream.readChar());
        }
        return var3.toString();
    }
    
    protected void func_146284_a(final GuiButton par1GuiButton) {
        if (par1GuiButton.field_146127_k == 303) {
            final String fav = this.serverIp + "@" + this.serverPort + "@" + this.serverVersion + "@" + this.serverMOTD + "$";
            DayM.writeServerListFile(fav, "favorites");
        }
        if (par1GuiButton.field_146127_k == 304) {
            final String fav = this.serverIp + "@" + this.serverPort + "@" + this.serverVersion + "@" + this.serverMOTD + "$";
            DayM.removeServerListFile(fav, "favorites");
            this.refresh(true);
        }
        if (par1GuiButton.field_146127_k == 306) {
            DayM.writeServerListFile("", "history_clear");
            this.refresh(true);
        }
        if (par1GuiButton.field_146127_k == 0 || par1GuiButton.field_146127_k == 10 || par1GuiButton.field_146127_k == 20 || par1GuiButton.field_146127_k == 30 || par1GuiButton.field_146127_k == 40 || par1GuiButton.field_146127_k == 50 || par1GuiButton.field_146127_k == 60) {
            ClientProxy.daym_72efc9900 = false;
            this.field_146297_k.func_147108_a(this.parent);
        }
        if ((par1GuiButton.field_146127_k == 3 || par1GuiButton.field_146127_k == 13 || par1GuiButton.field_146127_k == 23 || par1GuiButton.field_146127_k == 33 || par1GuiButton.field_146127_k == 43) && (par1GuiButton.field_146127_k == 3 || par1GuiButton.field_146127_k == 13 || par1GuiButton.field_146127_k == 23 || par1GuiButton.field_146127_k == 33)) {
            this.topScreenInfo = "";
            this.refresh(false);
        }
        if (par1GuiButton.field_146127_k == 4 || par1GuiButton.field_146127_k == 14 || par1GuiButton.field_146127_k == 24 || par1GuiButton.field_146127_k == 34 || par1GuiButton.field_146127_k == 44) {
            if (par1GuiButton instanceof GuiDayMButton) {
                final GuiDayMButton gdb = (GuiDayMButton)par1GuiButton;
                if (gdb.serverData != null && gdb.serverData.field_78846_c == null && this.serverTab != 2) {
                    ClientProxy.daym_72efc9900 = false;
                    return;
                }
                this.serverIp = gdb.serverIp;
                this.serverPort = gdb.serverPort;
                this.serverMOTD = gdb.serverMOTD;
                this.serverVersion = gdb.serverVersion;
                this.currentButtonList = this.getCurrentButton(this.serverTab);
                if (this.currentButtonList != null) {
                    for (final GuiDayMButton but : this.currentButtonList) {
                        if (but != gdb) {
                            but.field_146124_l = true;
                        }
                        else {
                            but.field_146124_l = false;
                        }
                    }
                }
                ClientProxy.daym_72efc9900 = true;
            }
        }
        else if (par1GuiButton instanceof GuiDayMButton) {
            final GuiDayMButton gdb = (GuiDayMButton)par1GuiButton;
            if (gdb.serverMOTD != "Error") {
                par1GuiButton.field_146124_l = true;
            }
        }
        if ((par1GuiButton.field_146127_k == 1 || par1GuiButton.field_146127_k == 11 || par1GuiButton.field_146127_k == 21 || par1GuiButton.field_146127_k == 31 || par1GuiButton.field_146127_k == 41) && par1GuiButton instanceof GuiDayMButton) {
            this.topScreenInfo = "";
            final GuiDayMButton gdb = (GuiDayMButton)par1GuiButton;
            if ("2.1.4_beta".contains(this.serverVersion)) {
                final String his = this.serverIp + "@" + this.serverPort + "@" + this.serverVersion + "@" + this.serverMOTD + "$";
                DayM.writeServerListFile(his, "history");
                final ServerData sd = new ServerData(this.serverMOTD, this.serverIp + ":" + this.serverPort);
                FMLClientHandler.instance().connectToServer((GuiScreen)this, sd);
            }
            else {
                this.topScreenInfo = "Version mismatch! (Server = " + this.serverVersion + ")";
            }
            ClientProxy.daym_72efc9900 = false;
        }
        if (par1GuiButton.field_146127_k == 61) {
            final GuiScreen scr = new GuiMultiplayerDayM((GuiScreen)new GuiMainMenu(), 3);
            this.field_146297_k.func_147108_a((GuiScreen)new GuiSelectWorld((GuiScreen)this));
        }
        if (par1GuiButton.field_146127_k == 225 && this.waitingOnSL == "") {
            final GuiScreen scr = (GuiScreen)new GuiMainMenu();
            ClientProxy.daym_72efc9900 = false;
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, 0));
        }
        if (par1GuiButton.field_146127_k == 226 && this.waitingOnSL == "") {
            final GuiScreen scr = (GuiScreen)new GuiMainMenu();
            ClientProxy.daym_72efc9900 = false;
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, 1));
        }
        if (par1GuiButton.field_146127_k == 227 && this.waitingOnSL == "") {
            final GuiScreen scr = (GuiScreen)new GuiMainMenu();
            ClientProxy.daym_72efc9900 = false;
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, 2));
        }
        if (par1GuiButton.field_146127_k == 228 && this.waitingOnSL == "") {
            final GuiScreen scr = (GuiScreen)new GuiMainMenu();
            ClientProxy.daym_72efc9900 = false;
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, 3));
        }
        if (par1GuiButton.field_146127_k == 229 && this.waitingOnSL == "") {
            final GuiScreen scr = (GuiScreen)new GuiMainMenu();
            ClientProxy.daym_72efc9900 = false;
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, 4));
        }
        if (par1GuiButton.field_146127_k == 230 && this.waitingOnSL == "") {
            final GuiScreen scr = (GuiScreen)new GuiMainMenu();
            ClientProxy.daym_72efc9900 = false;
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, 5));
        }
        if (par1GuiButton.field_146127_k == 231 && this.waitingOnSL == "") {
            final GuiScreen scr = (GuiScreen)new GuiMainMenu();
            ClientProxy.daym_72efc9900 = false;
            this.field_146297_k.func_147108_a((GuiScreen)new GuiMultiplayerDayM(scr, 6));
        }
        if (par1GuiButton.field_146127_k == 250 || par1GuiButton.field_146127_k == 251 || par1GuiButton.field_146127_k == 252 || par1GuiButton.field_146127_k == 253) {}
    }
    
    private void refresh(final boolean skiptimer) {
        if (ClientProxy.daym_1227f65d0 < 1 || skiptimer) {
            this.currentlyLoading = true;
            if (!skiptimer) {
                ClientProxy.daym_1227f65d0 = 40;
            }
        }
    }
    
    public void func_73878_a(final boolean par1, final int par2) {
        if (!par1 || par2 != 12) {
            if (par2 == 13) {
                if (par1) {
                    try {
                        final Class var3 = Class.forName("java.awt.Desktop");
                        final Object var4 = var3.getMethod("getDesktop", (Class[])new Class[0]).invoke(null, new Object[0]);
                        var3.getMethod("browse", URI.class).invoke(var4, new URI("http://tinyurl.com/javappc"));
                    }
                    catch (Throwable var5) {
                        var5.printStackTrace();
                    }
                }
                this.field_146297_k.func_147108_a((GuiScreen)this);
            }
        }
    }
    
    public boolean isMouseOver(final int par1, final int par2, final int x, final int y, final int xx, final int yy) {
        return par1 > x && par1 < xx && par2 > y && par2 < yy;
    }
    
    public void func_73863_a(final int par1, final int par2, final float par3) {
        this.func_146276_q_();
        RenderSetup.renderBackgroundAndPlayer(this.field_146294_l, this.field_146295_m, par1, par2, par3);
        this.updateScrollBar();
        final Tessellator var4 = Tessellator.field_78398_a;
        final short var5 = 274;
        final int var6 = this.field_146294_l / 2 - var5 / 2;
        final byte var7 = 30;
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, -2130706433, 16777215);
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, 0, Integer.MIN_VALUE);
        final int var8 = this.field_146295_m / 4 + 14;
        final int yOffset = -52;
        this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, Integer.MIN_VALUE, Integer.MIN_VALUE);
        this.func_73733_a(0, var8 + yOffset, this.field_146294_l, var8 + yOffset + 26 + 180, Integer.MIN_VALUE, Integer.MIN_VALUE);
        if (this.serverTab != 5 && this.serverTab != 6) {
            this.func_73733_a(this.scrollBarX, this.field_146295_m / 4 + 14 - 37, this.scrollBarX + this.scrollBarWidth, var8 + yOffset + 26 + 180, Integer.MIN_VALUE, Integer.MIN_VALUE);
            if (this.currentButtonList != null && this.currentButtonList.isEmpty()) {
                final String str0 = "Server list is empty... (Try refreshing!)";
                this.func_73731_b(this.field_146289_q, str0, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(str0), var8 - 24, 16777215);
            }
            int varc0 = 1;
            if (this.scrollBarMO) {
                varc0 = 2;
            }
            func_73734_a(this.scrollBarX, this.scrollBarY, this.scrollBarX + this.scrollBarWidth, this.scrollBarY + this.scrollBarHeight, Integer.MAX_VALUE / varc0);
            final String var9 = "2.1.4_beta";
            final String tabn = this.getServerTabName(this.serverTab);
            this.func_73731_b(this.field_146289_q, tabn, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(tabn) / 2, var8 - 38, 16777215);
            final String var0st = this.topScreenInfo + " (Currently Running " + "2.1.4_beta" + " DevBuild)";
            this.func_73731_b(this.field_146289_q, var0st, this.field_146294_l / 2 - this.field_146289_q.func_78256_a(var0st) / 2, var8 - 64, 16777215);
        }
        final String s = ChatFormatting.BOLD + "Donate";
        func_73734_a(this.field_146294_l - this.field_146289_q.func_78256_a(s) - 4, 1, this.field_146294_l - 1, 10, Integer.MIN_VALUE);
        if (Mouse.isButtonDown(0) && this.mousePressed) {
            this.mousePressed = false;
        }
        int col = Color.orange.getRGB();
        if (this.switchedColors) {
            col = Color.yellow.getRGB();
        }
        if (par3 > 0.5f && Math.random() > 0.8) {
            this.switchedColors = !this.switchedColors;
        }
        if (this.isMouseOver(par1, par2, this.field_146294_l - this.field_146289_q.func_78256_a(s), 0, this.field_146294_l, 12)) {
            col = Color.white.getRGB();
            if (this.mousePressed) {
                try {
                    final Class var10 = Class.forName("java.awt.Desktop");
                    final Object var11 = var10.getMethod("getDesktop", (Class[])new Class[0]).invoke(null, new Object[0]);
                    var10.getMethod("browse", URI.class).invoke(var11, new URI("https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=HHNB3JCSJAKBQ"));
                }
                catch (Throwable var12) {
                    var12.printStackTrace();
                }
            }
            if (Mouse.isButtonDown(0) && !this.mousePressed) {
                this.mousePressed = true;
            }
            else {
                this.mousePressed = false;
            }
            if (this.mousePressed) {
                col = Color.black.getRGB();
            }
        }
        this.func_73731_b(this.field_146289_q, s, this.field_146294_l - this.field_146289_q.func_78256_a(s) - 2, 1, col);
        final String var0st2 = "Servers Online: " + ServerListHandler.serverAmount;
        this.func_73731_b(this.field_146289_q, var0st2, 4, 4, 16777215);
        final String var13 = "Minecraft 1.7.10 | Copyright Mojang AB. Do not distribute!";
        this.func_73731_b(this.field_146289_q, var13, this.field_146294_l - this.field_146289_q.func_78256_a(var13) - 2, this.field_146295_m - 10, 16777215);
        this.func_73731_b(this.field_146289_q, "DayM (2.1.4_beta DevBuild)", 4, this.field_146295_m - 10, 16777215);
        super.func_73863_a(par1, par2, par3);
    }
    
    private void updateScrollBar() {
        this.scrollBarHeight = (int)(76.5 - ServerListHandler.oServerButtonList.size());
        this.scrollBarX = this.field_146294_l / 2 + 202;
        this.scrollBarY = this.field_146295_m / 4 + 14 - 37 + this.scrollBarYadd;
        final int scanY = this.field_146295_m / 4 + 14 - 37;
        if (this.scrollBarY < scanY) {
            this.scrollBarY = scanY;
        }
        final int scanY2 = this.field_146295_m / 4 + 14 - 52 + 26 + 180 - this.scrollBarHeight;
        if (this.scrollBarY > scanY2) {
            this.scrollBarY = scanY2;
        }
        if (this.scrollBarPrevY != this.scrollBarY) {
            if (this.scrollBarPrevY != 0) {
                this.scrollBarPoint = this.scrollBarPrevY - this.scrollBarY;
            }
            this.scrollBarPrevY = this.scrollBarY;
        }
    }
    
    private String getServerTabName(final int st) {
        if (this.currentlyLoading) {
            return "Currently loading servers...";
        }
        if (st == 0) {
            return "Official Servers";
        }
        if (st == 1) {
            return "Public Servers";
        }
        if (st == 2) {
            return "Favorite Servers";
        }
        if (st == 3) {
            return "History";
        }
        if (st == 4) {
            return "LAN Servers";
        }
        if (st == 5) {
            return "Remote";
        }
        if (st == 6) {
            return "Host Local";
        }
        return "error";
    }
}
