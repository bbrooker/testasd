package com.daym.entity.zombie;

import net.minecraft.entity.monster.*;
import net.minecraft.world.*;
import com.daym.registry.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.ai.*;
import com.daym.ai.*;
import com.daym.handlers.*;
import java.util.*;
import net.minecraft.entity.*;

public class EntityZombieBase extends EntityMob
{
    public int zombieTexture;
    public int radius;
    public int maxAmount;
    
    public EntityZombieBase(final World par1World) {
        super(par1World);
        this.zombieTexture = 0;
        this.radius = 4;
        this.maxAmount = 6;
        this.radius = -1;
        this.maxAmount = -1;
        this.checkIfCanSpawnZombieLimit();
        this.func_70105_a(0.6f, 1.8f);
        this.zombieTexture = this.field_70146_Z.nextInt(TextureRegistry.tex_zombies.length);
        this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
        this.field_70714_bg.func_75776_a(2, (EntityAIBase)new EntityAIAttackOnCollide((EntityCreature)this, (Class)EntityPlayer.class, 1.0, false));
        this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIMoveTowardsRestriction((EntityCreature)this, 1.0));
        this.field_70714_bg.func_75776_a(7, (EntityAIBase)new EntityAIWander((EntityCreature)this, 1.0));
        this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, (Class)EntityPlayer.class, 8.0f));
        this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
        this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAIHurtByTarget((EntityCreature)this, true));
        this.field_70715_bh.func_75776_a(2, (EntityAIBase)new AINearestAttackableTargetDayM((EntityCreature)this, EntityPlayer.class, 0, true));
        this.field_70728_aV = 0;
    }
    
    public EntityZombieBase(final World par1World, final int r, final int am) {
        super(par1World);
        this.zombieTexture = 0;
        this.radius = 4;
        this.maxAmount = 6;
        this.radius = r;
        this.maxAmount = am / (this.radius / 8 + 1);
        this.checkIfCanSpawnZombieLimit();
        this.func_70105_a(0.6f, 1.8f);
        this.zombieTexture = this.field_70146_Z.nextInt(TextureRegistry.tex_zombies.length);
        this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
        this.field_70714_bg.func_75776_a(2, (EntityAIBase)new EntityAIAttackOnCollide((EntityCreature)this, (Class)EntityPlayer.class, 1.0, false));
        this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIMoveTowardsRestriction((EntityCreature)this, 1.0));
        this.field_70714_bg.func_75776_a(7, (EntityAIBase)new EntityAIWander((EntityCreature)this, 1.0));
        this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, (Class)EntityPlayer.class, 8.0f));
        this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
        this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAIHurtByTarget((EntityCreature)this, true));
        this.field_70715_bh.func_75776_a(2, (EntityAIBase)new AINearestAttackableTargetDayM((EntityCreature)this, EntityPlayer.class, 0, true));
        this.field_70728_aV = 0;
    }
    
    private void checkIfCanSpawnZombieLimit() {
        if (this.radius != -1) {
            int amZom = 0;
            if (WorldHandler.daym_54c1b80c0 != null) {
                try {
                    final ArrayList<Entity> ents = (ArrayList<Entity>)WorldHandler.daym_54c1b80c0.clone();
                    for (final Entity ent : ents) {
                        if (this.func_70032_d(ent) < (this.radius + 1) * 3) {
                            ++amZom;
                        }
                    }
                }
                catch (ConcurrentModificationException ex) {}
            }
            if (amZom > 3) {
                this.func_70106_y();
            }
        }
        WorldHandler.daym_54c1b80c0.add((Entity)this);
    }
    
    protected void func_110147_ax() {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(40.0);
        this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(11.500000208616255);
        this.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(3.0);
    }
    
    public void func_70636_d() {
        super.func_70636_d();
    }
    
    protected String func_70639_aQ() {
        if (this.field_70146_Z.nextBoolean()) {
            return "daym:zombie_living_0";
        }
        return "daym:zombie_living_1";
    }
    
    protected String func_70621_aR() {
        return "daym:zombie_hurt_0";
    }
    
    protected String func_70673_aS() {
        return "daym:zombie_living_0";
    }
    
    protected float func_70599_aP() {
        return 0.4f;
    }
}
