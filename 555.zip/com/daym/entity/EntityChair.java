package com.daym.entity;

import net.minecraft.entity.*;
import com.daym.blocks.tileentity.*;
import net.minecraft.world.*;
import net.minecraft.nbt.*;

public class EntityChair extends Entity
{
    public TileCustomRender tile;
    public double daym_b12121370;
    public double daym_71bb645e0;
    public double daym_069e8cd90;
    
    public EntityChair(final World world) {
        super(world);
        this.field_70145_X = true;
        this.func_70105_a(0.5f, 0.01f);
        this.func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
        this.daym_b12121370 = this.field_70165_t;
        this.daym_71bb645e0 = this.field_70163_u;
        this.daym_069e8cd90 = this.field_70161_v;
    }
    
    public EntityChair(final World world, final double x, final double y, final double z, final double v, final TileCustomRender t) {
        super(world);
        this.field_70145_X = true;
        this.func_70105_a(0.5f, 0.01f);
        this.tile = t;
        this.func_70107_b(x, y + v, z);
        this.daym_b12121370 = this.field_70165_t;
        this.daym_71bb645e0 = this.field_70163_u;
        this.daym_069e8cd90 = this.field_70161_v;
    }
    
    public void func_70056_a(final double x, final double y, final double z, final float a, final float b, final int par1) {
        this.func_70107_b(x, y, z);
        this.func_70101_b(a, b);
    }
    
    protected void func_70088_a() {
        this.daym_b12121370 = this.field_70165_t;
        this.daym_71bb645e0 = this.field_70163_u;
        this.daym_069e8cd90 = this.field_70161_v;
    }
    
    public boolean canRiderInteract() {
        return true;
    }
    
    public boolean func_142008_O() {
        return true;
    }
    
    public boolean func_70104_M() {
        return false;
    }
    
    public boolean func_70067_L() {
        return false;
    }
    
    public void func_70071_h_() {
        super.func_70071_h_();
        if ((this.field_70153_n == null || (this.tile != null && !this.tile.isBeingRidden)) && this.field_70173_aa > 10) {
            if (this.tile != null) {
                this.tile.isBeingRidden = false;
            }
            this.func_70106_y();
            this.func_70076_C();
        }
        if (this.daym_b12121370 == 0.0 && this.daym_71bb645e0 == 0.0 && this.daym_069e8cd90 == 0.0) {
            this.daym_b12121370 = this.field_70165_t;
            this.daym_71bb645e0 = this.field_70163_u;
            this.daym_069e8cd90 = this.field_70161_v;
        }
        else {
            this.func_70107_b(this.daym_b12121370, this.daym_71bb645e0, this.daym_069e8cd90);
        }
    }
    
    protected void func_70037_a(final NBTTagCompound arg0) {
    }
    
    protected void func_70014_b(final NBTTagCompound arg0) {
    }
}
