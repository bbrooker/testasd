package com.daym.entity;

import net.minecraft.block.*;
import com.daym.*;
import com.daym.packet.message.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.init.*;
import com.daym.enums.*;
import cpw.mods.fml.common.*;
import net.minecraft.block.material.*;
import net.minecraft.world.*;
import net.minecraft.entity.item.*;
import com.daym.extended.*;
import com.daym.registry.*;
import com.daym.misc.*;
import net.minecraft.entity.monster.*;
import net.minecraft.entity.*;
import net.minecraft.enchantment.*;
import net.minecraft.entity.player.*;
import net.minecraft.network.play.server.*;
import net.minecraft.network.*;
import cpw.mods.fml.relauncher.*;
import java.util.*;
import com.daym.inventory.*;
import net.minecraft.util.*;
import net.minecraft.nbt.*;

public class EntityBullet extends Entity implements IProjectile
{
    private int xTile;
    private int yTile;
    private int zTile;
    private int inTile;
    private int inData;
    private boolean inGround;
    public int canBePickedUp;
    public int arrowShake;
    public Entity shootingEntity;
    private int ticksInGround;
    private int ticksInAir;
    public double damage;
    public double tempDamage;
    private int knockbackStrength;
    private double vecYHitDetection;
    private int hitAmount;
    public int gunID;
    private double vecXHitDetection;
    private double vecZHitDetection;
    private Block block;
    private double spread;
    private int xTileLight;
    private int yTileLight;
    private int zTileLight;
    private int xTileLight2;
    private int yTileLight2;
    private int zTileLight2;
    public float passedTru;
    
    public EntityBullet(final World par1World) {
        super(par1World);
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        this.inTile = 0;
        this.inData = 0;
        this.inGround = false;
        this.canBePickedUp = 0;
        this.arrowShake = 0;
        this.ticksInAir = 0;
        this.damage = 0.2;
        this.tempDamage = 0.5;
        this.block = null;
        this.spread = 0.007499999832361937;
        this.xTileLight = -1;
        this.yTileLight = -1;
        this.zTileLight = -1;
        this.xTileLight2 = -1;
        this.yTileLight2 = -1;
        this.zTileLight2 = -1;
        this.passedTru = 0.0f;
    }
    
    public EntityBullet(final World par1World, final EntityPlayer par2EntityLiving, final float speed, final int gunID) {
        super(par1World);
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        this.inTile = 0;
        this.inData = 0;
        this.inGround = false;
        this.canBePickedUp = 0;
        this.arrowShake = 0;
        this.ticksInAir = 0;
        this.damage = 0.2;
        this.tempDamage = 0.5;
        this.block = null;
        this.spread = 0.007499999832361937;
        this.xTileLight = -1;
        this.yTileLight = -1;
        this.zTileLight = -1;
        this.xTileLight2 = -1;
        this.yTileLight2 = -1;
        this.zTileLight2 = -1;
        this.passedTru = 0.0f;
        final GunStatEnum gse = GunStatEnum.getStatFromGun("gid_" + gunID);
        this.damage = gse.bulletDamage;
        this.tempDamage = 2.0;
        this.func_70105_a(0.1f, 0.1f);
        this.func_70012_b(par2EntityLiving.field_70165_t, par2EntityLiving.field_70163_u + par2EntityLiving.func_70047_e() + 0.20000000298023224, par2EntityLiving.field_70161_v, par2EntityLiving.field_70177_z, par2EntityLiving.field_70125_A);
        this.field_70165_t -= MathHelper.func_76134_b(this.field_70177_z / 180.0f * 3.1415927f) * 0.16f;
        this.field_70163_u -= 0.10000000149011612;
        this.field_70161_v -= MathHelper.func_76126_a(this.field_70177_z / 180.0f * 3.1415927f) * 0.16f;
        this.func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
        this.field_70129_M = 0.0f;
        this.field_70159_w = -MathHelper.func_76126_a(this.field_70177_z / 180.0f * 3.1415927f) * MathHelper.func_76134_b(this.field_70125_A / 180.0f * 3.1415927f);
        this.field_70179_y = MathHelper.func_76134_b(this.field_70177_z / 180.0f * 3.1415927f) * MathHelper.func_76134_b(this.field_70125_A / 180.0f * 3.1415927f);
        this.field_70181_x = -MathHelper.func_76126_a(this.field_70125_A / 180.0f * 3.1415927f);
        this.func_70186_c(this.field_70159_w, this.field_70181_x, this.field_70179_y, speed * 5.0f, 1.0f);
        this.shootingEntity = (Entity)par2EntityLiving;
        final String uuid = par2EntityLiving.func_110124_au().toString();
        final DayMSoundEnum dsound = gse.soundLib.sounds[0];
        DayM.daym_6cbaa18a0.sendToAll((IMessage)new MSG_GunShotSound(uuid, dsound.id, 1.0f, 1.0f));
        this.xTileLight2 = (int)par2EntityLiving.field_70165_t;
        this.yTileLight2 = (int)(par2EntityLiving.field_70163_u + 1.0);
        this.zTileLight2 = (int)par2EntityLiving.field_70161_v;
        if (par1World.func_147439_a(this.xTileLight2, this.yTileLight2, this.zTileLight2) == Blocks.field_150350_a) {}
        this.xTileLight = (int)(this.field_70165_t + this.field_70159_w * 0.4000000059604645) + (this.field_70146_Z.nextInt(2) - 1);
        this.yTileLight = (int)(this.field_70163_u + this.field_70181_x * 0.4000000059604645);
        this.zTileLight = (int)(this.field_70161_v + this.field_70179_y * 0.4000000059604645) + (this.field_70146_Z.nextInt(2) - 1);
        if (par1World.func_147439_a(this.xTileLight, this.yTileLight, this.zTileLight) == Blocks.field_150350_a) {}
    }
    
    public void func_70106_y() {
        super.func_70106_y();
        if (this.field_70170_p.func_147439_a(this.xTileLight, this.yTileLight, this.zTileLight) == BlockRegistry.invisibleLight) {
            this.field_70170_p.func_147468_f(this.xTileLight, this.yTileLight, this.zTileLight);
        }
        if (this.field_70170_p.func_147439_a(this.xTileLight2, this.yTileLight2, this.zTileLight2) == BlockRegistry.invisibleLight) {
            this.field_70170_p.func_147468_f(this.xTileLight2, this.yTileLight2, this.zTileLight2);
        }
    }
    
    public void func_70186_c(double p_setThrowableHeading_1_, double p_setThrowableHeading_3_, double p_setThrowableHeading_5_, final float p_setThrowableHeading_7_, final float p_setThrowableHeading_8_) {
        final float f1 = MathHelper.func_76133_a(p_setThrowableHeading_1_ * p_setThrowableHeading_1_ + p_setThrowableHeading_3_ * p_setThrowableHeading_3_ + p_setThrowableHeading_5_ * p_setThrowableHeading_5_);
        p_setThrowableHeading_1_ /= f1;
        p_setThrowableHeading_3_ /= f1;
        p_setThrowableHeading_5_ /= f1;
        p_setThrowableHeading_1_ += this.field_70146_Z.nextGaussian() * this.spread * p_setThrowableHeading_8_;
        p_setThrowableHeading_3_ += this.field_70146_Z.nextGaussian() * this.spread * p_setThrowableHeading_8_;
        p_setThrowableHeading_5_ += this.field_70146_Z.nextGaussian() * this.spread * p_setThrowableHeading_8_;
        p_setThrowableHeading_1_ *= p_setThrowableHeading_7_;
        p_setThrowableHeading_3_ *= p_setThrowableHeading_7_;
        p_setThrowableHeading_5_ *= p_setThrowableHeading_7_;
        this.field_70159_w = p_setThrowableHeading_1_;
        this.field_70181_x = p_setThrowableHeading_3_;
        this.field_70179_y = p_setThrowableHeading_5_;
        final float f2 = MathHelper.func_76133_a(p_setThrowableHeading_1_ * p_setThrowableHeading_1_ + p_setThrowableHeading_5_ * p_setThrowableHeading_5_);
        final float n = (float)(Math.atan2(p_setThrowableHeading_1_, p_setThrowableHeading_5_) * 180.0 / 3.141592741012573);
        this.field_70177_z = n;
        this.field_70126_B = n;
        final float n2 = (float)(Math.atan2(p_setThrowableHeading_3_, f2) * 180.0 / 3.141592741012573);
        this.field_70125_A = n2;
        this.field_70127_C = n2;
        this.ticksInGround = 0;
    }
    
    public void func_70071_h_() {
        super.func_70071_h_();
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (side.isClient()) {
            this.func_70076_C();
        }
        if (this.field_70173_aa > 10) {
            if (this.field_70170_p.func_147439_a(this.xTileLight, this.yTileLight, this.zTileLight) == BlockRegistry.invisibleLight) {
                this.field_70170_p.func_147468_f(this.xTileLight, this.yTileLight, this.zTileLight);
            }
            if (this.field_70170_p.func_147439_a(this.xTileLight2, this.yTileLight2, this.zTileLight2) == BlockRegistry.invisibleLight) {
                this.field_70170_p.func_147468_f(this.xTileLight2, this.yTileLight2, this.zTileLight2);
            }
        }
        if (this.func_70026_G()) {
            this.field_70170_p.func_72869_a("bubble", this.field_70165_t - this.field_70159_w, this.field_70163_u - this.field_70181_x, this.field_70161_v - this.field_70179_y, this.field_70159_w, this.field_70181_x, this.field_70179_y);
        }
        if (this.field_70173_aa > 100) {
            this.func_70106_y();
            this.func_70076_C();
        }
        if (this.passedTru > this.damage) {
            this.func_70106_y();
        }
        if (this.field_70127_C == 0.0f && this.field_70126_B == 0.0f) {
            final float f1 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
            final float n2 = (float)(Math.atan2(this.field_70159_w, this.field_70179_y) * 180.0 / 3.141592741012573);
            this.field_70177_z = n2;
            this.field_70126_B = n2;
            final float n3 = (float)(Math.atan2(this.field_70181_x, f1) * 180.0 / 3.141592741012573);
            this.field_70125_A = n3;
            this.field_70127_C = n3;
        }
        final Block localBlock = this.field_70170_p.func_147439_a(this.xTile, this.yTile, this.zTile);
        if (localBlock.func_149688_o() != Material.field_151579_a) {
            localBlock.func_149719_a((IBlockAccess)this.field_70170_p, this.xTile, this.yTile, this.zTile);
            final AxisAlignedBB localAxisAlignedBB = localBlock.func_149668_a(this.field_70170_p, this.xTile, this.yTile, this.zTile);
            if (localAxisAlignedBB != null && localAxisAlignedBB.func_72318_a(Vec3.func_72443_a(this.field_70165_t, this.field_70163_u, this.field_70161_v))) {
                this.inGround = true;
            }
        }
        if (this.arrowShake > 0) {
            --this.arrowShake;
        }
        if (!this.inGround) {
            ++this.ticksInAir;
            Vec3 localVec31 = Vec3.func_72443_a(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            Vec3 localVec32 = Vec3.func_72443_a(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);
            MovingObjectPosition localMovingObjectPosition1 = this.field_70170_p.func_147447_a(localVec31, localVec32, false, true, false);
            localVec31 = Vec3.func_72443_a(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            localVec32 = Vec3.func_72443_a(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);
            if (localMovingObjectPosition1 != null) {
                localVec32 = Vec3.func_72443_a(localMovingObjectPosition1.field_72307_f.field_72450_a, localMovingObjectPosition1.field_72307_f.field_72448_b, localMovingObjectPosition1.field_72307_f.field_72449_c);
            }
            Entity localObject1 = null;
            final List localList = this.field_70170_p.func_72839_b((Entity)this, this.field_70121_D.func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_72314_b(1.0, 1.0, 1.0));
            double d1 = 0.0;
            for (int j = 0; j < localList.size(); ++j) {
                final Entity localEntity = localList.get(j);
                if (localEntity.func_70067_L() && (localEntity != this.shootingEntity || this.ticksInAir >= 5)) {
                    final float f2 = 0.3f;
                    final Object localObject2 = localEntity.field_70121_D.func_72314_b((double)f2, (double)f2, (double)f2);
                    final MovingObjectPosition localMovingObjectPosition2 = ((AxisAlignedBB)localObject2).func_72327_a(localVec31, localVec32);
                    if (localMovingObjectPosition2 != null) {
                        final double d2 = localVec31.func_72438_d(localMovingObjectPosition2.field_72307_f);
                        if (d2 < d1 || d1 == 0.0) {
                            localObject1 = localEntity;
                            d1 = d2;
                        }
                    }
                }
            }
            if (localObject1 != null) {
                localMovingObjectPosition1 = new MovingObjectPosition(localObject1);
            }
            if (localMovingObjectPosition1 != null && localMovingObjectPosition1.field_72308_g != null && localMovingObjectPosition1.field_72308_g instanceof EntityPlayer) {
                final EntityPlayer localEntityPlayer = (EntityPlayer)localMovingObjectPosition1.field_72308_g;
                if (localEntityPlayer.field_71075_bZ.field_75102_a || (this.shootingEntity instanceof EntityPlayer && !((EntityPlayer)this.shootingEntity).func_96122_a(localEntityPlayer))) {
                    localMovingObjectPosition1 = null;
                }
            }
            if (localMovingObjectPosition1 != null) {
                if (localMovingObjectPosition1.field_72308_g != null) {
                    if (localMovingObjectPosition1.field_72308_g != this.shootingEntity) {
                        if (!(localMovingObjectPosition1.field_72308_g instanceof EntityItemFrame) && !(localMovingObjectPosition1.field_72308_g instanceof EntityPainting)) {
                            final float f3 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70181_x * this.field_70181_x + this.field_70179_y * this.field_70179_y);
                            final Entity ent = localMovingObjectPosition1.field_72308_g;
                            PlayerInventoryDayM inventorydaym = null;
                            if (ent instanceof EntityPlayer) {
                                inventorydaym = ExtendedPlayer.get((EntityPlayer)ent).inventory;
                            }
                            if (this.field_70163_u > ent.field_70163_u + 1.65 && this.field_70163_u < ent.field_70163_u + 1.95) {
                                if (ent instanceof EntityPlayer) {
                                    if (inventorydaym.inventory[4] != null && inventorydaym.inventory[4].func_77973_b() == ItemRegistry.item_c_headgear_0) {
                                        this.damage /= 2.0;
                                    }
                                }
                                else {
                                    this.damage *= Math.max(0.0f, 3.0f - this.passedTru) + 0.5;
                                }
                            }
                            else if (ent instanceof EntityPlayer && inventorydaym.inventory[6] != null && inventorydaym.inventory[6].func_77973_b() == ItemRegistry.item_vest_0) {
                                this.damage /= 4.0;
                            }
                            final int m = MathHelper.func_76143_f(f3 * this.damage);
                            DamageSource localDamageSource = null;
                            if (this.shootingEntity == null) {
                                localDamageSource = DamageSourceDayM.causeBulletDamage(this, this);
                            }
                            else {
                                localDamageSource = DamageSourceDayM.causeBulletDamage(this, this.shootingEntity);
                            }
                            if (this.func_70027_ad() && !(localMovingObjectPosition1.field_72308_g instanceof EntityEnderman)) {
                                localMovingObjectPosition1.field_72308_g.func_70015_d(5);
                            }
                            if (localMovingObjectPosition1.field_72308_g.func_70097_a(localDamageSource, (float)m)) {
                                if (localMovingObjectPosition1.field_72308_g instanceof EntityLivingBase) {
                                    final Object localObject2 = localMovingObjectPosition1.field_72308_g;
                                    if (this.shootingEntity != null && this.shootingEntity instanceof EntityLivingBase) {
                                        EnchantmentHelper.func_151384_a((EntityLivingBase)localObject2, this.shootingEntity);
                                        EnchantmentHelper.func_151385_b((EntityLivingBase)this.shootingEntity, (Entity)localObject2);
                                    }
                                    if (this.shootingEntity != null && localMovingObjectPosition1.field_72308_g != this.shootingEntity && localMovingObjectPosition1.field_72308_g instanceof EntityPlayer && this.shootingEntity instanceof EntityPlayerMP) {
                                        ((EntityPlayerMP)this.shootingEntity).field_71135_a.func_147359_a((Packet)new S2BPacketChangeGameState(6, 0.0f));
                                    }
                                }
                            }
                            else if (this.passedTru > this.damage) {
                                this.field_70159_w *= -0.1000000014901161;
                                this.field_70181_x *= -0.1000000014901161;
                                this.field_70179_y *= -0.1000000014901161;
                                this.field_70177_z += 180.0f;
                                this.field_70126_B += 180.0f;
                                this.ticksInAir = 0;
                            }
                            else {
                                this.passedTru += 1.2;
                                this.damage -= 0.5;
                            }
                        }
                        if (this.passedTru > this.damage) {
                            this.func_70106_y();
                        }
                        else {
                            this.passedTru += 1.1;
                            this.damage -= 0.5;
                        }
                    }
                    else {
                        this.func_70106_y();
                    }
                }
                else {
                    this.xTile = localMovingObjectPosition1.field_72311_b;
                    this.yTile = localMovingObjectPosition1.field_72312_c;
                    this.zTile = localMovingObjectPosition1.field_72309_d;
                    this.block = this.field_70170_p.func_147439_a(this.xTile, this.yTile, this.zTile);
                    this.inData = this.field_70170_p.func_72805_g(this.xTile, this.yTile, this.zTile);
                    this.field_70159_w = (float)(localMovingObjectPosition1.field_72307_f.field_72450_a - this.field_70165_t);
                    this.field_70181_x = (float)(localMovingObjectPosition1.field_72307_f.field_72448_b - this.field_70163_u);
                    this.field_70179_y = (float)(localMovingObjectPosition1.field_72307_f.field_72449_c - this.field_70161_v);
                    final float f3 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70181_x * this.field_70181_x + this.field_70179_y * this.field_70179_y);
                    this.field_70165_t -= this.field_70159_w / f3 * 0.0500000007450581;
                    this.field_70163_u -= this.field_70181_x / f3 * 0.0500000007450581;
                    this.field_70161_v -= this.field_70179_y / f3 * 0.0500000007450581;
                    this.inGround = true;
                    this.arrowShake = 7;
                    if (this.block.func_149688_o() != Material.field_151579_a) {
                        this.block.func_149670_a(this.field_70170_p, this.xTile, this.yTile, this.zTile, (Entity)this);
                    }
                }
            }
            this.field_70165_t += this.field_70159_w;
            this.field_70163_u += this.field_70181_x;
            this.field_70161_v += this.field_70179_y;
            final float f4 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
            this.field_70177_z = (float)(Math.atan2(this.field_70159_w, this.field_70179_y) * 180.0 / 3.141592741012573);
            this.field_70125_A = (float)(Math.atan2(this.field_70181_x, f4) * 180.0 / 3.141592741012573);
            while (this.field_70125_A - this.field_70127_C < -180.0f) {
                this.field_70127_C -= 360.0f;
            }
            while (this.field_70125_A - this.field_70127_C >= 180.0f) {
                this.field_70127_C += 360.0f;
            }
            while (this.field_70177_z - this.field_70126_B < -180.0f) {
                this.field_70126_B -= 360.0f;
            }
            while (this.field_70177_z - this.field_70126_B >= 180.0f) {
                this.field_70126_B += 360.0f;
            }
            this.field_70125_A = this.field_70127_C + (this.field_70125_A - this.field_70127_C) * 0.2f;
            this.field_70177_z = this.field_70126_B + (this.field_70177_z - this.field_70126_B) * 0.2f;
            float f5 = 0.99f;
            final float f6 = 0.05f;
            if (this.func_70090_H()) {
                for (int n = 0; n < 4; ++n) {
                    final float f7 = 0.25f;
                    this.field_70170_p.func_72869_a("bubble", this.field_70165_t - this.field_70159_w * f7, this.field_70163_u - this.field_70181_x * f7, this.field_70161_v - this.field_70179_y * f7, this.field_70159_w, this.field_70181_x, this.field_70179_y);
                }
                f5 = 0.8f;
            }
            if (this.func_70026_G()) {
                this.func_70066_B();
            }
            this.field_70159_w *= f5;
            this.field_70181_x *= f5;
            this.field_70179_y *= f5;
            this.field_70181_x -= f6 / 45.0f;
            this.func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            this.func_145775_I();
            return;
        }
        final int i = this.field_70170_p.func_72805_g(this.xTile, this.yTile, this.zTile);
        if (localBlock != this.block || i != this.inData) {
            this.inGround = false;
            this.field_70159_w *= this.field_70146_Z.nextFloat() * 0.2f;
            this.field_70181_x *= this.field_70146_Z.nextFloat() * 0.2f;
            this.field_70179_y *= this.field_70146_Z.nextFloat() * 0.2f;
            this.ticksInGround = 0;
            this.ticksInAir = 0;
            return;
        }
        for (int a = 0; a < 16; ++a) {}
        ++this.ticksInGround;
        if (this.ticksInGround == 1200) {
            this.func_70106_y();
        }
        if (this.block.func_149688_o() != Material.field_151577_b) {
            this.func_85030_a(this.block.field_149762_H.func_150495_a(), 1.0f, 1.2f / (this.field_70146_Z.nextFloat() * 0.2f + 0.9f));
        }
        else {
            this.func_85030_a(Block.field_149769_e.func_150495_a(), 1.0f, 1.2f / (this.field_70146_Z.nextFloat() * 0.2f + 0.9f));
        }
        this.func_70106_y();
    }
    
    protected void func_70088_a() {
    }
    
    protected void func_70037_a(final NBTTagCompound arg0) {
    }
    
    protected void func_70014_b(final NBTTagCompound arg0) {
    }
}
