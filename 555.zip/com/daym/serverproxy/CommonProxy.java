package com.daym.serverproxy;

import cpw.mods.fml.common.network.*;
import net.minecraft.nbt.*;
import cpw.mods.fml.common.network.simpleimpl.*;
import net.minecraft.entity.player.*;
import com.daym.clientproxy.*;
import cpw.mods.fml.common.*;
import com.daym.*;
import org.apache.logging.log4j.*;
import cpw.mods.fml.relauncher.*;
import com.daym.logger.*;
import java.io.*;
import java.net.*;
import net.minecraft.world.*;
import com.daym.extended.*;
import com.daym.gui.inventory.*;
import com.daym.inventory.*;
import java.util.*;

public class CommonProxy implements IGuiHandler
{
    private static final Map<String, NBTTagCompound> daym_412347470;
    public static ArrayList<String> daym_3995b8bc0;
    
    public CommonProxy() {
        CommonProxy.daym_3995b8bc0.add("anus");
        CommonProxy.daym_3995b8bc0.add("anal");
        CommonProxy.daym_3995b8bc0.add("arse");
        CommonProxy.daym_3995b8bc0.add("asshole");
        CommonProxy.daym_3995b8bc0.add("assface");
        CommonProxy.daym_3995b8bc0.add("asshat");
        CommonProxy.daym_3995b8bc0.add("assnigger");
        CommonProxy.daym_3995b8bc0.add("bitch");
        CommonProxy.daym_3995b8bc0.add("ballsack");
        CommonProxy.daym_3995b8bc0.add("boob");
        CommonProxy.daym_3995b8bc0.add("breast");
        CommonProxy.daym_3995b8bc0.add("bullshit");
        CommonProxy.daym_3995b8bc0.add("buttfucker");
        CommonProxy.daym_3995b8bc0.add("clit");
        CommonProxy.daym_3995b8bc0.add("cock");
        CommonProxy.daym_3995b8bc0.add("cum");
        CommonProxy.daym_3995b8bc0.add("cunt");
        CommonProxy.daym_3995b8bc0.add("dick");
        CommonProxy.daym_3995b8bc0.add("dildo");
        CommonProxy.daym_3995b8bc0.add("dipshit");
        CommonProxy.daym_3995b8bc0.add("dumass");
        CommonProxy.daym_3995b8bc0.add("dumbass");
        CommonProxy.daym_3995b8bc0.add("dumbshit");
        CommonProxy.daym_3995b8bc0.add("fag");
        CommonProxy.daym_3995b8bc0.add("fuck");
        CommonProxy.daym_3995b8bc0.add("gay");
        CommonProxy.daym_3995b8bc0.add("homo");
        CommonProxy.daym_3995b8bc0.add("jizz");
        CommonProxy.daym_3995b8bc0.add("jackass");
        CommonProxy.daym_3995b8bc0.add("nigger");
        CommonProxy.daym_3995b8bc0.add("nigga");
        CommonProxy.daym_3995b8bc0.add("niglet");
        CommonProxy.daym_3995b8bc0.add("penis");
        CommonProxy.daym_3995b8bc0.add("pussy");
        CommonProxy.daym_3995b8bc0.add("poop");
        CommonProxy.daym_3995b8bc0.add("porn");
        CommonProxy.daym_3995b8bc0.add("prostitute");
        CommonProxy.daym_3995b8bc0.add("queef");
        CommonProxy.daym_3995b8bc0.add("queer");
        CommonProxy.daym_3995b8bc0.add("rimjob");
        CommonProxy.daym_3995b8bc0.add("schlong");
        CommonProxy.daym_3995b8bc0.add("slut");
        CommonProxy.daym_3995b8bc0.add("titties");
        CommonProxy.daym_3995b8bc0.add("tits");
        CommonProxy.daym_3995b8bc0.add("twat");
        CommonProxy.daym_3995b8bc0.add("testicle");
        CommonProxy.daym_3995b8bc0.add("thundercunt");
        CommonProxy.daym_3995b8bc0.add("vagina");
        CommonProxy.daym_3995b8bc0.add("vajayjay");
        CommonProxy.daym_3995b8bc0.add("vjayjay");
        CommonProxy.daym_3995b8bc0.add("wank");
        CommonProxy.daym_3995b8bc0.add("whore");
    }
    
    public boolean isSinglePlayer() {
        return false;
    }
    
    public static EntityPlayer daym_281cc4bf0(final MessageContext ctx) {
        if (ctx.side.isClient()) {
            return ClientProxy.daym_281cc4bf0(ctx);
        }
        return (EntityPlayer)ctx.getServerHandler().field_147369_b;
    }
    
    public static void letServerKnow(final boolean rem) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (!side.isServer() || DayM.daym_053b870d0) {
            return;
        }
        if (FMLCommonHandler.instance().getMinecraftServerInstance().func_71262_S()) {
            try {
                final String ip = daym_c62a8ba60(DayM.daym_1a33edfd0 + "data/ipcheck" + DayM.daym_f51f5ec10);
                final int port = FMLCommonHandler.instance().getMinecraftServerInstance().func_71215_F();
                final String version = "2.1.4_beta";
                final String name = FMLCommonHandler.instance().getMinecraftServerInstance().func_71273_Y();
                if (DayM.daym_b564a6500 || DayM.daym_70a7d6d00) {
                    if (!hasProfanity(name)) {
                        if (FMLCommonHandler.instance().getMinecraftServerInstance().func_71266_T() || DayM.daym_70a7d6d00) {
                            if (name != null) {
                                if (!name.contains("*!*")) {
                                    daym_3d4deb730(ip, port + "", version, name, rem);
                                }
                            }
                            else {
                                LogManager.getLogger().error("[DayM Server POST-INIT - Empty Server Name[MOTD]]");
                            }
                        }
                    }
                    else {
                        LogManager.getLogger().error("[DayM Server Error - MOTD Profanity Detected]");
                    }
                }
                else {
                    LogManager.getLogger().error("[DayM Server POST-INIT - Port error 2]");
                }
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    private static boolean hasProfanity(final String name) {
        final boolean result = false;
        for (final String s : CommonProxy.daym_3995b8bc0) {
            if (name.toLowerCase().contains(s.toLowerCase())) {
                return true;
            }
        }
        return result;
    }
    
    public static void daym_3d4deb730(final String ip, final String port, final String version, final String name, final boolean remove) {
        daymlog.out("(Hosting) ip = " + ip);
        daymlog.out("(Hosting) port = " + port);
        daymlog.out("(Hosting) version = " + version);
        daymlog.out("(Hosting) name = " + name);
        if (name == null) {
            LogManager.getLogger().error("[DayM Server POST-INIT - Error 3]");
            return;
        }
        String doremove = "keep";
        if (remove) {
            doremove = "remove";
        }
        if (name.contains("@") || name.contains("$")) {
            LogManager.getLogger().error("(DayM) Illegal MOTD in server properties.");
            return;
        }
        try {
            final String name2 = name.replaceAll("\\s+", "%20");
            final String test = DayM.daym_1a33edfd0 + "data/rs" + DayM.daym_f51f5ec10 + "?a=" + ip + "&b=" + port + "&c=" + version + "&d=" + name2 + "&e=" + doremove;
            daym_c62a8ba60(test);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static String daym_c62a8ba60(final String urlexec) throws IOException {
        final URL url1 = new URL(urlexec);
        final URLConnection yc = url1.openConnection();
        final BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
        final String inputLine = in.readLine();
        in.close();
        return inputLine;
    }
    
    public static String[] decodeServers(final String si) {
        final String[] sp = si.split("\\$");
        return sp;
    }
    
    public static String[] decodeServerInfo(final String si) {
        final String[] sp = si.split("\\@");
        return sp;
    }
    
    public static boolean daym_b564a6500(final int port) {
        daymlog.out("--------------Testing port " + port);
        Socket s = null;
        try {
            s = new Socket("localhost", port);
            daymlog.out("--------------Port " + port + " is not available");
            return false;
        }
        catch (IOException e2) {
            daymlog.out("--------------Port " + port + " is available");
            return true;
        }
        finally {
            if (s != null) {
                try {
                    s.close();
                }
                catch (IOException e) {
                    throw new RuntimeException("You should handle this error.", e);
                }
            }
        }
    }
    
    public static void storeEntityData(final String name, final NBTTagCompound compound) {
        CommonProxy.daym_412347470.put(name, compound);
    }
    
    public static NBTTagCompound getEntityData(final String name) {
        return CommonProxy.daym_412347470.remove(name);
    }
    
    public Object getClientGuiElement(final int arg0, final EntityPlayer player, final World arg2, final int arg3, final int arg4, final int arg5) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (arg0 == DayM.GUI_CUSTOM_INV) {
            return new GuiPlayerInventoryDayM(player, player.field_71071_by, ExtendedPlayer.get(player).inventory, true);
        }
        if (player.field_71071_by.func_70448_g() == null) {
            return null;
        }
        if (arg0 == DayM.GUIID_ITEM) {
            return new GuiItemInventory(new ContainerItem(player, player.field_71071_by, new ItemInventory(player.func_70694_bm())));
        }
        return null;
    }
    
    public Object getServerGuiElement(final int arg0, final EntityPlayer player, final World arg2, final int arg3, final int arg4, final int arg5) {
        final Side side = FMLCommonHandler.instance().getEffectiveSide();
        if (arg0 == DayM.GUI_CUSTOM_INV) {
            return new PlayerContainerDayM(player, player.field_71071_by, ExtendedPlayer.get(player).inventory);
        }
        if (player.field_71071_by.func_70448_g() == null) {
            return null;
        }
        if (arg0 == DayM.GUIID_ITEM) {
            return new ContainerItem(player, player.field_71071_by, new ItemInventory(player.func_70694_bm()));
        }
        return null;
    }
    
    static {
        daym_412347470 = new HashMap<String, NBTTagCompound>();
        CommonProxy.daym_3995b8bc0 = new ArrayList<String>();
    }
}
