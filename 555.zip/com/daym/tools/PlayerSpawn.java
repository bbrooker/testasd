package com.daym.tools;

public class PlayerSpawn
{
    public String location;
    public int chance;
    public int x;
    public int y;
    public int z;
    
    public PlayerSpawn(final int c, final int xx, final int yy, final int zz) {
        this.chance = c;
        this.x = xx;
        this.y = yy;
        this.z = zz;
        this.updateLocation();
    }
    
    public void updateLocation() {
        this.location = this.chance + "." + this.x + "." + this.y + "." + this.z + "|";
    }
}
