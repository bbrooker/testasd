package com.daym.tools;

public class ZombieSpawn
{
    public String location;
    public int type;
    public int chance;
    public int radius;
    public int amount;
    public int randomize;
    public int x;
    public int y;
    public int z;
    
    public ZombieSpawn(final int t, final int c, final int r, final int a, final int rand, final int xx, final int yy, final int zz) {
        this.type = 0;
        this.chance = 0;
        this.radius = 0;
        this.amount = 0;
        this.randomize = 0;
        this.x = 0;
        this.y = 0;
        this.z = 0;
        this.type = t;
        this.chance = c;
        this.radius = r;
        this.amount = a;
        this.randomize = rand;
        this.x = xx;
        this.y = yy;
        this.z = zz;
        this.updateLocation();
    }
    
    public void updateLocation() {
        this.location = this.type + "." + this.chance + "." + this.radius + "." + this.amount + "." + this.randomize + "." + this.x + "." + this.y + "." + this.z + "|";
    }
}
