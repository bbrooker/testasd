package com.daym.tools;

import java.util.*;

public class LootSpawn
{
    public String location;
    public int tableID;
    public int radius;
    public ArrayList<Integer> lootTable;
    public ArrayList<Integer> lootTableChance;
    public int chance;
    public int x;
    public int y;
    public int z;
    
    public LootSpawn(final ArrayList<Integer> table, final ArrayList<Integer> tablec, final int t, final int r, final int c, final int xx, final int yy, final int zz) {
        this.tableID = 0;
        this.radius = 0;
        this.chance = 0;
        this.x = 0;
        this.y = 0;
        this.z = 0;
        this.lootTable = table;
        this.lootTableChance = tablec;
        this.tableID = t;
        this.radius = r;
        this.chance = c;
        this.x = xx;
        this.y = yy;
        this.z = zz;
        this.updateLocation();
    }
    
    public void updateLocation() {
        final String lootTableString = encodeLootTable(this.lootTable, this.lootTableChance);
        this.location = lootTableString + "." + this.tableID + "." + this.radius + "." + this.chance + "." + this.x + "." + this.y + "." + this.z + "|";
    }
    
    public static String encodeLootTable(final ArrayList<Integer> lt, final ArrayList<Integer> lt2) {
        String result = "";
        int i = 0;
        for (final Integer ints : lt) {
            try {
                result = result + ints + "?" + lt2.get(i) + ",";
            }
            catch (Exception ex) {}
            ++i;
        }
        return result;
    }
    
    public static ArrayList<String> decodeLootTable(final String lt) {
        final ArrayList<String> ail = new ArrayList<String>();
        final String[] arr$;
        final String[] result = arr$ = lt.split("\\,");
        for (final String str : arr$) {
            try {
                ail.add(str);
            }
            catch (Exception ex) {}
        }
        return ail;
    }
}
